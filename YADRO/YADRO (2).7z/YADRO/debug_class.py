import sys
sys.path.append('modules')

from parserr import YadroParser
from lexer import Lexer, TokenType

source = """class Person:
    name: string
    age: int"""

lexer = Lexer(source)
tokens = lexer.tokenize()

parser = YadroParser(tokens)
try:
    # Let's manually step through the parsing
    print(f"Parser position before parse_statement: {parser.current}")
    
    # Parse the class declaration
    ast = parser.parse_statement()
    print('\nAST:', ast)
    print('Class name:', ast.name)
    print('Fields:', ast.fields)
    print('Methods:', ast.methods)
    
    # Let's see what happened during parsing
    print(f"\nParser position after parse_statement: {parser.current}")
    print(f"Current token: {parser.peek() if not parser.is_at_end() else 'EOF'}")
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
    print(f"Parser position at error: {parser.current}")
    print(f"Current token: {parser.peek() if not parser.is_at_end() else 'EOF'}")
