# YADRO Parser Test Suite

This directory contains comprehensive tests for the YADRO parser module according to YUP specifications 26.1.1-26.1.4.

## Test Structure

### Core Test Modules
- `test_parser_expressions.py` - Expression parsing with precedence
- `test_parser_directives.py` - Compiler directives (#target, #import, etc.)
- `test_parser_declarations.py` - Variable and constant declarations
- `test_parser_functions.py` - Function declarations and calls
- `test_parser_classes.py` - Class and trait declarations
- `test_parser_control_flow.py` - Control flow statements (if, for, while, etc.)
- `test_parser_errors.py` - Error handling and recovery
- `test_parser_constitutional.py` - Constitutional compliance (YUP 26.1.3)
- `test_parser_integration.py` - Integration tests with lexer

### Test Infrastructure
- `conftest.py` - Pytest configuration and shared fixtures
- `utils.py` - Test utilities and helper functions
- `fixtures/` - Test code samples and data

## Current Status

### Working Tests
✅ Basic literal expressions (int, float, string, char, bool)
✅ Basic identifier expressions
✅ Some arithmetic binary expressions
✅ Some directive parsing (with corrected syntax)

### Issues Identified
❌ Some logical operators not implemented in lexer (xor, nand)
❌ Some assignment operators not implemented (<<=, >>=)
❌ Array indexing syntax differs from expectations
❌ Pipeline expression parsing needs adjustment
❌ Lambda expression syntax differs
❌ Some directive formats need adjustment

### Parser vs Test Misalignments
1. **Directive Format**: Parser expects `#target "string";` not multiline format
2. **Operator Support**: Some operators in tests not in lexer
3. **Expression Syntax**: Some complex expressions need syntax adjustment
4. **Type Annotations**: Array and generic syntax may differ

## Running Tests

```bash
# Run all tests
python -m pytest tests/ -v

# Run specific test module
python -m pytest tests/test_parser_expressions.py -v

# Run with coverage
python -m pytest tests/ --cov=modules/parserr --cov-report=html

# Run only passing tests
python -m pytest tests/ -v -k "not failing"
```

## Test Coverage Goals

- **Line Coverage**: >95% of parser code
- **Branch Coverage**: >90% of decision points
- **Feature Coverage**: 100% of documented language features
- **Error Coverage**: 100% of error conditions

## Next Steps

1. **Fix Syntax Mismatches**: Align test syntax with actual parser implementation
2. **Complete Missing Features**: Implement missing operators and expressions
3. **Enhance Error Tests**: Improve error handling test coverage
4. **Add Performance Tests**: Test large program parsing
5. **Constitutional Compliance**: Complete YUP 26.1.3 verification

## Notes

- Tests are designed to be comprehensive and maintainable
- Uses pytest fixtures and parameterized tests for efficiency
- Includes both positive and negative test cases
- Constitutional compliance tests ensure YUP 26.1.3 adherence
- Integration tests verify lexer-parser compatibility
