"""Pytest configuration and shared fixtures for parser tests."""

import pytest
import sys
import os
from pathlib import Path

# Add the modules directory to the path so we can import the parser
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'modules'))

from parserr import YadroParser, ParseError, Program
from lexer import Lexer, TokenType


@pytest.fixture
def parser():
    """Create a fresh parser instance for each test."""
    def create_parser(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        return YadroParser(tokens)
    return create_parser


@pytest.fixture
def parse_program():
    """Parse a complete program and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        return parser.parse_program()
    return parse


@pytest.fixture
def parse_expression():
    """Parse a single expression and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        return parser.parse_expression()
    return parse


@pytest.fixture
def parse_statement():
    """Parse a single statement and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        return parser.parse_statement()
    return parse


@pytest.fixture
def sample_tokens():
    """Provide sample tokens for testing."""
    return [
        TokenType.Int, TokenType.Plus, TokenType.Int, TokenType.Semicolon,
        TokenType.IDENTIFIER, TokenType.Assign, TokenType.String, TokenType.Semicolon
    ]


@pytest.fixture
def valid_yadro_code():
    """Sample valid YADRO code for testing."""
    return """
#target
os = "linux"
arch = "x86-64"

let x = 42;
var y: int = 10;
const PI: float = 3.14159;

fun add(a: int, b: int) -> int:
    return a + b

if x > 0:
    cli.print("Positive")
else:
    cli.print("Non-positive")
"""


@pytest.fixture
def expression_samples():
    """Sample expressions for testing."""
    return {
        'literals': [
            ('42', 'int'),
            ('3.14', 'float'),
            ('"hello"', 'string'),
            ('\'a\'', 'char'),
            ('true', 'bool'),
            ('false', 'bool'),
        ],
        'binary_ops': [
            ('1 + 2', 'addition'),
            ('3 - 4', 'subtraction'),
            ('5 * 6', 'multiplication'),
            ('7 / 8', 'division'),
            ('9 % 10', 'modulo'),
            ('1 and 2', 'logical_and'),
            ('1 or 2', 'logical_or'),
            ('1 == 2', 'equality'),
            ('1 != 2', 'inequality'),
            ('1 < 2', 'less_than'),
            ('1 > 2', 'greater_than'),
            ('1 <= 2', 'less_equal'),
            ('1 >= 2', 'greater_equal'),
        ],
        'unary_ops': [
            ('-x', 'negation'),
            ('!x', 'logical_not'),
            ('~x', 'bitwise_not'),
            ('*x', 'dereference'),
        ],
        'assignments': [
            ('x = 42', 'simple_assignment'),
            ('x += 1', 'plus_assign'),
            ('x -= 1', 'minus_assign'),
            ('x *= 2', 'star_assign'),
            ('x /= 2', 'slash_assign'),
        ],
        'complex': [
            ('1 + 2 * 3', 'precedence'),
            ('(1 + 2) * 3', 'parentheses'),
            'func(arg1, arg2)',
            'obj.property',
            'array[index]',
            'TypeName[int, string]',
        ]
    }


def assert_ast_node_type(node, expected_type):
    """Helper to assert AST node type."""
    assert node.__class__.__name__ == expected_type, f"Expected {expected_type}, got {node.__class__.__name__}"


def assert_parse_error(parse_func, source_code, expected_message=None):
    """Helper to assert that parsing raises ParseError."""
    with pytest.raises(ParseError) as exc_info:
        parse_func(source_code)
    
    if expected_message:
        assert expected_message in str(exc_info.value)


def assert_no_parse_errors(parse_func, source_code):
    """Helper to assert that parsing completes without errors."""
    try:
        result = parse_func(source_code)
        return result
    except ParseError as e:
        pytest.fail(f"Unexpected ParseError: {e}")


# Custom markers for different test categories
def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line("markers", "expressions: Tests for expression parsing")
    config.addinivalue_line("markers", "directives: Tests for compiler directives")
    config.addinivalue_line("markers", "declarations: Tests for variable/constant declarations")
    config.addinivalue_line("markers", "functions: Tests for function declarations")
    config.addinivalue_line("markers", "classes: Tests for class and trait declarations")
    config.addinivalue_line("markers", "control_flow: Tests for control flow statements")
    config.addinivalue_line("markers", "types: Tests for type system parsing")
    config.addinivalue_line("markers", "advanced: Tests for advanced features")
    config.addinivalue_line("markers", "errors: Tests for error handling")
    config.addinivalue_line("markers", "constitutional: Tests for constitutional compliance")
    config.addinivalue_line("markers", "integration: Integration tests")
