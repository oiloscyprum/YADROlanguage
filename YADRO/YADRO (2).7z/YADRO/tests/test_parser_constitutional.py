"""Tests for constitutional compliance per YUP 26.1.3.

These tests ensure the parser enforces the constitutional principles:
- Article I: Primacy of Static Verification
- Article II: Explicit Intent  
- Article III: Zero-Cost Abstraction Hierarchy
- Article IV: Determinism and Composability
"""

import pytest
from parserr import ParseError, YadroParser
from lexer import Lexer


@pytest.mark.constitutional
class TestArticleI_StaticVerification:
    """Test Article I: The correctness and safety of a program must be provable at compile time."""
    
    def test_parse_time_safety_checks(self, parse_program):
        """Test that parser performs safety checks at parse time."""
        # Parser should reject constructs that cannot be statically verified
        source = """
#target
os = "linux"
arch = "x86-64"

let x: int = "not an int"  # Type mismatch should be detectable
"""
        # This might be caught at semantic analysis, but parser should structure for it
        try:
            ast = parse_program(source)
            # Parser should create AST structure that enables static verification
            assert len(ast.statements) >= 1
        except ParseError:
            pass  # Parser might catch obvious errors
    
    def test_no_implicit_global_state(self, parse_program):
        """Test that parser rejects implicit global state (Article I.4)."""
        # Parser should not allow implicit global behavior
        source = """
let x = 42
# No implicit globals should be allowed
"""
        ast = parse_program(source)
        # All state should be explicitly declared
        for stmt in ast.statements:
            # Each statement should have explicit declaration
            assert hasattr(stmt, 'line') and hasattr(stmt, 'column')
    
    def test_explicit_type_annotations_support(self, parse_statement):
        """Test that parser supports explicit type annotations for static verification."""
        source = 'let x: int = 42;'
        ast = parse_statement(source)
        
        # Should have explicit type information
        assert hasattr(ast, 'type_annotation')
        assert ast.type_annotation is not None
    
    def test_no_dynamic_type_inference_violations(self, parse_program):
        """Test that parser structure supports static type checking."""
        source = """
let x = 42
let y = "hello"
let z = x + y  # This should be caught by semantic analysis
"""
        try:
            ast = parse_program(source)
            # Parser should create structure that enables type checking
            assert len(ast.statements) == 3
        except ParseError:
            pass  # Parser might catch obvious syntax errors


@pytest.mark.constitutional
class TestArticleII_ExplicitIntent:
    """Test Article II: Code must unambiguously express programmer intent."""
    
    def test_no_hidden_control_flow(self, parse_program):
        """Test that parser rejects hidden control flow (Article II.1)."""
        # All control flow should be explicit
        source = """
if x > 0:
    cli.print("positive")
else:
    cli.print("non-positive")
"""
        ast = parse_program(source)
        
        # Control flow should be explicitly represented in AST
        assert hasattr(ast.statements[0], 'condition')
        assert hasattr(ast.statements[0], 'then_branch')
        assert hasattr(ast.statements[0], 'else_branch')
    
    def test_explicit_environmental_declarations(self, parse_program):
        """Test that parser requires explicit environmental declarations (Article II.2)."""
        source = """
#target
os = "linux"
arch = "x86-64"
optimization = "speed"
"""
        ast = parse_program(source)
        
        # Target configuration should be explicit
        assert isinstance(ast.statements[0], type(parse_program.__self__.parse_program("#target os").statements[0]))
    
    def test_explicit_cost_semantics(self, parse_expression):
        """Test that parser preserves cost semantics (Article II.3)."""
        # Different operations should have different AST representations
        addition = parse_expression("1 + 2")
        multiplication = parse_expression("1 * 2")
        function_call = parse_expression("func()")
        
        # Each should have distinct AST structure reflecting different costs
        assert type(addition) != type(multiplication)
        assert type(addition) != type(function_call)
    
    def test_no_implicit_conversions(self, parse_program):
        """Test that parser doesn't allow implicit type conversions."""
        source = """
let x: int = 42
let y: float = 3.14
# No implicit conversion should be allowed
"""
        ast = parse_program(source)
        
        # Types should be explicitly preserved
        int_decl = ast.statements[0]
        float_decl = ast.statements[1]
        assert int_decl.type_annotation.name == "int"
        assert float_decl.type_annotation.name == "float"


@pytest.mark.constitutional
class TestArticleIII_ZeroCostAbstractions:
    """Test Article III: Zero-Cost Abstraction Hierarchy."""
    
    def test_abstraction_without_overhead_structure(self, parse_expression):
        """Test that parser structure enables zero-cost abstractions (Article III.1)."""
        # High-level constructs should have parseable structure
        pipeline = parse_expression("value >>> func1 >>> func2")
        explicit_call = parse_expression("func2(func1(value))")
        
        # Both should be representable in AST for optimization
        assert hasattr(pipeline, 'expressions')
        assert hasattr(explicit_call, 'callee')
    
    def test_seamless_interoperation_structure(self, parse_program):
        """Test parser supports seamless safe/unsafe interoperation (Article III.2)."""
        source = """
let safe_var = 42
#[unsafe]
let unsafe_ptr = &safe_var
"""
        try:
            ast = parse_program(source)
            # Should support both safe and unsafe contexts
            assert len(ast.statements) >= 1
        except ParseError:
            pass  # Parser structure should support this
    
    def test_escape_hatch_structure(self, parse_program):
        """Test that parser structure supports escape hatches (Article III.3)."""
        source = """
#[unsafe]
fun low_level_operation():
    asm("mov %eax, %eax"):
        # No inputs/outputs
"""
        try:
            ast = parse_program(source)
            # Should support unsafe blocks and assembly
            assert len(ast.statements) >= 1
        except ParseError:
            pass  # Parser should structure for this


@pytest.mark.constitutional
class TestArticleIV_DeterminismAndComposability:
    """Test Article IV: Determinism and Composability."""
    
    def test_no_global_mutable_state(self, parse_program):
        """Test that parser doesn't allow unmanaged global mutable state (Article IV.1)."""
        source = """
let x = 42  # Local state
# No implicit global mutable state should be allowed
"""
        ast = parse_program(source)
        
        # All state should be explicitly declared and scoped
        for stmt in ast.statements:
            assert hasattr(stmt, 'name') or hasattr(stmt, 'condition')  # Explicit declarations
    
    def test_modular_reasoning_structure(self, parse_program):
        """Test that parser structure enables modular reasoning (Article IV.2)."""
        source = """
fun add(a: int, b: int) -> int:
    return a + b

fun multiply(a: int, b: int) -> int:
    return a * b

fun combine(x: int, y: int) -> int:
    return add(x, y) * multiply(x, y)
"""
        ast = parse_program(source)
        
        # Each function should be independently analyzable
        assert len(ast.statements) == 3
        for stmt in ast.statements:
            assert hasattr(stmt, 'name')
            assert hasattr(stmt, 'params')
            assert hasattr(stmt, 'body')
    
    def test_side_effects_in_type_structure(self, parse_program):
        """Test that parser structure tracks side effects (Article IV.3)."""
        source = """
fun pure_function(x: int) -> int:
    return x * 2

#[unsafe]
fun side_effect_function():
    asm("int $0x80":)  # System call
"""
        try:
            ast = parse_program(source)
            # Should distinguish between pure and effectful functions
            assert len(ast.statements) >= 1
        except ParseError:
            pass  # Parser should structure for this


@pytest.mark.constitutional
class TestConstitutionalViolations:
    """Test detection of constitutional violations."""
    
    def test_implicit_global_state_violation(self, parse_program):
        """Test detection of implicit global state violations."""
        # This should be structured to allow detection
        source = """
let x = 42
# Any implicit global behavior would be a violation
"""
        ast = parse_program(source)
        # Parser should create structure that enables violation detection
        assert all(hasattr(stmt, 'line') for stmt in ast.statements)
    
    def test_hidden_control_flow_violation(self, parse_program):
        """Test detection of hidden control flow violations."""
        source = """
if condition:
    do_something()
# All control flow should be explicit
"""
        ast = parse_program(source)
        # Control flow should be explicitly represented
        if_stmt = ast.statements[0]
        assert hasattr(if_stmt, 'condition')
    
    def test_magic_type_inference_violation(self, parse_program):
        """Test detection of magic type inference violations."""
        source = """
let x: int = 42  # Explicit type
let y = "hello"   # Type inference should be limited
"""
        ast = parse_program(source)
        # Parser should preserve type information for checking
        explicit_decl = ast.statements[0]
        assert explicit_decl.type_annotation is not None


@pytest.mark.constitutional
class TestConstitutionalCompliance:
    """Test overall constitutional compliance."""
    
    def test_static_verification_compliance(self, parse_program):
        """Test overall compliance with static verification requirements."""
        source = """
#target
os = "linux"
arch = "x86-64"

let x: int = 42
var y: string = "hello"

fun safe_function(a: int, b: int) -> int:
    return a + b

if x > 0:
    cli.print("positive")
else:
    cli.print("non-positive")
"""
        ast = parse_program(source)
        
        # Should create structure that enables all constitutional checks
        assert len(ast.statements) >= 1
        for stmt in ast.statements:
            # Each statement should have explicit location for verification
            assert hasattr(stmt, 'line')
            assert hasattr(stmt, 'column')
    
    def test_explicit_intent_compliance(self, parse_program):
        """Test compliance with explicit intent requirements."""
        source = """
#target os = "linux"  # Explicit target
#plugin safety-opt     # Explicit plugins

let result: Option[int] = Some(42)  # Explicit types
"""
        ast = parse_program(source)
        
        # All declarations should be explicit
        for stmt in ast.statements:
            assert hasattr(stmt, 'line')  # Explicit location
    
    def test_determinism_compliance(self, parse_program):
        """Test compliance with determinism requirements."""
        source = """
fun deterministic_function(x: int) -> int:
    let y = x * 2
    return y + 1
"""
        ast = parse_program(source)
        
        # Function behavior should be determinable from inputs
        func_stmt = ast.statements[0]
        assert hasattr(func_stmt, 'params')
        assert hasattr(func_stmt, 'body')
        assert len(func_stmt.params) == 1


@pytest.mark.constitutional
@pytest.mark.parametrize("compliant_source,article", [
    ("let x: int = 42;", "I"),  # Static verification
    ("#target os = \"linux\"", "II"),  # Explicit intent
    ("value >>> func1 >>> func2", "III"),  # Zero-cost abstraction
    ("fun pure(x: int) -> int: return x * 2", "IV"),  # Determinism
])
def test_constitutional_compliance_parameterized(parse_program, compliant_source, article):
    """Parameterized test for constitutional compliance."""
    try:
        ast = parse_program(compliant_source)
        # Should parse successfully and create compliant structure
        assert len(ast.statements) >= 1
    except ParseError:
        # Should not fail on constitutional code
        pytest.fail(f"Constitutional code for Article {article} failed to parse")


@pytest.mark.constitutional
class TestConstitutionalInfrastructure:
    """Test that parser infrastructure supports constitutional enforcement."""
    
    def test_ast_location_tracking(self, parse_program):
        """Test that AST tracks locations for constitutional enforcement."""
        source = """
let x = 42
let y = "hello"
"""
        ast = parse_program(source)
        
        # All nodes should have location information
        for stmt in ast.statements:
            assert hasattr(stmt, 'line')
            assert hasattr(stmt, 'column')
            assert stmt.line > 0
            assert stmt.column > 0
    
    def test_error_message_constitutional_compliance(self, parse_program):
        """Test that error messages support constitutional compliance."""
        with pytest.raises(ParseError) as exc_info:
            parse_program("const MISSING_INIT;")
        
        error_message = str(exc_info.value)
        # Error messages should be explicit and actionable
        assert "Parse error" in error_message
        assert len(error_message) > 10
    
    def test_parser_state_transparency(self, parse_program):
        """Test that parser state is transparent for constitutional checking."""
        source = """
let x = 42
"""
        ast = parse_program(source)
        
        # AST should be transparent for constitutional analysis
        assert hasattr(ast, 'statements')
        assert isinstance(ast.statements, list)


if __name__ == "__main__":
    pytest.main([__file__])
