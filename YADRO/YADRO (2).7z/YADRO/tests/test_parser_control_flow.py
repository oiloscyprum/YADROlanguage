"""Tests for control flow statement parsing in YADRO parser."""

import pytest
from parserr import (
    IfStmt, SwitchStmt, ForStmt, WhileStmt, RepeatStmt, ReturnStmt,
    BreakStmt, ContinueStmt, DelStmt, ExprStmt, BlockStmt, VarDecl,
    LiteralExpr, IdentifierExpr, BinaryExpr, ParseError
)


@pytest.mark.control_flow
class TestIfStatements:
    """Test parsing of if statements."""
    
    def test_simple_if_statement(self, parse_statement):
        """Test parsing of simple if statement."""
        source = """if x > 0:
    cli.print("positive")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert isinstance(ast.condition, BinaryExpr)
        assert ast.condition.operator == ">"
        assert len(ast.then_branch) == 1
        assert isinstance(ast.then_branch[0], ExprStmt)
        assert len(ast.elif_branches) == 0
        assert ast.else_branch is None
    
    def test_if_else_statement(self, parse_statement):
        """Test parsing of if-else statement."""
        source = """if x > 0:
    cli.print("positive")
else:
    cli.print("non-positive")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert isinstance(ast.condition, BinaryExpr)
        assert len(ast.then_branch) == 1
        assert len(ast.elif_branches) == 0
        assert len(ast.else_branch) == 1
        assert isinstance(ast.else_branch[0], ExprStmt)
    
    def test_if_elsif_else_statement(self, parse_statement):
        """Test parsing of if-elsif-else statement."""
        source = """if x > 0:
    cli.print("positive")
elsif x < 0:
    cli.print("negative")
else:
    cli.print("zero")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert len(ast.then_branch) == 1
        assert len(ast.elif_branches) == 1
        assert len(ast.else_branch) == 1
        
        # Check elsif branch
        elif_condition, elif_branch = ast.elif_branches[0]
        assert isinstance(elif_condition, BinaryExpr)
        assert elif_condition.operator == "<"
        assert len(elif_branch) == 1
    
    def test_multiple_elsif_branches(self, parse_statement):
        """Test parsing of if statement with multiple elsif branches."""
        source = """if x > 100:
    cli.print("large")
elsif x > 50:
    cli.print("medium")
elsif x > 0:
    cli.print("small")
else:
    cli.print("zero or negative")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert len(ast.then_branch) == 1
        assert len(ast.elif_branches) == 2
        assert len(ast.else_branch) == 1
    
    def test_complex_if_condition(self, parse_statement):
        """Test parsing of if statement with complex condition."""
        source = """if x > 0 and y < 10:
    cli.print("in range")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert isinstance(ast.condition, BinaryExpr)
        assert ast.condition.operator == "and"
    
    def test_multi_statement_if_block(self, parse_statement):
        """Test parsing of if statement with multiple statements in block."""
        source = """if x > 0:
    cli.print("positive")
    let y = x * 2
    cli.print(y)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert len(ast.then_branch) == 3
        assert isinstance(ast.then_branch[0], ExprStmt)
        assert isinstance(ast.then_branch[1], VarDecl)
        assert isinstance(ast.then_branch[2], ExprStmt)


@pytest.mark.control_flow
class TestSwitchStatements:
    """Test parsing of switch statements."""
    
    def test_simple_switch_statement(self, parse_statement):
        """Test parsing of simple switch statement."""
        source = """switch x:
case 1:
    cli.print("one")
case 2:
    cli.print("two")
default:
    cli.print("other")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, SwitchStmt)
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "x"
        assert len(ast.cases) == 2
        assert ast.default_case is not None
        assert len(ast.default_case) == 1
    
    def test_switch_without_default(self, parse_statement):
        """Test parsing of switch statement without default case."""
        source = """switch x:
case 1:
    cli.print("one")
case 2:
    cli.print("two")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, SwitchStmt)
        assert len(ast.cases) == 2
        assert ast.default_case is None
    
    def test_switch_with_complex_patterns(self, parse_statement):
        """Test parsing of switch statement with complex patterns."""
        source = """switch value:
case x > 0:
    cli.print("positive")
case x < 0:
    cli.print("negative")
case x == 0:
    cli.print("zero")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, SwitchStmt)
        assert len(ast.cases) == 3
        assert ast.default_case is None
        
        # Check that patterns are expressions
        for case_pattern, case_branch in ast.cases:
            assert isinstance(case_pattern, BinaryExpr)
            assert len(case_branch) == 1
    
    def test_multi_statement_switch_cases(self, parse_statement):
        """Test parsing of switch statement with multiple statements per case."""
        source = """switch option:
case Some(value):
    cli.print("has value")
    cli.print(value)
case None:
    cli.print("no value")
    return -1"""
        ast = parse_statement(source)
        
        assert isinstance(ast, SwitchStmt)
        assert len(ast.cases) == 2
        
        # First case should have 2 statements
        assert len(ast.cases[0][1]) == 2
        # Second case should have 2 statements
        assert len(ast.cases[1][1]) == 2


@pytest.mark.control_flow
class TestForLoops:
    """Test parsing of for loop statements."""
    
    def test_simple_for_loop(self, parse_statement):
        """Test parsing of simple for loop."""
        source = """for item in collection:
    cli.print(item)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ForStmt)
        assert ast.variable == "item"
        assert isinstance(ast.iterable, IdentifierExpr)
        assert ast.iterable.name == "collection"
        assert len(ast.body) == 1
        assert isinstance(ast.body[0], ExprStmt)
    
    def test_for_loop_with_type_annotation(self, parse_statement):
        """Test parsing of for loop with type annotation."""
        source = """for int item in numbers:
    cli.print(item)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ForStmt)
        assert ast.variable == "item"
        assert isinstance(ast.iterable, IdentifierExpr)
        assert ast.iterable.name == "numbers"
    
    def test_multi_statement_for_loop(self, parse_statement):
        """Test parsing of for loop with multiple statements."""
        source = """for item in collection:
    cli.print("processing:", item)
    let processed = item * 2
    cli.print("result:", processed)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ForStmt)
        assert len(ast.body) == 3
        assert isinstance(ast.body[0], ExprStmt)
        assert isinstance(ast.body[1], VarDecl)
        assert isinstance(ast.body[2], ExprStmt)
    
    def test_nested_for_loops(self, parse_statement):
        """Test parsing of nested for loops."""
        source = """for i in range(10):
    for j in range(5):
        cli.print(i, j)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ForStmt)
        assert len(ast.body) == 1
        assert isinstance(ast.body[0], ForStmt)
        assert ast.body[0].variable == "j"
        assert len(ast.body[0].body) == 1


@pytest.mark.control_flow
class TestWhileLoops:
    """Test parsing of while loop statements."""
    
    def test_simple_while_loop(self, parse_statement):
        """Test parsing of simple while loop."""
        source = """while x > 0:
    cli.print(x)
    x = x - 1"""
        ast = parse_statement(source)
        
        assert isinstance(ast, WhileStmt)
        assert isinstance(ast.condition, BinaryExpr)
        assert ast.condition.operator == ">"
        assert len(ast.body) == 2
        assert isinstance(ast.body[0], ExprStmt)
        assert isinstance(ast.body[1], VarDecl)
    
    def test_while_loop_with_complex_condition(self, parse_statement):
        """Test parsing of while loop with complex condition."""
        source = """while x > 0 and not finished:
    process(x)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, WhileStmt)
        assert isinstance(ast.condition, BinaryExpr)
        assert ast.condition.operator == "and"
    
    def test_single_statement_while_loop(self, parse_statement):
        """Test parsing of while loop with single statement."""
        source = """while running:
    tick()"""
        ast = parse_statement(source)
        
        assert isinstance(ast, WhileStmt)
        assert isinstance(ast.condition, IdentifierExpr)
        assert ast.condition.name == "running"
        assert len(ast.body) == 1


@pytest.mark.control_flow
class TestRepeatLoops:
    """Test parsing of repeat-until loop statements."""
    
    def test_simple_repeat_loop(self, parse_statement):
        """Test parsing of simple repeat loop."""
        source = """repeat:
    cli.print("looping")
until x > 10"""
        ast = parse_statement(source)
        
        assert isinstance(ast, RepeatStmt)
        assert len(ast.body) == 1
        assert isinstance(ast.body[0], ExprStmt)
        assert isinstance(ast.until_condition, BinaryExpr)
        assert ast.until_condition.operator == ">"
    
    def test_multi_statement_repeat_loop(self, parse_statement):
        """Test parsing of repeat loop with multiple statements."""
        source = """repeat:
    x = x + 1
    cli.print("iteration:", x)
    if x > 100:
        break
until finished"""
        ast = parse_statement(source)
        
        assert isinstance(ast, RepeatStmt)
        assert len(ast.body) == 3
        assert isinstance(ast.until_condition, IdentifierExpr)
        assert ast.until_condition.name == "finished"


@pytest.mark.control_flow
class TestReturnStatements:
    """Test parsing of return statements."""
    
    def test_return_without_value(self, parse_statement):
        """Test parsing of return statement without value."""
        source = 'return;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ReturnStmt)
        assert ast.expression is None
    
    def test_return_with_value(self, parse_statement):
        """Test parsing of return statement with value."""
        source = 'return 42;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ReturnStmt)
        assert isinstance(ast.expression, LiteralExpr)
        assert ast.expression.value == 42
    
    def test_return_with_complex_expression(self, parse_statement):
        """Test parsing of return statement with complex expression."""
        source = 'return x * 2 + y;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ReturnStmt)
        assert isinstance(ast.expression, BinaryExpr)
    
    def test_return_with_function_call(self, parse_statement):
        """Test parsing of return statement with function call."""
        source = 'return calculate_result();'
        ast = parse_statement(source)
        
        assert isinstance(ast, ReturnStmt)
        assert hasattr(ast.expression, 'callee')  # CallExpr


@pytest.mark.control_flow
class TestBreakAndContinue:
    """Test parsing of break and continue statements."""
    
    def test_break_statement(self, parse_statement):
        """Test parsing of break statement."""
        source = 'break;'
        ast = parse_statement(source)
        
        assert isinstance(ast, BreakStmt)
    
    def test_continue_statement(self, parse_statement):
        """Test parsing of continue statement."""
        source = 'continue;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ContinueStmt)


@pytest.mark.control_flow
class TestDelStatements:
    """Test parsing of del statements."""
    
    def test_del_statement(self, parse_statement):
        """Test parsing of del statement."""
        source = 'del resource;'
        ast = parse_statement(source)
        
        assert isinstance(ast, DelStmt)
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "resource"
    
    def test_del_with_member_access(self, parse_statement):
        """Test parsing of del statement with member access."""
        source = 'del obj.resource;'
        ast = parse_statement(source)
        
        assert isinstance(ast, DelStmt)
        assert hasattr(ast.expression, 'property')  # MemberExpr


@pytest.mark.control_flow
class TestComplexControlFlow:
    """Test parsing of complex control flow scenarios."""
    
    def test_nested_control_flow(self, parse_statement):
        """Test parsing of nested control flow structures."""
        source = """if x > 0:
    for i in range(10):
        if i > 5:
            break
        else:
            continue"""
        ast = parse_statement(source)
        
        assert isinstance(ast, IfStmt)
        assert len(ast.then_branch) == 1
        assert isinstance(ast.then_branch[0], ForStmt)
        assert len(ast.then_branch[0].body) == 1
        assert isinstance(ast.then_branch[0].body[0], IfStmt)
    
    def test_switch_with_loops(self, parse_statement):
        """Test parsing of switch statement containing loops."""
        source = """switch mode:
case "process":
    for item in items:
        process(item)
case "search":
    while not found:
        search()
default:
    cli.print("unknown mode")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, SwitchStmt)
        assert len(ast.cases) == 2
        assert ast.default_case is not None
        
        # Check first case contains for loop
        assert isinstance(ast.cases[0][1][0], ForStmt)
        # Check second case contains while loop
        assert isinstance(ast.cases[1][1][0], WhileStmt)


@pytest.mark.control_flow
class TestControlFlowErrors:
    """Test error handling in control flow parsing."""
    
    def test_if_without_condition(self, parse_statement):
        """Test error handling for if without condition."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement("""if:
    cli.print("no condition")""")
    
    def test_for_without_in(self, parse_statement):
        """Test error handling for for without in clause."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement("""for item collection:
    cli.print(item)""")
    
    def test_while_without_condition(self, parse_statement):
        """Test error handling for while without condition."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement("""while:
    cli.print("no condition")""")
    
    def test_repeat_without_until(self, parse_statement):
        """Test error handling for repeat without until."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement("""repeat:
    cli.print("no until")""")


@pytest.mark.control_flow
@pytest.mark.parametrize("source,expected_type", [
    ('if x > 0: cli.print("positive")', IfStmt),
    ('switch x: case 1: cli.print("one")', SwitchStmt),
    ('for item in collection: cli.print(item)', ForStmt),
    ('while x > 0: cli.print(x)', WhileStmt),
    ('repeat: cli.print("loop") until x > 10', RepeatStmt),
    ('return 42;', ReturnStmt),
    ('break;', BreakStmt),
    ('continue;', ContinueStmt),
    ('del resource;', DelStmt),
])
def test_control_flow_parameterized(parse_statement, source, expected_type):
    """Parameterized test for all control flow statement types."""
    ast = parse_statement(source)
    assert isinstance(ast, expected_type)


@pytest.mark.control_flow
class TestControlFlowIntegration:
    """Test integration of control flow in programs."""
    
    def test_complex_control_flow_program(self, parse_program):
        """Test parsing program with complex control flow."""
        source = """
let x = 0

if x >= 0:
    while x < 10:
        if x % 2 == 0:
            cli.print("even:", x)
        else:
            cli.print("odd:", x)
        x = x + 1
else:
    cli.print("negative number")

switch x:
case 0:
    cli.print("zero")
case 10:
    cli.print("ten")
default:
    cli.print("other")

for i in range(3):
    cli.print("final loop:", i)
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 5
        
        # Check each statement type
        assert isinstance(ast.statements[0], VarDecl)
        assert isinstance(ast.statements[1], IfStmt)
        assert isinstance(ast.statements[2], SwitchStmt)
        assert isinstance(ast.statements[3], ForStmt)
        assert isinstance(ast.statements[4], ExprStmt)


if __name__ == "__main__":
    pytest.main([__file__])
