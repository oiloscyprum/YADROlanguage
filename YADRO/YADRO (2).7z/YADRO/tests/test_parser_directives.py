"""Tests for compiler directive parsing in YADRO parser."""

import pytest
from parserr import (
    TargetDirective, PluginDirective, RequiresDirective, ImportDirective,
    StartDirective, EndDirective, ParseError
)


@pytest.mark.directives
class TestTargetDirective:
    """Test parsing of #target directives."""
    
    def test_simple_target_directive(self, parse_statement):
        """Test parsing of simple #target directive."""
        source = '#target "linux";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'linux'
        assert ast.line == 1
        assert ast.column == 16  # Column after the semicolon
    
    def test_target_directive_single_line(self, parse_statement):
        """Test parsing of single-line #target directive."""
        source = '#target "x86-64";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'x86-64'
    
    def test_target_directive_with_windows(self, parse_statement):
        """Test parsing of #target directive with Windows target."""
        source = '#target "windows";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'windows'
    
    def test_target_directive_with_macos(self, parse_statement):
        """Test parsing of #target directive with macOS target."""
        source = '#target "macos";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'macos'


@pytest.mark.directives
class TestPluginDirective:
    """Test parsing of #plugin directives."""
    
    def test_simple_plugin_directive(self, parse_statement):
        """Test parsing of simple #plugin directive."""
        source = '#plugin "safety-opt";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert ast.plugin == 'safety-opt'
    
    def test_plugin_directive_with_version(self, parse_statement):
        """Test parsing of #plugin directive with version."""
        source = '#plugin "linter==1.2";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert ast.plugin == 'linter==1.2'
    
    def test_plugin_directive_multiple_plugins(self, parse_statement):
        """Test parsing of #plugin directive with multiple plugins."""
        source = '#plugin "safety-opt,linter==1.2,formatter";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert 'safety-opt' in ast.plugin
        assert 'linter==1.2' in ast.plugin
        assert 'formatter' in ast.plugin


@pytest.mark.directives
class TestRequiresDirective:
    """Test parsing of #requires directives."""
    
    def test_requires_dll(self, parse_statement):
        """Test parsing of #requires directive with DLL."""
        source = '#requires "kernel32.dll";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert ast.version == '"kernel32.dll"'
    
    def test_requires_so(self, parse_statement):
        """Test parsing of #requires directive with shared library."""
        source = '#requires "libc.so.6";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert ast.version == '"libc.so.6"'
    
    def test_requires_multiple_libraries(self, parse_statement):
        """Test parsing of #requires directive with multiple libraries."""
        source = '#requires "kernel32.dll,libc.so.6";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert 'kernel32.dll' in ast.version
        assert 'libc.so.6' in ast.version


@pytest.mark.directives
class TestImportDirective:
    """Test parsing of #import directives."""
    
    def test_simple_import_directive(self, parse_statement):
        """Test parsing of simple #import directive."""
        source = '#import std.core.cli;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std.core.cli'
        assert ast.alias is None
    
    def test_import_directive_with_alias(self, parse_statement):
        """Test parsing of #import directive with alias."""
        source = '#import std.os.fs as fs;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std.os.fs'
        assert ast.alias == 'fs'
    
    def test_import_directive_single_module(self, parse_statement):
        """Test parsing of single-module #import directive."""
        source = '#import std;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std'
        assert ast.alias is None


@pytest.mark.directives
class TestStartDirective:
    """Test parsing of #start directives."""
    
    def test_start_directive(self, parse_statement):
        """Test parsing of #start directive."""
        source = '#start main;'
        ast = parse_statement(source)
        
        assert isinstance(ast, StartDirective)
        assert ast.function == 'main'
    
    def test_start_directive_with_function_name(self, parse_statement):
        """Test parsing of #start directive with different function name."""
        source = '#start entry_point;'
        ast = parse_statement(source)
        
        assert isinstance(ast, StartDirective)
        assert ast.function == 'entry_point'


@pytest.mark.directives
class TestEndDirective:
    """Test parsing of #end directives."""
    
    def test_end_directive(self, parse_statement):
        """Test parsing of #end directive."""
        source = '#end main;'
        ast = parse_statement(source)
        
        assert isinstance(ast, EndDirective)
        assert ast.function == 'main'
    
    def test_end_directive_with_function_name(self, parse_statement):
        """Test parsing of #end directive with different function name."""
        source = '#end entry_point;'
        ast = parse_statement(source)
        
        assert isinstance(ast, EndDirective)
        assert ast.function == 'entry_point'


@pytest.mark.directives
class TestDirectiveIntegration:
    """Test integration of multiple directives."""
    
    def test_multiple_directives_in_program(self, parse_program):
        """Test parsing program with multiple directives."""
        source = """
#target
os = "linux"
arch = "x86-64"

#plugin
safety-opt
linter==1.2

#requires
"kernel32.dll"
"libc.so.6"

#import
std.core.cli
std.os.fs as fs

#start main
#end main
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 6
        
        # Check each directive type
        directives = [TargetDirective, PluginDirective, RequiresDirective, 
                      ImportDirective, StartDirective, EndDirective]
        
        for i, expected_type in enumerate(directives):
            assert isinstance(ast.statements[i], expected_type)
    
    def test_directive_order_independence(self, parse_program):
        """Test that directives can appear in any order."""
        source = """
#start main
#target os = "linux"
#import std.core.cli
#plugin safety-opt
#end main
#requires "kernel32.dll"
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 6
        assert isinstance(ast.statements[0], StartDirective)
        assert isinstance(ast.statements[1], TargetDirective)
        assert isinstance(ast.statements[2], ImportDirective)
        assert isinstance(ast.statements[3], PluginDirective)
        assert isinstance(ast.statements[4], EndDirective)
        assert isinstance(ast.statements[5], RequiresDirective)


@pytest.mark.directives
class TestDirectiveErrors:
    """Test error handling in directive parsing."""
    
    def test_malformed_target_directive(self, parse_statement):
        """Test error handling for malformed #target directive."""
        from parserr import ParseError
        
        # Missing closing quote
        with pytest.raises(ParseError):
            parse_statement('#target os = "linux')
    
    def test_malformed_import_directive(self, parse_statement):
        """Test error handling for malformed #import directive."""
        from parserr import ParseError
        
        # Missing module name
        with pytest.raises(ParseError):
            parse_statement('#import')
    
    def test_malformed_requires_directive(self, parse_statement):
        """Test error handling for malformed #requires directive."""
        from parserr import ParseError
        
        # Missing quotes around library name
        with pytest.raises(ParseError):
            parse_statement('#requires kernel32.dll')
    
    def test_malformed_start_directive(self, parse_statement):
        """Test error handling for malformed #start directive."""
        from parserr import ParseError
        
        # Missing function name
        with pytest.raises(ParseError):
            parse_statement('#start')
    
    def test_malformed_end_directive(self, parse_statement):
        """Test error handling for malformed #end directive."""
        from parserr import ParseError
        
        # Missing function name
        with pytest.raises(ParseError):
            parse_statement('#end')


@pytest.mark.directives
class TestDirectiveFixtures:
    """Test directive parsing with fixture files."""
    
    def test_valid_target_directive_fixture(self, parse_statement):
        """Test parsing valid target directive from fixture."""
        source = """
#target
os = "linux"
arch = "x86-64"
optimization = "speed"
"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert 'linux' in ast.target
        assert 'x86-64' in ast.target
        assert 'speed' in ast.target
    
    def test_valid_import_directive_fixture(self, parse_statement):
        """Test parsing valid import directive from fixture."""
        source = """
#import
std.core.cli
std.os.fs as fs
std.collections.vector
std.math
"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert 'std.core.cli' in ast.module
        assert 'std.os.fs as fs' in ast.module
        assert 'std.collections.vector' in ast.module
        assert 'std.math' in ast.module


@pytest.mark.directives
@pytest.mark.parametrize("directive_source,expected_type,expected_content", [
    ('#target "linux";', TargetDirective, 'linux'),
    ('#plugin "safety-opt";', PluginDirective, 'safety-opt'),
    ('#requires "kernel32.dll";', RequiresDirective, '"kernel32.dll"'),
    ('#import std.core.cli;', ImportDirective, 'std.core.cli'),
    ('#start main;', StartDirective, 'main'),
    ('#end main;', EndDirective, 'main'),
])
def test_directive_parameterized(parse_statement, directive_source, expected_type, expected_content):
    """Parameterized test for all directive types."""
    ast = parse_statement(directive_source)
    
    assert isinstance(ast, expected_type)
    if hasattr(ast, 'target'):
        assert ast.target == expected_content
    elif hasattr(ast, 'plugin'):
        assert ast.plugin == expected_content
    elif hasattr(ast, 'version'):
        assert ast.version == expected_content
    elif hasattr(ast, 'module'):
        assert ast.module == expected_content
    elif hasattr(ast, 'function'):
        assert ast.function == expected_content


if __name__ == "__main__":
    pytest.main([__file__])
