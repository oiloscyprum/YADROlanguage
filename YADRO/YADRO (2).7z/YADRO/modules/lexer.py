from enum import Enum, auto
from dataclasses import dataclass
from typing import List, Optional, Any

class TokenType(Enum):
    Target = "#target"
    Plugin = "#plugin"
    Requires = "#requires"
    Import = "#import"
    Start = "#start"
    End = "#end"

    LineCom = "/"
    BlComStart = "/*"
    BlComEnd = "*/"

    Newline = "\n"
    Semicolon = ";"
    Indent = " " * 4
    Dedent = None
    Colon = ":"

    Ifblk = "if"
    Elsif = "elsif"
    Elseblk = "else"
    Switch = "switch"
    Case = "case"
    Default = "default"
    Forlp = "for"
    In = "in"
    Whilelp = "while"
    Repeat = "repeat"
    Until = "until"
    Return = "return"
    Break = "break"
    Continue = "continue"

    Fun = "fun"
    Temp = "temp"
    Class = "class"
    Trait = "trait"
    Impl = "impl"
    Where = "where"
    Const = "const"
    Sfun = "sfun"

    Int = "int"
    Float = "float"
    Bool = "bool"
    String = "string"
    Char = "char"
    Array = "array"
    Darray = "darray"
    Dict = "dict"
    Set = "set"
    Vector = "vector"
    Gc = "gc"
    Result = "Result"
    Option = "Option"
    GcWeak = "gc_weak"

    Del = "del"
    Unsafe = "unsafe"
    Async = "async"
    Thread = "thread"
    Ffi = "ffi"
    Actor = "actor"
    Linear = "linear"
    Asm = "asm"

    true = "true"
    false = "false"

    Plus = "+"
    Minus = "-"
    Star = "*"
    Slash = "/"
    Percent = "%"
    Caret = "^"
    PipeDiv = "|"

    Eq = "=="
    Ne = "!="
    Lt = "<"
    Gt = ">"
    Le = "<="
    Ge = ">="

    And = "and"
    Or = "or"
    Xor = "xor"
    Nand = "nand"
    Not = "!"

    Lshift = "<<"
    Rshift = ">>"
    Amp = "&"
    Pipe = "|"
    Tilde = "~"

    Lparen = "("
    Rparen = ")"
    Lbrace = "{"
    Rbrace = "}"
    Lbrack = "["
    Rbrack = "]"
    Comma = ","
    Dot = "."
    Assign = "="
    PlusAssign = "+="
    MinusAssign = "-="
    StarAssign = "*="
    SlashAssign = "/="
    PercentAssign = "%="
    CaretAssign = "^="
    PipeDivAssign = "|/="
    LshiftAssign = "<<="
    RshiftAssign = ">>="
    AmpAssign = "&="
    PipeAssign = "|="
    TildeAssign = "~="
    AddrAssign = "@="
    SwapAssign = "$="

    Arrow = "->"
    FatArrow = "=>"
    Question = "?"
    DoubleQuestion = "??"
    ColonColon = "::"
    Dollar = "$"
    At = "@"
    Hash = "#"
    Backtick = "`"

    PipelineRight = ">>>"
    PipelineLeft = "<<<"

    Ref = "&"
    MutRef = "&mut"

    Match = "match"
    With = "with"
    Predicate = "~"

    IDENTIFIER = "<identifier>"
    EoF = "<EOF>"

@dataclass
class Token():
    type: TokenType
    value: str
    line: int
    column: int
    lexeme : str
    def __str__(self):
       return f"Lexeme {self.value} == {self.type.name} at line: {self.line}, column:{self.column}"

class LexerError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"Line {line}, Column {column}: {message}")
        self.line = line
        self.column = column

class Lexer:
    def __init__(self, source: str, source_path: str = "<string>"):
        self.source = source
        self.source_path = source_path
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]  # Stack of indentation levels

    def error(self, message: str):
        raise LexerError(message, self.line, self.column)

    def peek(self, offset: int = 0) -> Optional[str]:
        pos = self.pos + offset
        if pos < len(self.source):
            return self.source[pos]
        return None

    def advance(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        ch = self.source[self.pos]
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def skip_whitespace(self, skip_newlines: bool = False):
        while self.peek() and self.peek() in ' \t\r' + ('\n' if skip_newlines else ''):
            self.advance()

    def skip_comment(self):
        if self.peek() == '/' and self.peek(1) == '/':
            while self.peek() and self.peek() != '\n':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '*':
            self.advance()
            self.advance()
            while True:
                if self.peek() is None:
                    self.error("Unterminated block comment")
                if self.peek() == '*' and self.peek(1) == '/':
                    self.advance()
                    self.advance()
                    break
                self.advance()

    def read_string(self) -> str:
        quote = self.advance()
        value = ""
        while True:
            ch = self.peek()
            if ch is None:
                self.error("Unterminated string")
            if ch == quote:
                self.advance()
                break
            if ch == '\\':
                self.advance()
                escape = self.advance()
                escape_map = {
                    'n': '\n', 't': '\t', 'r': '\r',
                    '\\': '\\', '"': '"', "'": "'"
                }
                value += escape_map.get(escape, escape)
            else:
                value += ch
                self.advance()
        return value

    def read_char(self) -> str:
        self.advance()
        if self.peek() == '\\':
            self.advance()
            ch = self.advance()
            escape_map = {
                'n': '\n', 't': '\t', 'r': '\r',
                '\\': '\\', "'": "'"
            }
            value = escape_map.get(ch, ch)
        else:
            value = self.advance()
        if self.peek() != "'":
            self.error("Invalid character literal")
        self.advance()
        return value

    def read_number(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        is_float = False

        if self.peek() == '0' and self.peek(1) in 'xXbBoO':
            value += self.advance()
            value += self.advance()
            while self.peek() and self.peek() in '0123456789abcdefABCDEF_':
                if self.peek() != '_':
                    value += self.advance()
                else:
                    self.advance()
            return Token(TokenType.Int, int(value, 0), start_line, start_col, value)

        while self.peek() and (self.peek().isdigit() or self.peek() in '._'):
            if self.peek() == '.':
                if is_float:
                    break
                if self.peek(1) and not self.peek(1).isdigit():
                    break
                is_float = True
                value += self.advance()
            elif self.peek() == '_':
                self.advance()
            else:
                value += self.advance()

        if self.peek() and self.peek() in 'eE':
            is_float = True
            value += self.advance()
            if self.peek() and self.peek() in '+-':
                value += self.advance()
            while self.peek() and self.peek().isdigit():
                value += self.advance()

        token_type = TokenType.Float if is_float else TokenType.Int
        token_value = float(value) if is_float else int(value)
        return Token(token_type, token_value, start_line, start_col, value)

    def read_identifier(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        while self.peek() and (self.peek().isalnum() or self.peek() in '_'):
            value += self.advance()

        token_type = TokenType.IDENTIFIER

        for token in TokenType:
            if hasattr(token, 'value') and token.value == value:
                token_type = token
                break

        if value == 'true':
            return Token(TokenType.true, True, start_line, start_col, value)
        elif value == 'false':
            return Token(TokenType.false, False, start_line, start_col, value)

        return Token(token_type, value, start_line, start_col, value)

    def read_directive(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        while self.peek() and (self.peek().isalnum() or self.peek() in '_#'):
            value += self.advance()

        token_type = TokenType.IDENTIFIER
        for token in TokenType:
            if hasattr(token, 'value') and token.value == value:
                token_type = token
                break

        return Token(token_type, value, start_line, start_col, value)

    def handle_indentation(self):
        indent = 0
        while self.peek() and self.peek() in ' \t':
            if self.peek() == ' ':
                indent += 1
            else:
                indent += 4
            self.advance()

        if self.peek() and self.peek() in '\n\r':
            return

        if self.peek() == '/' and self.peek(1) in '/*':
            return

        current_indent = self.indent_stack[-1]

        if indent > current_indent:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.Indent, indent, self.line, self.column, "INDENT"))
        elif indent < current_indent:
            while self.indent_stack and self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.Dedent, indent, self.line, self.column, "DEDENT"))
            if self.indent_stack[-1] != indent:
                self.error(f"Invalid indentation level")

    def tokenize(self) -> List[Token]:
        at_line_start = True

        while self.pos < len(self.source):
            if at_line_start:
                self.handle_indentation()
                at_line_start = False

            self.skip_whitespace()

            ch = self.peek()
            if ch is None:
                break

            if ch == '/' and self.peek(1) in '/*':
                self.skip_comment()
                continue

            start_line, start_col = self.line, self.column

            if ch == '\n':
                self.advance()
                self.tokens.append(Token(TokenType.Newline, '\n', start_line, start_col, "\\n"))
                at_line_start = True
                continue

            if ch in '"\'':
                if ch == '"':
                    value = self.read_string()
                    self.tokens.append(Token(TokenType.String, value, start_line, start_col, f'"{value}"'))
                else:
                    value = self.read_char()
                    self.tokens.append(Token(TokenType.Char, value, start_line, start_col, f"'{value}'"))
                continue

            if ch.isdigit():
                self.tokens.append(self.read_number())
                continue

            if ch == '#':
                self.tokens.append(self.read_directive())
                continue

            if ch.isalpha() or ch == '_':
                self.tokens.append(self.read_identifier())
                continue

            if ch == '>' and self.peek(1) == '>' and self.peek(2) == '>':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipelineRight, '>>>', start_line, start_col, ">>>"))
                continue
            if ch == '<' and self.peek(1) == '<' and self.peek(2) == '<':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipelineLeft, '<<<', start_line, start_col, "<<<"))
                continue

            if ch == '=' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Eq, '==', start_line, start_col, "=="))
                continue
            if ch == '!' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Ne, '!=', start_line, start_col, "!="))
                continue
            if ch == '<' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Le, '<=', start_line, start_col, "<="))
                continue
            if ch == '>' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Ge, '>=', start_line, start_col, ">="))
                continue
            # Check for <<= and >>= before << and >>
            if ch == '<' and self.peek(1) == '<' and self.peek(2) == '=':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.LshiftAssign, '<<=', start_line, start_col, "<<="))
                continue
            if ch == '>' and self.peek(1) == '>' and self.peek(2) == '=':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.RshiftAssign, '>>=', start_line, start_col, ">>="))
                continue
            if ch == '<' and self.peek(1) == '<':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Lshift, '<<', start_line, start_col, "<<"))
                continue
            if ch == '>' and self.peek(1) == '>':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Rshift, '>>', start_line, start_col, ">>"))
                continue
            if ch == '-' and self.peek(1) == '>':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Arrow, '->', start_line, start_col, "->"))
                continue
            if ch == '+' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PlusAssign, '+=', start_line, start_col, "+="))
                continue
            if ch == '-' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.MinusAssign, '-=', start_line, start_col, "-="))
                continue
            if ch == '*' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.StarAssign, '*=', start_line, start_col, "*="))
                continue
            if ch == '/' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.SlashAssign, '/=', start_line, start_col, "/="))
                continue
            if ch == '%' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PercentAssign, '%=', start_line, start_col, "%="))
                continue
            if ch == '&' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.AmpAssign, '&=', start_line, start_col, "&="))
                continue
            if ch == '|' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipeAssign, '|=', start_line, start_col, "|="))
                continue
            if ch == '^' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.CaretAssign, '^=', start_line, start_col, "^="))
                continue
            if ch == '@' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.AddrAssign, '@=', start_line, start_col, "@="))
                continue
            if ch == '$' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.SwapAssign, '$=', start_line, start_col, "$="))
                continue

            # Single character tokens
            single_char_tokens = {
                '+': TokenType.Plus, '-': TokenType.Minus, '*': TokenType.Star,
                '/': TokenType.Slash, '%': TokenType.Percent, '^': TokenType.Caret,
                '<': TokenType.Lt, '>': TokenType.Gt, '=': TokenType.Assign,
                '&': TokenType.Amp, '|': TokenType.Pipe, '~': TokenType.Tilde,
                '(': TokenType.Lparen, ')': TokenType.Rparen,
                '{': TokenType.Lbrace, '}': TokenType.Rbrace,
                '[': TokenType.Lbrack, ']': TokenType.Rbrack,
                ':': TokenType.Colon, ';': TokenType.Semicolon,
                ',': TokenType.Comma, '.': TokenType.Dot,
                '?': TokenType.Question,
            }

            if ch in single_char_tokens:
                self.advance()
                self.tokens.append(Token(single_char_tokens[ch], ch, start_line, start_col, ch))
                continue

            self.error(f"Unexpected character: {ch}")

        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.Dedent, 0, self.line, self.column, "DEDENT"))

        self.tokens.append(Token(TokenType.EoF, None, self.line, self.column, "EOF"))
        return self.tokens

if __name__ == '__main__':
    code = """#import
std.core.cli
#start
fun main() -> int:
    int x = 42
    if x > 0:
        return 0
    else:
        return 1
#end
"""
    tokens = Lexer(code).tokenize()
    for t in tokens:
        print(t)