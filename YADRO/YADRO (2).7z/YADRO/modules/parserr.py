"""
YADRO Parser Module

This module implements a complete recursive descent parser for the YADRO programming language,
transforming the token stream from the lexer into an Abstract Syntax Tree (AST).
"""

from typing import List, Optional, Union, Any, Dict
from dataclasses import dataclass
from enum import Enum

from lexer import Token, TokenType, LexerError


class ParseError(Exception):
    """Exception raised for parsing errors."""
    
    def __init__(self, message: str, token: Optional[Token] = None):
        self.message = message
        self.token = token
        if token:
            super().__init__(f"Parse error at line {token.line}, column {token.column}: {message}")
        else:
            super().__init__(f"Parse error: {message}")


# AST Node Base Classes
@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int
    column: int


@dataclass
class Statement(ASTNode):
    """Base class for all statement nodes."""
    pass


@dataclass
class Expression(ASTNode):
    """Base class for all expression nodes."""
    pass


@dataclass
class Type(ASTNode):
    """Base class for all type nodes."""
    pass


# Core AST Nodes
@dataclass
class Program(ASTNode):
    """Root node of the AST."""
    statements: List[Statement]
    
    def __post_init__(self):
        if hasattr(self, 'statements') and self.statements:
            self.line = self.statements[0].line
            self.column = self.statements[0].column


# Directive Nodes
@dataclass
class TargetDirective(Statement):
    target: str


@dataclass
class PluginDirective(Statement):
    plugin: str


@dataclass
class RequiresDirective(Statement):
    version: str


@dataclass
class ImportDirective(Statement):
    module: str
    alias: Optional[str] = None


@dataclass
class StartDirective(Statement):
    function: str


@dataclass
class EndDirective(Statement):
    function: str


# Declaration Nodes
@dataclass
class VarDecl(Statement):
    name: str
    type_annotation: Optional[Type]
    initializer: Optional[Expression]
    is_mutable: bool = False


@dataclass
class ConstDecl(Statement):
    name: str
    type_annotation: Optional[Type]
    initializer: Expression
    line: int
    column: int
    
    def __post_init__(self):
        # Move line/column to proper position for dataclass
        pass


@dataclass
class FunctionDecl(Statement):
    name: str
    type_params: List[str]
    params: List['Param']
    return_type: Optional[Type]
    body: List[Statement]
    attributes: List[str]
    is_static: bool = False
    is_method: bool = False


@dataclass
class Param:
    name: str
    type_annotation: Type
    is_mutable: bool = False
    default_value: Optional[Expression] = None


@dataclass
class ClassDecl(Statement):
    name: str
    type_params: List[str]
    fields: List[VarDecl]
    methods: List[FunctionDecl]
    attributes: List[str]
    base_class: Optional[str] = None


@dataclass
class TraitDecl(Statement):
    name: str
    type_params: List[str]
    methods: List[FunctionDecl]
    super_traits: List[str]


@dataclass
class ImplDecl(Statement):
    trait_name: str
    type_name: str
    type_params: List[str]
    methods: List[FunctionDecl]


# Control Flow Nodes
@dataclass
class IfStmt(Statement):
    condition: Expression
    then_branch: List[Statement]
    elif_branches: List[tuple[Expression, List[Statement]]]
    else_branch: Optional[List[Statement]]


@dataclass
class SwitchStmt(Statement):
    expression: Expression
    cases: List[tuple[Expression, List[Statement]]]
    default_case: Optional[List[Statement]]


@dataclass
class ForStmt(Statement):
    variable: str
    iterable: Expression
    body: List[Statement]


@dataclass
class WhileStmt(Statement):
    condition: Expression
    body: List[Statement]


@dataclass
class RepeatStmt(Statement):
    body: List[Statement]
    until_condition: Expression


@dataclass
class ReturnStmt(Statement):
    expression: Optional[Expression]


@dataclass
class BreakStmt(Statement):
    pass


@dataclass
class ContinueStmt(Statement):
    pass


@dataclass
class DelStmt(Statement):
    expression: Expression


# Expression Nodes
@dataclass
class BinaryExpr(Expression):
    left: Expression
    operator: str
    right: Expression


@dataclass
class UnaryExpr(Expression):
    operator: str
    operand: Expression


@dataclass
class AssignExpr(Expression):
    target: Expression
    operator: str
    value: Expression


@dataclass
class PipelineExpr(Expression):
    direction: str  # ">>>" or "<<<"
    expressions: List[Expression]


@dataclass
class CallExpr(Expression):
    callee: Expression
    arguments: List[Expression]


@dataclass
class MemberExpr(Expression):
    object: Expression
    property: str


@dataclass
class IndexExpr(Expression):
    object: Expression
    index: Expression


@dataclass
class LiteralExpr(Expression):
    value: Any
    literal_type: str  # "int", "float", "string", "char", "bool"


@dataclass
class IdentifierExpr(Expression):
    name: str


@dataclass
class RefExpr(Expression):
    expression: Expression
    is_mutable: bool = False


@dataclass
class DerefExpr(Expression):
    expression: Expression


@dataclass
class PredicateExpr(Expression):
    expression: Expression
    predicate: str


@dataclass
class MatchExpr(Expression):
    expression: Expression
    arms: List[tuple[Expression, Expression]]


@dataclass
class ResultExpr(Expression):
    expression: Expression
    is_ok: bool = True


@dataclass
class OptionExpr(Expression):
    expression: Expression
    is_some: bool = True


@dataclass
class AsmExpr(Expression):
    template: str
    inputs: List[tuple[str, Expression]]
    outputs: List[tuple[str, str]]
    clobbers: List[str]


@dataclass
class LambdaExpr(Expression):
    params: List[Param]
    return_type: Optional[Type]
    body: List[Statement]


@dataclass
class GenericExpr(Expression):
    expression: Expression
    type_args: List[Type]


@dataclass
class ArrayLiteralExpr(Expression):
    elements: List[Expression]


@dataclass  
class DictLiteralExpr(Expression):
    pairs: List[tuple[Expression, Expression]]


# Type Nodes
@dataclass
class BasicType(Type):
    name: str


@dataclass
class ArrayType(Type):
    element_type: Type
    size: Optional[Expression] = None


@dataclass
class DictType(Type):
    key_type: Type
    value_type: Type


@dataclass
class SetType(Type):
    element_type: Type


@dataclass
class VectorType(Type):
    element_type: Type


@dataclass
class ReferenceType(Type):
    referenced_type: Type
    is_mutable: bool = False


@dataclass
class PredicateType(Type):
    base_type: Type
    predicate: str


@dataclass
class GenericType(Type):
    name: str
    type_args: List[Type]


@dataclass
class ResultType(Type):
    ok_type: Type
    err_type: Type


@dataclass
class OptionType(Type):
    some_type: Type


@dataclass
class GcType(Type):
    inner_type: Type
    is_weak: bool = False


# Special Statement Nodes
@dataclass
class BlockStmt(Statement):
    statements: List[Statement]


@dataclass
class UnsafeStmt(Statement):
    statements: List[Statement]


@dataclass
class AsmStmt(Statement):
    template: str
    inputs: List[tuple[str, Expression]]
    outputs: List[tuple[str, str]]
    clobbers: List[str]


@dataclass
class ExprStmt(Statement):
    expression: Expression


class YadroParser:
    """Recursive descent parser for YADRO language."""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.current = 0
        self.errors: List[ParseError] = []
    
    def parse_program(self) -> Program:
        """Parse the entire token stream into a Program AST."""
        statements = []
        
        while not self.is_at_end():
            # Skip newlines and empty lines between statements
            while self.match(TokenType.Newline) or self.match(TokenType.Indent) or self.match(TokenType.Dedent):
                continue
            
            if self.is_at_end():
                break
            
            try:
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
        
        if statements:
            return Program(statements[0].line, statements[0].column, statements)
        else:
            return Program(1, 1, [])
    
    def parse_statement(self) -> Statement:
        """Parse a statement with proper block handling."""
        # Skip newlines but not Dedent tokens (they're important for block boundaries)
        while self.match(TokenType.Newline):
            continue
        
        # If we're at a Dedent token, don't parse a statement
        if self.check(TokenType.Dedent):
            return None
            
        if self.match(TokenType.Target):
            return self.parse_target_directive()
        elif self.match(TokenType.Plugin):
            return self.parse_plugin_directive()
        elif self.match(TokenType.Requires):
            return self.parse_requires_directive()
        elif self.match(TokenType.Import):
            return self.parse_import_directive()
        elif self.match(TokenType.Start):
            return self.parse_start_directive()
        elif self.match(TokenType.End):
            return self.parse_end_directive()
        elif self.match(TokenType.Temp):
            return self.parse_generic_function_decl()
        elif self.match(TokenType.Fun):
            return self.parse_function_decl()
        elif self.match(TokenType.Class):
            return self.parse_class_decl()
        elif self.match(TokenType.Trait):
            return self.parse_trait_decl()
        elif self.match(TokenType.Impl):
            return self.parse_impl_decl()
        elif self.match(TokenType.Const):
            return self.parse_const_decl()
        elif self.match(TokenType.Del):
            return self.parse_del_stmt()
        elif self.match(TokenType.Ifblk):
            return self.parse_if_stmt()
        elif self.match(TokenType.Switch):
            return self.parse_switch_stmt()
        elif self.match(TokenType.Forlp):
            return self.parse_for_stmt()
        elif self.match(TokenType.Whilelp):
            return self.parse_while_stmt()
        elif self.match(TokenType.Repeat):
            return self.parse_repeat_stmt()
        elif self.match(TokenType.Return):
            return self.parse_return_stmt()
        elif self.match(TokenType.Break):
            return self.parse_break_stmt()
        elif self.match(TokenType.Continue):
            return self.parse_continue_stmt()
        elif self.match(TokenType.Unsafe):
            return self.parse_unsafe_stmt()
        elif self.match(TokenType.Asm):
            return self.parse_asm_stmt()
        else:
            # Check for variable declaration (let/var) or class field (identifier: type)
            if self.check(TokenType.IDENTIFIER):
                next_token = self.peek()
                print(f"DEBUG parse_statement: Found IDENTIFIER '{next_token.value}' at position {self.current}")
                if self.current + 1 < len(self.tokens):
                    next_next = self.tokens[self.current + 1]
                    print(f"DEBUG parse_statement: Next token is '{next_next.value}' ({next_next.type.name})")
                    if next_next and next_next.type == TokenType.Colon:
                        print(f"DEBUG parse_statement: Should parse as class field!")
                        return self.parse_class_field()
                    elif next_next and next_next.value in ['let', 'var']:
                        print(f"DEBUG parse_statement: Should parse as variable declaration!")
                        return self.parse_var_decl()
                else:
                    print(f"DEBUG parse_statement: No next token available")
            print(f"DEBUG parse_statement: Falling through to parse_expr_stmt")
            return self.parse_expr_stmt()
    
    def parse_expression(self) -> Expression:
        """Parse an expression with proper precedence."""
        return self.parse_assignment()
    
    def parse_expr_stmt(self) -> ExprStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after expression")
        return ExprStmt(expr.line, expr.column, expr)
    
    def parse_assignment(self) -> Expression:
        """Parse assignment expressions."""
        expr = self.parse_pipeline()
        
        # Check for consecutive operators (error detection)
        if self.is_operator_token(self.peek()) and isinstance(expr, AssignExpr):
            raise ParseError(f"Unexpected operator: {self.peek().value}", self.peek())
        
        if self.match(TokenType.Assign) or any(self.match(t) for t in [
            TokenType.PlusAssign, TokenType.MinusAssign, TokenType.StarAssign,
            TokenType.SlashAssign, TokenType.PercentAssign, TokenType.LshiftAssign,
            TokenType.RshiftAssign, TokenType.AmpAssign, TokenType.PipeAssign,
            TokenType.CaretAssign, TokenType.AddrAssign, TokenType.SwapAssign
        ]):
            operator = self.previous().value
            
            # Check for consecutive operators after assignment
            if self.is_operator_token(self.peek()):
                raise ParseError(f"Unexpected operator: {self.peek().value}", self.peek())
            
            value = self.parse_assignment()
            return AssignExpr(expr.line, expr.column, expr, operator, value)
        
        return expr
    
    def is_operator_token(self, token: Token) -> bool:
        """Check if token is an operator."""
        if not token:
            return False
        
        operators = {
            TokenType.Plus, TokenType.Minus, TokenType.Star, TokenType.Slash, TokenType.Percent,
            TokenType.Lshift, TokenType.Rshift, TokenType.Lt, TokenType.Gt, TokenType.Le, TokenType.Ge,
            TokenType.Eq, TokenType.Ne, TokenType.And, TokenType.Or, TokenType.Xor, TokenType.Nand,
            TokenType.Not, TokenType.Amp, TokenType.Pipe, TokenType.Caret, TokenType.Tilde,
            TokenType.PlusAssign, TokenType.MinusAssign, TokenType.StarAssign, TokenType.SlashAssign,
            TokenType.PercentAssign, TokenType.LshiftAssign, TokenType.RshiftAssign, TokenType.AmpAssign,
            TokenType.PipeAssign, TokenType.CaretAssign, TokenType.AddrAssign, TokenType.SwapAssign,
            TokenType.PipeDiv, TokenType.Assign
        }
        
        return token.type in operators
    
    def parse_pipeline(self) -> Expression:
        """Parse pipeline expressions (>>> and <<<) with comprehensive support."""
        expr = self.parse_logical_or()
        
        if self.match(TokenType.PipelineRight) or self.match(TokenType.PipelineLeft):
            direction = self.previous().value
            expressions = [expr]
            
            # Continue collecting pipeline expressions
            # Parse the first expression after the pipeline operator
            expressions.append(self.parse_logical_or())
            
            # Continue while there are more pipeline operators
            while self.match(TokenType.PipelineRight) or self.match(TokenType.PipelineLeft):
                if self.previous().value != direction:
                    raise ParseError(f"Cannot mix pipeline operators {direction} and {self.previous().value}")
                expressions.append(self.parse_logical_or())
            
            return PipelineExpr(expr.line, expr.column, direction, expressions)
        
        return expr
    
    def is_at_statement_end(self) -> bool:
        """Check if current position is at the end of a statement."""
        return self.check(TokenType.Semicolon) or self.check(TokenType.EoF) or self.check(TokenType.Newline) or self.check(TokenType.Dedent)
    
    def parse_logical_or(self) -> Expression:
        """Parse logical OR expressions."""
        expr = self.parse_logical_xor()
        
        while self.match(TokenType.Or):
            operator = self.previous().value
            right = self.parse_logical_xor()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_xor(self) -> Expression:
        """Parse logical XOR expressions."""
        expr = self.parse_logical_nand()
        
        while self.match(TokenType.Xor):
            operator = self.previous().value
            right = self.parse_logical_nand()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_nand(self) -> Expression:
        """Parse logical NAND expressions."""
        expr = self.parse_logical_and()
        
        while self.match(TokenType.Nand):
            operator = self.previous().value
            right = self.parse_logical_and()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_and(self) -> Expression:
        """Parse logical AND expressions."""
        expr = self.parse_equality()
        
        while self.match(TokenType.And):
            operator = self.previous().value
            right = self.parse_equality()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_equality(self) -> Expression:
        """Parse equality expressions."""
        expr = self.parse_comparison()
        
        while self.match(TokenType.Eq) or self.match(TokenType.Ne):
            operator = self.previous().value
            right = self.parse_comparison()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_comparison(self) -> Expression:
        """Parse comparison expressions."""
        expr = self.parse_bitwise_or()
        
        while self.match(TokenType.Lt) or self.match(TokenType.Gt) or \
              self.match(TokenType.Le) or self.match(TokenType.Ge):
            operator = self.previous().value
            right = self.parse_bitwise_or()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_or(self) -> Expression:
        """Parse bitwise OR expressions."""
        expr = self.parse_bitwise_xor()
        
        while self.match(TokenType.Pipe):
            operator = self.previous().value
            right = self.parse_bitwise_xor()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_xor(self) -> Expression:
        """Parse bitwise XOR expressions."""
        expr = self.parse_bitwise_and()
        
        while self.match(TokenType.Caret):
            operator = self.previous().value
            right = self.parse_bitwise_and()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_and(self) -> Expression:
        """Parse bitwise AND expressions."""
        expr = self.parse_shift()
        
        while self.match(TokenType.Amp):
            operator = self.previous().value
            right = self.parse_shift()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_shift(self) -> Expression:
        """Parse shift expressions."""
        expr = self.parse_additive()
        
        while self.match(TokenType.Lshift) or self.match(TokenType.Rshift):
            operator = self.previous().value
            right = self.parse_additive()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_additive(self) -> Expression:
        """Parse additive expressions."""
        expr = self.parse_multiplicative()
        
        while self.match(TokenType.Plus) or self.match(TokenType.Minus):
            operator = self.previous().value
            right = self.parse_multiplicative()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_multiplicative(self) -> Expression:
        """Parse multiplicative expressions."""
        expr = self.parse_unary()
        
        while self.match(TokenType.Star) or self.match(TokenType.Slash) or \
              self.match(TokenType.Percent) or self.match(TokenType.PipeDiv):
            operator = self.previous().value
            right = self.parse_unary()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_unary(self) -> Expression:
        """Parse unary expressions."""
        if self.match(TokenType.Minus) or self.match(TokenType.Not) or \
           self.match(TokenType.Tilde) or self.match(TokenType.Star):
            operator = self.previous().value
            right = self.parse_unary()
            return UnaryExpr(right.line, right.column, operator, right)
        
        return self.parse_call()
    
    def parse_call(self) -> Expression:
        """Parse function calls, member access, array indexing, generic expressions, and predicates."""
        expr = self.parse_primary()
        
        while True:
            if self.match(TokenType.Lparen):
                expr = self.finish_call(expr)
            elif self.match(TokenType.Lbrack):
                # Check if this is array indexing or generic type arguments
                # Use lookahead to disambiguate: if content looks like a type, parse as generic; otherwise as index
                saved_pos = self.current
                is_generic = False
                
                if isinstance(expr, IdentifierExpr) and not self.check(TokenType.Rbrack):
                    # Check if next token is a type keyword
                    next_token = self.peek()
                    type_keywords = {
                        TokenType.Int, TokenType.Float, TokenType.Bool, TokenType.String, TokenType.Char,
                        TokenType.Array, TokenType.Darray, TokenType.Dict, TokenType.Set, TokenType.Vector,
                        TokenType.Gc, TokenType.GcWeak, TokenType.Result, TokenType.Option,
                        TokenType.Ref, TokenType.MutRef
                    }
                    if next_token.type in type_keywords:
                        is_generic = True
                    elif next_token.type == TokenType.IDENTIFIER:
                        # Could be a type name - check if it's a known type identifier
                        # For now, assume identifier after [ in expression context is more likely an index
                        # unless we're in a type annotation context (which we're not here)
                        is_generic = False
                
                self.current = saved_pos  # Restore position
                
                if is_generic and isinstance(expr, IdentifierExpr):
                    # Generic type expression like TypeName[T, U]
                    type_args = []
                    if not self.check(TokenType.Rbrack):
                        type_args.append(self.parse_type())
                        while self.match(TokenType.Comma):
                            type_args.append(self.parse_type())
                    self.consume(TokenType.Rbrack, "Expected ']' after type arguments")
                    expr = GenericExpr(expr.line, expr.column, expr, type_args)
                else:
                    # Array indexing: expr[index]
                    index = self.parse_expression()
                    self.consume(TokenType.Rbrack, "Expected ']' after index")
                    expr = IndexExpr(expr.line, expr.column, expr, index)
            elif self.match(TokenType.Dot):
                name = self.consume(TokenType.IDENTIFIER, "Expected property name after '.'").value
                expr = MemberExpr(expr.line, expr.column, expr, name)
            elif self.match(TokenType.Predicate):
                # Predicate expression: expr ~ predicate
                predicate = self.consume(TokenType.IDENTIFIER, "Expected predicate name after '~'").value
                
                # Check for complex predicate with parameters
                if self.match(TokenType.Lparen):
                    # Complex predicate: expr ~ predicate(args...)
                    args = []
                    if not self.check(TokenType.Rparen):
                        args.append(self.parse_expression())
                        while self.match(TokenType.Comma):
                            args.append(self.parse_expression())
                    self.consume(TokenType.Rparen, "Expected ')' after predicate arguments")
                    # Create a complex predicate expression
                    predicate_expr = PredicateExpr(expr.line, expr.column, expr, predicate)
                    predicate_expr.args = args  # Add args attribute for complex predicates
                    expr = predicate_expr
                else:
                    # Simple predicate: expr ~ predicate
                    expr = PredicateExpr(expr.line, expr.column, expr, predicate)
            else:
                break
        
        return expr
    
    def parse_primary(self) -> Expression:
        """Parse primary expressions."""
        if self.match(TokenType.true):
            return LiteralExpr(self.previous().line, self.previous().column, True, "bool")
        if self.match(TokenType.false):
            return LiteralExpr(self.previous().line, self.previous().column, False, "bool")
        
        if self.match(TokenType.Int):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "int")
        
        if self.match(TokenType.Float):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "float")
        
        if self.match(TokenType.String):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "string")
        
        if self.match(TokenType.Char):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "char")
        
        if self.match(TokenType.IDENTIFIER):
            identifier = self.previous()
            
            # Check for Result/Option expressions
            if identifier.value == 'Ok':
                self.consume(TokenType.Lparen, "Expected '(' after Ok")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Ok expression")
                return ResultExpr(identifier.line, identifier.column, expr, True)
            elif identifier.value == 'Err':
                self.consume(TokenType.Lparen, "Expected '(' after Err")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Err expression")
                return ResultExpr(identifier.line, identifier.column, expr, False)
            elif identifier.value == 'Some':
                self.consume(TokenType.Lparen, "Expected '(' after Some")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Some expression")
                return OptionExpr(identifier.line, identifier.column, expr, True)
            elif identifier.value == 'None':
                return OptionExpr(identifier.line, identifier.column, None, False)
            elif identifier.value == 'match':
                return self.parse_match_expr()
            else:
                return IdentifierExpr(identifier.line, identifier.column, identifier.value)
        
        if self.match(TokenType.Lparen):
            # Check for lambda expression: (params) -> return_type { body }
            if self.is_lambda_start():
                return self.parse_lambda_expr()
            else:
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after expression")
                return expr
        
        if self.match(TokenType.Ref):
            expr = self.parse_unary()
            return RefExpr(expr.line, expr.column, expr, False)
        
        if self.match(TokenType.MutRef):
            expr = self.parse_unary()
            return RefExpr(expr.line, expr.column, expr, True)
        
        # Add array literal parsing: [expr1, expr2, ...]
        if self.match(TokenType.Lbrack):
            return self.parse_array_literal()
        
        # Add dict literal parsing: {key1: value1, key2: value2, ...}
        if self.match(TokenType.Lbrace):
            # Check if this is a dict literal or a block
            # Dict literal has key: value pairs, block has statements
            if self.is_dict_literal_start():
                return self.parse_dict_literal()
            else:
                raise ParseError(f"Unexpected token: '{'{'}' in expression context", self.peek())
        
        raise ParseError(f"Unexpected token: {self.peek().value}", self.peek())
    
    def is_lambda_start(self) -> bool:
        """Check if current position starts a lambda expression."""
        # Look ahead for pattern like (param: type) -> return_type {
        saved_pos = self.current
        try:
            # Skip parameters
            paren_count = 1
            while paren_count > 0 and not self.is_at_end():
                if self.check(TokenType.Lparen):
                    paren_count += 1
                elif self.check(TokenType.Rparen):
                    paren_count -= 1
                self.advance()
            
            # Check for ->
            if self.check(TokenType.Arrow):
                return True
        finally:
            self.current = saved_pos
        return False
    
    def parse_lambda_expr(self) -> LambdaExpr:
        """Parse lambda expression: (params) -> return_type { body }"""
        lambda_token = self.previous()  # '(' token
        
        # Parse parameters (type annotation is optional for lambda parameters)
        params = []
        if not self.check(TokenType.Rparen):
            params.append(self.parse_lambda_param())
            while self.match(TokenType.Comma):
                params.append(self.parse_lambda_param())
        self.consume(TokenType.Rparen, "Expected ')' after lambda parameters")
        
        # Parse return type
        return_type = None
        if self.match(TokenType.Arrow):
            return_type = self.parse_type()
        
        # Parse body
        self.consume(TokenType.Lbrace, "Expected '{' for lambda body")
        
        body = []
        while not self.check(TokenType.Rbrace) and not self.is_at_end():
            try:
                body.append(self.parse_statement())
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                break
        
        self.consume(TokenType.Rbrace, "Expected '}' after lambda body")
        
        return LambdaExpr(lambda_token.line, lambda_token.column, params, return_type, body)
    
    def parse_array_literal(self) -> ArrayLiteralExpr:
        """Parse array literal: [expr1, expr2, ...]"""
        lbracket_token = self.previous()  # '[' token
        
        elements = []
        if not self.check(TokenType.Rbrack):
            elements.append(self.parse_expression())
            while self.match(TokenType.Comma):
                elements.append(self.parse_expression())
        
        self.consume(TokenType.Rbrack, "Expected ']' after array elements")
        return ArrayLiteralExpr(lbracket_token.line, lbracket_token.column, elements)
    
    def parse_dict_literal(self) -> DictLiteralExpr:
        """Parse dict literal: {key1: value1, key2: value2, ...}"""
        lbrace_token = self.previous()  # '{' token
        
        pairs = []
        if not self.check(TokenType.Rbrace):
            # Parse first key-value pair
            key = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after dict key")
            value = self.parse_expression()
            pairs.append((key, value))
            
            # Parse additional pairs
            while self.match(TokenType.Comma):
                key = self.parse_expression()
                self.consume(TokenType.Colon, "Expected ':' after dict key")
                value = self.parse_expression()
                pairs.append((key, value))
        
        self.consume(TokenType.Rbrace, "Expected '}' after dict literal")
        return DictLiteralExpr(lbrace_token.line, lbrace_token.column, pairs)
    
    def is_dict_literal_start(self) -> bool:
        """Check if current position starts a dict literal vs a block."""
        # Look ahead to see if we have key: value pattern
        saved_pos = self.current
        try:
            # Skip whitespace/newlines
            while self.match(TokenType.Newline):
                continue
            
            if self.is_at_end():
                return False
            
            # Next token should be an expression (key)
            if not self.is_expression_start():
                return False
            
            # Skip the key expression (simplified check)
            # In a real implementation, we'd need to parse the expression
            # For now, just check if the next non-expression token is ':'
            
            # Reset and do a simple check
            self.current = saved_pos
            
            # Skip any leading whitespace/newlines
            while self.match(TokenType.Newline):
                continue
            
            # Check if we have something that looks like a key followed by ':'
            # This is a simplified heuristic
            token_count = 0
            found_colon = False
            
            while token_count < 5 and not self.is_at_end():  # Look ahead up to 5 tokens
                token = self.advance()
                token_count += 1
                
                if token.type == TokenType.Colon:
                    found_colon = True
                    break
                elif token.type in [TokenType.Comma, TokenType.Rbrace]:
                    break
            
            self.current = saved_pos
            return found_colon
            
        except:
            self.current = saved_pos
            return False
    
    def is_expression_start(self) -> bool:
        """Check if current token can start an expression."""
        if self.is_at_end():
            return False
        
        current = self.peek()
        expression_starters = {
            TokenType.true, TokenType.false, TokenType.Int, TokenType.Float,
            TokenType.String, TokenType.Char, TokenType.IDENTIFIER,
            TokenType.Lparen, TokenType.Lbrack, TokenType.Lbrace,
            TokenType.Ref, TokenType.MutRef, TokenType.Minus, TokenType.Not,
            TokenType.Bang
        }
        
        return current.type in expression_starters
    
    def parse_match_expr(self) -> MatchExpr:
        """Parse match expression: match expr { pattern => expr, ... }"""
        match_token = self.advance()  # consume 'match'
        
        # Parse the expression to match on
        expr = self.parse_expression()
        
        # Parse match arms
        self.consume(TokenType.Lbrace, "Expected '{' after match expression")
        
        arms = []
        while not self.check(TokenType.Rbrace) and not self.is_at_end():
            # Parse pattern
            pattern = self.parse_expression()
            
            # Parse '=>'
            self.consume(TokenType.Arrow, "Expected '=>' after match pattern")
            
            # Parse expression
            arm_expr = self.parse_expression()
            
            arms.append((pattern, arm_expr))
            
            # Check for comma (except for last arm)
            if not self.check(TokenType.Rbrace):
                self.consume(TokenType.Comma, "Expected ',' after match arm")
        
        self.consume(TokenType.Rbrace, "Expected '}' after match arms")
        
        return MatchExpr(match_token.line, match_token.column, expr, arms)
    
    def parse_block(self, end_tokens: List[TokenType] = None, max_depth: int = 100) -> List[Statement]:
        """Parse a block of statements until end tokens or dedent with depth protection."""
        if end_tokens is None:
            end_tokens = [TokenType.Fun, TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl]
        
        print(f"DEBUG parse_block: Starting at position {self.current}, token: {self.peek()}")
        statements = []
        depth = 0
        
        # Consume initial Indent token if present (indentation-based block)
        if self.match(TokenType.Indent):
            print(f"DEBUG parse_block: Consumed Indent token")
            pass  # Indent consumed, now parse block content
        
        while not self.is_at_end() and depth < max_depth:
            print(f"DEBUG parse_block: Loop iteration, position {self.current}, token: {self.peek()}")
            # Skip newlines but NOT Dedent tokens - they're important for block boundaries
            while self.match(TokenType.Newline) or self.match(TokenType.Indent):
                print(f"DEBUG parse_block: Skipped newline/indent, now at position {self.current}")
                continue
            
            # Check for block termination conditions
            if self.check(TokenType.EoF):
                print(f"DEBUG parse_block: Found EOF, breaking")
                break
                
            # Check for end tokens FIRST (before Dedent)
            if any(self.check(token) for token in end_tokens):
                print(f"DEBUG parse_block: Found end token, breaking")
                break
                
            if self.check(TokenType.Dedent):
                # Always consume the Dedent token
                print(f"DEBUG parse_block: Found Dedent, consuming and breaking")
                self.advance()
                break
            
            # Handle nested structures with braces
            if self.check(TokenType.Lbrace):
                depth += 1
                self.advance()  # consume '{'
                continue
            elif self.check(TokenType.Rbrace):
                if depth == 0:
                    break
                depth -= 1
                self.advance()  # consume '}'
                continue
            
            try:
                print(f"DEBUG parse_block: About to parse statement at position {self.current}")
                stmt = self.parse_statement()
                print(f"DEBUG parse_block: Parsed statement: {stmt}")
                if stmt:  # Only add non-null statements
                    statements.append(stmt)
            except ParseError as e:
                print(f"DEBUG parse_block: ParseError: {e}")
                self.errors.append(e)
                self.synchronize()
                # Try to continue parsing the block
                continue
        
        print(f"DEBUG parse_block: Returning {len(statements)} statements")
        return statements
    
    def is_at_statement_start(self) -> bool:
        """Check if current position is at the start of a new statement/declaration."""
        if self.is_at_end():
            return False
            
        current_token = self.peek()
        
        # Check if we're at a token that starts a statement
        statement_starters = {
            TokenType.Target, TokenType.Plugin, TokenType.Requires, TokenType.Import,
            TokenType.Start, TokenType.End, TokenType.Temp, TokenType.Fun, TokenType.Class,
            TokenType.Trait, TokenType.Impl, TokenType.Const, TokenType.Del, TokenType.Ifblk,
            TokenType.Switch, TokenType.Forlp, TokenType.Whilelp, TokenType.Repeat,
            TokenType.Return, TokenType.Break, TokenType.Continue, TokenType.Unsafe, TokenType.Asm
        }
        
        if current_token.type in statement_starters:
            return True
            
        # Check for variable declarations (let/var)
        if current_token.type == TokenType.IDENTIFIER and current_token.value in ['let', 'var']:
            return True
            
        return False
    def match(self, token_type: TokenType) -> bool:
        """Check if current token matches given type."""
        if self.check(token_type):
            self.advance()
            return True
        return False
    
    def check(self, token_type: TokenType) -> bool:
        """Check if current token is of given type."""
        if self.is_at_end():
            return False
        return self.peek().type == token_type
    
    def advance(self) -> Token:
        """Consume current token and advance."""
        if not self.is_at_end():
            self.current += 1
        return self.previous()
    
    def is_at_end(self) -> bool:
        """Check if we've reached end of tokens."""
        return self.peek().type == TokenType.EoF
    
    def peek(self) -> Token:
        """Get current token without consuming it."""
        return self.tokens[self.current]
    
    def previous(self) -> Token:
        """Get previous token."""
        return self.tokens[self.current - 1]
    
    def consume(self, token_type: TokenType, message: str) -> Token:
        """Consume token of expected type or raise error."""
        if self.check(token_type):
            return self.advance()
        raise ParseError(message, self.peek())
    
    def consume_statement_end(self, message: str = "Expected ';' or newline after statement"):
        """Consume statement terminator (semicolon or newline)."""
        if self.match(TokenType.Semicolon):
            return
        if self.match(TokenType.Newline):
            return
        # If neither, try to continue (for error recovery)
        # But raise error if we're clearly at end of statement
        if not self.is_at_end() and not self.check(TokenType.Dedent):
            raise ParseError(message, self.peek())
    
    def synchronize(self):
        """Synchronize parser after error to continue parsing."""
        self.advance()
        
        while not self.is_at_end():
            # Skip tokens until we find a synchronization point
            if self.previous().type == TokenType.Semicolon:
                return
            
            if self.previous().type == TokenType.Newline:
                # Check if next token starts a new statement
                if self.is_at_statement_start():
                    return
            
            # Check for block boundaries
            if self.previous().type in [TokenType.Rbrace, TokenType.Dedent]:
                return
            
            # Check for major statement starters
            if self.peek().type in [TokenType.Fun, TokenType.Class, TokenType.Trait, 
                                   TokenType.Impl, TokenType.Ifblk, TokenType.Whilelp,
                                   TokenType.Forlp, TokenType.Repeat, TokenType.Switch,
                                   TokenType.Return, TokenType.Break, TokenType.Continue,
                                   TokenType.Del, TokenType.Const, TokenType.Target,
                                   TokenType.Import, TokenType.Requires, TokenType.Plugin,
                                   TokenType.Start, TokenType.End]:
                return
            
            # Check for variable declarations and class fields
            if self.peek().type == TokenType.IDENTIFIER:
                next_next = self.tokens[self.current + 1] if self.current + 1 < len(self.tokens) else None
                if next_next and (next_next.value in ['let', 'var'] or next_next.type == TokenType.Colon):
                    return
            
            # Check for end of file
            if self.peek().type == TokenType.EoF:
                return
            
            self.advance()
    
    # Statement parsing methods (to be implemented)
    def parse_target_directive(self) -> TargetDirective:
        """Parse #target directive, supporting both single-line and multiline formats."""
        # Skip newline if present (multiline format)
        if self.match(TokenType.Newline):
            # Multiline format: #target\nos = "linux"\narch = "x86-64"
            # For now, collect the target info as a string representation
            # In a full implementation, this would parse the assignments properly
            target_parts = []
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.check(TokenType.Newline) or self.check(TokenType.Dedent):
                    break
                if self.check(TokenType.IDENTIFIER):
                    key = self.advance().value
                    if self.match(TokenType.Assign):
                        if self.check(TokenType.String):
                            value = self.advance().value
                            target_parts.append(f"{key}={value}")
                else:
                    self.advance()  # Skip other tokens
            target = "\n".join(target_parts) if target_parts else ""
        else:
            # Single-line format: #target "string";
            target = self.consume(TokenType.String, "Expected target string after #target").value
            self.consume(TokenType.Semicolon, "Expected ';' after target directive")
        return TargetDirective(self.previous().line, self.previous().column, target)
    
    def parse_plugin_directive(self) -> PluginDirective:
        plugin = self.consume(TokenType.String, "Expected plugin string after #plugin").value
        self.consume(TokenType.Semicolon, "Expected ';' after plugin directive")
        return PluginDirective(self.previous().line, self.previous().column, plugin)
    
    def parse_requires_directive(self) -> RequiresDirective:
        """Parse #requires directive, supporting both single-line and multiline formats."""
        # Skip newline if present (multiline format)
        if self.match(TokenType.Newline):
            # Multiline format: #requires\n"kernel32.dll"\n"libc.so.6"
            # Collect all string literals
            requires = []
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.check(TokenType.Newline) or self.check(TokenType.Dedent):
                    break
                if self.check(TokenType.String):
                    requires.append(self.advance().value)
                else:
                    self.advance()  # Skip other tokens
            version = "\n".join(requires) if requires else ""
        else:
            # Single-line format: #requires "kernel32.dll";
            version = self.consume(TokenType.String, "Expected version string after #requires").value
            self.consume(TokenType.Semicolon, "Expected ';' after requires directive")
        return RequiresDirective(self.previous().line, self.previous().column, version)
    
    def parse_import_directive(self) -> ImportDirective:
        """Parse #import directive, supporting both single-line and multiline formats."""
        # Skip newline if present (multiline format)
        if self.match(TokenType.Newline):
            # Multiline format: #import\nstd.core.cli\nstd.os.fs as fs
            # For multiline, take the first module (simplified - full impl would handle multiple)
            if self.check(TokenType.IDENTIFIER):
                module_parts = []
                module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module name after #import").value)
                
                while self.match(TokenType.Dot):
                    module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module part after '.'").value)
                
                module = ".".join(module_parts)
                alias = None
                
                # Check for 'as' keyword
                if self.check(TokenType.IDENTIFIER) and self.peek().value == "as":
                    self.advance()  # consume 'as'
                    alias = self.consume(TokenType.IDENTIFIER, "Expected alias after 'as'").value
            else:
                module = ""
                alias = None
        else:
            # Single-line format: #import std.core.cli;
            module_parts = []
            module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module name after #import").value)
            
            while self.match(TokenType.Dot):
                module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module part after '.'").value)
            
            module = ".".join(module_parts)
            alias = None
            
            # Check for 'as' keyword
            if self.check(TokenType.IDENTIFIER) and self.peek().value == "as":
                self.advance()  # consume 'as'
                alias = self.consume(TokenType.IDENTIFIER, "Expected alias after 'as'").value
            
            self.consume(TokenType.Semicolon, "Expected ';' after import directive")
        return ImportDirective(self.previous().line, self.previous().column, module, alias)
    
    def parse_start_directive(self) -> StartDirective:
        function = self.consume(TokenType.IDENTIFIER, "Expected function name after #start").value
        self.consume(TokenType.Semicolon, "Expected ';' after start directive")
        return StartDirective(self.previous().line, self.previous().column, function)
    
    def parse_end_directive(self) -> EndDirective:
        function = self.consume(TokenType.IDENTIFIER, "Expected function name after #end").value
        self.consume(TokenType.Semicolon, "Expected ';' after end directive")
        return EndDirective(self.previous().line, self.previous().column, function)
    
    def parse_type_parameter(self) -> str:
        """Parse a type parameter with optional constraints."""
        param_name = self.consume(TokenType.IDENTIFIER, "Expected type parameter name").value
        
        # Check for constraints: T: Comparable + Send
        constraints = []
        if self.match(TokenType.Colon):
            # Parse first constraint
            if self.check(TokenType.IDENTIFIER):
                constraints.append(self.consume(TokenType.IDENTIFIER, "Expected constraint").value)
            
            # Parse additional constraints with +
            while self.match(TokenType.Plus):
                if self.check(TokenType.IDENTIFIER):
                    constraints.append(self.consume(TokenType.IDENTIFIER, "Expected constraint").value)
                else:
                    raise ParseError("Expected constraint after '+'")
        
        # Return parameter with constraints
        if constraints:
            return f"{param_name}: {' + '.join(constraints)}"
        return param_name
    
    def parse_generic_function_decl(self) -> FunctionDecl:
        """Parse generic function declaration with temp[T] prefix."""
        temp_token = self.previous()  # 'temp' token
        
        # Parse type parameters
        self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
        type_params = []
        if not self.check(TokenType.Rbrack):
            type_params.append(self.parse_type_parameter())
            while self.match(TokenType.Comma):
                type_params.append(self.parse_type_parameter())
        self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse 'fun' keyword
        self.consume(TokenType.Fun, "Expected 'fun' after type parameters")
        fun_token = self.previous()
        
        # Parse function name
        name = self.consume(TokenType.IDENTIFIER, "Expected function name").value
        
        # Parse parameters
        self.consume(TokenType.Lparen, "Expected '(' after function name")
        params = []
        if not self.check(TokenType.Rparen):
            params.append(self.parse_param())
            while self.match(TokenType.Comma):
                params.append(self.parse_param())
        self.consume(TokenType.Rparen, "Expected ')' after parameters")
        
        # Parse return type
        return_type = None
        if self.match(TokenType.Arrow):
            return_type = self.parse_type()
        
        # Parse function body
        self.consume(TokenType.Colon, "Expected ':' before function body")
        body = self.parse_block()
        
        # Parse attributes (simplified for now)
        attributes = []
        
        return FunctionDecl(fun_token.line, fun_token.column, name, type_params, params, return_type, body, attributes)
    
    def parse_function_decl(self) -> FunctionDecl:
        """Parse function declaration including FFI attributes."""
        fun_token = self.previous()  # 'fun' token
        
        # Parse function attributes: fun[async], fun[thread], fun[const], fun[ffi], fun[class]
        attributes = []
        if self.match(TokenType.Lbrack):
            # Parse attribute list: [async], [thread], [const], [ffi("lib.so", abi="cdecl")], [class]
            while True:
                if self.match(TokenType.Async):
                    attributes.append("async")
                elif self.match(TokenType.Thread):
                    attributes.append("thread")
                elif self.match(TokenType.Const):
                    attributes.append("const")
                elif self.match(TokenType.Ffi):
                    # Parse FFI attribute: ffi("lib.so", abi="cdecl")
                    ffi_attr = "ffi"
                    if self.match(TokenType.Lparen):
                        if self.check(TokenType.String):
                            lib_name = self.consume(TokenType.String, "Expected library name").value
                            ffi_attr = f'ffi("{lib_name}"'
                            # Check for abi parameter
                            if self.match(TokenType.Comma):
                                if self.check(TokenType.IDENTIFIER) and self.peek().value == "abi":
                                    self.advance()  # consume 'abi'
                                    self.consume(TokenType.Assign, "Expected '=' after 'abi'")
                                    abi = self.consume(TokenType.String, "Expected ABI name").value
                                    ffi_attr += f', abi="{abi}"'
                            self.consume(TokenType.Rparen, "Expected ')' after FFI parameters")
                            ffi_attr += ")"
                        else:
                            self.consume(TokenType.Rparen, "Expected ')' after FFI")
                    attributes.append(ffi_attr)
                elif self.check(TokenType.IDENTIFIER) and self.peek().value == "class":
                    self.advance()  # consume 'class'
                    attributes.append("class")
                else:
                    break
                
                # Check for more attributes (comma-separated)
                if not self.match(TokenType.Comma):
                    break
            
            self.consume(TokenType.Rbrack, "Expected ']' after function attributes")
        
        # Parse function name
        name = self.consume(TokenType.IDENTIFIER, "Expected function name").value
        
        # Parse parameters
        self.consume(TokenType.Lparen, "Expected '(' after function name")
        params = []
        if not self.check(TokenType.Rparen):
            params.append(self.parse_param())
            while self.match(TokenType.Comma):
                params.append(self.parse_param())
        self.consume(TokenType.Rparen, "Expected ')' after parameters")
        
        # Parse return type
        return_type = None
        if self.match(TokenType.Arrow):
            return_type = self.parse_type()
        
        # Check if this is a method (has [class] attribute or &self parameter)
        is_method = "class" in attributes
        if not is_method and params:
            # Check if first parameter is &self
            first_param = params[0]
            if first_param.name == "self" and isinstance(first_param.type_annotation, ReferenceType):
                is_method = True
        
        # Parse function body
        self.consume(TokenType.Colon, "Expected ':' before function body")
        
        # Check if this is an FFI function (no body)
        if any("ffi" in attr or "extern" in attr for attr in attributes):
            # FFI functions have no body
            body = []
        else:
            body = self.parse_block()
        
        return FunctionDecl(fun_token.line, fun_token.column, name, [], params, return_type, body, attributes, False, is_method)
    
    def parse_lambda_param(self) -> Param:
        """Parse lambda parameter (type annotation optional): x or x: Type"""
        # Parse parameter name
        name_token = self.consume(TokenType.IDENTIFIER, "Expected parameter name")
        name = name_token.value
        
        # Type annotation is optional for lambda parameters
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        else:
            # If no type annotation, create a placeholder type
            # In a full implementation, this would be inferred
            type_annotation = BasicType(name_token.line, name_token.column, "inferred")
        
        return Param(name, type_annotation, False, None)
    
    def parse_param(self) -> Param:
        """Parse function parameter."""
        # Check for reference parameters: &self, &mut self
        is_ref = False
        is_mut_ref = False
        if self.match(TokenType.Ref):
            is_ref = True
        elif self.match(TokenType.MutRef):
            is_mut_ref = True
            is_ref = True  # &mut is also a reference
        
        # Parse parameter name
        name_token = self.consume(TokenType.IDENTIFIER, "Expected parameter name")
        name = name_token.value
        
        # Parse type annotation (required for parameters, unless it's &self which is special)
        if name == "self" and is_ref:
            # &self or &mut self - create a reference type with 'self' as the base type name
            # For now, use a BasicType with name "self" wrapped in ReferenceType
            base_type = BasicType(name_token.line, name_token.column, "self")
            type_annotation = ReferenceType(name_token.line, name_token.column, base_type, is_mut_ref)
        else:
            self.consume(TokenType.Colon, "Expected ':' after parameter name")
            type_annotation = self.parse_type()
            # If we had & or &mut, wrap the type in ReferenceType
            if is_ref:
                type_annotation = ReferenceType(type_annotation.line, type_annotation.column, type_annotation, is_mut_ref)
        
        # Check for mutability
        is_mutable = is_mut_ref
        
        # Check for default value: param: Type = default
        default_value = None
        if self.match(TokenType.Assign):
            default_value = self.parse_expression()
        
        return Param(name, type_annotation, is_mutable, default_value)
    
    def parse_class_field(self) -> VarDecl:
        """Parse class field declaration: name: type [= initializer]"""
        name_token = self.consume(TokenType.IDENTIFIER, "Expected field name")
        name = name_token.value
        
        self.consume(TokenType.Colon, "Expected ':' after field name")
        
        # Parse type annotation
        type_annotation = self.parse_type()
        
        # Check for optional initializer
        initializer = None
        if self.match(TokenType.Assign):
            initializer = self.parse_expression()
        
        # Consume statement end
        self.consume_statement_end("Expected ';' or newline after field declaration")
        
        # Create a VarDecl to represent the field
        return VarDecl(name_token.line, name_token.column, name, type_annotation, initializer, False)
    
    def parse_class_decl(self) -> ClassDecl:
        """Parse class declaration including actor classes and arena allocation."""
        class_token = self.previous()  # 'class' token
        
        # Parse class name
        name = self.consume(TokenType.IDENTIFIER, "Expected class name").value
        
        # Parse type parameters (generics)
        type_params = []
        if self.match(TokenType.Temp):
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse attributes (actor, linear, etc.)
        attributes = []
        if self.match(TokenType.Actor):
            attributes.append("actor")
            # Actor classes may have additional actor-specific parameters
            if self.match(TokenType.Lparen):
                # Parse actor configuration: class[actor](max_concurrent = 10)
                while not self.check(TokenType.Rparen) and not self.is_at_end():
                    if self.match(TokenType.IDENTIFIER):
                        param_name = self.previous().value
                        self.consume(TokenType.Assign, "Expected '=' after actor parameter name")
                        param_value = self.parse_expression()
                        # Store actor parameters (simplified - would need proper AST node)
                        attributes.append(f"{param_name}={param_value}")
                    if not self.match(TokenType.Comma):
                        break
                self.consume(TokenType.Rparen, "Expected ')' after actor parameters")
        elif self.match(TokenType.Linear):
            attributes.append("linear")
        
        # Parse inheritance (optional)
        base_class = None
        if self.match(TokenType.Lparen):
            # Inheritance: class Name(Parent):
            base_class = self.consume(TokenType.IDENTIFIER, "Expected base class name").value
            self.consume(TokenType.Rparen, "Expected ')' after base class name")
        
        # Parse class body
        self.consume(TokenType.Colon, "Expected ':' before class body")
        
        # Skip newline after colon
        if self.match(TokenType.Newline):
            pass
        
        fields = []
        methods = []
        
        # Parse class body using block parsing
        print(f"DEBUG: About to parse class body, current position: {self.current}")
        print(f"DEBUG: Current token: {self.peek()}")
        body_statements = self.parse_block([TokenType.Fun, TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl])
        print(f"DEBUG: Parsed {len(body_statements)} statements from class body")
        for i, stmt in enumerate(body_statements):
            print(f"DEBUG: Statement {i}: {stmt}")
        
        for stmt in body_statements:
            if isinstance(stmt, VarDecl):
                # Field declaration (could be let/var or just name: type)
                fields.append(stmt)
            elif isinstance(stmt, FunctionDecl):
                # Method declaration
                methods.append(stmt)
            else:
                # Could be other statements, handle as needed
                pass
        
        return ClassDecl(class_token.line, class_token.column, name, type_params, fields, methods, attributes, base_class)
    
    def parse_trait_decl(self) -> TraitDecl:
        """Parse trait declaration."""
        trait_token = self.previous()  # 'trait' token
        
        # Parse trait name
        name = self.consume(TokenType.IDENTIFIER, "Expected trait name").value
        
        # Parse type parameters (generics)
        type_params = []
        if self.match(TokenType.Temp):
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse super traits
        super_traits = []
        if self.match(TokenType.Colon):
            super_traits.append(self.consume(TokenType.IDENTIFIER, "Expected super trait name").value)
            while self.match(TokenType.Comma):
                super_traits.append(self.consume(TokenType.IDENTIFIER, "Expected super trait name").value)
        
        # Parse trait body
        self.consume(TokenType.Colon, "Expected ':' before trait body")
        
        methods = []
        
        # Parse trait methods using block parsing
        while not self.is_at_end():
            if self.check(TokenType.Dedent) or self.check(TokenType.EoF):
                break
                
            if self.is_at_statement_start():
                if any(self.check(token) for token in [TokenType.Fun, TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl]):
                    break
            
            try:
                if self.check(TokenType.Fun):
                    # Method signature (simplified - no body for traits)
                    method = self.parse_function_decl()
                    method.body = []  # Traits don't have implementations
                    methods.append(method)
                else:
                    break
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                break
        
        return TraitDecl(trait_token.line, trait_token.column, name, type_params, methods, super_traits)
    
    def parse_impl_decl(self) -> ImplDecl:
        """Parse implementation block."""
        impl_token = self.previous()  # 'impl' token
        
        # Simple implementation: just parse type name for now
        type_name = self.consume(TokenType.IDENTIFIER, "Expected type name").value
        
        # Parse type parameters (generics)
        type_params = []
        if self.match(TokenType.Temp):
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse impl body
        self.consume(TokenType.Colon, "Expected ':' before impl body")
        
        methods = []
        
        # Parse implementation methods using block parsing
        while not self.is_at_end():
            if self.check(TokenType.Dedent) or self.check(TokenType.EoF):
                break
                
            if self.is_at_statement_start():
                if any(self.check(token) for token in [TokenType.Fun, TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl]):
                    break
            
            try:
                if self.check(TokenType.Fun):
                    methods.append(self.parse_function_decl())
                else:
                    break
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                break
        
        return ImplDecl(impl_token.line, impl_token.column, "", type_name, type_params, methods)
    
    def parse_var_decl(self) -> VarDecl:
        """Parse variable declaration (let/var)."""
        decl_token = self.advance()  # consume 'let' or 'var'
        is_mutable = decl_token.value == 'var'
        
        name = self.consume(TokenType.IDENTIFIER, "Expected variable name").value
        
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        
        initializer = None
        if self.match(TokenType.Assign):
            initializer = self.parse_expression()
        
        self.consume_statement_end("Expected ';' or newline after variable declaration")
        
        return VarDecl(decl_token.line, decl_token.column, name, type_annotation, initializer, is_mutable)
    
    def parse_type(self) -> Type:
        """Parse type annotations including arena allocation."""
        if self.match(TokenType.Int):
            return BasicType(self.previous().line, self.previous().column, "int")
        elif self.match(TokenType.Float):
            return BasicType(self.previous().line, self.previous().column, "float")
        elif self.match(TokenType.Bool):
            return BasicType(self.previous().line, self.previous().column, "bool")
        elif self.match(TokenType.String):
            return BasicType(self.previous().line, self.previous().column, "string")
        elif self.match(TokenType.Char):
            return BasicType(self.previous().line, self.previous().column, "char")
        elif self.match(TokenType.Array):
            return self.parse_array_type()
        elif self.match(TokenType.Vector):
            return self.parse_vector_type()
        elif self.match(TokenType.Dict):
            return self.parse_dict_type()
        elif self.match(TokenType.Set):
            return self.parse_set_type()
        elif self.match(TokenType.Gc) or self.match(TokenType.GcWeak):
            return self.parse_gc_type()
        elif self.match(TokenType.Option):
            return self.parse_option_type()
        elif self.match(TokenType.Result):
            return self.parse_result_type()
        elif self.match(TokenType.IDENTIFIER):
            # Could be a basic type, generic type, or user-defined type
            type_name = self.previous().value
            
            # Check for generic type arguments
            if self.match(TokenType.Lbrack):
                type_args = []
                if not self.check(TokenType.Rbrack):
                    type_args.append(self.parse_type())
                    while self.match(TokenType.Comma):
                        type_args.append(self.parse_type())
                self.consume(TokenType.Rbrack, "Expected ']' after type arguments")
                return GenericType(self.previous().line, self.previous().column, type_name, type_args)
            else:
                return BasicType(self.previous().line, self.previous().column, type_name)
        elif self.match(TokenType.Ref):
            inner_type = self.parse_type()
            return ReferenceType(inner_type.line, inner_type.column, inner_type, False)
        elif self.match(TokenType.MutRef):
            inner_type = self.parse_type()
            return ReferenceType(inner_type.line, inner_type.column, inner_type, True)
        else:
            raise ParseError(f"Expected type, found: {self.peek().value}", self.peek())
    
    def parse_gc_type(self) -> GcType:
        """Parse garbage collected type: gc[T] or gc_weak[T] with advanced options."""
        gc_token = self.previous()
        is_weak = False
        
        # Check for gc_weak
        if gc_token.value == "gc_weak":
            is_weak = True
        
        self.consume(TokenType.Lbrack, "Expected '[' after gc")
        inner_type = self.parse_type()
        
        # Check for arena allocation parameters
        arena_params = None
        if self.match(TokenType.Comma):
            # Parse arena allocation parameters: gc[T, arena_id] or gc[T, size]
            if self.match(TokenType.IDENTIFIER):
                # Named arena: gc[T, "my_arena"]
                if self.match(TokenType.String):
                    arena_name = self.previous().value
                    arena_params = {"name": arena_name}
                else:
                    # Arena identifier: gc[T, main]
                    arena_id = self.previous().value
                    arena_params = {"id": arena_id}
            elif self.match(TokenType.Int):
                # Sized arena: gc[T, 1024]
                arena_size = self.previous().value
                arena_params = {"size": arena_size}
        
        self.consume(TokenType.Rbrack, "Expected ']' after gc type")
        
        gc_type = GcType(gc_token.line, gc_token.column, inner_type, is_weak)
        gc_type.arena_params = arena_params  # Add arena parameters
        return gc_type
    
    def parse_option_type(self) -> OptionType:
        """Parse Option type: Option[T]"""
        option_token = self.previous()
        self.consume(TokenType.Lbrack, "Expected '[' after 'Option'")
        some_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after Option type")
        return OptionType(option_token.line, option_token.column, some_type)
    
    def parse_result_type(self) -> ResultType:
        """Parse Result type: Result[T, E]"""
        result_token = self.previous()
        self.consume(TokenType.Lbrack, "Expected '[' after 'Result'")
        ok_type = self.parse_type()
        self.consume(TokenType.Comma, "Expected ',' after Result ok type")
        err_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after Result type")
        return ResultType(result_token.line, result_token.column, ok_type, err_type)
    
    def parse_array_type(self) -> ArrayType:
        """Parse array type: array[element_type] or array[element_type, size]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'array'")
        element_type = self.parse_type()
        size = None
        if self.match(TokenType.Comma):
            size = self.parse_expression()
        self.consume(TokenType.Rbrack, "Expected ']' after array type")
        return ArrayType(element_type.line, element_type.column, element_type, size)
    
    def parse_vector_type(self) -> VectorType:
        """Parse vector type: vector[element_type]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'vector'")
        element_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after vector type")
        return VectorType(element_type.line, element_type.column, element_type)
    
    def parse_dict_type(self) -> DictType:
        """Parse dict type: dict[key_type, value_type]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'dict'")
        key_type = self.parse_type()
        self.consume(TokenType.Comma, "Expected ',' after dict key type")
        value_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after dict type")
        return DictType(key_type.line, key_type.column, key_type, value_type)
    
    def parse_set_type(self) -> SetType:
        """Parse set type: set[element_type]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'set'")
        element_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after set type")
        return SetType(element_type.line, element_type.column, element_type)
    
    def parse_const_decl(self) -> ConstDecl:
        name_token = self.consume(TokenType.IDENTIFIER, "Expected constant name after 'const'")
        name = name_token.value
        
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        
        self.consume(TokenType.Assign, "Expected '=' after constant declaration")
        initializer = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after constant declaration")
        
        return ConstDecl(
            name=name,
            type_annotation=type_annotation,
            initializer=initializer,
            line=name_token.line,
            column=name_token.column
        )
    
    def parse_del_stmt(self) -> DelStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after del statement")
        return DelStmt(expr.line, expr.column, expr)
    
    def parse_if_stmt(self) -> IfStmt:
        """Parse if statement with proper block handling."""
        if_token = self.previous()  # 'if' token
        
        condition = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after if condition")
        
        # Parse then branch
        then_branch = []
        
        # Skip newline after colon
        self.consume(TokenType.Newline, "Expected newline after ':'")
        
        # Consume the Indent
        self.consume(TokenType.Indent, "Expected indent after if condition")
        
        # Parse statements until Dedent
        while not self.check(TokenType.Dedent) and not self.is_at_end():
            try:
                stmt = self.parse_statement()
                if stmt:
                    then_branch.append(stmt)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                break
        
        # Consume the Dedent
        self.consume(TokenType.Dedent, "Expected dedent after if block")
        
        # Parse elsif branches
        elif_branches = []
        while self.match(TokenType.Elsif):
            elif_condition = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after elsif condition")
            
            # Skip newline after colon
            self.consume(TokenType.Newline, "Expected newline after ':'")
            
            elif_body = []
            self.consume(TokenType.Indent, "Expected indent after elsif condition")
            while not self.check(TokenType.Dedent) and not self.is_at_end():
                try:
                    stmt = self.parse_statement()
                    if stmt:
                        elif_body.append(stmt)
                except ParseError as e:
                    self.errors.append(e)
                    self.synchronize()
                    break
            self.consume(TokenType.Dedent, "Expected dedent after elsif block")
            elif_branches.append((elif_condition, elif_body))
        
        # Parse else branch
        else_branch = None
        if self.match(TokenType.Elseblk):
            self.consume(TokenType.Colon, "Expected ':' after 'else'")
            
            # Skip newline after colon
            self.consume(TokenType.Newline, "Expected newline after ':'")
            
            else_branch = []
            self.consume(TokenType.Indent, "Expected indent after else")
            while not self.check(TokenType.Dedent) and not self.is_at_end():
                try:
                    stmt = self.parse_statement()
                    if stmt:
                        else_branch.append(stmt)
                except ParseError as e:
                    self.errors.append(e)
                    self.synchronize()
                    break
            self.consume(TokenType.Dedent, "Expected dedent after else block")
        
        return IfStmt(if_token.line, if_token.column, condition, then_branch, elif_branches, else_branch)
    
    def parse_switch_stmt(self) -> SwitchStmt:
        """Parse switch statement with proper block handling."""
        switch_token = self.previous()  # 'switch' token
        
        expression = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after switch expression")
        
        cases = []
        default_case = None
        
        # Parse cases
        while not self.is_at_end() and not self.check(TokenType.Default):
            if self.is_at_statement_start() and not self.check(TokenType.Case):
                break
                
            self.consume(TokenType.Case, "Expected 'case' in switch statement")
            case_expr = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after case expression")
            
            case_body = self.parse_block([TokenType.Case, TokenType.Default])
            cases.append((case_expr, case_body))
        
        # Parse default case
        if self.match(TokenType.Default):
            self.consume(TokenType.Colon, "Expected ':' after default")
            default_case = self.parse_block()
        
        return SwitchStmt(switch_token.line, switch_token.column, expression, cases, default_case)
    
    def parse_for_stmt(self) -> ForStmt:
        """Parse for loop with proper block handling."""
        for_token = self.previous()  # 'for' token
        
        var_token = self.consume(TokenType.IDENTIFIER, "Expected variable name after 'for'")
        variable = var_token.value
        
        self.consume(TokenType.In, "Expected 'in' after for loop variable")
        iterable = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after for loop iterable")
        
        # Parse for loop body using block parsing
        body = self.parse_block()
        
        return ForStmt(for_token.line, for_token.column, variable, iterable, body)
    
    def parse_while_stmt(self) -> WhileStmt:
        """Parse while loop with proper block handling."""
        while_token = self.previous()  # 'while' token
        
        condition = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after while condition")
        
        # Parse while loop body using block parsing
        body = self.parse_block()
        
        return WhileStmt(while_token.line, while_token.column, condition, body)
    
    def parse_repeat_stmt(self) -> RepeatStmt:
        """Parse repeat loop with proper block handling."""
        repeat_token = self.previous()  # 'repeat' token
        
        self.consume(TokenType.Colon, "Expected ':' after 'repeat'")
        
        # Parse repeat body using block parsing
        body = self.parse_block([TokenType.Until])
        
        self.consume(TokenType.Until, "Expected 'until' after repeat body")
        until_condition = self.parse_expression()
        # No semicolon required after until condition (per spec)
        self.consume_statement_end("Expected ';' or newline after repeat-until statement")
        
        return RepeatStmt(repeat_token.line, repeat_token.column, body, until_condition)
    
    def parse_return_stmt(self) -> ReturnStmt:
        expr = None
        if not self.check(TokenType.Semicolon) and not self.check(TokenType.Newline):
            expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after return statement")
        return ReturnStmt(self.previous().line, self.previous().column, expr)
    
    def parse_break_stmt(self) -> BreakStmt:
        self.consume_statement_end("Expected ';' or newline after break statement")
        return BreakStmt(self.previous().line, self.previous().column)
    
    def parse_continue_stmt(self) -> ContinueStmt:
        self.consume_statement_end("Expected ';' or newline after continue statement")
        return ContinueStmt(self.previous().line, self.previous().column)
    
    def parse_unsafe_stmt(self) -> UnsafeStmt:
        """Parse unsafe block."""
        self.consume(TokenType.Colon, "Expected ':' after 'unsafe'")
        
        statements = self.parse_block()
        
        return UnsafeStmt(statements[0].line if statements else 1, statements[0].column if statements else 1, statements)
    
    def parse_asm_stmt(self) -> AsmStmt:
        """Parse assembly statement with comprehensive support."""
        self.consume(TokenType.Colon, "Expected ':' after 'asm'")
        
        # Parse assembly template (string)
        template = self.consume(TokenType.String, "Expected assembly template string").value
        
        # Parse inputs, outputs, and clobbers
        inputs = []
        outputs = []
        clobbers = []
        
        # Parse input constraints: "r"(expr)
        while self.match(TokenType.String) and self.previous().value.startswith('"'):
            constraint = self.previous().value
            if self.match(TokenType.Lparen):
                input_expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after assembly input expression")
                inputs.append((constraint, input_expr))
            else:
                break
        
        # Parse output constraints: "=r"(variable)
        while self.match(TokenType.String) and self.previous().value.startswith('"='):
            constraint = self.previous().value
            if self.match(TokenType.Lparen):
                if self.match(TokenType.IDENTIFIER):
                    output_var = self.previous().value
                    self.consume(TokenType.Rparen, "Expected ')' after assembly output variable")
                    outputs.append((constraint, output_var))
                else:
                    raise ParseError("Expected variable name for assembly output")
            else:
                break
        
        # Parse clobbers: "cc", "memory"
        while self.match(TokenType.String):
            clobber = self.previous().value
            if clobber.startswith('"') and not clobber.startswith('"='):
                clobbers.append(clobber)
            else:
                break
        
        return AsmStmt(template, inputs, outputs, clobbers)
    
    def parse_expr_stmt(self) -> ExprStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after expression")
        return ExprStmt(expr.line, expr.column, expr)
    
    def finish_call(self, callee: Expression) -> CallExpr:
        """Finish parsing a function call."""
        arguments = []
        
        if not self.check(TokenType.Rparen):
            arguments.append(self.parse_expression())
            while self.match(TokenType.Comma):
                arguments.append(self.parse_expression())
        
        self.consume(TokenType.Rparen, "Expected ')' after arguments")
        return CallExpr(callee.line, callee.column, callee, arguments)
