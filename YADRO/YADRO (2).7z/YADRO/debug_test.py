import sys
sys.path.append('modules')

from parserr import YadroParser
from lexer import Lexer

source = """if x > 0:
    cli.print("positive")
else:
    cli.print("non-positive")"""

lexer = Lexer(source)
tokens = lexer.tokenize()

parser = YadroParser(tokens)
try:
    ast = parser.parse_statement()
    print('SUCCESS: If-else statement parsed correctly')
    print('then_branch length:', len(ast.then_branch))
    print('else_branch length:', len(ast.else_branch) if ast.else_branch else 0)
    print('elif_branches length:', len(ast.elif_branches))
except Exception as e:
    print(f"Error: {e}")
