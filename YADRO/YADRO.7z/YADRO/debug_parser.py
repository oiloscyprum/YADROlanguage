import sys
import os
sys.path.append(os.path.join(os.getcwd(), 'modules'))

from parserr import YadroParser, ParseError, TokenType
from lexer import Lexer

def debug_parse(source):
    print(f"Parsing: '{source}'")
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    print("Tokens:")
    for t in tokens:
        print(f"  {t}")
    
    parser = YadroParser(tokens)
    try:
        ast = parser.parse_expression()
        print(f"Result AST: {ast}")
        print(f"Parser Errors: {parser.errors}")
    except Exception as e:
        print(f"Caught exception: {type(e).__name__}: {e}")

print("--- Test 1: Mismatched Parentheses ---")
debug_parse("(1 + 2")

print("\n--- Test 2: Mismatched Brackets ---")
debug_parse("array[1, 2")

print("\n--- Test 3: Invalid Operator ---")
debug_parse("1 + * 2")
