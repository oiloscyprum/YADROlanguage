"""Tests for expression parsing in YADRO parser."""

import pytest
from parserr import (
    LiteralExpr, IdentifierExpr, BinaryExpr, UnaryExpr, AssignExpr,
    CallExpr, MemberExpr, IndexExpr, GenericExpr, PipelineExpr,
    MatchExpr, ResultExpr, OptionExpr, LambdaExpr, PredicateExpr,
    RefExpr, DerefExpr, YadroParser, ParseError, ArrayLiteralExpr,
    DictLiteralExpr, SetLiteralExpr, GpuIntrinsicExpr,
    WasmGcOperationExpr, JsCapabilityExpr
)
from lexer import Lexer, TokenType


@pytest.mark.expressions
class TestLiteralExpressions:
    """Test parsing of literal expressions."""
    
    @pytest.mark.parametrize("source,expected_type,expected_value", [
        ("42", "int", 42),
        ("3.14", "float", 3.14),
        ('"hello"', "string", "hello"),
        ("'a'", "char", "a"),
        ("true", "bool", True),
        ("false", "bool", False),
    ])
    def test_parse_literals(self, parse_expression, source, expected_type, expected_value):
        """Test parsing of basic literal expressions."""
        ast = parse_expression(source)
        
        assert isinstance(ast, LiteralExpr)
        assert ast.literal_type == expected_type
        assert ast.value == expected_value
        assert ast.line == 1
        assert ast.column == 1


@pytest.mark.expressions
class TestIdentifierExpressions:
    """Test parsing of identifier expressions."""
    
    def test_simple_identifier(self, parse_expression):
        """Test parsing of simple identifier."""
        ast = parse_expression("variable_name")
        
        assert isinstance(ast, IdentifierExpr)
        assert ast.name == "variable_name"
        assert ast.line == 1
        assert ast.column == 1
    
    def test_identifier_with_underscores(self, parse_expression):
        """Test parsing of identifier with underscores."""
        ast = parse_expression("my_variable_name")
        
        assert isinstance(ast, IdentifierExpr)
        assert ast.name == "my_variable_name"


@pytest.mark.expressions
class TestBinaryExpressions:
    """Test parsing of binary expressions with proper precedence."""
    
    @pytest.mark.parametrize("source,expected_op,expected_left,expected_right", [
        ("1 + 2", "+", "1", "2"),
        ("3 - 4", "-", "3", "4"),
        ("5 * 6", "*", "5", "6"),
        ("7 / 8", "/", "7", "8"),
        ("9 % 10", "%", "9", "10"),
    ])
    def test_arithmetic_operators(self, parse_expression, source, expected_op, expected_left, expected_right):
        """Test parsing of arithmetic binary operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == expected_op
        assert isinstance(ast.left, LiteralExpr)
        assert isinstance(ast.right, LiteralExpr)
        assert ast.left.value == int(expected_left)
        assert ast.right.value == int(expected_right)
    
    @pytest.mark.parametrize("source,expected_op", [
        ("1 == 2", "=="),
        ("1 != 2", "!="),
        ("1 < 2", "<"),
        ("1 > 2", ">"),
        ("1 <= 2", "<="),
        ("1 >= 2", ">="),
    ])
    def test_comparison_operators(self, parse_expression, source, expected_op):
        """Test parsing of comparison operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == expected_op
        assert isinstance(ast.left, LiteralExpr)
        assert isinstance(ast.right, LiteralExpr)
    
    @pytest.mark.parametrize("source,expected_op", [
        ("1 and 2", "and"),
        ("1 or 2", "or"),
        ("1 xor 2", "xor"),
        ("1 nand 2", "nand"),
    ])
    def test_logical_operators(self, parse_expression, source, expected_op):
        """Test parsing of logical operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == expected_op
    
    @pytest.mark.parametrize("source,expected_op", [
        ("1 & 2", "&"),
        ("1 | 2", "|"),
        ("1 ^ 2", "^"),
        ("1 << 2", "<<"),
        ("1 >> 2", ">>"),
    ])
    def test_bitwise_operators(self, parse_expression, source, expected_op):
        """Test parsing of bitwise operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == expected_op
    
    def test_operator_precedence_arithmetic(self, parse_expression):
        """Test arithmetic operator precedence: * and / before + and -."""
        ast = parse_expression("1 + 2 * 3")
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == "+"
        assert isinstance(ast.left, LiteralExpr)
        assert ast.left.value == 1
        
        # Right side should be 2 * 3
        assert isinstance(ast.right, BinaryExpr)
        assert ast.right.operator == "*"
        assert ast.right.left.value == 2
        assert ast.right.right.value == 3
    
    def test_operator_precedence_parentheses(self, parse_expression):
        """Test that parentheses override precedence."""
        ast = parse_expression("(1 + 2) * 3")
        
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == "*"
        
        # Left side should be (1 + 2)
        assert isinstance(ast.left, BinaryExpr)
        assert ast.left.operator == "+"
        assert ast.left.left.value == 1
        assert ast.left.right.value == 2
        
        # Right side should be 3
        assert isinstance(ast.right, LiteralExpr)
        assert ast.right.value == 3
    
    def test_complex_precedence_chain(self, parse_expression):
        """Test complex operator precedence chain."""
        ast = parse_expression("1 + 2 * 3 - 4 / 5")
        
        # Should parse as: (1 + (2 * 3)) - (4 / 5)
        assert isinstance(ast, BinaryExpr)
        assert ast.operator == "-"
        
        # Left side: 1 + 2 * 3
        assert isinstance(ast.left, BinaryExpr)
        assert ast.left.operator == "+"
        
        # Right side: 4 / 5
        assert isinstance(ast.right, BinaryExpr)
        assert ast.right.operator == "/"


@pytest.mark.expressions
class TestUnaryExpressions:
    """Test parsing of unary expressions."""
    
    @pytest.mark.parametrize("source,expected_op", [
        ("-x", "-"),
        ("!x", "!"),
        ("~x", "~"),
        ("*x", "*"),
    ])
    def test_unary_operators(self, parse_expression, source, expected_op):
        """Test parsing of unary operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, UnaryExpr)
        assert ast.operator == expected_op
        assert isinstance(ast.operand, IdentifierExpr)
        assert ast.operand.name == "x"


@pytest.mark.expressions
class TestAssignmentExpressions:
    """Test parsing of assignment expressions."""
    
    @pytest.mark.parametrize("source,expected_op", [
        ("x = 42", "="),
        ("x += 1", "+="),
        ("x -= 1", "-="),
        ("x *= 2", "*="),
        ("x /= 2", "/="),
        ("x %= 2", "%="),
        ("x <<= 1", "<<="),
        ("x >>= 1", ">>="),
        ("x &= 1", "&="),
        ("x |= 1", "|="),
        ("x ^= 1", "^="),
        ("x @= addr", "@="),  # Get address assignment
        ("x $= y", "$="),    # Swap assignment
    ])
    def test_assignment_operators(self, parse_expression, source, expected_op):
        """Test parsing of assignment operators."""
        ast = parse_expression(source)
        
        assert isinstance(ast, AssignExpr)
        assert ast.operator == expected_op
        assert isinstance(ast.target, IdentifierExpr)
        assert ast.target.name == "x"
        
        # For @= and $= operators, the right side is an identifier (addr, y)
        # For other operators, the right side is a literal (42, 1, 2, etc.)
        if expected_op in ["@=", "$="]:
            assert isinstance(ast.value, IdentifierExpr)
        else:
            assert isinstance(ast.value, LiteralExpr)


@pytest.mark.expressions
class TestFunctionCallExpressions:
    """Test parsing of function call expressions."""
    
    def test_simple_function_call(self, parse_expression):
        """Test parsing of simple function call."""
        ast = parse_expression("func()")
        
        assert isinstance(ast, CallExpr)
        assert isinstance(ast.callee, IdentifierExpr)
        assert ast.callee.name == "func"
        assert len(ast.arguments) == 0
    
    def test_function_call_with_arguments(self, parse_expression):
        """Test parsing of function call with arguments."""
        ast = parse_expression("func(arg1, arg2, 42)")
        
        assert isinstance(ast, CallExpr)
        assert isinstance(ast.callee, IdentifierExpr)
        assert ast.callee.name == "func"
        assert len(ast.arguments) == 3
        
        assert isinstance(ast.arguments[0], IdentifierExpr)
        assert ast.arguments[0].name == "arg1"
        assert isinstance(ast.arguments[1], IdentifierExpr)
        assert ast.arguments[1].name == "arg2"
        assert isinstance(ast.arguments[2], LiteralExpr)
        assert ast.arguments[2].value == 42
    
    def test_nested_function_calls(self, parse_expression):
        """Test parsing of nested function calls."""
        ast = parse_expression("outer(inner(arg))")
        
        assert isinstance(ast, CallExpr)
        assert ast.callee.name == "outer"
        assert len(ast.arguments) == 1
        
        # Argument should be inner(arg)
        inner_call = ast.arguments[0]
        assert isinstance(inner_call, CallExpr)
        assert inner_call.callee.name == "inner"
        assert len(inner_call.arguments) == 1


@pytest.mark.expressions
class TestMemberAccessExpressions:
    """Test parsing of member access expressions."""
    
    def test_simple_member_access(self, parse_expression):
        """Test parsing of simple member access."""
        ast = parse_expression("obj.property")
        
        assert isinstance(ast, MemberExpr)
        assert isinstance(ast.object, IdentifierExpr)
        assert ast.object.name == "obj"
        assert ast.property == "property"
    
    def test_chained_member_access(self, parse_expression):
        """Test parsing of chained member access."""
        ast = parse_expression("obj.prop1.prop2")
        
        assert isinstance(ast, MemberExpr)
        assert ast.property == "prop2"
        
        # Object should be obj.prop1
        assert isinstance(ast.object, MemberExpr)
        assert ast.object.property == "prop1"
        assert isinstance(ast.object.object, IdentifierExpr)
        assert ast.object.object.name == "obj"


@pytest.mark.expressions
class TestArrayIndexingExpressions:
    """Test parsing of array indexing expressions."""
    
    def test_simple_array_indexing(self, parse_expression):
        """Test parsing of simple array indexing."""
        ast = parse_expression("array[index]")
        
        assert isinstance(ast, IndexExpr)
        assert isinstance(ast.object, IdentifierExpr)
        assert ast.object.name == "array"
        assert isinstance(ast.index, IdentifierExpr)
        assert ast.index.name == "index"
    
    def test_nested_array_indexing(self, parse_expression):
        """Test parsing of nested array indexing."""
        ast = parse_expression("array1[array2[index]]")
        
        assert isinstance(ast, IndexExpr)
        assert isinstance(ast.object, IdentifierExpr)
        assert ast.object.name == "array1"
        
        # Index should be array2[index]
        assert isinstance(ast.index, IndexExpr)
        assert ast.index.object.name == "array2"
        assert isinstance(ast.index.index, IdentifierExpr)
        assert ast.index.index.name == "index"


@pytest.mark.expressions
class TestGenericExpressions:
    """Test parsing of generic type expressions."""
    
    def test_simple_generic_expression(self, parse_expression):
        """Test parsing of simple generic expression."""
        ast = parse_expression("TypeName[int]")
        
        assert isinstance(ast, GenericExpr)
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "TypeName"
        assert len(ast.type_args) == 1
        assert ast.type_args[0].name == "int"
    
    def test_multiple_generic_arguments(self, parse_expression):
        """Test parsing of generic expression with multiple arguments."""
        ast = parse_expression("TypeName[int, string]")
        
        assert isinstance(ast, GenericExpr)
        assert ast.expression.name == "TypeName"
        assert len(ast.type_args) == 2
        assert ast.type_args[0].name == "int"
        assert ast.type_args[1].name == "string"


@pytest.mark.expressions
class TestPipelineExpressions:
    """Test parsing of pipeline expressions."""
    
    def test_right_pipeline(self, parse_expression):
        """Test parsing of right pipeline (>>>)."""
        ast = parse_expression("value >>> func1 >>> func2")
        
        assert isinstance(ast, PipelineExpr)
        assert ast.direction == ">>>"
        assert len(ast.expressions) == 3
        
        assert isinstance(ast.expressions[0], IdentifierExpr)
        assert ast.expressions[0].name == "value"
        assert isinstance(ast.expressions[1], IdentifierExpr)
        assert ast.expressions[1].name == "func1"
        assert isinstance(ast.expressions[2], IdentifierExpr)
        assert ast.expressions[2].name == "func2"
    
    def test_left_pipeline(self, parse_expression):
        """Test parsing of left pipeline (<<<)."""
        ast = parse_expression("func2 <<< func1 <<< value")
        
        assert isinstance(ast, PipelineExpr)
        assert ast.direction == "<<<"
        assert len(ast.expressions) == 3
    
    def test_pipeline_with_function_calls(self, parse_expression):
        """Test pipeline with function calls and complex expressions."""
        ast = parse_expression("data >>> filter(x => x > 0) >>> map(x => x * 2)")
        
        assert isinstance(ast, PipelineExpr)
        assert ast.direction == ">>>"
        assert len(ast.expressions) == 3
        
        assert isinstance(ast.expressions[0], IdentifierExpr)
        assert ast.expressions[0].name == "data"
        assert isinstance(ast.expressions[1], CallExpr)
        assert isinstance(ast.expressions[2], CallExpr)


@pytest.mark.expressions
class TestResultOptionExpressions:
    """Test parsing of Result and Option expressions."""
    
    def test_ok_expression(self, parse_expression):
        """Test parsing of Ok expression."""
        ast = parse_expression("Ok(value)")
        
        assert isinstance(ast, ResultExpr)
        assert ast.is_ok is True
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "value"
    
    def test_err_expression(self, parse_expression):
        """Test parsing of Err expression."""
        ast = parse_expression("Err(error)")
        
        assert isinstance(ast, ResultExpr)
        assert ast.is_ok is False
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "error"
    
    def test_some_expression(self, parse_expression):
        """Test parsing of Some expression."""
        ast = parse_expression("Some(value)")
        
        assert isinstance(ast, OptionExpr)
        assert ast.is_some is True
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "value"
    
    def test_none_expression(self, parse_expression):
        """Test parsing of None expression."""
        ast = parse_expression("None")
        
        assert isinstance(ast, OptionExpr)
        assert ast.is_some is False
        assert ast.expression is None


@pytest.mark.expressions
class TestLambdaExpressions:
    """Test parsing of lambda expressions."""
    
    def test_simple_lambda(self, parse_expression):
        """Test parsing of simple lambda."""
        ast = parse_expression("(x) -> int { return x; }")
        
        assert isinstance(ast, LambdaExpr)
        assert len(ast.params) == 1
        assert ast.params[0].name == "x"
        assert ast.return_type.name == "int"
        assert len(ast.body) == 1
    
    def test_lambda_with_multiple_params(self, parse_expression):
        """Test parsing of lambda with multiple parameters."""
        ast = parse_expression("(x: int, y: string) -> bool { return true; }")
        
        assert isinstance(ast, LambdaExpr)
        assert len(ast.params) == 2
        assert ast.params[0].name == "x"
        assert ast.params[1].name == "y"
        assert ast.return_type.name == "bool"


@pytest.mark.expressions
class TestPredicateExpressions:
    """Test parsing of predicate expressions."""
    
    def test_simple_predicate(self, parse_expression):
        """Test parsing of simple predicate expression."""
        ast = parse_expression("expr ~ predicate")
        
        assert isinstance(ast, PredicateExpr)
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "expr"
        assert ast.predicate == "predicate"
    
    def test_predicate_with_parameters(self, parse_expression):
        """Test parsing of predicate with parameters."""
        ast = parse_expression("expr ~ predicate(arg1, arg2)")
        
        assert isinstance(ast, PredicateExpr)
        assert ast.expression.name == "expr"
        assert ast.predicate == "predicate"


@pytest.mark.expressions
class TestReferenceExpressions:
    """Test parsing of reference expressions."""
    
    def test_immutable_reference(self, parse_expression):
        """Test parsing of immutable reference."""
        ast = parse_expression("&x")
        
        assert isinstance(ast, RefExpr)
        assert ast.is_mutable is False
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "x"
    
    def test_mutable_reference(self, parse_expression):
        """Test parsing of mutable reference."""
        ast = parse_expression("&mut x")
        
        assert isinstance(ast, RefExpr)
        assert ast.is_mutable is True
        assert isinstance(ast.expression, IdentifierExpr)
        assert ast.expression.name == "x"


@pytest.mark.expressions
class TestComplexExpressions:
    """Test parsing of complex nested expressions."""
    
    def test_complex_function_call(self, parse_expression):
        """Test parsing of complex function call with nested expressions."""
        ast = parse_expression("obj.method(arg1 + arg2, array[index])")
        
        assert isinstance(ast, CallExpr)
        assert isinstance(ast.callee, MemberExpr)
        assert ast.callee.property == "method"
        assert len(ast.arguments) == 2
    
    def test_complex_assignment(self, parse_expression):
        """Test parsing of complex assignment expression."""
        ast = parse_expression("obj.property = func(arg1, arg2) + value")
        
        assert isinstance(ast, AssignExpr)
        assert isinstance(ast.target, MemberExpr)
        assert isinstance(ast.value, BinaryExpr)
    
    def test_very_complex_expression(self, parse_expression):
        """Test parsing of very complex nested expression."""
        source = "collection.filter(x => x > 0).map(x => x * 2).reduce((a, b) => a + b)"
        ast = parse_expression(source)
        
        # Should be a chain of member accesses and function calls
        assert isinstance(ast, CallExpr)
        assert isinstance(ast.callee, MemberExpr)


@pytest.mark.expressions
class TestExpressionErrors:
    """Test error handling in expression parsing."""
    
    def test_mismatched_parentheses(self, parse_expression):
        """Test error handling for mismatched parentheses."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_expression("(1 + 2")
    
    def test_invalid_operator_combination(self, parse_expression):
        """Test error handling for invalid operator combinations."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_expression("1 + / 2")
    
    def test_incomplete_expression(self, parse_expression):
        """Test error handling for incomplete expressions."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_expression("1 +")


@pytest.mark.expressions
class TestVerificationExpressions:
    """Test parsing of formal verification expressions (YUP 26.1.5)."""
    
    def test_spec_type_definition(self):
        """Test parsing of spec type definitions."""
        from parserr import SpecTypeDecl
        source = "spec PositiveInt = int where value > 0"
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_statement()
        
        assert isinstance(ast, SpecTypeDecl)
        assert ast.spec_name == "PositiveInt"
    
    def test_old_expression(self, parse_expression):
        """Test parsing of old() expressions for verification."""
        ast = parse_expression("old(self.len())")
        
        assert isinstance(ast, CallExpr)
        assert isinstance(ast.callee, IdentifierExpr)
        assert ast.callee.name == "old"
    
    def test_ghost_variable_annotation(self):
        """Test parsing of ghost variable annotations."""
        from parserr import VarDecl
        source = "#ghost u32 old_left = left"
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_statement()
        
        # Should parse as annotated declaration
        assert isinstance(ast, VarDecl)
        assert hasattr(ast, 'is_ghost')
        assert ast.is_ghost is True


@pytest.mark.expressions 
class TestGPUExpressions:
    """Test parsing of GPU-specific expressions (YUP 26.1.7)."""
    
    def test_gpu_intrinsic_call(self, parse_expression):
        """Test parsing of GPU intrinsic calls."""
        ast = parse_expression("#gpu_thread_id()")
        
        assert isinstance(ast, GpuIntrinsicExpr)
        assert ast.intrinsic_type == "thread_id"
    
    def test_gpu_atomic_operation(self, parse_expression):
        """Test parsing of GPU atomic operations."""
        ast = parse_expression("#gpu_atomic(\"add\", target, value, Acquire)")
        
        assert isinstance(ast, GpuIntrinsicExpr)
        assert ast.intrinsic_type == "add"
    
    def test_gpu_sync_operation(self, parse_expression):
        """Test parsing of GPU synchronization operations."""
        ast = parse_expression("#gpu_sync_block()")
        
        assert isinstance(ast, GpuIntrinsicExpr)
        assert ast.intrinsic_type == "sync_block"
    
    def test_memory_space_type(self):
        """Test parsing of memory space types."""
        from parserr import MemorySpaceType
        source = "global[darray[int]]"
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_type()
        
        assert isinstance(ast, MemorySpaceType)
        assert ast.space == "global"


@pytest.mark.expressions
class TestWASMExpressions:
    """Test parsing of WebAssembly-specific expressions (YUP 26.1.9)."""
    
    def test_wasm_gc_allocation(self, parse_expression):
        """Test parsing of WASM GC allocation."""
        ast = parse_expression("wasm_gc::alloc(Person.new())")
        
        assert isinstance(ast, WasmGcOperationExpr)
        assert ast.operation == "alloc"
    
    def test_wasm_gc_promotion(self, parse_expression):
        """Test parsing of WASM GC promotion."""
        ast = parse_expression("wasm_gc::promote(linear_person)")
        
        assert isinstance(ast, WasmGcOperationExpr)
        assert ast.operation == "promote"
    
    def test_wasm_gc_array_allocation(self, parse_expression):
        """Test parsing of WASM GC array allocation."""
        ast = parse_expression("wasm_gc::array_alloc[u32](100)")
        
        assert isinstance(ast, WasmGcOperationExpr)
        assert ast.operation == "array_alloc"
    
    def test_js_capability_call(self, parse_expression):
        """Test parsing of JavaScript capability calls."""
        ast = parse_expression("#requires_js(dom::get_element_by_id(\"root\"))")
        
        assert isinstance(ast, JsCapabilityExpr)
        assert ast.capability == "dom"


@pytest.mark.expressions
class TestAdvancedPredicateExpressions:
    """Test advanced predicate expressions for refined types."""
    
    def test_complex_predicate(self, parse_expression):
        """Test parsing of complex predicate expressions."""
        ast = parse_expression("~int positive : ~value > 0")
        
        assert isinstance(ast, PredicateExpr)
        # Check string representation contains key elements since full AST repr is complex
        assert "value" in ast.predicate
        assert ">" in ast.predicate
    
    def test_predicate_with_function_call(self, parse_expression):
        """Test predicate with function call in condition."""
        ast = parse_expression("~string non_empty : ~len(value) > 0")
        
        assert isinstance(ast, PredicateExpr)
        assert "len" in ast.predicate
        assert "value" in ast.predicate
    
    def test_nested_predicate(self, parse_expression):
        """Test nested predicate expressions."""
        ast = parse_expression("~darray[int] sorted : ~is_sorted(value) and ~len(value) > 0")
        
        assert isinstance(ast, PredicateExpr)
        assert "and" in ast.predicate
        assert "is_sorted" in ast.predicate


if __name__ == "__main__":
    pytest.main([__file__])
