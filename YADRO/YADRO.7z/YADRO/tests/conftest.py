"""Pytest configuration and shared fixtures for parser tests."""

import pytest
import sys
import os
from pathlib import Path

# Add the modules directory to the path so we can import the parser
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'modules'))

from parserr import YadroParser, ParseError, Program
from lexer import Lexer, TokenType


@pytest.fixture
def parser():
    """Create a fresh parser instance for each test."""
    def create_parser(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        return YadroParser(tokens)
    return create_parser


@pytest.fixture
def parse_program():
    """Parse a complete program and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse


@pytest.fixture
def parse_expression():
    """Parse a single expression and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_expression()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse


@pytest.fixture
def parse_statement():
    """Parse a single statement and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_statement()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse


@pytest.fixture
def sample_tokens():
    """Provide sample tokens for testing."""
    return [
        TokenType.Int, TokenType.Plus, TokenType.Int, TokenType.Semicolon,
        TokenType.IDENTIFIER, TokenType.Assign, TokenType.String, TokenType.Semicolon
    ]


@pytest.fixture
def valid_yadro_code():
    """Sample valid YADRO code for testing."""
    return """
#target
os = "linux"
arch = "x86-64"

let x = 42;
var y: int = 10;
const PI: float = 3.14159;

fun add(a: int, b: int) -> int:
    return a + b

if x > 0:
    cli.print("Positive")
else:
    cli.print("Non-positive")
"""


@pytest.fixture
def expression_samples():
    """Sample expressions for testing."""
    return {
        'literals': [
            ('42', 'int'),
            ('3.14', 'float'),
            ('"hello"', 'string'),
            ('\'a\'', 'char'),
            ('true', 'bool'),
            ('false', 'bool'),
        ],
        'binary_ops': [
            ('1 + 2', 'addition'),
            ('3 - 4', 'subtraction'),
            ('5 * 6', 'multiplication'),
            ('7 / 8', 'division'),
            ('9 % 10', 'modulo'),
            ('1 and 2', 'logical_and'),
            ('1 or 2', 'logical_or'),
            ('1 xor 2', 'logical_xor'),
            ('1 nand 2', 'logical_nand'),
            ('1 == 2', 'equality'),
            ('1 != 2', 'inequality'),
            ('1 < 2', 'less_than'),
            ('1 > 2', 'greater_than'),
            ('1 <= 2', 'less_equal'),
            ('1 >= 2', 'greater_equal'),
        ],
        'unary_ops': [
            ('-x', 'negation'),
            ('!x', 'logical_not'),
            ('~x', 'bitwise_not'),
            ('*x', 'dereference'),
        ],
        'assignments': [
            ('x = 42', 'simple_assignment'),
            ('x += 1', 'plus_assign'),
            ('x -= 1', 'minus_assign'),
            ('x *= 2', 'star_assign'),
            ('x /= 2', 'slash_assign'),
            ('x <<= 1', 'left_shift_assign'),
            ('x >>= 1', 'right_shift_assign'),
            ('x @= addr', 'address_assign'),
            ('x $= y', 'swap_assign'),
        ],
        'complex': [
            ('1 + 2 * 3', 'precedence'),
            ('(1 + 2) * 3', 'parentheses'),
            'func(arg1, arg2)',
            'obj.property',
            'array[index]',
            'TypeName[int, string]',
        ]
    }


# New fixtures for advanced features

@pytest.fixture
def formal_verification_samples():
    """Sample formal verification code for testing."""
    return {
        'spec_types': [
            ('spec PositiveInt = int where value > 0', 'simple_spec'),
            ('spec NonEmptyString = string where len(value) > 0', 'function_spec'),
            ('spec SortedArray[T] = darray[T] where is_sorted(value)', 'generic_spec'),
        ],
        'function_specs': [
            ('fun divide(int a, int b) -> int spec: requires b > 0 ensures result > 0: return a / b', 'simple_spec'),
            ('fun factorial(u32 n) -> u64 spec: requires n <= 20 ensures result >= 1: # Implementation', 'complex_spec'),
        ],
        'loop_invariants': [
            ('while i <= n spec invariant acc == factorial(i - 1): acc *= i', 'simple_invariant'),
            ('for i in range(0, n) spec invariant sum == i * (i - 1) / 2: sum += i', 'for_invariant'),
        ],
        'ghost_variables': [
            ('#[ghost] u32 old_left = left', 'simple_ghost'),
            ('#[ghost] u64 old_capacity = self.capacity', 'class_ghost'),
        ],
    }


@pytest.fixture
def gpu_programming_samples():
    """Sample GPU programming code for testing."""
    return {
        'gpu_targets': [
            ('#target gpu = "cuda-12.4"', 'cuda_target'),
            ('#target gpu = "rocm-6.0"', 'rocm_target'),
            ('#target gpu = ["cuda-12.4", "rocm-6.0"]', 'multi_gpu_target'),
        ],
        'memory_spaces': [
            ('global[darray[int]]', 'global_memory'),
            ('shared[darray[float]]', 'shared_memory'),
            ('local[int]', 'local_memory'),
            ('constant[Params]', 'constant_memory'),
            ('unified[darray[byte]]', 'unified_memory'),
        ],
        'kernel_functions': [
            ('fun[gpu(kernel)] raytrace_kernel(global[Scene] scene) -> Unit: # Implementation', 'simple_kernel'),
            ('fun[gpu(kernel)] requires_sync = "block" reduction_kernel(global[darray[float]] input) -> Unit: # Implementation', 'sync_kernel'),
        ],
        'kernel_launches': [
            ('launch kernel(data) config: grid_dim = (1024, 1024) block_dim = (256,)', 'simple_launch'),
            ('Task[Unit] task = launch kernel(data) config: grid_dim = (512, 512)', 'task_launch'),
        ],
        'gpu_intrinsics': [
            ('#gpu_thread_id()', 'thread_id'),
            ('#gpu_sync_block()', 'block_sync'),
            ('#gpu_atomic("add", counter, 1, Acquire)', 'atomic_op'),
        ],
    }


@pytest.fixture
def wasm_gc_samples():
    """Sample WebAssembly GC code for testing."""
    return {
        'wasm_targets': [
            ('#target wasm = "gc-2.0"', 'gc_target'),
            ('#target wasm = "mvp"', 'mvp_target'),
            ('#target js_ffi = true', 'js_ffi_target'),
        ],
        'gc_types': [
            ('wasm_gc[Person]', 'gc_reference'),
            ('wasm_struct[Person]', 'gc_struct'),
            ('wasm_array[u32]', 'gc_array'),
            ('wasm_externref', 'extern_ref'),
            ('wasm_anyref', 'any_ref'),
        ],
        'js_capabilities': [
            ('#requires_js capabilities = ["dom", "fetch"]', 'simple_capabilities'),
            ('#requires_js capabilities = ["dom", "fetch"] sandboxed = true', 'sandboxed_capabilities'),
        ],
        'heap_conversions': [
            ('wasm_gc::promote(linear_person)', 'promotion'),
            ('wasm_gc::demote(gc_person)', 'demotion'),
            ('wasm_gc::copy(linear_data)', 'copy'),
        ],
        'gc_operations': [
            ('wasm_gc::alloc(Person.new())', 'allocation'),
            ('wasm_gc::array_alloc[u32](100)', 'array_allocation'),
            ('wasm_gc::null()', 'null_ref'),
        ],
    }


@pytest.fixture
def constitutional_samples():
    """Sample constitutional compliance code for testing."""
    return {
        'article_i': [
            ('fun divide(int a, int b) -> int spec: requires b > 0: return a / b', 'proof_assistant'),
            ('spec PositiveInt = int where value > 0', 'behavioral_types'),
        ],
        'article_ii': [
            ('#target os = "linux" arch = "x86-64"', 'explicit_config'),
            ('#requires_js capabilities = ["dom"]', 'explicit_capabilities'),
        ],
        'article_iii': [
            ('#[unsafe] fun low_level_op(): asm("mov %eax, %eax"):', 'right_to_descend'),
            ('value >>> func1 >>> func2', 'zero_cost_abstraction'),
        ],
        'article_iv': [
            ('fun pure(x: int) -> int: return x * 2', 'deterministic'),
            ('fun[async] async_op() -> Task[int]: return await operation()', 'side_effects'),
        ],
        'article_v': [
            ('let owner: darray[int] = [1, 2, 3]', 'ownership'),
            ('protocol Comparable: fun compare(&self, other: &Self) -> int', 'protocols'),
            ('fun might_fail() -> Result[int, Error]: return Ok(42)', 'algebraic_effects'),
            ('arena: Arena = Arena.new()', 'arena_allocation'),
        ],
    }


@pytest.fixture
def advanced_yadro_code():
    """Sample advanced YADRO code with all features."""
    return """
#target
os = "linux"
arch = "x86-64"
gpu = "cuda-12.4"

#requires_js
capabilities = ["dom", "fetch"]

#verification
level = "require"
prover = "why3"

spec PositiveInt = int where value > 0

fun[gpu(kernel)] raytrace_kernel(
    global[Scene] scene,
    global[Image] output
) -> Unit
spec:
    requires scene.is_valid()
    ensures output.is_rendered()
:
    u32 tid = #gpu_thread_id()
    # GPU implementation

fun wasm_entry_point() -> wasm_gc[App]:
    wasm_gc[App] app = wasm_gc::alloc(App.new())
    return app

#[critical]
fun verified_function(PositiveInt x) -> PositiveInt
spec:
    ensures result > x
:
    return x + 1
"""


def assert_ast_node_type(node, expected_type):
    """Helper to assert AST node type."""
    assert node.__class__.__name__ == expected_type, f"Expected {expected_type}, got {node.__class__.__name__}"


def assert_parse_error(parse_func, source_code, expected_message=None):
    """Helper to assert that parsing raises ParseError."""
    with pytest.raises(ParseError) as exc_info:
        parse_func(source_code)
    
    if expected_message:
        assert expected_message in str(exc_info.value)


def assert_no_parse_errors(parse_func, source_code):
    """Helper to assert that parsing completes without errors."""
    try:
        result = parse_func(source_code)
        return result
    except ParseError as e:
        pytest.fail(f"Unexpected ParseError: {e}")


# Constitutional compliance helpers
def assert_constitutional_compliance(ast, required_articles=None):
    """Helper to assert AST complies with constitutional requirements."""
    # All statements should have explicit location information
    for stmt in ast.statements:
        assert hasattr(stmt, 'line'), f"Statement missing line info: {stmt}"
        assert hasattr(stmt, 'column'), f"Statement missing column info: {stmt}"
    
    # Check for specific constitutional articles if required
    if required_articles:
        for article in required_articles:
            # Article-specific checks would go here
            pass


# Custom markers for different test categories
def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line("markers", "expressions: Tests for expression parsing")
    config.addinivalue_line("markers", "directives: Tests for compiler directives")
    config.addinivalue_line("markers", "declarations: Tests for variable/constant declarations")
    config.addinivalue_line("markers", "functions: Tests for function declarations")
    config.addinivalue_line("markers", "classes: Tests for class and trait declarations")
    config.addinivalue_line("markers", "control_flow: Tests for control flow statements")
    config.addinivalue_line("markers", "types: Tests for type system parsing")
    config.addinivalue_line("markers", "advanced: Tests for advanced features")
    config.addinivalue_line("markers", "errors: Tests for error handling")
    config.addinivalue_line("markers", "constitutional: Tests for constitutional compliance")
    config.addinivalue_line("markers", "integration: Integration tests")
    config.addinivalue_line("markers", "formal_verification: Tests for formal verification (YUP 26.1.5)")
    config.addinivalue_line("markers", "gpu: Tests for GPU programming (YUP 26.1.7)")
    config.addinivalue_line("markers", "wasm_gc: Tests for WebAssembly GC (YUP 26.1.9)")
    config.addinivalue_line("markers", "yuppi: Tests for YUPPI package management (YUP 26.1.2)")
    config.addinivalue_line("markers", "compiler: Tests for compiler implementation (YUP 26.1.4)")


def assert_ast_node_type(node, expected_type):
    """Helper to assert AST node type."""
    assert node.__class__.__name__ == expected_type, f"Expected {expected_type}, got {node.__class__.__name__}"


def assert_parse_error(parse_func, source_code, expected_message=None):
    """Helper to assert that parsing raises ParseError."""
    with pytest.raises(ParseError) as exc_info:
        parse_func(source_code)
    
    if expected_message:
        assert expected_message in str(exc_info.value)


def assert_no_parse_errors(parse_func, source_code):
    """Helper to assert that parsing completes without errors."""
    try:
        result = parse_func(source_code)
        return result
    except ParseError as e:
        pytest.fail(f"Unexpected ParseError: {e}")


# Constitutional compliance helpers
def assert_constitutional_compliance(ast, required_articles=None):
    """Helper to assert AST complies with constitutional requirements."""
    # All statements should have explicit location information
    for stmt in ast.statements:
        assert hasattr(stmt, 'line'), f"Statement missing line info: {stmt}"
        assert hasattr(stmt, 'column'), f"Statement missing column info: {stmt}"
    
    # Check for specific constitutional articles if required
    if required_articles:
        for article in required_articles:
            # Article-specific checks would go here
            pass


def assert_parse_error(parse_func, source_code, expected_message=None):
    """Helper to assert that parsing raises ParseError."""
    with pytest.raises(ParseError) as exc_info:
        parse_func(source_code)
    
    if expected_message:
        assert expected_message in str(exc_info.value)


def assert_no_parse_errors(parse_func, source_code):
    """Helper to assert that parsing completes without errors."""
    try:
        result = parse_func(source_code)
        return result
    except ParseError as e:
        pytest.fail(f"Unexpected ParseError: {e}")


# Custom markers for different test categories
def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line("markers", "expressions: Tests for expression parsing")
    config.addinivalue_line("markers", "directives: Tests for compiler directives")
    config.addinivalue_line("markers", "declarations: Tests for variable/constant declarations")
    config.addinivalue_line("markers", "functions: Tests for function declarations")
    config.addinivalue_line("markers", "classes: Tests for class and trait declarations")
    config.addinivalue_line("markers", "control_flow: Tests for control flow statements")
    config.addinivalue_line("markers", "types: Tests for type system parsing")
    config.addinivalue_line("markers", "advanced: Tests for advanced features")
    config.addinivalue_line("markers", "errors: Tests for error handling")
    config.addinivalue_line("markers", "constitutional: Tests for constitutional compliance")
    config.addinivalue_line("markers", "integration: Integration tests")
