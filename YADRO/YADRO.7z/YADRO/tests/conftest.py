"""Pytest configuration and shared fixtures for parser tests."""

import pytest
import sys
import os
from pathlib import Path

# Add the modules directory to the path so we can import the parser
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'modules'))

from parserr import YadroParser, ParseError, Program
from lexer import Lexer, TokenType


@pytest.fixture
def parser():
    """Create a fresh parser instance for each test."""
    def create_parser(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        return YadroParser(tokens)
    return create_parser


@pytest.fixture
def parse_program():
    """Parse a complete program and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse


@pytest.fixture
def parse_expression():
    """Parse a single expression and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_expression()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse


@pytest.fixture
def parse_statement():
    """Parse a single statement and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_statement()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse

@pytest.fixture
def parse_type():
    """Parse a type annotation and return the AST."""
    def parse(source_code):
        lexer = Lexer(source_code)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_type()
        if parser.errors:
            raise parser.errors[0]
        return ast
    return parse
