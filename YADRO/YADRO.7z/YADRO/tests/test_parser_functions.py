"""Tests for function declaration parsing in YADRO parser."""

import pytest
from parserr import (
    FunctionDecl, Param, BasicType, GenericType, IdentifierExpr, LiteralExpr,
    ReturnStmt, VarDecl, ParseError
)


@pytest.mark.functions
class TestBasicFunctionDeclarations:
    """Test parsing of basic function declarations."""
    
    def test_simple_function(self, parse_statement):
        """Test parsing of simple function without parameters."""
        source = """fun hello() -> void:
    cli.print("Hello, World!")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "hello"
        assert len(ast.params) == 0
        assert ast.return_type.name == "void"
        assert len(ast.body) == 1
        assert ast.is_static is False
        assert ast.is_method is False
        assert len(ast.type_params) == 0
    
    def test_function_with_parameters(self, parse_statement):
        """Test parsing of function with parameters."""
        source = """fun add(a: int, b: int) -> int:
    return a + b"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "add"
        assert len(ast.params) == 2
        
        # Check first parameter
        assert ast.params[0].name == "a"
        assert isinstance(ast.params[0].type_annotation, BasicType)
        assert ast.params[0].type_annotation.name == "int"
        assert ast.params[0].is_mutable is False
        
        # Check second parameter
        assert ast.params[1].name == "b"
        assert isinstance(ast.params[1].type_annotation, BasicType)
        assert ast.params[1].type_annotation.name == "int"
        
        assert isinstance(ast.return_type, BasicType)
        assert ast.return_type.name == "int"
    
    def test_function_without_return_type(self, parse_statement):
        """Test parsing of function without explicit return type."""
        source = """fun process(value):
    cli.print(value)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "process"
        assert len(ast.params) == 1
        assert ast.return_type is None
    
    def test_function_with_mutable_parameters(self, parse_statement):
        """Test parsing of function with mutable parameters."""
        source = """fun modify(mut value: &mut string):
    value.append(" modified")"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert len(ast.params) == 1
        assert ast.params[0].name == "value"
        assert ast.params[0].is_mutable is True


@pytest.mark.functions
class TestGenericFunctionDeclarations:
    """Test parsing of generic function declarations."""
    
    def test_simple_generic_function(self, parse_statement):
        """Test parsing of simple generic function."""
        source = """temp[T] fun identity(value: T) -> T:
    return value"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "identity"
        assert len(ast.type_params) == 1
        assert "T" in ast.type_params
        assert len(ast.params) == 1
        assert ast.params[0].name == "value"
        assert ast.params[0].type_annotation.name == "T"
        assert ast.return_type.name == "T"
    
    def test_multiple_type_parameters(self, parse_statement):
        """Test parsing of function with multiple type parameters."""
        source = """temp[T, U] fun convert(value: T) -> U:
    return cast[U](value)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "convert"
        assert len(ast.type_params) == 2
        assert "T" in ast.type_params
        assert "U" in ast.type_params
    
    def test_generic_function_with_constraints(self, parse_statement):
        """Test parsing of generic function with constraints."""
        source = """temp[T] fun process(item: T) -> T where T: Copy:
    return item.copy()"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "process"
        assert len(ast.type_params) == 1
        assert "T" in ast.type_params


@pytest.mark.functions
class TestMethodDeclarations:
    """Test parsing of method declarations."""
    
    def test_simple_method(self, parse_statement):
        """Test parsing of simple method."""
        source = """fun[class] get_value(&self) -> int:
    return self.value"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "get_value"
        assert ast.is_method is True
        assert len(ast.params) == 1
        assert ast.params[0].name == "self"
    
    def test_static_method(self, parse_statement):
        """Test parsing of static method."""
        source = """fun[class] create() -> MyClass:
    return MyClass{}"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "create"
        assert ast.is_method is True
        assert ast.is_static is True
    
    def test_method_with_parameters(self, parse_statement):
        """Test parsing of method with parameters."""
        source = """fun[class] set_value(&mut self, new_value: int):
    self.value = new_value"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "set_value"
        assert ast.is_method is True
        assert len(ast.params) == 2
        assert ast.params[0].name == "self"
        assert ast.params[1].name == "new_value"


@pytest.mark.functions
class TestFunctionAttributes:
    """Test parsing of function attributes."""
    
    def test_async_function(self, parse_statement):
        """Test parsing of async function."""
        source = """fun[async] fetch_data(url: string) -> Task[string]:
    return await http.get(url)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "fetch_data"
        assert "async" in ast.attributes
    
    def test_thread_function(self, parse_statement):
        """Test parsing of thread function."""
        source = """fun[thread] background_task():
    run_in_background()"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "background_task"
        assert "thread" in ast.attributes
    
    def test_const_function(self, parse_statement):
        """Test parsing of compile-time function."""
        source = """fun[const] compile_time_calc(x: int) -> int:
    return x * 42"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "compile_time_calc"
        assert "const" in ast.attributes
    
    def test_ffi_function(self, parse_statement):
        """Test parsing of FFI function."""
        source = """fun[ffi("libc.so.6", abi="cdecl")] extern_func() -> &void"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "extern_func"
        # Check if any attribute contains "ffi"
        assert any("ffi" in attr for attr in ast.attributes)


@pytest.mark.functions
class TestFunctionBodies:
    """Test parsing of function bodies."""
    
    def test_single_statement_body(self, parse_statement):
        """Test parsing of function with single statement body."""
        source = """fun simple() -> int:
    return 42"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert len(ast.body) == 1
        assert isinstance(ast.body[0], ReturnStmt)
    
    def test_multi_statement_body(self, parse_statement):
        """Test parsing of function with multiple statements."""
        source = """fun complex(x: int) -> int:
    let y = x * 2
    let z = y + 10
    return z"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert len(ast.body) == 3
        assert isinstance(ast.body[0], VarDecl)
        assert isinstance(ast.body[1], VarDecl)
        assert isinstance(ast.body[2], ReturnStmt)
    
    def test_nested_control_flow(self, parse_statement):
        """Test parsing of function with nested control flow."""
        source = """fun nested(x: int) -> int:
    if x > 0:
        for i in range(x):
            if i % 2 == 0:
                return i
    return -1"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        # Body contains if statement and return statement (2 statements)
        assert len(ast.body) == 2


@pytest.mark.functions
class TestComplexFunctionDeclarations:
    """Test parsing of complex function declarations."""
    
    def test_generic_method_with_attributes(self, parse_statement):
        """Test parsing of generic method with attributes."""
        source = """temp[T] fun[class][async] process_async(&mut self, data: T) -> Task[T] where T: Serializable:
    let processed = self.serialize(data)
    return await self.send(processed)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert ast.name == "process_async"
        assert ast.is_method is True
        assert len(ast.type_params) == 1
        assert "async" in ast.attributes
    
    def test_function_with_complex_return_type(self, parse_statement):
        """Test parsing of function with complex return type."""
        source = """fun complex_return() -> Result[dict[string, int], Error]:
    return Ok({"count": 42})"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        # Result[T, E] is parsed as ResultType, not GenericType
        from parserr import ResultType, GenericType
        assert isinstance(ast.return_type, ResultType)
        assert ast.return_type.ok_type.key_type.name == "string"
    
    def test_function_with_default_parameters(self, parse_statement):
        """Test parsing of function with default parameters."""
        source = """fun greet(name: string = "World") -> string:
    return "Hello, " + name"""
        ast = parse_statement(source)
        
        assert isinstance(ast, FunctionDecl)
        assert len(ast.params) == 1
        assert ast.params[0].name == "name"


@pytest.mark.functions
class TestFunctionErrors:
    """Test error handling in function parsing."""
    
    def test_function_without_name(self, parse_statement):
        """Test error handling for function without name."""
        with pytest.raises(ParseError):
            parse_statement("fun () -> int:\n    return 42")
    
    def test_mismatched_parentheses(self, parse_statement):
        """Test error handling for mismatched parentheses."""
        with pytest.raises(ParseError):
            parse_statement("func add(a: int, b: int -> int:\n    return a + b")
    
    def test_invalid_parameter_syntax(self, parse_statement):
        """Test error handling for invalid parameter syntax."""
        with pytest.raises(ParseError):
            parse_statement("fun bad_param(123) -> int:\n    return x")
    
    def test_missing_function_body(self, parse_statement):
        """Test error handling for missing function body."""
        with pytest.raises(ParseError):
            parse_statement("fun incomplete() -> int:")


@pytest.mark.functions
@pytest.mark.parametrize("source,expected_name,expected_param_count,expected_return_type", [
    ("fun simple() -> void:\n    return", "simple", 0, "void"),
    ("fun add(a: int, b: int) -> int:\n    return a + b", "add", 2, "int"),
    ("fun process(value: string):\n    cli.print(value)", "process", 1, None),
    ("temp[T] fun generic(item: T) -> T:\n    return item", "generic", 1, "T"),
])
def test_function_parameterized(parse_statement, source, expected_name, expected_param_count, expected_return_type):
    """Parameterized test for function variations."""
    ast = parse_statement(source)
    
    assert isinstance(ast, FunctionDecl)
    assert ast.name == expected_name
    assert len(ast.params) == expected_param_count
    
    if expected_return_type is None:
        assert ast.return_type is None
    else:
        assert ast.return_type.name == expected_return_type


@pytest.mark.functions
class TestFunctionIntegration:
    """Test integration of functions in programs."""
    
    def test_multiple_functions_in_program(self, parse_program):
        """Test parsing program with multiple functions."""
        source = """
fun add(a: int, b: int) -> int:
    return a + b

fun multiply(a: int, b: int) -> int:
    return a * b

temp[T] fun identity(value: T) -> T:
    return value

fun[class] get_name(&self) -> string:
    return self.name
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 4
        for stmt in ast.statements:
            assert isinstance(stmt, FunctionDecl)
    
    def test_function_with_other_statements(self, parse_program):
        """Test parsing program with functions and other statements."""
        source = """
let global_var = 42

const PI = 3.14159

fun calculate(x: int) -> int:
    return x * global_var

let result = calculate(10)
"""
        ast = parse_program(source)
        
        from parserr import VarDecl, ConstDecl, FunctionDecl
        
        assert len(ast.statements) == 4
        assert isinstance(ast.statements[0], VarDecl)
        assert isinstance(ast.statements[1], ConstDecl)
        assert isinstance(ast.statements[2], FunctionDecl)
        assert isinstance(ast.statements[3], VarDecl)


if __name__ == "__main__":
    pytest.main([__file__])
