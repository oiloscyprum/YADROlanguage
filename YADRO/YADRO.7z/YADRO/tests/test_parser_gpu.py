"""Tests for GPU programming features per YUP 26.1.7.

These tests ensure the parser supports GPU programming syntax:
- GPU target declarations
- Memory space types
- Kernel function syntax
- Kernel launch configuration
- GPU synchronization primitives
- Host/device boundary enforcement
"""

import pytest
from parserr import ParseError


@pytest.mark.gpu
class TestGPUTargetDirectives:
    """Test parsing of GPU target directives."""
    
    def test_cuda_target_directive(self, parse_program):
        """Test parsing of CUDA target directive."""
        source = """
#target
os = "linux"
arch = "x86-64"
gpu = "cuda-12.4"
gpu_arch = "sm_90"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            target = ast.statements[0]
            assert hasattr(target, 'properties')
            assert target.properties['gpu'] == 'cuda-12.4'
            assert target.properties['gpu_arch'] == 'sm_90'
        except ParseError:
            pass
    
    def test_rocm_target_directive(self, parse_program):
        """Test parsing of ROCm target directive."""
        source = """
#target
os = "linux"
arch = "x86-64"
gpu = "rocm-6.0"
gpu_arch = "gfx1100"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_spirv_target_directive(self, parse_program):
        """Test parsing of SPIR-V target directive."""
        source = """
#target
os = "windows"
arch = "x86-64"
gpu = "spirv-1.6"
gpu_arch = "vulkan-1.3"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_multi_gpu_target_directive(self, parse_program):
        """Test parsing of multi-GPU target directive."""
        source = """
#target
os = "linux"
arch = "aarch64"
gpu = ["cuda-12.4", "rocm-6.0"]
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            target = ast.statements[0]
            assert 'cuda-12.4' in target.properties['gpu']
            assert 'rocm-6.0' in target.properties['gpu']
        except ParseError:
            pass


@pytest.mark.gpu
class TestMemorySpaceTypes:
    """Test parsing of GPU memory space types."""
    
    def test_global_memory_type(self, parse_expression):
        """Test parsing of global memory type."""
        try:
            ast = parse_expression("global[darray[int]]")
            assert hasattr(ast, 'memory_space')
            assert ast.memory_space == 'global'
        except ParseError:
            pass
    
    def test_shared_memory_type(self, parse_expression):
        """Test parsing of shared memory type."""
        try:
            ast = parse_expression("shared[darray[float]]")
            assert hasattr(ast, 'memory_space')
            assert ast.memory_space == 'shared'
        except ParseError:
            pass
    
    def test_local_memory_type(self, parse_expression):
        """Test parsing of local memory type."""
        try:
            ast = parse_expression("local[int]")
            assert hasattr(ast, 'memory_space')
            assert ast.memory_space == 'local'
        except ParseError:
            pass
    
    def test_constant_memory_type(self, parse_expression):
        """Test parsing of constant memory type."""
        try:
            ast = parse_expression("constant[ShaderParams]")
            assert hasattr(ast, 'memory_space')
            assert ast.memory_space == 'constant'
        except ParseError:
            pass
    
    def test_unified_memory_type(self, parse_expression):
        """Test parsing of unified memory type."""
        try:
            ast = parse_expression("unified[darray[byte]]")
            assert hasattr(ast, 'memory_space')
            assert ast.memory_space == 'unified'
        except ParseError:
            pass


@pytest.mark.gpu
class TestKernelFunctions:
    """Test parsing of GPU kernel functions."""
    
    def test_simple_kernel_function(self, parse_program):
        """Test parsing of simple GPU kernel function."""
        source = """
fun[gpu(kernel)] raytrace_kernel(
    global[Scene] scene,
    global[Image] output,
    u32 thread_idx
) -> Unit:
    # Kernel implementation
    pass
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            func_stmt = ast.statements[0]
            assert hasattr(func_stmt, 'is_gpu_kernel')
            assert func_stmt.is_gpu_kernel is True
        except ParseError:
            pass
    
    def test_kernel_with_sync_requirements(self, parse_program):
        """Test parsing of kernel with synchronization requirements."""
        source = """
fun[gpu(kernel)]
requires_sync = "block"
shared_mem = 4096
fun[gpu] reduction_kernel(
    global[darray[float]] input,
    global[float] output,
    shared[float] scratch
):
    # Implementation
    pass
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_kernel_with_memory_parameters(self, parse_program):
        """Test parsing of kernel with memory space parameters."""
        source = """
fun[gpu(kernel)] matrix_multiply(
    global[darray[float]] A,
    global[darray[float]] B,
    global[darray[float]] C,
    shared[darray[float]] tile
) -> Unit:
    # GPU matrix multiplication
    pass
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.gpu
class TestKernelLaunchSyntax:
    """Test parsing of kernel launch syntax."""
    
    def test_simple_kernel_launch(self, parse_program):
        """Test parsing of simple kernel launch."""
        source = """
launch raytrace_kernel(scene_data, image_buffer) config:
    grid_dim = (1024, 1024)
    block_dim = (256,)
    shared_mem = 4096
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            launch_stmt = ast.statements[0]
            assert hasattr(launch_stmt, 'is_kernel_launch')
            assert launch_stmt.is_kernel_launch is True
        except ParseError:
            pass
    
    def test_kernel_launch_with_stream(self, parse_program):
        """Test parsing of kernel launch with stream."""
        source = """
launch raytrace_kernel(scene, image) config:
    grid_dim = (1024, 1024)
    block_dim = (256,)
    stream = compute_stream
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_kernel_launch_task_assignment(self, parse_program):
        """Test parsing of kernel launch with task assignment."""
        source = """
Task[Unit] kernel_task = launch raytrace_kernel(scene, image) config:
    grid_dim = (1024, 1024)
    block_dim = (256,)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_fire_and_forget_launch(self, parse_program):
        """Test parsing of fire-and-forget kernel launch."""
        source = """
#[fire_and_forget]
launch raytrace_kernel(scene, image) config:
    grid_dim = (1024, 1024)
    block_dim = (256,)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.gpu
class TestGPUIntrinsics:
    """Test parsing of GPU intrinsic functions."""
    
    def test_thread_id_intrinsic(self, parse_expression):
        """Test parsing of thread ID intrinsic."""
        try:
            ast = parse_expression("#gpu_thread_id()")
            assert hasattr(ast, 'is_gpu_intrinsic')
            assert ast.is_gpu_intrinsic is True
        except ParseError:
            pass
    
    def test_block_sync_intrinsic(self, parse_expression):
        """Test parsing of block synchronization intrinsic."""
        try:
            ast = parse_expression("#gpu_sync_block()")
            assert hasattr(ast, 'gpu_sync_type')
            assert ast.gpu_sync_type == 'block'
        except ParseError:
            pass
    
    def test_grid_sync_intrinsic(self, parse_expression):
        """Test parsing of grid synchronization intrinsic."""
        try:
            ast = parse_expression("#gpu_sync_grid()")
            assert hasattr(ast, 'gpu_sync_type')
            assert ast.gpu_sync_type == 'grid'
        except ParseError:
            pass
    
    def test_warp_sync_intrinsic(self, parse_expression):
        """Test parsing of warp synchronization intrinsic."""
        try:
            ast = parse_expression("#gpu_any_sync(mask, predicate)")
            assert hasattr(ast, 'is_gpu_intrinsic')
        except ParseError:
            pass
    
    def test_atomic_operation_intrinsic(self, parse_expression):
        """Test parsing of atomic operation intrinsic."""
        try:
            ast = parse_expression("#gpu_atomic(\"add\", target, value, Acquire)")
            assert hasattr(ast, 'gpu_atomic_op')
            assert ast.gpu_atomic_op == 'add'
        except ParseError:
            pass


@pytest.mark.gpu
class TestMemoryTransferOperations:
    """Test parsing of GPU memory transfer operations."""
    
    def test_transfer_to_device(self, parse_program):
        """Test parsing of transfer to device operation."""
        source = """
global[darray[float]] device_data = transfer_to_device(host_data)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_transfer_to_host(self, parse_program):
        """Test parsing of transfer to host operation."""
        source = """
darray[float] host_data = transfer_to_host(device_data)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_gpu_transfer_operation(self, parse_expression):
        """Test parsing of generic GPU transfer operation."""
        try:
            ast = parse_expression("#gpu_transfer(host_data)")
            assert hasattr(ast, 'is_gpu_transfer')
        except ParseError:
            pass


@pytest.mark.gpu
class TestGPUSafetyAnnotations:
    """Test parsing of GPU safety annotations."""
    
    def test_relaxed_annotation(self, parse_program):
        """Test parsing of relaxed annotation for GPU code."""
        source = """
#[relaxed(reason = "benign race on histogram counter")]
fun[gpu(kernel)] histogram_kernel(
    global[darray[int]] values,
    global[darray[u32]] histogram
):
    # Implementation with benign race
    pass
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_unsafe_gpu_annotation(self, parse_program):
        """Test parsing of unsafe GPU annotation."""
        source = """
#[unsafe(gpu)]
fun[gpu(kernel)] custom_asm_kernel(global[float] data):
    asm("mma.sync.aligned.m16n8k16.f32.f16.f16.f32 ..."):
        # Tensor core intrinsic
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.gpu
class TestGPUIntegration:
    """Test integration of GPU features with regular code."""
    
    def test_host_device_integration(self, parse_program):
        """Test parsing of host/device integration."""
        source = """
fun render_scene(Scene host_scene, Image host_output) -> Result[Unit, GpuError]:
    global[darray[Sphere]] device_spheres = transfer_to_device(host_scene.spheres)?
    
    Task[Unit] render_task = launch path_trace_kernel(
        device_spheres,
        host_output.as_device_image()
    ) config:
        grid_dim = (ceil_div(host_output.pixels(), 256), 1)
        block_dim = (256,)
    
    await render_task?
    host_output.copy_from_device()?
    return Ok(())
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_gpu_memory_management(self, parse_program):
        """Test parsing of GPU memory management."""
        source = """
class[linear] GpuMemoryManager:
    u64 device_ptr
    u64 size
    
    fun[class] allocate(&mut self, u64 size) -> Option[u64]:
        if self.current + size > self.limit:
            return None
        u64 ptr = self.current
        self.current += size
        return Some(ptr)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.gpu
class TestGPUErrors:
    """Test error handling in GPU parsing."""
    
    def test_invalid_kernel_syntax(self, parse_program):
        """Test error handling for invalid kernel syntax."""
        source = """
fun[gpu(kernel)] bad_kernel() -> Unit:
    # Missing required kernel parameters
    pass
"""
        # This might be a semantic error, not parse error
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_invalid_memory_space(self, parse_expression):
        """Test error handling for invalid memory space."""
        source = "invalid_space[int] x = 42"
        with pytest.raises(ParseError):
            parse_expression(source)
    
    def test_malformed_launch_config(self, parse_program):
        """Test error handling for malformed launch configuration."""
        source = """
launch kernel() config:
    invalid_config = value
"""
        with pytest.raises(ParseError):
            parse_program(source)


@pytest.mark.gpu
@pytest.mark.parametrize("gpu_source,expected_feature", [
    ("#target gpu = \"cuda-12.4\"", "gpu_target"),
    ("global[darray[int]]", "global_memory"),
    ("fun[gpu(kernel)] kernel() -> Unit: pass", "kernel_function"),
    ("launch kernel() config: grid_dim = (1024, 1024)", "kernel_launch"),
    ("#gpu_thread_id()", "gpu_intrinsic"),
])
def test_gpu_features_parameterized(parse_program, gpu_source, expected_feature):
    """Parameterized test for GPU programming features."""
    try:
        ast = parse_program(gpu_source)
        # Should parse successfully and create GPU structure
        assert len(ast.statements) >= 1
    except ParseError:
        # Should not fail on well-formed GPU code
        pytest.fail(f"GPU feature {expected_feature} failed to parse")


if __name__ == "__main__":
    pytest.main([__file__])
