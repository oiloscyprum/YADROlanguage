"""Tests for compiler directive parsing in YADRO parser."""

import pytest
from parserr import (
    TargetDirective, PluginDirective, RequiresDirective, ImportDirective,
    StartDirective, EndDirective, ParseError
)


@pytest.mark.directives
class TestTargetDirective:
    """Test parsing of #target directives."""
    
    def test_simple_target_directive(self, parse_statement):
        """Test parsing of simple #target directive."""
        source = '#target "linux";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'linux'
        assert ast.line == 1
        assert ast.column == 16  # Column after the semicolon
    
    def test_multiline_target_directive(self, parse_program):
        """Test parsing of multiline #target directive (YUP 26.1.1)."""
        source = """
#target
os = "linux"
arch = "x86-64"
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], TargetDirective)
        target = ast.statements[0]
        assert target.properties['os'] == 'linux'
        assert target.properties['arch'] == 'x86-64'
    
    def test_gpu_target_directive(self, parse_program):
        """Test parsing of GPU target directive (YUP 26.1.7)."""
        source = """
#target
os = "linux"
arch = "x86-64"
gpu = "cuda-12.4"
gpu_arch = "sm_90"
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        target = ast.statements[0]
        assert isinstance(target, TargetDirective)
        assert target.properties['gpu'] == 'cuda-12.4'
        assert target.properties['gpu_arch'] == 'sm_90'
    
    def test_wasm_target_directive(self, parse_program):
        """Test parsing of WebAssembly target directive (YUP 26.1.9)."""
        source = """
#target
arch = "wasm32"
wasm = "gc-2.0"
wasm_features = ["bulk-memory", "reference-types", "gc"]
js_ffi = true
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        target = ast.statements[0]
        assert isinstance(target, TargetDirective)
        assert target.properties['arch'] == 'wasm32'
        assert target.properties['wasm'] == 'gc-2.0'
        assert 'bulk-memory' in target.properties['wasm_features']
        assert target.properties['js_ffi'] is True
    
    def test_multi_gpu_target_directive(self, parse_program):
        """Test parsing of multi-GPU target directive."""
        source = """
#target
os = "linux"
arch = "aarch64"
gpu = ["cuda-12.4", "rocm-6.0"]
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        target = ast.statements[0]
        assert isinstance(target, TargetDirective)
        assert 'cuda-12.4' in target.properties['gpu']
        assert 'rocm-6.0' in target.properties['gpu']
    
    def test_target_directive_single_line(self, parse_statement):
        """Test parsing of single-line #target directive."""
        source = '#target "x86-64";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'x86-64'
    
    def test_target_directive_with_windows(self, parse_statement):
        """Test parsing of #target directive with Windows target."""
        source = '#target "windows";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'windows'
    
    def test_target_directive_with_macos(self, parse_statement):
        """Test parsing of #target directive with macOS target."""
        source = '#target "macos";'
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.target == 'macos'
    
    def test_target_with_optimization_level(self, parse_program):
        """Test parsing of target with optimization level."""
        source = """
#target
os = "linux"
arch = "x86-64"
optimization = "speed"
"""
        ast = parse_program(source)
        
        target = ast.statements[0]
        assert target.properties['optimization'] == 'speed'


@pytest.mark.directives
class TestPluginDirective:
    """Test parsing of #plugin directives."""
    
    def test_simple_plugin_directive(self, parse_statement):
        """Test parsing of simple #plugin directive."""
        source = '#plugin "safety-opt";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert ast.plugin == 'safety-opt'
    
    def test_plugin_directive_with_version(self, parse_statement):
        """Test parsing of #plugin directive with version."""
        source = '#plugin "linter==1.2";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert ast.plugin == 'linter==1.2'
    
    def test_plugin_directive_multiple_plugins(self, parse_statement):
        """Test parsing of #plugin directive with multiple plugins."""
        source = '#plugin "safety-opt,linter==1.2,formatter";'
        ast = parse_statement(source)
        
        assert isinstance(ast, PluginDirective)
        assert 'safety-opt' in ast.plugin
        assert 'linter==1.2' in ast.plugin
        assert 'formatter' in ast.plugin


@pytest.mark.directives
class TestRequiresDirective:
    """Test parsing of #requires directives."""
    
    def test_requires_dll(self, parse_statement):
        """Test parsing of #requires directive with DLL."""
        source = '#requires "kernel32.dll";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert ast.version == 'kernel32.dll'
    
    def test_requires_so(self, parse_statement):
        """Test parsing of #requires directive with shared library."""
        source = '#requires "libc.so.6";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert ast.version == 'libc.so.6'
    
    def test_requires_multiple_libraries(self, parse_statement):
        """Test parsing of #requires directive with multiple libraries."""
        source = '#requires "kernel32.dll,libc.so.6";'
        ast = parse_statement(source)
        
        assert isinstance(ast, RequiresDirective)
        assert 'kernel32.dll' in ast.version
        assert 'libc.so.6' in ast.version


@pytest.mark.directives
class TestImportDirective:
    """Test parsing of #import directives."""
    
    def test_simple_import_directive(self, parse_statement):
        """Test parsing of simple #import directive."""
        source = '#import std.core.cli;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std.core.cli'
        assert ast.alias is None
    
    def test_import_directive_with_alias(self, parse_statement):
        """Test parsing of #import directive with alias."""
        source = '#import std.os.fs as fs;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std.os.fs'
        assert ast.alias == 'fs'
    
    def test_import_directive_single_module(self, parse_statement):
        """Test parsing of single-module #import directive."""
        source = '#import std;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert ast.module == 'std'
        assert ast.alias is None


@pytest.mark.directives
class TestStartDirective:
    """Test parsing of #start directives."""
    
    def test_start_directive(self, parse_statement):
        """Test parsing of #start directive."""
        source = '#start main;'
        ast = parse_statement(source)
        
        assert isinstance(ast, StartDirective)
        assert ast.function == 'main'
    
    def test_start_directive_with_function_name(self, parse_statement):
        """Test parsing of #start directive with different function name."""
        source = '#start entry_point;'
        ast = parse_statement(source)
        
        assert isinstance(ast, StartDirective)
        assert ast.function == 'entry_point'


@pytest.mark.directives
class TestEndDirective:
    """Test parsing of #end directives."""
    
    def test_end_directive(self, parse_statement):
        """Test parsing of #end directive."""
        source = '#end main;'
        ast = parse_statement(source)
        
        assert isinstance(ast, EndDirective)
        assert ast.function == 'main'
    
    def test_end_directive_with_function_name(self, parse_statement):
        """Test parsing of #end directive with different function name."""
        source = '#end entry_point;'
        ast = parse_statement(source)
        
        assert isinstance(ast, EndDirective)
        assert ast.function == 'entry_point'


@pytest.mark.directives
class TestRequiresJSDirective:
    """Test parsing of #requires_js directives (YUP 26.1.9)."""
    
    def test_simple_js_capability_directive(self, parse_program):
        """Test parsing of simple JS capability directive."""
        source = """
#requires_js
capabilities = ["dom", "fetch"]
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        assert hasattr(ast.statements[0], 'js_capabilities')
        assert 'dom' in ast.statements[0].js_capabilities
        assert 'fetch' in ast.statements[0].js_capabilities
    
    def test_js_capability_with_sandboxing(self, parse_program):
        """Test JS capability directive with sandboxing."""
        source = """
#requires_js
capabilities = ["dom", "fetch", "webcrypto"]
sandboxed = true
"""
        ast = parse_program(source)
        
        directive = ast.statements[0]
        assert directive.js_capabilities == ['dom', 'fetch', 'webcrypto']
        assert directive.sandboxed is True


@pytest.mark.directives
class TestVerificationDirectives:
    """Test parsing of verification-related directives (YUP 26.1.5)."""
    
    def test_verification_level_directive(self, parse_program):
        """Test parsing of verification level directive."""
        source = """
#verification
level = "require"
prover = "why3"
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        directive = ast.statements[0]
        assert directive.verification_level == 'require'
        assert directive.prover == 'why3'
    
    def test_proof_obligations_directive(self, parse_program):
        """Test parsing of proof obligations directive."""
        source = """
#verification
dump_obligations = true
output_file = "obligations.v"
"""
        ast = parse_program(source)
        
        directive = ast.statements[0]
        assert directive.dump_obligations is True
        assert directive.output_file == 'obligations.v'


@pytest.mark.directives
class TestConstitutionalDirectives:
    """Test parsing of constitutional compliance directives (YUP 26.1.3)."""
    
    def test_constitution_compliance_directive(self, parse_program):
        """Test parsing of constitution compliance directive."""
        source = """
#constitution
compliance = "strict"
articles = ["I.1", "II.1", "III.3"]
"""
        ast = parse_program(source)
        
        directive = ast.statements[0]
        assert directive.compliance_level == 'strict'
        assert 'I.1' in directive.articles
        assert 'II.1' in directive.articles
        assert 'III.3' in directive.articles
    
    def test_constitutional_safeguard_directive(self, parse_program):
        """Test parsing of constitutional safeguard directive."""
        source = """
#constitution
safeguards = ["no_implicit_promotion", "explicit_cost_model"]
zero_cost_abstraction = true
"""
        ast = parse_program(source)
        
        directive = ast.statements[0]
        assert 'no_implicit_promotion' in directive.safeguards
        assert 'explicit_cost_model' in directive.safeguards
        assert directive.zero_cost_abstraction is True


@pytest.mark.directives
class TestDirectiveIntegration:
    """Test integration of multiple directives."""
    
    def test_multiple_directives_in_program(self, parse_program):
        """Test parsing program with multiple directives."""
        source = """
#target
os = "linux"
arch = "x86-64"

#plugin
safety-opt
linter==1.2

#requires
"kernel32.dll"
"libc.so.6"

#import
std.core.cli
std.os.fs as fs

#start main
#end main
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 6
        
        # Check each directive type
        directives = [TargetDirective, PluginDirective, RequiresDirective, 
                      ImportDirective, StartDirective, EndDirective]
        
        for i, expected_type in enumerate(directives):
            assert isinstance(ast.statements[i], expected_type)
    
    def test_directive_order_independence(self, parse_program):
        """Test that directives can appear in any order."""
        source = """
#start main
#target os = "linux"
#import std.core.cli
#plugin safety-opt
#end main
#requires "kernel32.dll"
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 6
        assert isinstance(ast.statements[0], StartDirective)
        assert isinstance(ast.statements[1], TargetDirective)
        assert isinstance(ast.statements[2], ImportDirective)
        assert isinstance(ast.statements[3], PluginDirective)
        assert isinstance(ast.statements[4], EndDirective)
        assert isinstance(ast.statements[5], RequiresDirective)


@pytest.mark.directives
class TestDirectiveErrors:
    """Test error handling in directive parsing."""
    
    def test_malformed_target_directive(self, parse_statement):
        """Test error handling for malformed #target directive."""
        from parserr import ParseError
        from lexer import LexerError
        
        # Missing closing quote
        with pytest.raises((ParseError, LexerError)):
            parse_statement('#target os = "linux')
    
    def test_malformed_import_directive(self, parse_statement):
        """Test error handling for malformed #import directive."""
        from parserr import ParseError
        
        # Missing module name
        with pytest.raises(ParseError):
            parse_statement('#import')
    
    def test_malformed_requires_directive(self, parse_statement):
        """Test error handling for malformed #requires directive."""
        from parserr import ParseError
        
        # Missing quotes around library name
        with pytest.raises(ParseError):
            parse_statement('#requires kernel32.dll')
    
    def test_malformed_start_directive(self, parse_statement):
        """Test error handling for malformed #start directive."""
        from parserr import ParseError
        
        # Missing function name
        with pytest.raises(ParseError):
            parse_statement('#start')
    
    def test_malformed_end_directive(self, parse_statement):
        """Test error handling for malformed #end directive."""
        from parserr import ParseError
        
        # Missing function name
        with pytest.raises(ParseError):
            parse_statement('#end')


@pytest.mark.directives
class TestDirectiveFixtures:
    """Test directive parsing with fixture files."""
    
    def test_valid_target_directive_fixture(self, parse_statement):
        """Test parsing valid target directive from fixture."""
        source = """
#target
os = "linux"
arch = "x86-64"
optimization = "speed"
"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TargetDirective)
        assert ast.properties['os'] == 'linux'
        assert ast.properties['arch'] == 'x86-64'
        assert ast.properties['optimization'] == 'speed'
    
    def test_valid_import_directive_fixture(self, parse_statement):
        """Test parsing valid import directive from fixture."""
        source = """
#import
std.core.cli
std.os.fs as fs
std.collections.vector
std.math
"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ImportDirective)
        assert 'std.core.cli' in ast.module
        assert 'std.os.fs as fs' in ast.module
        assert 'std.collections.vector' in ast.module
        assert 'std.math' in ast.module


@pytest.mark.directives
@pytest.mark.parametrize("directive_source,expected_type,expected_content", [
    ('#target "linux";', TargetDirective, 'linux'),
    ('#plugin "safety-opt";', PluginDirective, 'safety-opt'),
    ('#requires "kernel32.dll";', RequiresDirective, 'kernel32.dll'),
    ('#import std.core.cli;', ImportDirective, 'std.core.cli'),
    ('#start main;', StartDirective, 'main'),
    ('#end main;', EndDirective, 'main'),
])
def test_directive_parameterized(parse_statement, directive_source, expected_type, expected_content):
    """Parameterized test for all directive types."""
    ast = parse_statement(directive_source)
    
    assert isinstance(ast, expected_type)
    if hasattr(ast, 'target'):
        assert ast.target == expected_content
    elif hasattr(ast, 'plugin'):
        assert ast.plugin == expected_content
    elif hasattr(ast, 'version'):
        assert ast.version == expected_content
    elif hasattr(ast, 'module'):
        assert ast.module == expected_content
    elif hasattr(ast, 'function'):
        assert ast.function == expected_content


if __name__ == "__main__":
    pytest.main([__file__])
