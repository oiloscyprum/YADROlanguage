"""Tests for WebAssembly GC features per YUP 26.1.9.

These tests ensure the parser supports WebAssembly GC syntax:
- WASM target declarations
- GC heap types
- JavaScript FFI capability declarations
- Heap boundary conversion syntax
- Non-determinism annotations
"""

import pytest
from parserr import ParseError


@pytest.mark.wasm_gc
class TestWASMGCTargetDirectives:
    """Test parsing of WebAssembly GC target directives."""
    
    def test_wasm_gc_target_directive(self, parse_program):
        """Test parsing of WASM GC target directive."""
        source = """
#target
arch = "wasm32"
wasm = "gc-2.0"
wasm_features = ["bulk-memory", "reference-types", "gc"]
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            target = ast.statements[0]
            assert hasattr(target, 'properties')
            assert target.properties['arch'] == 'wasm32'
            assert target.properties['wasm'] == 'gc-2.0'
            assert 'bulk-memory' in target.properties['wasm_features']
        except ParseError:
            pass
    
    def test_wasm_mvp_target_directive(self, parse_program):
        """Test parsing of WASM MVP target directive."""
        source = """
#target
arch = "wasm32"
wasm = "mvp"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            target = ast.statements[0]
            assert target.properties['wasm'] == 'mvp'
        except ParseError:
            pass
    
    def test_wasm_js_ffi_target_directive(self, parse_program):
        """Test parsing of WASM with JS FFI target directive."""
        source = """
#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            target = ast.statements[0]
            assert target.properties['js_ffi'] is True
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCTypes:
    """Test parsing of WebAssembly GC heap types."""
    
    def test_wasm_gc_reference_type(self, parse_expression):
        """Test parsing of WASM GC reference type."""
        try:
            ast = parse_expression("wasm_gc[Person]")
            assert hasattr(ast, 'wasm_gc_type')
            assert ast.wasm_gc_type == 'reference'
        except ParseError:
            pass
    
    def test_wasm_struct_type(self, parse_expression):
        """Test parsing of WASM struct type."""
        try:
            ast = parse_expression("wasm_struct[Person]")
            assert hasattr(ast, 'wasm_gc_type')
            assert ast.wasm_gc_type == 'struct'
        except ParseError:
            pass
    
    def test_wasm_array_type(self, parse_expression):
        """Test parsing of WASM array type."""
        try:
            ast = parse_expression("wasm_array[u32]")
            assert hasattr(ast, 'wasm_gc_type')
            assert ast.wasm_gc_type == 'array'
        except ParseError:
            pass
    
    def test_wasm_externref_type(self, parse_expression):
        """Test parsing of WASM external reference type."""
        try:
            ast = parse_expression("wasm_externref")
            assert hasattr(ast, 'wasm_gc_type')
            assert ast.wasm_gc_type == 'externref'
        except ParseError:
            pass
    
    def test_wasm_anyref_type(self, parse_expression):
        """Test parsing of WASM universal reference type."""
        try:
            ast = parse_expression("wasm_anyref")
            assert hasattr(ast, 'wasm_gc_type')
            assert ast.wasm_gc_type == 'anyref'
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCStructDefinitions:
    """Test parsing of WASM GC struct definitions."""
    
    def test_simple_wasm_struct_definition(self, parse_program):
        """Test parsing of simple WASM struct definition."""
        source = """
wasm_struct Person:
    string name
    u32 age
    wasm_gc[Person] parent
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            struct_stmt = ast.statements[0]
            assert hasattr(struct_stmt, 'is_wasm_struct')
            assert struct_stmt.is_wasm_struct is True
        except ParseError:
            pass
    
    def test_wasm_struct_with_cyclic_reference(self, parse_program):
        """Test parsing of WASM struct with cyclic reference."""
        source = """
wasm_struct Node:
    string data
    wasm_gc[Node] next
    wasm_gc[Node] prev
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCCapabilityDeclarations:
    """Test parsing of WASM GC capability declarations."""
    
    def test_simple_js_capability_declaration(self, parse_program):
        """Test parsing of simple JS capability declaration."""
        source = """
#requires_js
capabilities = ["dom", "fetch"]
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            cap_stmt = ast.statements[0]
            assert hasattr(cap_stmt, 'js_capabilities')
            assert 'dom' in cap_stmt.js_capabilities
            assert 'fetch' in cap_stmt.js_capabilities
        except ParseError:
            pass
    
    def test_js_capability_with_sandboxing(self, parse_program):
        """Test parsing of JS capability with sandboxing."""
        source = """
#requires_js
capabilities = ["dom", "fetch", "webcrypto"]
sandboxed = true
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            cap_stmt = ast.statements[0]
            assert cap_stmt.sandboxed is True
        except ParseError:
            pass
    
    def test_js_function_import(self, parse_program):
        """Test parsing of JS function import with capabilities."""
        source = """
fun[ffi("js")] fetch_url(string url) -> Task[wasm_externref]
effects:
    network_access
    may_block
requires_capabilities = ["fetch"]
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCHeapConversions:
    """Test parsing of WASM GC heap conversion operations."""
    
    def test_promotion_to_gc_heap(self, parse_program):
        """Test parsing of promotion to GC heap."""
        source = """
wasm_gc[Person] gc_person = wasm_gc::promote(linear_person)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            conv_stmt = ast.statements[0]
            assert hasattr(conv_stmt, 'wasm_gc_operation')
            assert conv_stmt.wasm_gc_operation == 'promote'
        except ParseError:
            pass
    
    def test_demotion_from_gc_heap(self, parse_program):
        """Test parsing of demotion from GC heap."""
        source = """
Person linear_person = wasm_gc::demote(gc_person)?
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_try_demotion_operation(self, parse_program):
        """Test parsing of try demotion operation."""
        source = """
switch wasm_gc::try_demote(gc_person):
    case Ok(person):
        process(person)
    case Err(MultipleReferences):
        cli.print("Object has multiple GC references")
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_copy_to_gc_heap(self, parse_program):
        """Test parsing of copy to GC heap."""
        source = """
wasm_gc[SimpleData] gc_data = wasm_gc::copy(linear_data)
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCCollectionOperations:
    """Test parsing of WASM GC collection operations."""
    
    def test_gc_allocation(self, parse_expression):
        """Test parsing of GC allocation."""
        try:
            ast = parse_expression("wasm_gc::alloc(Person.new())")
            assert hasattr(ast, 'wasm_gc_op')
            assert ast.wasm_gc_op == 'alloc'
        except ParseError:
            pass
    
    def test_gc_array_allocation(self, parse_expression):
        """Test parsing of GC array allocation."""
        try:
            ast = parse_expression("wasm_gc::array_alloc[u32](100)")
            assert hasattr(ast, 'wasm_gc_op')
            assert ast.wasm_gc_op == 'array_alloc'
        except ParseError:
            pass
    
    def test_gc_null_reference(self, parse_expression):
        """Test parsing of GC null reference."""
        try:
            ast = parse_expression("wasm_gc::null()")
            assert hasattr(ast, 'wasm_gc_op')
            assert ast.wasm_gc_op == 'null'
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCNonDeterminism:
    """Test parsing of WASM GC non-determinism annotations."""
    
    def test_non_deterministic_function_annotation(self, parse_program):
        """Test parsing of non-deterministic function annotation."""
        source = """
fun[non_deterministic(gc_collection)]
measure_allocation_time() -> u64:
    u64 start = time::now()
    wasm_gc::alloc(HeavyObject.new())
    return time::now() - start
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            func_stmt = ast.statements[0]
            assert hasattr(func_stmt, 'is_non_deterministic')
            assert func_stmt.is_non_deterministic is True
        except ParseError:
            pass
    
    def test_deterministic_alternative(self, parse_program):
        """Test parsing of deterministic alternative using arena."""
        source = """
fun measure_allocation_time_deterministic() -> u64:
    arena: Arena = Arena.new()
    gc[HeavyObject] obj = arena.alloc(HeavyObject.new())
    return time::now() - start
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCIntegration:
    """Test integration of WASM GC features with regular code."""
    
    def test_wasm_entry_point(self, parse_program):
        """Test parsing of WASM entry point."""
        source = """
fun wasm_entry_point() -> wasm_gc[App]:
    darray[TodoItem] todos = [
        TodoItem{1, "Learn YADRO", false},
        TodoItem{2, "Build WASM app", true}
    ]
    
    wasm_gc[darray[wasm_gc[JsTodoItem]]] js_todos = 
        wasm_gc::array_alloc[wasm_gc[JsTodoItem]](todos.len())
    
    return wasm_gc::alloc(App{ todos: js_todos })
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_dom_manipulation(self, parse_program):
        """Test parsing of DOM manipulation with JS FFI."""
        source = """
fun setup_ui() -> Result[Unit, JsError]:
    wasm_gc[DomElement] root = dom::get_element_by_id("app")?
    root.set_text("Hello from YADRO!")
    return Ok(())
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_js_callback_registration(self, parse_program):
        """Test parsing of JS callback registration."""
        source = """
fun setup_click_handler(DomElement element, fun() -> Unit handler):
    wasm_externref callback = js_callback::wrap(handler)
    
    #[effect(js_event)]
    #requires_js(dom::add_event_listener(
        element.raw_element,
        "click",
        callback
    ))
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCSafety:
    """Test parsing of WASM GC safety features."""
    
    def test_unsafe_wasm_annotation(self, parse_program):
        """Test parsing of unsafe WASM annotation."""
        source = """
#[unsafe(wasm_gc)]
fun custom_gc_barrier():
    asm.wasm("gc.barrier"):
        # Raw WASM GC instruction
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            func_stmt = ast.statements[0]
            assert hasattr(func_stmt, 'is_unsafe_wasm')
            assert func_stmt.is_unsafe_wasm is True
        except ParseError:
            pass
    
    def test_linear_only_module(self, parse_program):
        """Test parsing of linear-only module (default safety)."""
        source = """
fun process_data(darray[u8] data) -> Result[u64, Error]:
    return Ok(crc32(data))
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.wasm_gc
class TestWASMGCErrors:
    """Test error handling in WASM GC parsing."""
    
    def test_invalid_wasm_type(self, parse_expression):
        """Test error handling for invalid WASM type."""
        source = "invalid_wasm_type[int] x = 42"
        with pytest.raises(ParseError):
            parse_expression(source)
    
    def test_missing_capability_declaration(self, parse_program):
        """Test error handling for missing capability declaration."""
        source = """
fun use_dom_without_capability():
    dom::get_element_by_id("root")
"""
        # This might be a semantic error, not parse error
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_invalid_heap_boundary_crossing(self, parse_program):
        """Test error handling for invalid heap boundary crossing."""
        source = """
let invalid_ref = &wasm_gc[Object]  # Should not be allowed
"""
        with pytest.raises(ParseError):
            parse_program(source)


@pytest.mark.wasm_gc
@pytest.mark.parametrize("wasm_source,expected_feature", [
    ("#target wasm = \"gc-2.0\"", "wasm_gc_target"),
    ("wasm_gc[Person]", "wasm_gc_reference"),
    ("wasm_struct Person: string name", "wasm_struct_definition"),
    ("#requires_js capabilities = [\"dom\"]", "js_capability"),
    ("wasm_gc::alloc(Object.new())", "gc_allocation"),
])
def test_wasm_gc_features_parameterized(parse_program, wasm_source, expected_feature):
    """Parameterized test for WebAssembly GC features."""
    try:
        ast = parse_program(wasm_source)
        # Should parse successfully and create WASM GC structure
        assert len(ast.statements) >= 1
    except ParseError:
        # Should not fail on well-formed WASM GC code
        pytest.fail(f"WASM GC feature {expected_feature} failed to parse")


if __name__ == "__main__":
    pytest.main([__file__])
