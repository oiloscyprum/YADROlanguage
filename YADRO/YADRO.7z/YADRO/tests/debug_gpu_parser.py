
import pytest
from parserr import ParseError, YadroParser
from lexer import Lexer

def parse_program(source):
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = YadroParser(tokens)
    return parser.parse_program()

def test_simple_kernel_function_debug():
    source = """
fun[gpu(kernel)] raytrace_kernel(
    global[Scene] scene,
    global[Image] output,
    u32 thread_idx
) -> Unit:
    # Kernel implementation
    pass
"""
    ast = parse_program(source)
    print("\nParsed AST:", ast)
    if ast.statements:
        print("First statement:", ast.statements[0])
        print("Type of first statement:", type(ast.statements[0]))
        if hasattr(ast.statements[0], 'is_gpu_kernel'):
             print("is_gpu_kernel:", ast.statements[0].is_gpu_kernel)
        else:
             print("No is_gpu_kernel attribute")
    
    assert len(ast.statements) >= 1
    func_stmt = ast.statements[0]
    # Check if it's a kernel function declaration
    # Note: Depending on implementation, it might be a specific class or have a flag
    assert hasattr(func_stmt, 'is_gpu_kernel') or func_stmt.__class__.__name__ == 'KernelFunctionDecl'
    if hasattr(func_stmt, 'is_gpu_kernel'):
        assert func_stmt.is_gpu_kernel is True
