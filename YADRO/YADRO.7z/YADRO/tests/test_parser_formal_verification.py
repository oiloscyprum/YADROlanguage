"""Tests for formal verification features per YUP 26.1.5.

These tests ensure the parser supports formal verification syntax:
- Spec blocks for refined types
- Function specifications (pre/post-conditions)
- Loop invariants
- Ghost variables
- Verification intermediate representation structure
- Proof obligation generation
"""

import pytest
from parserr import ParseError


@pytest.mark.formal_verification
class TestSpecBlocks:
    """Test parsing of spec blocks for refined types."""
    
    def test_simple_spec_type_definition(self, parse_program):
        """Test parsing of simple spec type definition."""
        source = """
spec PositiveInt = int where value > 0
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            spec_stmt = ast.statements[0]
            assert hasattr(spec_stmt, 'spec_name')
            assert spec_stmt.spec_name == 'PositiveInt'
            assert hasattr(spec_stmt, 'base_type')
            assert hasattr(spec_stmt, 'predicate')
        except ParseError:
            pass  # Parser should structure for spec blocks
    
    def test_complex_spec_type_definition(self, parse_program):
        """Test parsing of complex spec type with function calls."""
        source = """
spec SortedArray[T] = darray[T] where is_sorted(value)
spec NonEmptyString = string where len(value) > 0
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 2
        except ParseError:
            pass
    
    def test_nested_spec_predicate(self, parse_program):
        """Test parsing of nested spec predicates."""
        source = """
spec BoundedBuffer = darray[int] where len(value) > 0 and max(value) < 100
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestFunctionSpecifications:
    """Test parsing of function specifications."""
    
    def test_function_with_pre_post_conditions(self, parse_program):
        """Test parsing of function with requires and ensures clauses."""
        source = """
fun divide(PositiveInt numerator, PositiveInt denominator) -> PositiveInt
spec:
    requires denominator > 0
    ensures result > 0
    ensures result <= numerator
:
    return numerator / denominator
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            func_stmt = ast.statements[0]
            assert hasattr(func_stmt, 'specifications')
            assert hasattr(func_stmt.specifications, 'requires')
            assert hasattr(func_stmt.specifications, 'ensures')
        except ParseError:
            pass
    
    def test_function_with_loop_invariants(self, parse_program):
        """Test parsing of function with loop invariants."""
        source = """
fun factorial(u32 n) -> u64
spec:
    requires n <= 20
    ensures result >= 1
:
    u64 acc = 1
    u32 i = 1
    while i <= n
    spec invariant acc == factorial(i - 1)
    spec invariant i <= n + 1
    :
        acc *= i
        i += 1
    return acc
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass
    
    def test_function_with_ghost_variables(self, parse_program):
        """Test parsing of function with ghost variables."""
        source = """
fun binary_search(darray[int] sorted, int target) -> Option[u32]
spec:
    requires is_sorted(sorted)
    ensures match result:
        case Some(idx): sorted[idx] == target
        case None: !contains(sorted, target)
:
    u32 left = 0
    u32 right = sorted.len()
    
    #[ghost] u32 old_left = left
    #[ghost] u32 old_right = right
    
    # Binary search implementation
    return None
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestClassInvariants:
    """Test parsing of class invariants."""
    
    def test_class_with_invariants(self, parse_program):
        """Test parsing of class with invariants."""
        source = """
class[linear] BoundedBuffer[T](u32 capacity):
    darray[T] data
    u32 head = 0
    u32 tail = 0
    
spec invariant:
    capacity > 0
    data.len() == capacity
    head < capacity
    tail < capacity
    (tail + 1) % capacity != head
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            class_stmt = ast.statements[0]
            assert hasattr(class_stmt, 'invariants')
        except ParseError:
            pass
    
    def test_class_method_with_specifications(self, parse_program):
        """Test parsing of class method with specifications."""
        source = """
class[linear] VerifiedAllocator:
    u64 base_ptr
    u64 current
    u64 limit
    
spec invariant:
    base_ptr > 0
    base_ptr <= current
    current <= limit

fun[class] alloc(&mut self, u64 size) -> Option[u64]
spec:
    requires size > 0
    requires size <= 0x100000000u64
    ensures match result:
        case Some(ptr): 
            ptr >= self.base_ptr and 
            ptr + size <= self.limit and
            ptr % 8 == 0
        case None: 
            self.current == old(self.current)
:
    # Implementation
    return None
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestVerificationExpressions:
    """Test parsing of verification-specific expressions."""
    
    def test_old_expression(self, parse_expression):
        """Test parsing of old() expressions."""
        try:
            ast = parse_expression("old(self.len())")
            assert hasattr(ast, 'is_old_expr')
            assert ast.is_old_expr is True
        except ParseError:
            pass
    
    def test_ghost_variable_annotation(self, parse_statement):
        """Test parsing of ghost variable annotations."""
        source = '#[ghost] u32 old_counter = counter;'
        try:
            ast = parse_statement(source)
            assert hasattr(ast, 'is_ghost')
            assert ast.is_ghost is True
        except ParseError:
            pass
    
    def test_axiom_declaration(self, parse_program):
        """Test parsing of axiom declarations."""
        source = """
#[unsafe(axiom)]
spec axiom commutativity_of_addition(int a, int b):
    a + b == b + a
justification: "Peano arithmetic axiom PA3"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            axiom_stmt = ast.statements[0]
            assert hasattr(axiom_stmt, 'is_axiom')
            assert axiom_stmt.is_axiom is True
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestVerificationDirectives:
    """Test parsing of verification-related directives."""
    
    def test_verification_level_directive(self, parse_program):
        """Test parsing of verification level directive."""
        source = """
#verification
level = "require"
prover = "why3"
proof_cache = true
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            verify_stmt = ast.statements[0]
            assert hasattr(verify_stmt, 'verification_level')
            assert verify_stmt.verification_level == 'require'
        except ParseError:
            pass
    
    def test_proof_obligation_directive(self, parse_program):
        """Test parsing of proof obligation directive."""
        source = """
#verification
dump_obligations = true
output_format = "why3"
output_file = "proof_obligations.why"
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestVerificationIntegration:
    """Test integration of verification features with regular code."""
    
    def test_verified_critical_function(self, parse_program):
        """Test parsing of verified critical function."""
        source = """
#[critical]
fun abs_diff(u32 a, u32 b) -> u32
spec:
    ensures result == abs(a as int - b as int) as u32
    ensures result <= max(a, b)
:
    if a > b:
        return a - b
    else:
        return b - a
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 1
            func_stmt = ast.statements[0]
            assert hasattr(func_stmt, 'is_critical')
            assert func_stmt.is_critical is True
        except ParseError:
            pass
    
    def test_verified_module_structure(self, parse_program):
        """Test parsing of complete verified module."""
        source = """
#verification
level = "certify"
prover = "why3"

spec PositiveInt = int where value > 0

fun verified_add(PositiveInt a, PositiveInt b) -> PositiveInt
spec:
    ensures result == a + b
:
    return a + b

class[linear] SafeCounter:
    u64 value
    
spec invariant:
    value >= 0
    
fun[class] increment(&mut self) -> Unit
spec:
    ensures self.value == old(self.value) + 1
:
    self.value += 1
"""
        try:
            ast = parse_program(source)
            assert len(ast.statements) >= 3
        except ParseError:
            pass


@pytest.mark.formal_verification
class TestVerificationErrors:
    """Test error handling in verification parsing."""
    
    def test_malformed_spec_block(self, parse_program):
        """Test error handling for malformed spec blocks."""
        source = """
spec PositiveInt = int where  # Missing predicate
"""
        with pytest.raises(ParseError):
            parse_program(source)
    
    def test_invalid_spec_syntax(self, parse_program):
        """Test error handling for invalid spec syntax."""
        source = """
fun bad_spec() -> int
spec:
    requires  # Missing condition
:
    return 42
"""
        with pytest.raises(ParseError):
            parse_program(source)
    
    def test_ghost_without_annotation(self, parse_program):
        """Test error handling for ghost variables without annotation."""
        source = """
u32 ghost_var = 42  # Should require #[ghost] annotation
"""
        # This might not be a parse error, but semantic error
        try:
            ast = parse_program(source)
            # Parser should structure it for semantic analysis
            assert len(ast.statements) >= 1
        except ParseError:
            pass  # Parser might catch this


@pytest.mark.formal_verification
@pytest.mark.parametrize("verification_source,expected_feature", [
    ("spec PositiveInt = int where value > 0", "spec_type"),
    ("fun test() -> int spec: requires true: pass", "function_spec"),
    ("while true spec invariant true: pass", "loop_invariant"),
    ("#[ghost] u32 x = 42", "ghost_variable"),
    ("#verification level = \"require\"", "verification_directive"),
])
def test_formal_verification_parameterized(parse_program, verification_source, expected_feature):
    """Parameterized test for formal verification features."""
    try:
        ast = parse_program(verification_source)
        # Should parse successfully and create verification structure
        assert len(ast.statements) >= 1
    except ParseError:
        # Should not fail on well-formed verification code
        pytest.fail(f"Formal verification feature {expected_feature} failed to parse")


if __name__ == "__main__":
    pytest.main([__file__])
