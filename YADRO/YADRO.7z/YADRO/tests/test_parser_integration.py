"""Integration tests for YADRO parser with lexer."""

import pytest
from parserr import YadroParser, ParseError, Program
from lexer import Lexer, TokenType


@pytest.mark.integration
class TestParserLexerIntegration:
    """Test integration between parser and lexer."""
    
    def test_simple_program_parsing(self):
        """Test parsing a complete simple program."""
        source = """
#target
os = "linux"
arch = "x86-64"

let x = 42
var y: string = "hello"

fun add(a: int, b: int) -> int:
    return a + b

if x > 0:
    cli.print("positive")
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 5  # target, let, var, fun, if
        
        # Check statement types
        from parserr import TargetDirective, VarDecl, FunctionDecl, IfStmt
        assert isinstance(ast.statements[0], TargetDirective)
        assert isinstance(ast.statements[1], VarDecl)
        assert isinstance(ast.statements[2], VarDecl)
        assert isinstance(ast.statements[3], FunctionDecl)
        assert isinstance(ast.statements[4], IfStmt)
    
    def test_empty_program_parsing(self):
        """Test parsing an empty program."""
        source = ""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 0
    
    def test_whitespace_only_program(self):
        """Test parsing program with only whitespace."""
        source = """
   
   
    """
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 0
    
    def test_comments_only_program(self):
        """Test parsing program with only comments."""
        source = """
// This is a comment
/* This is a block comment */
// Another comment
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        # Comments should be filtered out by lexer
    
    def test_token_consumption(self):
        """Test that parser consumes all tokens correctly."""
        source = """
let x = 42
let y = "hello"
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        initial_token_count = len(tokens)
        
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        # Parser should consume all relevant tokens
        assert isinstance(ast, Program)
        assert len(ast.statements) == 2
    
    def test_error_token_handling(self):
        """Test parser handling of error tokens from lexer."""
        source = """
let x = 42
let y = +  # This should cause an error
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        with pytest.raises(ParseError):
            parser.parse_program()


@pytest.mark.integration
class TestComplexProgramIntegration:
    """Test integration with complex programs."""
    
    def test_full_language_features(self):
        """Test program using all major language features."""
        source = """
#target
os = "linux"
arch = "x86-64"

#import
std.core.cli
std.collections.vector

let global_var: int = 42
const MAX_SIZE: int = 1000

temp[T] fun identity(value: T) -> T:
    return value

class Container[T]:
    items: vector[T]
    count: int
    
    fun[class] new() -> Container[T]:
        return Container[T]{items: vector[T]{}, count: 0}
    
    fun add(&mut self, item: T):
        self.items.push(item)
        self.count = self.count + 1

fun process_data(data: vector[int]) -> Option[int]:
    if data.len() == 0:
        return None
    
    let result = data[0] * 2
    return Some(result)

for item in data:
    let processed = process_data(vector[int]{item})
    switch processed:
        case Some(value):
            cli.print("Processed:", value)
        case None:
            cli.print("Processing failed")
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) >= 8  # target, import, let, const, temp, class, fun, for
        
        # Verify key structures
        from parserr import TargetDirective, ImportDirective, VarDecl, ConstDecl, FunctionDecl, ClassDecl, ForStmt
        statement_types = [type(stmt) for stmt in ast.statements]
        assert TargetDirective in statement_types
        assert ImportDirective in statement_types
        assert VarDecl in statement_types
        assert ConstDecl in statement_types
        assert FunctionDecl in statement_types
        assert ClassDecl in statement_types
        assert ForStmt in statement_types
    
    def test_nested_structures(self):
        """Test deeply nested structures."""
        source = """
fun complex_function(x: int) -> int:
    if x > 0:
        for i in range(10):
            if i % 2 == 0:
                while i < x:
                    switch i:
                        case 0:
                            return 0
                        case 1:
                            return 1
                        default:
                            return i
                    i = i + 1
            else:
                continue
    else:
        return -1
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], FunctionDecl)
        
        # Check nested structure
        func = ast.statements[0]
        assert len(func.body) == 1
        assert isinstance(func.body[0], IfStmt)
    
    def test_expressions_integration(self):
        """Test complex expression parsing."""
        source = """
let result = (1 + 2) * 3 - 4 / 5
let pipeline = value >>> func1 >>> func2 >>> func3
let complex = obj.method(arg1, arg2 + arg3).property
let generic_call = TypeName[int, string](param)
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 4
        
        # Each should be a variable declaration with complex expressions
        for stmt in ast.statements:
            assert isinstance(stmt, VarDecl)
            assert stmt.initializer is not None


@pytest.mark.integration
class TestErrorRecoveryIntegration:
    """Test error recovery in integration scenarios."""
    
    def test_partial_parsing_with_errors(self):
        """Test that parser can partially parse programs with errors."""
        source = """
let x = 42
let y = +  # Error here
let z = 73
const VALID = 100
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        try:
            ast = parser.parse_program()
            # Should parse some statements despite error
            assert isinstance(ast, Program)
        except ParseError:
            # Expected to fail, but test recovery mechanism
            pass
    
    def test_multiple_error_recovery(self):
        """Test recovery from multiple errors."""
        source = """
let valid1 = 42
let error1 = +  # First error
let valid2 = "hello"
const error2 =  # Second error
let valid3 = 73
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        try:
            ast = parser.parse_program()
            # Should collect errors and continue
            assert isinstance(ast, Program)
        except ParseError:
            # Expected to fail
            pass
    
    def test_synchronization_after_error(self):
        """Test parser synchronization after errors."""
        source = """
#target os = "linux"
let x = 42
func bad_func(  # Incomplete function
let y = 73  # Should be able to continue after error
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        try:
            ast = parser.parse_program()
            # Should synchronize and parse some statements
            assert isinstance(ast, Program)
        except ParseError:
            pass


@pytest.mark.integration
class TestPerformanceIntegration:
    """Test performance aspects of parser integration."""
    
    def test_large_program_parsing(self):
        """Test parsing of large programs."""
        # Create a large program
        statements = []
        for i in range(1000):
            statements.append(f"let var{i} = {i};")
        
        source = "\n".join(statements)
        
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        try:
            ast = parser.parse_program()
            assert isinstance(ast, Program)
            assert len(ast.statements) == 1000
        except Exception as e:
            pytest.fail(f"Failed to parse large program: {e}")
    
    def test_deep_nesting_performance(self):
        """Test performance with deeply nested structures."""
        # Create deeply nested if statements
        source = "let x = 42\n"
        for i in range(100):
            source += "    " * i + f"if x > {i}:\n"
        
        source += "    " * 100 + "cli.print('deeply nested')\n"
        
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        
        try:
            ast = parser.parse_program()
            assert isinstance(ast, Program)
        except RecursionError:
            # Might hit recursion limits, which is acceptable
            pass
        except Exception as e:
            pytest.fail(f"Failed to parse deeply nested program: {e}")


@pytest.mark.integration
class TestTokenStreamIntegration:
    """Test specific token stream handling."""
    
    def test_indentation_handling(self):
        """Test proper handling of indentation tokens."""
        source = """
if x > 0:
    cli.print("nested")
    if y > 0:
        cli.print("deeply nested")
    cli.print("back to level 1")
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], IfStmt)
    
    def test_newline_handling(self):
        """Test proper handling of newline tokens."""
        source = "let x = 42\nlet y = 73\nlet z = 100\n"
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 3
    
    def test_semicolon_handling(self):
        """Test proper handling of semicolon tokens."""
        source = "let x = 42; let y = 73; let z = 100;"
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 3
    
    def test_mixed_statement_separators(self):
        """Test handling of mixed newlines and semicolons."""
        source = """
let x = 42;
let y = 73
let z = 100;
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 3


@pytest.mark.integration
@pytest.mark.parametrize("source,expected_statements", [
    ("let x = 42;", 1),
    ("let x = 42\nlet y = 73", 2),
    ("let x = 42; let y = 73; let z = 100;", 3),
    ("", 0),
    ("// comment only", 0),
])
def test_integration_parameterized(source, expected_statements):
    """Parameterized integration tests."""
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = YadroParser(tokens)
    ast = parser.parse_program()
    
    assert isinstance(ast, Program)
    assert len(ast.statements) == expected_statements


@pytest.mark.integration
class TestRealWorldScenarios:
    """Test real-world parsing scenarios."""
    
    def test_configuration_file_parsing(self):
        """Test parsing configuration-style code."""
        source = """
#target
os = "linux"
arch = "x86-64"
optimization = "speed"

#import
std.core.cli
std.os.fs
std.collections.dict

let config: dict[string, string] = {
    "host": "localhost",
    "port": "8080",
    "debug": "true"
}

const MAX_CONNECTIONS: int = 1000

fun load_config(path: string) -> dict[string, string]:
    return config
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) >= 6
    
    def test_algorithmic_code_parsing(self):
        """Test parsing algorithmic code."""
        source = """
fun fibonacci(n: int) -> int:
    if n <= 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

fun factorial(n: int) -> int:
    let result = 1
    for i in range(2, n + 1):
        result = result * i
    return result

fun is_prime(n: int) -> bool:
    if n <= 1:
        return false
    for i in range(2, n / 2 + 1):
        if n % i == 0:
            return false
    return true
"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = YadroParser(tokens)
        ast = parser.parse_program()
        
        assert isinstance(ast, Program)
        assert len(ast.statements) == 3
        for stmt in ast.statements:
            assert isinstance(stmt, FunctionDecl)


if __name__ == "__main__":
    pytest.main([__file__])
