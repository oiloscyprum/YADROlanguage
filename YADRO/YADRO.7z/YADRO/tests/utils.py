"""Utility functions for parser testing."""

import json
from typing import Any, Dict, List
from parserr import ASTNode


def ast_to_dict(node: ASTNode) -> Dict[str, Any]:
    """Convert AST node to dictionary for comparison."""
    if node is None:
        return None
    
    result = {
        'type': node.__class__.__name__,
        'line': getattr(node, 'line', None),
        'column': getattr(node, 'column', None),
    }
    
    # Add node-specific attributes
    for attr_name in dir(node):
        if not attr_name.startswith('_') and attr_name not in ['line', 'column']:
            attr_value = getattr(node, attr_name)
            if not callable(attr_value):
                result[attr_name] = _serialize_value(attr_value)
    
    return result


def _serialize_value(value: Any) -> Any:
    """Serialize a value for JSON comparison."""
    if isinstance(value, ASTNode):
        return ast_to_dict(value)
    elif isinstance(value, list):
        return [_serialize_value(item) for item in value]
    elif isinstance(value, tuple):
        return tuple(_serialize_value(item) for item in value)
    elif hasattr(value, '__dict__'):
        return {k: _serialize_value(v) for k, v in value.__dict__.items() 
                if not k.startswith('_') and not callable(v)}
    else:
        return value


def assert_ast_equal(actual: ASTNode, expected: Dict[str, Any]):
    """Assert that AST node matches expected structure."""
    actual_dict = ast_to_dict(actual)
    assert actual_dict == expected, f"AST mismatch:\nExpected: {json.dumps(expected, indent=2)}\nActual: {json.dumps(actual_dict, indent=2)}"


def create_token_stream(token_types: List[str]) -> List[Dict]:
    """Create a mock token stream for testing."""
    from lexer import Token
    
    tokens = []
    for i, token_type in enumerate(token_types):
        # Create a simple token representation
        tokens.append({
            'type': token_type,
            'value': token_type,
            'line': 1,
            'column': i + 1
        })
    return tokens


def load_fixture(fixture_path: str) -> str:
    """Load a test fixture file."""
    from pathlib import Path
    
    fixture_file = Path(__file__).parent / 'fixtures' / fixture_path
    with open(fixture_file, 'r', encoding='utf-8') as f:
        return f.read()


def save_fixture(fixture_path: str, content: str):
    """Save content to a test fixture file."""
    from pathlib import Path
    
    fixture_file = Path(__file__).parent / 'fixtures' / fixture_path
    fixture_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(fixture_file, 'w', encoding='utf-8') as f:
        f.write(content)


class ParseResult:
    """Container for parse test results."""
    
    def __init__(self, ast_node=None, errors=None, success=True):
        self.ast_node = ast_node
        self.errors = errors or []
        self.success = success
    
    def __repr__(self):
        return f"ParseResult(success={self.success}, errors={len(self.errors)})"


def safe_parse(parse_func, source_code):
    """Safely parse source code and capture any errors."""
    from parserr import ParseError
    
    try:
        ast_node = parse_func(source_code)
        return ParseResult(ast_node=ast_node, success=True)
    except ParseError as e:
        return ParseResult(errors=[e], success=False)
    except Exception as e:
        return ParseResult(errors=[e], success=False)


def generate_test_cases(category: str, test_data: Dict[str, List]) -> List[tuple]:
    """Generate parameterized test cases from test data."""
    test_cases = []
    
    for subcategory, cases in test_data.items():
        for case in cases:
            if isinstance(case, tuple):
                source, description = case
            else:
                source, description = case, case
            
            test_cases.append((source, f"{category}_{subcategory}_{description}"))
    
    return test_cases


def validate_ast_structure(node: ASTNode, required_fields: List[str]) -> bool:
    """Validate that AST node has required fields."""
    for field in required_fields:
        if not hasattr(node, field):
            return False
    return True


def count_ast_nodes(node: ASTNode, node_type: str = None) -> int:
    """Count AST nodes of specific type or all nodes."""
    if node is None:
        return 0
    
    count = 1 if node_type is None or node.__class__.__name__ == node_type else 0
    
    # Recursively count child nodes
    for attr_name in dir(node):
        if not attr_name.startswith('_'):
            attr_value = getattr(node, attr_name)
            if not callable(attr_value):
                if isinstance(attr_value, ASTNode):
                    count += count_ast_nodes(attr_value, node_type)
                elif isinstance(attr_value, list):
                    for item in attr_value:
                        if isinstance(item, ASTNode):
                            count += count_ast_nodes(item, node_type)
                elif isinstance(attr_value, tuple):
                    for item in attr_value:
                        if isinstance(item, ASTNode):
                            count += count_ast_nodes(item, node_type)
    
    return count


def extract_node_types(node: ASTNode) -> List[str]:
    """Extract all node types from AST."""
    if node is None:
        return []
    
    types = [node.__class__.__name__]
    
    # Recursively extract child node types
    for attr_name in dir(node):
        if not attr_name.startswith('_'):
            attr_value = getattr(node, attr_name)
            if not callable(attr_value):
                if isinstance(attr_value, ASTNode):
                    types.extend(extract_node_types(attr_value))
                elif isinstance(attr_value, list):
                    for item in attr_value:
                        if isinstance(item, ASTNode):
                            types.extend(extract_node_types(item))
                elif isinstance(attr_value, tuple):
                    for item in attr_value:
                        if isinstance(item, ASTNode):
                            types.extend(extract_node_types(item))
    
    return types
