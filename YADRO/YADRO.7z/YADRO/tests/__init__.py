"""Test suite for YADRO parser module."""
