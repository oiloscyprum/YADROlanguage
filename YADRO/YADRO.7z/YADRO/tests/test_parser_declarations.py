"""Tests for variable and constant declaration parsing in YADRO parser."""

import pytest
from parserr import (
    VarDecl, ConstDecl, BasicType, ReferenceType, ArrayType, DictType,
    SetType, VectorType, GenericType, GcType, LiteralExpr, IdentifierExpr,
    ParseError
)


@pytest.mark.declarations
class TestVariableDeclarations:
    """Test parsing of variable declarations."""
    
    def test_simple_let_declaration(self, parse_statement):
        """Test parsing of simple let declaration."""
        source = 'let x = 42;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'x'
        assert ast.is_mutable is False
        assert ast.type_annotation is None
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == 42
    
    def test_simple_var_declaration(self, parse_statement):
        """Test parsing of simple var declaration."""
        source = 'var y = 10;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'y'
        assert ast.is_mutable is True
        assert ast.type_annotation is None
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == 10
    
    def test_let_with_type_annotation(self, parse_statement):
        """Test parsing of let declaration with type annotation."""
        source = 'let name: string = "test";'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'name'
        assert ast.is_mutable is False
        assert isinstance(ast.type_annotation, BasicType)
        assert ast.type_annotation.name == 'string'
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == "test"
    
    def test_var_with_type_annotation(self, parse_statement):
        """Test parsing of var declaration with type annotation."""
        source = 'var count: int = 0;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'count'
        assert ast.is_mutable is True
        assert isinstance(ast.type_annotation, BasicType)
        assert ast.type_annotation.name == 'int'
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == 0
    
    def test_let_without_initializer(self, parse_statement):
        """Test parsing of let declaration without initializer."""
        source = 'let x;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'x'
        assert ast.is_mutable is False
        assert ast.type_annotation is None
        assert ast.initializer is None
    
    def test_var_without_initializer(self, parse_statement):
        """Test parsing of var declaration without initializer."""
        source = 'var y;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'y'
        assert ast.is_mutable is True
        assert ast.type_annotation is None
        assert ast.initializer is None


@pytest.mark.declarations
class TestConstantDeclarations:
    """Test parsing of constant declarations."""
    
    def test_simple_const_declaration(self, parse_statement):
        """Test parsing of simple const declaration."""
        source = 'const PI = 3.14159;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ConstDecl)
        assert ast.name == 'PI'
        assert ast.type_annotation is None
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == 3.14159
    
    def test_const_with_type_annotation(self, parse_statement):
        """Test parsing of const declaration with type annotation."""
        source = 'const MAX_SIZE: int = 1000;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ConstDecl)
        assert ast.name == 'MAX_SIZE'
        assert isinstance(ast.type_annotation, BasicType)
        assert ast.type_annotation.name == 'int'
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == 1000
    
    def test_const_string_declaration(self, parse_statement):
        """Test parsing of const string declaration."""
        source = 'const APP_NAME: string = "MyApp";'
        ast = parse_statement(source)
        
        assert isinstance(ast, ConstDecl)
        assert ast.name == 'APP_NAME'
        assert isinstance(ast.type_annotation, BasicType)
        assert ast.type_annotation.name == 'string'
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value == "MyApp"
    
    def test_const_bool_declaration(self, parse_statement):
        """Test parsing of const boolean declaration."""
        source = 'const DEBUG: bool = true;'
        ast = parse_statement(source)
        
        assert isinstance(ast, ConstDecl)
        assert ast.name == 'DEBUG'
        assert isinstance(ast.type_annotation, BasicType)
        assert ast.type_annotation.name == 'bool'
        assert isinstance(ast.initializer, LiteralExpr)
        assert ast.initializer.value is True


@pytest.mark.declarations
class TestReferenceTypeDeclarations:
    """Test parsing of declarations with reference types."""
    
    def test_immutable_reference_declaration(self, parse_statement):
        """Test parsing of immutable reference declaration."""
        source = 'let ref: &int = &x;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'ref'
        assert isinstance(ast.type_annotation, ReferenceType)
        assert ast.type_annotation.is_mutable is False
        assert isinstance(ast.type_annotation.referenced_type, BasicType)
        assert ast.type_annotation.referenced_type.name == 'int'
    
    def test_mutable_reference_declaration(self, parse_statement):
        """Test parsing of mutable reference declaration."""
        source = 'var mut_ref: &mut string = &mut s;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'mut_ref'
        assert ast.is_mutable is True
        assert isinstance(ast.type_annotation, ReferenceType)
        assert ast.type_annotation.is_mutable is True
        assert isinstance(ast.type_annotation.referenced_type, BasicType)
        assert ast.type_annotation.referenced_type.name == 'string'


@pytest.mark.declarations
class TestCollectionTypeDeclarations:
    """Test parsing of declarations with collection types."""
    
    def test_array_declaration(self, parse_statement):
        """Test parsing of array declaration."""
        source = 'let arr: array[int] = [1, 2, 3];'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'arr'
        assert isinstance(ast.type_annotation, ArrayType)
        assert isinstance(ast.type_annotation.element_type, BasicType)
        assert ast.type_annotation.element_type.name == 'int'
    
    def test_sized_array_declaration(self, parse_statement):
        """Test parsing of sized array declaration."""
        source = 'let fixed_arr: array[int, 10];'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'fixed_arr'
        assert isinstance(ast.type_annotation, ArrayType)
        assert isinstance(ast.type_annotation.element_type, BasicType)
        assert ast.type_annotation.element_type.name == 'int'
        # Size should be parsed as expression
        assert ast.type_annotation.size is not None
    
    def test_dict_declaration(self, parse_statement):
        """Test parsing of dictionary declaration."""
        source = 'let map: dict[string, int] = {"a": 1, "b": 2};'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'map'
        assert isinstance(ast.type_annotation, DictType)
        assert isinstance(ast.type_annotation.key_type, BasicType)
        assert ast.type_annotation.key_type.name == 'string'
        assert isinstance(ast.type_annotation.value_type, BasicType)
        assert ast.type_annotation.value_type.name == 'int'
    
    def test_set_declaration(self, parse_statement):
        """Test parsing of set declaration."""
        source = 'let unique: set[int] = {1, 2, 3};'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'unique'
        assert isinstance(ast.type_annotation, SetType)
        assert isinstance(ast.type_annotation.element_type, BasicType)
        assert ast.type_annotation.element_type.name == 'int'
    
    def test_vector_declaration(self, parse_statement):
        """Test parsing of vector declaration."""
        source = 'let vec: vector[float, 4] = [1.0, 2.0, 3.0, 4.0];'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'vec'
        assert isinstance(ast.type_annotation, VectorType)
        assert isinstance(ast.type_annotation.element_type, BasicType)
        assert ast.type_annotation.element_type.name == 'float'


@pytest.mark.declarations
class TestGenericTypeDeclarations:
    """Test parsing of declarations with generic types."""
    
    def test_simple_generic_declaration(self, parse_statement):
        """Test parsing of simple generic type declaration."""
        source = 'let data: Option[int] = Some(42);'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'data'
        assert isinstance(ast.type_annotation, GenericType)
        assert ast.type_annotation.name == 'Option'
        assert len(ast.type_annotation.type_args) == 1
        assert isinstance(ast.type_annotation.type_args[0], BasicType)
        assert ast.type_annotation.type_args[0].name == 'int'
    
    def test_multiple_generic_args_declaration(self, parse_statement):
        """Test parsing of generic type with multiple arguments."""
        source = 'let result: Result[string, Error] = Ok("success");'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'result'
        assert isinstance(ast.type_annotation, GenericType)
        assert ast.type_annotation.name == 'Result'
        assert len(ast.type_annotation.type_args) == 2
        assert isinstance(ast.type_annotation.type_args[0], BasicType)
        assert ast.type_annotation.type_args[0].name == 'string'
        assert isinstance(ast.type_annotation.type_args[1], BasicType)
        assert ast.type_annotation.type_args[1].name == 'Error'


@pytest.mark.declarations
class TestArenaAllocationDeclarations:
    """Test parsing of declarations with arena allocation types."""
    
    def test_gc_declaration(self, parse_statement):
        """Test parsing of gc type declaration."""
        source = 'let managed: gc[string] = gc<string>("hello");'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'managed'
        assert isinstance(ast.type_annotation, GcType)
        assert ast.type_annotation.is_weak is False
        assert isinstance(ast.type_annotation.inner_type, BasicType)
        assert ast.type_annotation.inner_type.name == 'string'
    
    def test_gc_weak_declaration(self, parse_statement):
        """Test parsing of gc_weak type declaration."""
        source = 'let weak_ref: gc_weak[int] = gc_weak<int>(&value);'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'weak_ref'
        assert isinstance(ast.type_annotation, GcType)
        assert ast.type_annotation.is_weak is True
        assert isinstance(ast.type_annotation.inner_type, BasicType)
        assert ast.type_annotation.inner_type.name == 'int'


@pytest.mark.declarations
class TestComplexDeclarations:
    """Test parsing of complex declaration scenarios."""
    
    def test_nested_generic_types(self, parse_statement):
        """Test parsing of nested generic types."""
        source = 'let nested: dict[string, vector[int, 3]] = {"points": [1, 2, 3]};'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'nested'
        assert isinstance(ast.type_annotation, DictType)
        assert isinstance(ast.type_annotation.key_type, BasicType)
        assert ast.type_annotation.key_type.name == 'string'
        assert isinstance(ast.type_annotation.value_type, VectorType)
    
    def test_reference_to_generic_type(self, parse_statement):
        """Test parsing of reference to generic type."""
        source = 'let ref_to_option: &Option[string] = &some_option;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'ref_to_option'
        assert isinstance(ast.type_annotation, ReferenceType)
        assert ast.type_annotation.is_mutable is False
        assert isinstance(ast.type_annotation.referenced_type, GenericType)
        assert ast.type_annotation.referenced_type.name == 'Option'
    
    def test_mutable_reference_to_collection(self, parse_statement):
        """Test parsing of mutable reference to collection."""
        source = 'var mut_ref: &mut dict[int, string] = &mut my_dict;'
        ast = parse_statement(source)
        
        assert isinstance(ast, VarDecl)
        assert ast.name == 'mut_ref'
        assert ast.is_mutable is True
        assert isinstance(ast.type_annotation, ReferenceType)
        assert ast.type_annotation.is_mutable is True
        assert isinstance(ast.type_annotation.referenced_type, DictType)


@pytest.mark.declarations
class TestDeclarationErrors:
    """Test error handling in declaration parsing."""
    
    def test_const_without_initializer(self, parse_statement):
        """Test error handling for const without initializer."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement('const MISSING_INIT;')
    
    def test_invalid_type_annotation(self, parse_statement):
        """Test error handling for invalid type annotation."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement('let x: invalid_type = 42;')
    
    def test_mismatched_brackets(self, parse_statement):
        """Test error handling for mismatched brackets in types."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement('let x: array[int = 42;')
    
    def test_invalid_generic_syntax(self, parse_statement):
        """Test error handling for invalid generic syntax."""
        from parserr import ParseError
        
        with pytest.raises(ParseError):
            parse_statement('let x: Option = Some(42);')


@pytest.mark.declarations
@pytest.mark.parametrize("source,expected_name,expected_mutable,expected_has_type,expected_has_init", [
    ('let x = 42;', 'x', False, False, True),
    ('var y = 10;', 'y', True, False, True),
    ('let name: string = "test";', 'name', False, True, True),
    ('var count: int = 0;', 'count', True, True, True),
    ('let z;', 'z', False, False, False),
    ('const PI = 3.14;', 'PI', False, False, True),
    ('const MAX: int = 100;', 'MAX', False, True, True),
])
def test_declaration_parameterized(parse_statement, source, expected_name, expected_mutable, expected_has_type, expected_has_init):
    """Parameterized test for declaration variations."""
    ast = parse_statement(source)
    
    assert isinstance(ast, (VarDecl, ConstDecl))
    assert ast.name == expected_name
    
    if isinstance(ast, VarDecl):
        assert ast.is_mutable == expected_mutable
    
    assert (ast.type_annotation is not None) == expected_has_type
    assert (ast.initializer is not None) == expected_has_init


@pytest.mark.declarations
class TestDeclarationIntegration:
    """Test integration of declarations in programs."""
    
    def test_multiple_declarations_in_program(self, parse_program):
        """Test parsing program with multiple declarations."""
        source = """
let x = 42;
var y: int = 10;
const PI: float = 3.14159;
let name: string = "test";
var data: dict[string, int] = {"a": 1, "b": 2};
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 5
        
        # Check each declaration
        assert isinstance(ast.statements[0], VarDecl)
        assert ast.statements[0].name == 'x'
        assert ast.statements[0].is_mutable is False
        
        assert isinstance(ast.statements[1], VarDecl)
        assert ast.statements[1].name == 'y'
        assert ast.statements[1].is_mutable is True
        
        assert isinstance(ast.statements[2], ConstDecl)
        assert ast.statements[2].name == 'PI'
        
        assert isinstance(ast.statements[3], VarDecl)
        assert ast.statements[3].name == 'name'
        
        assert isinstance(ast.statements[4], VarDecl)
        assert ast.statements[4].name == 'data'
        assert isinstance(ast.statements[4].type_annotation, DictType)


if __name__ == "__main__":
    pytest.main([__file__])
