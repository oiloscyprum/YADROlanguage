"""Tests for error handling and recovery in YADRO parser."""

import pytest
from parserr import ParseError, YadroParser
from lexer import Lexer, TokenType


@pytest.mark.errors
class TestParseErrorHandling:
    """Test basic ParseError handling."""
    
    def test_parse_error_with_token(self):
        """Test ParseError creation with token information."""
        from lexer import Token
        
        token = Token(TokenType.IDENTIFIER, "x", 1, 5, "x")
        error = ParseError("Test error", token)
        
        assert "Test error" in str(error)
        assert "line 1" in str(error)
        assert "column 5" in str(error)
    
    def test_parse_error_without_token(self):
        """Test ParseError creation without token information."""
        error = ParseError("Test error")
        
        assert "Test error" in str(error)
        assert "Parse error" in str(error)


@pytest.mark.errors
class TestSyntaxErrors:
    """Test detection of syntax errors."""
    
    def test_unexpected_token(self, parse_expression):
        """Test handling of unexpected tokens."""
        with pytest.raises(ParseError) as exc_info:
            parse_expression("1 + + 2")
        
        assert "Parse error" in str(exc_info.value)
    
    def test_mismatched_parentheses(self, parse_expression):
        """Test handling of mismatched parentheses."""
        with pytest.raises(ParseError):
            parse_expression("(1 + 2")
    
    def test_mismatched_brackets(self, parse_expression):
        """Test handling of mismatched brackets."""
        with pytest.raises(ParseError):
            parse_expression("array[1, 2")
    
    def test_mismatched_braces(self, parse_statement):
        """Test handling of mismatched braces."""
        with pytest.raises(ParseError):
            parse_statement("if x > 0:\n    cli.print(x")
    
    def test_invalid_operator_combination(self, parse_expression):
        """Test handling of invalid operator combinations."""
        with pytest.raises(ParseError):
            parse_expression("1 + / 2")
        
        with pytest.raises(ParseError):
            parse_expression("1 % % 2")
    
    def test_incomplete_expression(self, parse_expression):
        """Test handling of incomplete expressions."""
        with pytest.raises(ParseError):
            parse_expression("1 +")
        
        with pytest.raises(ParseError):
            parse_expression("/ 2")
        
        with pytest.raises(ParseError):
            parse_expression("func(")


@pytest.mark.errors
class TestDeclarationErrors:
    """Test error handling in declarations."""
    
    def test_const_without_initializer(self, parse_statement):
        """Test error for const declaration without initializer."""
        with pytest.raises(ParseError):
            parse_statement("const MISSING_INIT;")
    
    def test_invalid_identifier(self, parse_statement):
        """Test error for invalid identifier names."""
        with pytest.raises(ParseError):
            parse_statement("let 123invalid = 42;")
    
    def test_missing_type_annotation(self, parse_statement):
        """Test error for missing type annotation where required."""
        with pytest.raises(ParseError):
            parse_statement("let x: ;")
    
    def test_invalid_type_syntax(self, parse_statement):
        """Test error for invalid type syntax."""
        with pytest.raises(ParseError):
            parse_statement("let x: invalid_type[ = 42;")
        
        with pytest.raises(ParseError):
            parse_statement("let x: dict[string = 42;")


@pytest.mark.errors
class TestControlFlowErrors:
    """Test error handling in control flow statements."""
    
    def test_if_without_condition(self, parse_statement):
        """Test error for if statement without condition."""
        with pytest.raises(ParseError):
            parse_statement('if:\n    cli.print("no condition")')
    
    def test_for_without_in(self, parse_statement):
        """Test error for for loop without in clause."""
        with pytest.raises(ParseError):
            parse_statement("for item collection:\n    cli.print(item)")
    
    def test_while_without_condition(self, parse_statement):
        """Test error for while loop without condition."""
        with pytest.raises(ParseError):
            parse_statement('while:\n    cli.print("no condition")')
    
    def test_repeat_without_until(self, parse_statement):
        """Test error for repeat loop without until."""
        with pytest.raises(ParseError):
            parse_statement('repeat:\n    cli.print("no until")')
    
    def test_switch_without_expression(self, parse_statement):
        """Test error for switch without expression."""
        with pytest.raises(ParseError):
            parse_statement('switch:\n    case 1: cli.print("no expression")')


@pytest.mark.errors
class TestDirectiveErrors:
    """Test error handling in directives."""
    
    def test_malformed_target_directive(self, parse_statement):
        """Test error for malformed #target directive."""
        from lexer import LexerError
        with pytest.raises((ParseError, LexerError)):
            parse_statement('#target os = "linux')
        
        with pytest.raises(ParseError):
            parse_statement('#target "linux"')
    
    def test_malformed_import_directive(self, parse_statement):
        """Test error for malformed #import directive."""
        with pytest.raises(ParseError):
            parse_statement('#import')
        
        with pytest.raises(ParseError):
            parse_statement('#import std.core.')
    
    def test_malformed_requires_directive(self, parse_statement):
        """Test error for malformed #requires directive."""
        with pytest.raises(ParseError):
            parse_statement('#requires kernel32.dll')
        
        with pytest.raises(ParseError):
            parse_statement('#requires')


@pytest.mark.errors
class TestErrorRecovery:
    """Test error recovery and synchronization."""
    
    def test_parser_synchronization_after_error(self, parse_program):
        """Test that parser can synchronize after errors."""
        source = """
let x = 42
let y = +  # Error here
let z = 73
const VALID = 100
"""
        try:
            ast = parse_program(source)
            # Should parse some statements despite the error
            assert len(ast.statements) >= 1
        except ParseError:
            # Expected to raise ParseError, but test recovery mechanism
            pass
    
    def test_multiple_errors_in_program(self, parse_program):
        """Test handling of multiple errors in a program."""
        source = """
let x = 42
let y = +  # Error 1
const BAD =  # Error 2
let z = 73
"""
        try:
            ast = parse_program(source)
            # Should collect multiple errors
            assert hasattr(ast, 'statements')
        except ParseError:
            # Expected to raise ParseError
            pass
    
    def test_error_recovery_in_expressions(self, parse_expression):
        """Test error recovery in expression parsing."""
        # Test that parser can provide meaningful error messages
        with pytest.raises(ParseError) as exc_info:
            parse_expression("1 + / 2")
        
        error_message = str(exc_info.value)
        assert "Parse error" in error_message


@pytest.mark.errors
class TestEdgeCaseErrors:
    """Test error handling for edge cases."""
    
    def test_empty_input(self, parse_program):
        """Test handling of empty input."""
        ast = parse_program("")
        from parserr import Program
        assert isinstance(ast, Program)  # Should return empty Program
    
    def test_only_whitespace(self, parse_program):
        """Test handling of input with only whitespace."""
        ast = parse_program("   \n  \t  \n  ")
        # Should handle gracefully
    
    def test_only_comments(self, parse_program):
        """Test handling of input with only comments."""
        source = """
// This is a comment
/* This is a block comment */
// Another comment
"""
        ast = parse_program(source)
        # Should handle gracefully
    
    def test_unclosed_comment(self, parse_program):
        """Test handling of unclosed block comment."""
        source = """
let x = 42
/* This comment is not closed
let y = 73
"""
        # This might be handled at lexer level, but parser should handle gracefully
        from lexer import LexerError
        try:
            ast = parse_program(source)
        except (ParseError, LexerError):
            pass  # Expected
    
    def test_unicode_characters(self, parse_program):
        """Test handling of unicode characters."""
        source = 'let emoji = "😀";'
        try:
            ast = parse_program(source)
            # Should handle unicode properly
        except ParseError:
            pass  # Might fail depending on lexer implementation


@pytest.mark.errors
class TestComplexErrorScenarios:
    """Test complex error scenarios."""
    
    def test_nested_structure_errors(self, parse_program):
        """Test errors in deeply nested structures."""
        source = """
if x > 0:
    for i in range(10):
        if i > 5:
            while condition:
                switch value:
                    case 1:
                        let bad = +  # Error in deeply nested context
                        cli.print("nested")
"""
        try:
            ast = parse_program(source)
        except ParseError:
            pass  # Expected
    
    def test_mixed_language_constructs_errors(self, parse_program):
        """Test errors across different language constructs."""
        source = """
#target os = "linux"  # Valid directive
let x = 42  # Valid declaration
func bad_func(  # Incomplete function
const MISSING =  # Incomplete const
if x > 0:  # Valid if
    let y = +  # Error in if block
"""
        try:
            ast = parse_program(source)
        except ParseError:
            pass  # Expected


@pytest.mark.errors
class TestErrorMessageQuality:
    """Test quality of error messages."""
    
    def test_error_message_includes_location(self, parse_expression):
        """Test that error messages include location information."""
        with pytest.raises(ParseError) as exc_info:
            parse_expression("1 + + 2")
        
        error_message = str(exc_info.value)
        # Should include line and column information
        assert "line" in error_message.lower() or "column" in error_message.lower()
    
    def test_error_message_descriptive(self, parse_expression):
        """Test that error messages are descriptive."""
        with pytest.raises(ParseError) as exc_info:
            parse_expression("(1 + 2")
        
        error_message = str(exc_info.value)
        # Should be somewhat descriptive
        assert len(error_message) > 10
    
    def test_error_message_for_expected_token(self, parse_statement):
        """Test error message when expecting specific token."""
        with pytest.raises(ParseError) as exc_info:
            parse_statement("const MISSING_INIT;")
        
        error_message = str(exc_info.value)
        # Should mention what was expected
        assert any(keyword in error_message.lower() for keyword in ["expected", "missing", "required"])


@pytest.mark.errors
@pytest.mark.parametrize("invalid_source,error_pattern", [
        ("1 + + 2", r"Parse error"),
        ("(1 + 2", r"Parse error"),
        ("const MISSING;", r"Parse error"),
        ("if:", r"Parse error"),
        ("for item collection:", r"Parse error"),
        ("#target os = 123", r"Expected string, identifier, boolean or array value"),
        ("let x: invalid_type[ = 42;", r"Parse error"),
    ])
def test_parameterized_errors(parse_program, invalid_source, error_pattern):
    """Parameterized test for various error conditions."""
    import re
    from lexer import LexerError
    
    with pytest.raises((ParseError, LexerError)) as exc_info:
        parse_program(invalid_source)
    
    error_message = str(exc_info.value)
    assert re.search(error_pattern, error_message, re.IGNORECASE) is not None


@pytest.mark.errors
class TestParserRobustness:
    """Test parser robustness under stress."""
    
    def test_very_long_input(self, parse_program):
        """Test handling of very long input."""
        # Create a long input with many statements
        statements = ["let x{} = {};".format(i, i) for i in range(1000)]
        source = "\n".join(statements)
        
        try:
            ast = parse_program(source)
            # Should handle large input without crashing
            assert len(ast.statements) == 1000
        except ParseError:
            pass  # Might fail due to memory or other constraints
    
    def test_deeply_nested_expressions(self, parse_expression):
        """Test handling of deeply nested expressions."""
        # Create a deeply nested expression
        nested = "1"
        for _ in range(50):  # Reduced from 100 to avoid RecursionError in test env
            nested = f"({nested} + 1)"
        
        try:
            ast = parse_expression(nested)
            # Should handle deep nesting
        except (ParseError, RecursionError):
            pass  # Might hit recursion limits
    
    def test_many_errors_in_single_file(self, parse_program):
        """Test handling of many errors in a single file."""
        # Create input with many intentional errors
        error_statements = [
            "let x = +",
            "const BAD =",
            "if:",
            "for item:",
            "1 + * 2",
            "func(",
            "array[",
        ] * 10  # Repeat 10 times
        
        source = "\n".join(error_statements)
        
        try:
            ast = parse_program(source)
        except ParseError:
            pass  # Expected to fail, but should not crash


if __name__ == "__main__":
    pytest.main([__file__])
