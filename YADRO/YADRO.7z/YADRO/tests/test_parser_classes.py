"""Tests for class and trait declaration parsing in YADRO parser."""

import pytest
from parserr import (
    ClassDecl, TraitDecl, ImplDecl, FunctionDecl, VarDecl, Param, BasicType,
    GenericType, IdentifierExpr, ParseError
)


@pytest.mark.classes
class TestBasicClassDeclarations:
    """Test parsing of basic class declarations."""
    
    def test_simple_class(self, parse_statement):
        """Test parsing of simple class."""
        source = """class Person:
    name: string
    age: int"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Person"
        assert ast.base_class is None
        assert len(ast.type_params) == 0
        assert len(ast.fields) == 2
        assert len(ast.methods) == 0
        assert len(ast.attributes) == 0
        
        # Check fields
        assert ast.fields[0].name == "name"
        assert isinstance(ast.fields[0].type_annotation, BasicType)
        assert ast.fields[0].type_annotation.name == "string"
        
        assert ast.fields[1].name == "age"
        assert isinstance(ast.fields[1].type_annotation, BasicType)
        assert ast.fields[1].type_annotation.name == "int"
    
    def test_class_with_inheritance(self, parse_statement):
        """Test parsing of class with inheritance."""
        source = """class Employee(Person):
    salary: float
    position: string"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Employee"
        assert ast.base_class == "Person"
        assert len(ast.fields) == 2
    
    def test_class_with_methods(self, parse_statement):
        """Test parsing of class with methods."""
        source = """class Person:
    name: string
    
    fun[class] new(name: string) -> Person:
        return Person{name: name}
    
    fun get_name(&self) -> string:
        return self.name"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Person"
        assert len(ast.fields) == 1
        assert len(ast.methods) == 2
        
        # Check methods
        assert ast.methods[0].name == "new"
        assert ast.methods[0].is_method is True
        assert ast.methods[0].is_static is True
        
        assert ast.methods[1].name == "get_name"
        assert ast.methods[1].is_method is True
        assert ast.methods[1].is_static is False
    
    def test_empty_class(self, parse_statement):
        """Test parsing of empty class."""
        source = """class EmptyClass:
"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "EmptyClass"
        assert len(ast.fields) == 0
        assert len(ast.methods) == 0


@pytest.mark.classes
class TestGenericClassDeclarations:
    """Test parsing of generic class declarations."""
    
    def test_simple_generic_class(self, parse_statement):
        """Test parsing of simple generic class."""
        source = """temp[T] class Container:
    value: T"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Container"
        assert len(ast.type_params) == 1
        assert "T" in ast.type_params
        assert len(ast.fields) == 1
        assert ast.fields[0].type_annotation.name == "T"
    
    def test_multiple_type_parameters(self, parse_statement):
        """Test parsing of class with multiple type parameters."""
        source = """temp[K, V] class Dictionary:
    data: dict[K, V]"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Dictionary"
        assert len(ast.type_params) == 2
        assert "K" in ast.type_params
        assert "V" in ast.type_params
    
    def test_generic_class_with_inheritance(self, parse_statement):
        """Test parsing of generic class with inheritance."""
        source = """temp[T] class SpecialContainer(BaseContainer[T]):
    special_field: int"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "SpecialContainer"
        assert len(ast.type_params) == 1
        assert ast.base_class == "BaseContainer[T]"


@pytest.mark.classes
class TestSpecializedClassDeclarations:
    """Test parsing of specialized class declarations."""
    
    def test_actor_class(self, parse_statement):
        """Test parsing of actor class."""
        source = """class[actor] BankAccount:
    balance: int
    
    fun receive(&mut self, msg: Message):
        switch msg:
            case Deposit(amount):
                self.balance += amount
            case Withdraw(amount):
                self.balance -= amount"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "BankAccount"
        assert "actor" in ast.attributes
        assert len(ast.fields) == 1
        assert len(ast.methods) == 1
    
    def test_linear_class(self, parse_statement):
        """Test parsing of linear class."""
        source = """class[linear] File:
    descriptor: int
    
    sfun drop(&mut self):
        os.close(self.descriptor)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "File"
        assert "linear" in ast.attributes
        assert len(ast.fields) == 1
        assert len(ast.methods) == 1
    
    def test_class_with_multiple_attributes(self, parse_statement):
        """Test parsing of class with multiple attributes."""
        source = """class[actor, linear] Resource:
    handle: int"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "Resource"
        assert "actor" in ast.attributes
        assert "linear" in ast.attributes


@pytest.mark.classes
class TestTraitDeclarations:
    """Test parsing of trait declarations."""
    
    def test_simple_trait(self, parse_statement):
        """Test parsing of simple trait."""
        source = """trait Stringifiable:
    fun to_string(&self) -> string"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TraitDecl)
        assert ast.name == "Stringifiable"
        assert len(ast.type_params) == 0
        assert len(ast.methods) == 1
        assert len(ast.super_traits) == 0
        
        # Check method
        assert ast.methods[0].name == "to_string"
        assert ast.methods[0].is_method is True
    
    def test_trait_with_super_traits(self, parse_statement):
        """Test parsing of trait with super traits."""
        source = """trait Comparable(Other):
    fun compare(&self, other: &Other) -> int"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TraitDecl)
        assert ast.name == "Comparable"
        assert len(ast.type_params) == 1
        assert "Other" in ast.type_params
        assert len(ast.methods) == 1
    
    def test_trait_with_multiple_methods(self, parse_statement):
        """Test parsing of trait with multiple methods."""
        source = """trait Drawable:
    fun draw(&self)
    fun get_bounds(&self) -> Rect
    fun set_position(&mut self, x: int, y: int)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TraitDecl)
        assert ast.name == "Drawable"
        assert len(ast.methods) == 3
        
        # Check method signatures
        assert ast.methods[0].name == "draw"
        assert ast.methods[1].name == "get_bounds"
        assert ast.methods[2].name == "set_position"
    
    def test_generic_trait(self, parse_statement):
        """Test parsing of generic trait."""
        source = """temp[T] trait Container:
    fun add(&mut self, item: T)
    fun get(&self, index: int) -> T
    fun size(&self) -> int"""
        ast = parse_statement(source)
        
        assert isinstance(ast, TraitDecl)
        assert ast.name == "Container"
        assert len(ast.type_params) == 1
        assert "T" in ast.type_params
        assert len(ast.methods) == 3


@pytest.mark.classes
class TestImplementationDeclarations:
    """Test parsing of implementation declarations."""
    
    def test_simple_impl(self, parse_statement):
        """Test parsing of simple implementation."""
        source = """impl Stringifiable for int:
    fun to_string(&self) -> string:
        return int_to_str(*self)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ImplDecl)
        assert ast.trait_name == "Stringifiable"
        assert ast.type_name == "int"
        assert len(ast.type_params) == 0
        assert len(ast.methods) == 1
        
        # Check method
        assert ast.methods[0].name == "to_string"
        assert ast.methods[0].is_method is True
    
    def test_generic_impl(self, parse_statement):
        """Test parsing of generic implementation."""
        source = """temp[T] impl Container for vector[T]:
    fun add(&mut self, item: T):
        self.push(item)
    
    fun size(&self) -> int:
        return self.len()"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ImplDecl)
        assert ast.trait_name == "Container"
        assert ast.type_name == "vector[T]"
        assert len(ast.type_params) == 1
        assert "T" in ast.type_params
        assert len(ast.methods) == 2
    
    def test_impl_for_generic_type(self, parse_statement):
        """Test parsing of implementation for generic type."""
        source = """impl Comparable for MyClass[int]:
    fun compare(&self, other: &MyClass[int]) -> int:
        return self.value.compare(other.value)"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ImplDecl)
        assert ast.trait_name == "Comparable"
        assert ast.type_name == "MyClass[int]"
        assert len(ast.methods) == 1


@pytest.mark.classes
class TestComplexClassStructures:
    """Test parsing of complex class structures."""
    
    def test_nested_classes(self, parse_program):
        """Test parsing of nested classes."""
        source = """
class Outer:
    value: int
    
    class Inner:
        data: string
        
        fun[class] new(data: string) -> Inner:
            return Inner{data: data}
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], ClassDecl)
        assert ast.statements[0].name == "Outer"
    
    def test_class_with_complex_fields(self, parse_statement):
        """Test parsing of class with complex field types."""
        source = """class ComplexClass:
    items: vector[string]
    mapping: dict[int, string]
    optional: Option[float]
    callback: func(int) -> void"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert ast.name == "ComplexClass"
        assert len(ast.fields) == 4
    
    def test_class_with_generic_methods(self, parse_statement):
        """Test parsing of class with generic methods."""
        source = """class Container:
    data: vector[int]
    
    temp[T] fun convert(&self, converter: func(int) -> T) -> vector[T]:
        let result: vector[T] = []
        for item in self.data:
            result.push(converter(item))
        return result"""
        ast = parse_statement(source)
        
        assert isinstance(ast, ClassDecl)
        assert len(ast.methods) == 1
        assert len(ast.methods[0].type_params) == 1


@pytest.mark.classes
class TestClassErrors:
    """Test error handling in class parsing."""
    
    def test_class_without_name(self, parse_statement):
        """Test error handling for class without name."""
        with pytest.raises(ParseError):
            parse_statement("class:\n    field: int")
    
    def test_invalid_field_syntax(self, parse_statement):
        """Test error handling for invalid field syntax."""
        with pytest.raises(ParseError):
            parse_statement("class BadClass:\n    int field")
    
    def test_mismatched_braces(self, parse_statement):
        """Test error handling for mismatched braces."""
        with pytest.raises(ParseError):
            parse_statement("class Incomplete { field: int")
    
    def test_trait_without_methods(self, parse_statement):
        """Test error handling for trait without methods."""
        with pytest.raises(ParseError):
            parse_statement("trait EmptyTrait:")
    
    def test_impl_without_methods(self, parse_statement):
        """Test error handling for implementation without methods."""
        with pytest.raises(ParseError):
            parse_statement("impl SomeTrait for SomeType:")


@pytest.mark.classes
@pytest.mark.parametrize("source,expected_name,expected_type", [
    ("class Simple:\n    field: int", "Simple", ClassDecl),
    ("trait SimpleTrait:\n    fun method(&self)", "SimpleTrait", TraitDecl),
    ("impl Trait for Type:\n    fun method(&self)", "Trait", ImplDecl),
])
def test_class_parameterized(parse_statement, source, expected_name, expected_type):
    """Parameterized test for class-like declarations."""
    ast = parse_statement(source)
    
    assert isinstance(ast, expected_type)
    if expected_type == ClassDecl:
        assert ast.name == expected_name
    elif expected_type == TraitDecl:
        assert ast.name == expected_name
    elif expected_type == ImplDecl:
        assert ast.trait_name == expected_name


@pytest.mark.classes
class TestClassIntegration:
    """Test integration of classes in programs."""
    
    def test_complete_class_definition(self, parse_program):
        """Test parsing complete class definition with trait and implementation."""
        source = """
trait Stringifiable:
    fun to_string(&self) -> string

class Person:
    name: string
    age: int
    
    fun[class] new(name: string, age: int) -> Person:
        return Person{name: name, age: age}
    
    fun get_name(&self) -> string:
        return self.name

impl Stringifiable for Person:
    fun to_string(&self) -> string:
        return self.name + " (" + self.age.to_string() + ")"

let person = Person.new("Alice", 30)
let description = person.to_string()
"""
        ast = parse_program(source)
        
        assert len(ast.statements) == 5
        assert isinstance(ast.statements[0], TraitDecl)
        assert isinstance(ast.statements[1], ClassDecl)
        assert isinstance(ast.statements[2], ImplDecl)
        assert isinstance(ast.statements[3], VarDecl)
        assert isinstance(ast.statements[4], VarDecl)


if __name__ == "__main__":
    pytest.main([__file__])
