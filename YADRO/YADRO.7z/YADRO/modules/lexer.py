from enum import Enum, auto
from dataclasses import dataclass
from typing import List, Optional, Any

class TokenType(Enum):
    Target = "#target"
    Plugin = "#plugin"
    Requires = "#requires"
    Import = "#import"
    Start = "#start"
    End = "#end"

    # Formal Verification Tokens
    Spec = "spec"
    RequiresKw = "requires"  # Different from #requires directive
    Ensures = "ensures"
    Invariant = "invariant"
    Ghost = "#[ghost]"
    Old = "old"
    Axiom = "axiom"
    Verification = "#verification"
    Constitution = "#constitution"
    Compliance = "compliance"
    Articles = "articles"
    Level = "level"
    Prover = "prover"
    Safeguards = "safeguards"
    ZeroCostAbstraction = "zero_cost_abstraction"

    # GPU Programming Tokens
    Gpu = "gpu"
    Kernel = "kernel"
    Global = "global"
    Shared = "shared"
    Local = "local"
    Constant = "constant"
    Unified = "unified"
    Launch = "launch"
    Config = "config"
    GridDim = "grid_dim"
    BlockDim = "block_dim"
    SharedMem = "shared_mem"
    Stream = "stream"
    GpuThread = "#gpu_thread_id"
    GpuSyncBlock = "#gpu_sync_block"
    GpuSyncGrid = "#gpu_sync_grid"
    GpuAtomic = "#gpu_atomic"
    GpuTransfer = "#gpu_transfer"
    RequiresSync = "requires_sync"
    Relaxed = "#[relaxed]"
    FireAndForget = "#[fire_and_forget]"
    UnsafeGpu = "#[unsafe(gpu)]"
    NonDeterministic = "#[non_deterministic]"
    Critical = "#[critical]"

    # WebAssembly GC Tokens
    Wasm = "wasm"
    WasmGc = "wasm_gc"
    WasmStruct = "wasm_struct"
    WasmArray = "wasm_array"
    WasmExternref = "wasm_externref"
    WasmAnyref = "wasm_anyref"
    RequiresJs = "#requires_js"
    Capabilities = "capabilities"
    Sandboxed = "sandboxed"
    WasmAlloc = "wasm_gc::alloc"
    WasmPromote = "wasm_gc::promote"
    WasmDemote = "wasm_gc::demote"
    WasmCopy = "wasm_gc::copy"
    WasmArrayAlloc = "wasm_gc::array_alloc"
    WasmNull = "wasm_gc::null"
    UnsafeWasm = "#[unsafe(wasm_gc)]"
    JsCallback = "js_callback::wrap"
    Dom = "dom"
    Fetch = "fetch"
    Webcrypto = "webcrypto"

    LineCom = "/"
    BlComStart = "/*"
    BlComEnd = "*/"

    Newline = "\n"
    Semicolon = ";"
    Indent = " " * 4
    Dedent = None
    Colon = ":"

    Ifblk = "if"
    Elsif = "elsif"
    Elseblk = "else"
    Switch = "switch"
    Case = "case"
    Default = "default"
    Forlp = "for"
    In = "in"
    Whilelp = "while"
    Repeat = "repeat"
    Until = "until"
    Return = "return"
    Break = "break"
    Continue = "continue"

    Fun = "fun"
    Temp = "temp"
    Class = "class"
    Trait = "trait"
    Impl = "impl"
    Where = "where"
    Const = "const"
    Sfun = "sfun"

    Int = "int"
    Float = "float"
    Bool = "bool"
    String = "string"
    Char = "char"
    Array = "array"
    Darray = "darray"
    Dict = "dict"
    Set = "set"
    Vector = "vector"
    Gc = "gc"
    Result = "Result"
    Option = "Option"
    GcWeak = "gc_weak"

    Del = "del"
    Unsafe = "unsafe"
    Async = "async"
    Thread = "thread"
    Ffi = "ffi"
    Actor = "actor"
    Linear = "linear"
    Asm = "asm"

    true = "true"
    false = "false"

    Plus = "+"
    Minus = "-"
    Star = "*"
    Slash = "/"
    Percent = "%"
    Caret = "^"
    PipeDiv = "|"

    Eq = "=="
    Ne = "!="
    Lt = "<"
    Gt = ">"
    Le = "<="
    Ge = ">="

    And = "and"
    Or = "or"
    Xor = "xor"
    Nand = "nand"
    Not = "!"

    Lshift = "<<"
    Rshift = ">>"
    Amp = "&"
    Pipe = "|"
    Tilde = "~"

    Lparen = "("
    Rparen = ")"
    Lbrace = "{"
    Rbrace = "}"
    Lbrack = "["
    Rbrack = "]"
    Comma = ","
    Dot = "."
    Assign = "="
    PlusAssign = "+="
    MinusAssign = "-="
    StarAssign = "*="
    SlashAssign = "/="
    PercentAssign = "%="
    CaretAssign = "^="
    PipeDivAssign = "|/="
    LshiftAssign = "<<="
    RshiftAssign = ">>="
    AmpAssign = "&="
    PipeAssign = "|="
    TildeAssign = "~="
    AddrAssign = "@="
    SwapAssign = "$="

    Arrow = "->"
    FatArrow = "=>"
    Question = "?"
    DoubleQuestion = "??"
    ColonColon = "::"
    Dollar = "$"
    At = "@"
    Hash = "#"
    Backtick = "`"

    PipelineRight = ">>>"
    PipelineLeft = "<<<"

    Ref = "&"
    MutRef = "&mut"

    Match = "match"
    With = "with"
    Predicate = "~"

    IDENTIFIER = "<identifier>"
    EoF = "<EOF>"

@dataclass
class Token():
    type: TokenType
    value: str
    line: int
    column: int
    lexeme : str
    def __str__(self):
       return f"Lexeme {self.value} == {self.type.name} at line: {self.line}, column:{self.column}"

class LexerError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"Line {line}, Column {column}: {message}")
        self.line = line
        self.column = column

class Lexer:
    def __init__(self, source: str, source_path: str = "<string>"):
        self.source = source
        self.source_path = source_path
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]  # Stack of indentation levels

    def error(self, message: str):
        raise LexerError(message, self.line, self.column)

    def peek(self, offset: int = 0) -> Optional[str]:
        pos = self.pos + offset
        if pos < len(self.source):
            return self.source[pos]
        return None

    def advance(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        ch = self.source[self.pos]
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def skip_whitespace(self, skip_newlines: bool = False):
        while self.peek() and self.peek() in ' \t\r' + ('\n' if skip_newlines else ''):
            self.advance()

    def skip_comment(self):
        if self.peek() == '/' and self.peek(1) == '/':
            while self.peek() and self.peek() != '\n':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '*':
            self.advance()
            self.advance()
            while True:
                if self.peek() is None:
                    self.error("Unterminated block comment")
                if self.peek() == '*' and self.peek(1) == '/':
                    self.advance()
                    self.advance()
                    break
                self.advance()

    def read_string(self) -> str:
        quote = self.advance()
        value = ""
        while True:
            ch = self.peek()
            if ch is None:
                self.error("Unterminated string")
            if ch == quote:
                self.advance()
                break
            if ch == '\\':
                self.advance()
                escape = self.advance()
                escape_map = {
                    'n': '\n', 't': '\t', 'r': '\r',
                    '\\': '\\', '"': '"', "'": "'"
                }
                value += escape_map.get(escape, escape)
            else:
                value += ch
                self.advance()
        return value

    def read_char(self) -> str:
        self.advance()
        if self.peek() == '\\':
            self.advance()
            ch = self.advance()
            escape_map = {
                'n': '\n', 't': '\t', 'r': '\r',
                '\\': '\\', "'": "'"
            }
            value = escape_map.get(ch, ch)
        else:
            value = self.advance()
        if self.peek() != "'":
            self.error("Invalid character literal")
        self.advance()
        return value

    def read_number(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        is_float = False

        if self.peek() == '0' and self.peek(1) in 'xXbBoO':
            value += self.advance()
            value += self.advance()
            while self.peek() and self.peek() in '0123456789abcdefABCDEF_':
                if self.peek() != '_':
                    value += self.advance()
                else:
                    self.advance()
            return Token(TokenType.Int, int(value, 0), start_line, start_col, value)

        while self.peek() and (self.peek().isdigit() or self.peek() in '._'):
            if self.peek() == '.':
                if is_float:
                    break
                if self.peek(1) and not self.peek(1).isdigit():
                    break
                is_float = True
                value += self.advance()
            elif self.peek() == '_':
                self.advance()
            else:
                value += self.advance()

        if self.peek() and self.peek() in 'eE':
            is_float = True
            value += self.advance()
            if self.peek() and self.peek() in '+-':
                value += self.advance()
            while self.peek() and self.peek().isdigit():
                value += self.advance()

        token_type = TokenType.Float if is_float else TokenType.Int
        token_value = float(value) if is_float else int(value)
        return Token(token_type, token_value, start_line, start_col, value)

    def read_identifier(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        
        # Handle WASM GC operations like wasm_gc::alloc, wasm_gc::promote, etc.
        if self.source[self.pos:].startswith('wasm_gc::'):
            self.advance()  # w
            self.advance()  # a
            self.advance()  # s
            self.advance()  # m
            self.advance()  # _
            self.advance()  # g
            self.advance()  # c
            self.advance()  # :
            self.advance()  # :
            
            # Check for specific WASM GC operations
            if self.source[self.pos:].startswith('alloc'):
                self.advance()  # a
                self.advance()  # l
                self.advance()  # l
                self.advance()  # o
                self.advance()  # c
                return Token(TokenType.WasmAlloc, 'wasm_gc::alloc', start_line, start_col, 'wasm_gc::alloc')
            elif self.source[self.pos:].startswith('promote'):
                self.advance()  # p
                self.advance()  # r
                self.advance()  # o
                self.advance()  # m
                self.advance()  # o
                self.advance()  # t
                self.advance()  # e
                return Token(TokenType.WasmPromote, 'wasm_gc::promote', start_line, start_col, 'wasm_gc::promote')
            elif self.source[self.pos:].startswith('demote'):
                self.advance()  # d
                self.advance()  # e
                self.advance()  # m
                self.advance()  # o
                self.advance()  # t
                self.advance()  # e
                return Token(TokenType.WasmDemote, 'wasm_gc::demote', start_line, start_col, 'wasm_gc::demote')
            elif self.source[self.pos:].startswith('copy'):
                self.advance()  # c
                self.advance()  # o
                self.advance()  # p
                self.advance()  # p
                self.advance()  # y
                return Token(TokenType.WasmCopy, 'wasm_gc::copy', start_line, start_col, 'wasm_gc::copy')
            elif self.source[self.pos:].startswith('array_alloc'):
                self.advance()  # a
                self.advance()  # r
                self.advance()  # r
                self.advance()  # a
                self.advance()  # y
                self.advance()  # _
                self.advance()  # a
                self.advance()  # l
                self.advance()  # l
                self.advance()  # o
                self.advance()  # c
                return Token(TokenType.WasmArrayAlloc, 'wasm_gc::array_alloc', start_line, start_col, 'wasm_gc::array_alloc')
            elif self.source[self.pos:].startswith('null'):
                self.advance()  # n
                self.advance()  # u
                self.advance()  # l
                self.advance()  # l
                return Token(TokenType.WasmNull, 'wasm_gc::null', start_line, start_col, 'wasm_gc::null')
        
        # Handle js_callback::wrap
        elif self.source[self.pos:].startswith('js_callback::wrap'):
            self.advance()  # j
            self.advance()  # s
            self.advance()  # _
            self.advance()  # c
            self.advance()  # a
            self.advance()  # l
            self.advance()  # l
            self.advance()  # b
            self.advance()  # a
            self.advance()  # c
            self.advance()  # k
            self.advance()  # :
            self.advance()  # :
            self.advance()  # w
            self.advance()  # r
            self.advance()  # a
            self.advance()  # p
            return Token(TokenType.JsCallback, 'js_callback::wrap', start_line, start_col, 'js_callback::wrap')
        
        # Handle regular identifiers
        while self.peek() and (self.peek().isalnum() or self.peek() in '_'):
            value += self.advance()

        token_type = TokenType.IDENTIFIER

        for token in TokenType:
            if hasattr(token, 'value') and token.value == value:
                token_type = token
                break

        if value == 'true':
            return Token(TokenType.true, True, start_line, start_col, value)
        elif value == 'false':
            return Token(TokenType.false, False, start_line, start_col, value)

        return Token(token_type, value, start_line, start_col, value)

    def read_directive(self) -> Token:
        start_line, start_col = self.line, self.column
        value = ""
        
        # Handle complex directives like #gpu_thread_id(), #requires_js, etc.
        if self.peek() and self.peek() == '#':
            value += self.advance()
            
            # Check for GPU intrinsics
            if self.source[self.pos:].startswith('gpu_thread_id'):
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # _
                self.advance()  # t
                self.advance()  # h
                self.advance()  # r
                self.advance()  # e
                self.advance()  # a
                self.advance()  # d
                self.advance()  # _
                self.advance()  # i
                self.advance()  # d
                return Token(TokenType.GpuThread, '#gpu_thread_id', start_line, start_col, '#gpu_thread_id')
            elif self.source[self.pos:].startswith('gpu_sync_block'):
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # _
                self.advance()  # s
                self.advance()  # y
                self.advance()  # n
                self.advance()  # c
                self.advance()  # _
                self.advance()  # b
                self.advance()  # l
                self.advance()  # o
                self.advance()  # c
                self.advance()  # k
                return Token(TokenType.GpuSyncBlock, '#gpu_sync_block', start_line, start_col, '#gpu_sync_block')
            elif self.source[self.pos:].startswith('gpu_sync_grid'):
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # _
                self.advance()  # s
                self.advance()  # y
                self.advance()  # n
                self.advance()  # c
                self.advance()  # _
                self.advance()  # g
                self.advance()  # r
                self.advance()  # i
                self.advance()  # d
                return Token(TokenType.GpuSyncGrid, '#gpu_sync_grid', start_line, start_col, '#gpu_sync_grid')
            elif self.source[self.pos:].startswith('gpu_atomic'):
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # _
                self.advance()  # a
                self.advance()  # t
                self.advance()  # o
                self.advance()  # m
                self.advance()  # i
                self.advance()  # c
                return Token(TokenType.GpuAtomic, '#gpu_atomic', start_line, start_col, '#gpu_atomic')
            elif self.source[self.pos:].startswith('gpu_transfer'):
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # _
                self.advance()  # t
                self.advance()  # r
                self.advance()  # a
                self.advance()  # n
                self.advance()  # s
                self.advance()  # f
                self.advance()  # e
                self.advance()  # r
                return Token(TokenType.GpuTransfer, '#gpu_transfer', start_line, start_col, '#gpu_transfer')
            elif self.source[self.pos:].startswith('requires_js'):
                self.advance()  # r
                self.advance()  # e
                self.advance()  # q
                self.advance()  # u
                self.advance()  # i
                self.advance()  # r
                self.advance()  # e
                self.advance()  # s
                self.advance()  # _
                self.advance()  # j
                self.advance()  # s
                return Token(TokenType.RequiresJs, '#requires_js', start_line, start_col, '#requires_js')
            elif self.source[self.pos:].startswith('verification'):
                self.advance()  # v
                self.advance()  # e
                self.advance()  # r
                self.advance()  # i
                self.advance()  # f
                self.advance()  # i
                self.advance()  # c
                self.advance()  # a
                self.advance()  # t
                self.advance()  # i
                self.advance()  # o
                self.advance()  # n
                return Token(TokenType.Verification, '#verification', start_line, start_col, '#verification')
            elif self.source[self.pos:].startswith('constitution'):
                self.advance()  # c
                self.advance()  # o
                self.advance()  # n
                self.advance()  # s
                self.advance()  # t
                self.advance()  # i
                self.advance()  # t
                self.advance()  # u
                self.advance()  # t
                self.advance()  # i
                self.advance()  # o
                self.advance()  # n
                return Token(TokenType.Constitution, '#constitution', start_line, start_col, '#constitution')
            elif self.source[self.pos:].startswith('ghost'):
                self.advance()  # g
                self.advance()  # h
                self.advance()  # o
                self.advance()  # s
                self.advance()  # t
                return Token(TokenType.Ghost, '#ghost', start_line, start_col, '#ghost')
            elif self.source[self.pos:].startswith('relaxed'):
                self.advance()  # r
                self.advance()  # e
                self.advance()  # l
                self.advance()  # a
                self.advance()  # x
                self.advance()  # e
                self.advance()  # d
                return Token(TokenType.Relaxed, '#relaxed', start_line, start_col, '#relaxed')
            elif self.source[self.pos:].startswith('fire_and_forget'):
                self.advance()  # f
                self.advance()  # i
                self.advance()  # r
                self.advance()  # e
                self.advance()  # _
                self.advance()  # a
                self.advance()  # n
                self.advance()  # d
                self.advance()  # _
                self.advance()  # f
                self.advance()  # o
                self.advance()  # r
                self.advance()  # g
                self.advance()  # e
                self.advance()  # t
                return Token(TokenType.FireAndForget, '#fire_and_forget', start_line, start_col, '#fire_and_forget')
            elif self.source[self.pos:].startswith('critical'):
                self.advance()  # c
                self.advance()  # r
                self.advance()  # i
                self.advance()  # t
                self.advance()  # i
                self.advance()  # c
                self.advance()  # a
                self.advance()  # l
                return Token(TokenType.Critical, '#critical', start_line, start_col, '#critical')
            elif self.source[self.pos:].startswith('non_deterministic'):
                self.advance()  # n
                self.advance()  # o
                self.advance()  # n
                self.advance()  # _
                self.advance()  # d
                self.advance()  # e
                self.advance()  # t
                self.advance()  # e
                self.advance()  # r
                self.advance()  # m
                self.advance()  # i
                self.advance()  # n
                self.advance()  # i
                self.advance()  # s
                self.advance()  # t
                self.advance()  # i
                self.advance()  # c
                return Token(TokenType.NonDeterministic, '#non_deterministic', start_line, start_col, '#non_deterministic')
            elif self.source[self.pos:].startswith('unsafe(gpu)'):
                self.advance()  # u
                self.advance()  # n
                self.advance()  # s
                self.advance()  # a
                self.advance()  # f
                self.advance()  # e
                self.advance()  # (
                self.advance()  # g
                self.advance()  # p
                self.advance()  # u
                self.advance()  # )
                return Token(TokenType.UnsafeGpu, '#unsafe(gpu)', start_line, start_col, '#unsafe(gpu)')
            elif self.source[self.pos:].startswith('unsafe(wasm_gc)'):
                self.advance()  # u
                self.advance()  # n
                self.advance()  # s
                self.advance()  # a
                self.advance()  # f
                self.advance()  # e
                self.advance()  # (
                self.advance()  # w
                self.advance()  # a
                self.advance()  # s
                self.advance()  # m
                self.advance()  # _
                self.advance()  # g
                self.advance()  # c
                self.advance()  # )
                return Token(TokenType.UnsafeWasm, '#unsafe(wasm_gc)', start_line, start_col, '#unsafe(wasm_gc)')
        
        # Handle regular directives and identifiers
        while self.peek() and (self.peek().isalnum() or self.peek() in '_#'):
            value += self.advance()

        token_type = TokenType.IDENTIFIER
        for token in TokenType:
            if hasattr(token, 'value') and token.value == value:
                token_type = token
                break

        return Token(token_type, value, start_line, start_col, value)

    def handle_indentation(self):
        indent = 0
        while self.peek() and self.peek() in ' \t':
            if self.peek() == ' ':
                indent += 1
            else:
                indent += 4
            self.advance()

        if self.peek() and self.peek() in '\n\r':
            return

        if self.peek() == '/' and self.peek(1) in '/*':
            return

        current_indent = self.indent_stack[-1]

        if indent > current_indent:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.Indent, indent, self.line, self.column, "INDENT"))
        elif indent < current_indent:
            while self.indent_stack and self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.Dedent, indent, self.line, self.column, "DEDENT"))
            if self.indent_stack[-1] != indent:
                self.error(f"Invalid indentation level")

    def tokenize(self) -> List[Token]:
        at_line_start = True

        while self.pos < len(self.source):
            if at_line_start:
                self.handle_indentation()
                at_line_start = False

            self.skip_whitespace()

            ch = self.peek()
            if ch is None:
                break

            if ch == '/' and self.peek(1) in '/*':
                self.skip_comment()
                continue

            start_line, start_col = self.line, self.column

            if ch == '\n':
                self.advance()
                self.tokens.append(Token(TokenType.Newline, '\n', start_line, start_col, "\\n"))
                at_line_start = True
                continue

            if ch in '"\'':
                if ch == '"':
                    value = self.read_string()
                    self.tokens.append(Token(TokenType.String, value, start_line, start_col, f'"{value}"'))
                else:
                    value = self.read_char()
                    self.tokens.append(Token(TokenType.Char, value, start_line, start_col, f"'{value}'"))
                continue

            if ch.isdigit():
                self.tokens.append(self.read_number())
                continue

            if ch == '#':
                self.tokens.append(self.read_directive())
                continue

            if ch.isalpha() or ch == '_':
                self.tokens.append(self.read_identifier())
                continue

            if ch == '>' and self.peek(1) == '>' and self.peek(2) == '>':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipelineRight, '>>>', start_line, start_col, ">>>"))
                continue
            if ch == '<' and self.peek(1) == '<' and self.peek(2) == '<':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipelineLeft, '<<<', start_line, start_col, "<<<"))
                continue

            if ch == '=' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Eq, '==', start_line, start_col, "=="))
                continue
            if ch == '!' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Ne, '!=', start_line, start_col, "!="))
                continue
            if ch == '<' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Le, '<=', start_line, start_col, "<="))
                continue
            if ch == '>' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Ge, '>=', start_line, start_col, ">="))
                continue
            # Check for <<= and >>= before << and >>
            if ch == '<' and self.peek(1) == '<' and self.peek(2) == '=':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.LshiftAssign, '<<=', start_line, start_col, "<<="))
                continue
            if ch == '>' and self.peek(1) == '>' and self.peek(2) == '=':
                self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.RshiftAssign, '>>=', start_line, start_col, ">>="))
                continue
            if ch == '<' and self.peek(1) == '<':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Lshift, '<<', start_line, start_col, "<<"))
                continue
            if ch == '>' and self.peek(1) == '>':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.Rshift, '>>', start_line, start_col, ">>"))
                continue
            if ch == '-' and self.peek(1) == '>':
                if self.peek(2) == '>':
                    self.advance(); self.advance(); self.advance()
                    self.tokens.append(Token(TokenType.PipelineRight, '>>>', start_line, start_col, ">>>"))
                    continue
                else:
                    self.advance(); self.advance()
                    self.tokens.append(Token(TokenType.Arrow, '->', start_line, start_col, "->"))
                    continue
            if ch == '=' and self.peek(1) == '>':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.FatArrow, '=>', start_line, start_col, "=>"))
                continue
            if ch == '+' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PlusAssign, '+=', start_line, start_col, "+="))
                continue
            if ch == '-' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.MinusAssign, '-=', start_line, start_col, "-="))
                continue
            if ch == '*' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.StarAssign, '*=', start_line, start_col, "*="))
                continue
            if ch == '/' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.SlashAssign, '/=', start_line, start_col, "/="))
                continue
            if ch == '%' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PercentAssign, '%=', start_line, start_col, "%="))
                continue
            if ch == '&' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.AmpAssign, '&=', start_line, start_col, "&="))
                continue
            if ch == '&' and self.peek(1) == 'm' and self.peek(2) == 'u' and self.peek(3) == 't':
                self.advance(); self.advance(); self.advance(); self.advance()
                self.tokens.append(Token(TokenType.MutRef, '&mut', start_line, start_col, "&mut"))
                continue
            if ch == '&':
                self.advance()
                self.tokens.append(Token(TokenType.Ref, '&', start_line, start_col, "&"))
                continue
            if ch == '|' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.PipeAssign, '|=', start_line, start_col, "|="))
                continue
            if ch == '^' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.CaretAssign, '^=', start_line, start_col, "^="))
                continue
            if ch == '@' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.AddrAssign, '@=', start_line, start_col, "@="))
                continue
            if ch == '$' and self.peek(1) == '=':
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.SwapAssign, '$=', start_line, start_col, "$="))
                continue

            # Single character tokens
            single_char_tokens = {
                '+': TokenType.Plus, '-': TokenType.Minus, '*': TokenType.Star,
                '/': TokenType.Slash, '%': TokenType.Percent, '^': TokenType.Caret,
                '<': TokenType.Lt, '>': TokenType.Gt, '=': TokenType.Assign,
                '!': TokenType.Not, '|': TokenType.Pipe, '~': TokenType.Tilde,
                '(': TokenType.Lparen, ')': TokenType.Rparen,
                '{': TokenType.Lbrace, '}': TokenType.Rbrace,
                '[': TokenType.Lbrack, ']': TokenType.Rbrack,
                ':': TokenType.Colon, ';': TokenType.Semicolon,
                ',': TokenType.Comma, '.': TokenType.Dot,
                '?': TokenType.Question,
            }

            if ch in single_char_tokens:
                self.advance()
                self.tokens.append(Token(single_char_tokens[ch], ch, start_line, start_col, ch))
                continue

            self.error(f"Unexpected character: {ch}")

        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.Dedent, 0, self.line, self.column, "DEDENT"))

        self.tokens.append(Token(TokenType.EoF, None, self.line, self.column, "EOF"))
        return self.tokens

if __name__ == '__main__':
    code = """#import
std.core.cli
#start
fun main() -> int:
    int x = 42
    if x > 0:
        return 0
    else:
        return 1
#end
"""
    tokens = Lexer(code).tokenize()
    for t in tokens:
        print(t)