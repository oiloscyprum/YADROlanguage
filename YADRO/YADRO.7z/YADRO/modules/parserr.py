"""
YADRO Parser Module

This module implements a complete recursive descent parser for the YADRO programming language,
transforming the token stream from the lexer into an Abstract Syntax Tree (AST).
"""

from typing import List, Optional, Union, Any, Dict
from dataclasses import dataclass
from enum import Enum

from lexer import Token, TokenType, LexerError


class ParseError(Exception):
    """Exception raised for parsing errors."""
    
    def __init__(self, message: str, token: Optional[Token] = None):
        self.message = message
        self.token = token
        if token:
            super().__init__(f"Parse error at line {token.line}, column {token.column}: {message}")
        else:
            super().__init__(f"Parse error: {message}")


# AST Node Base Classes
@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int
    column: int


@dataclass
class Statement(ASTNode):
    """Base class for all statement nodes."""
    pass


@dataclass
class Expression(ASTNode):
    """Base class for all expression nodes."""
    pass


@dataclass
class Type(ASTNode):
    """Base class for all type nodes."""
    pass


# Core AST Nodes
@dataclass
class Program(ASTNode):
    """Root node of the AST."""
    statements: List[Statement]
    
    def __post_init__(self):
        if hasattr(self, 'statements') and self.statements:
            self.line = self.statements[0].line
            self.column = self.statements[0].column


# Directive Nodes
@dataclass
class TargetDirective(Statement):
    target: Union[str, Dict[str, Union[str, List[str]]]]  # Support both string and properties

    @property
    def properties(self):
        if isinstance(self.target, dict):
            return self.target
        return {}


@dataclass
class PluginDirective(Statement):
    plugin: str


@dataclass
class RequiresDirective(Statement):
    version: str


@dataclass
class ImportDirective(Statement):
    module: str
    alias: Optional[str] = None


@dataclass
class StartDirective(Statement):
    function: str


@dataclass
class EndDirective(Statement):
    function: str


# Declaration Nodes
@dataclass
class VarDecl(Statement):
    name: str
    type_annotation: Optional[Type]
    initializer: Optional[Expression]
    is_mutable: bool = False


@dataclass
class ConstDecl(Statement):
    name: str
    type_annotation: Optional[Type]
    initializer: Expression
    line: int
    column: int
    
    def __post_init__(self):
        # Move line/column to proper position for dataclass
        pass


@dataclass
class FunctionDecl(Statement):
    name: str
    type_params: List[str]
    params: List['Param']
    return_type: Optional[Type]
    body: List[Statement]
    attributes: List[str]
    is_static: bool = False
    is_method: bool = False


@dataclass
class Param:
    name: str
    type_annotation: Type
    is_mutable: bool = False
    default_value: Optional[Expression] = None


@dataclass
class ClassDecl(Statement):
    name: str
    type_params: List[str]
    fields: List[VarDecl]
    methods: List[FunctionDecl]
    attributes: List[str]
    base_class: Optional[str] = None
    nested_classes: List['ClassDecl'] = None  # Support for nested classes

    def __post_init__(self):
        if self.nested_classes is None:
            self.nested_classes = []


@dataclass
class TraitDecl(Statement):
    name: str
    type_params: List[str]
    methods: List[FunctionDecl]
    super_traits: List[str]


@dataclass
class ImplDecl(Statement):
    trait_name: str
    type_name: str
    type_params: List[str]
    methods: List[FunctionDecl]


@dataclass
class ProtocolDecl(Statement):
    name: str
    methods: List[FunctionDecl]


# Control Flow Nodes
@dataclass
class IfStmt(Statement):
    condition: Expression
    then_branch: List[Statement]
    elif_branches: List[tuple[Expression, List[Statement]]]
    else_branch: Optional[List[Statement]]


@dataclass
class SwitchStmt(Statement):
    expression: Expression
    cases: List[tuple[Expression, List[Statement]]]
    default_case: Optional[List[Statement]]


@dataclass
class ForStmt(Statement):
    variable: str
    iterable: Expression
    body: List[Statement]


@dataclass
class WhileStmt(Statement):
    condition: Expression
    body: List[Statement]


@dataclass
class RepeatStmt(Statement):
    body: List[Statement]
    until_condition: Expression


@dataclass
class ReturnStmt(Statement):
    expression: Optional[Expression]


@dataclass
class BreakStmt(Statement):
    pass


@dataclass
class ContinueStmt(Statement):
    pass


@dataclass
class DelStmt(Statement):
    expression: Expression


# Expression Nodes
@dataclass
class BinaryExpr(Expression):
    left: Expression
    operator: str
    right: Expression


@dataclass
class AddExpr(BinaryExpr):
    pass


@dataclass
class MulExpr(BinaryExpr):
    pass


@dataclass
class UnaryExpr(Expression):
    operator: str
    operand: Expression


@dataclass
class AssignExpr(Expression):
    target: Expression
    operator: str
    value: Expression


@dataclass
class PipelineExpr(Expression):
    direction: str  # ">>>" or "<<<"
    expressions: List[Expression]


@dataclass
class CallExpr(Expression):
    callee: Expression
    arguments: List[Expression]


@dataclass
class MemberExpr(Expression):
    object: Expression
    property: str


@dataclass
class IndexExpr(Expression):
    object: Expression
    index: Expression


@dataclass
class LiteralExpr(Expression):
    value: Any
    literal_type: str  # "int", "float", "string", "char", "bool"


@dataclass
class IdentifierExpr(Expression):
    name: str


@dataclass
class RefExpr(Expression):
    expression: Expression
    is_mutable: bool = False


@dataclass
class DerefExpr(Expression):
    expression: Expression


@dataclass
class PredicateExpr(Expression):
    expression: Expression
    predicate: str


@dataclass
class MatchExpr(Expression):
    expression: Expression
    arms: List[tuple[Expression, Expression]]


@dataclass
class ResultExpr(Expression):
    expression: Expression
    is_ok: bool = True


@dataclass
class OptionExpr(Expression):
    expression: Expression
    is_some: bool = True


@dataclass
class AsmExpr(Expression):
    template: str
    inputs: List[tuple[str, Expression]]
    outputs: List[tuple[str, str]]
    clobbers: List[str]


@dataclass
class LambdaExpr(Expression):
    params: List[Param]
    return_type: Optional[Type]
    body: List[Statement]


@dataclass
class GenericExpr(Expression):
    expression: Expression
    type_args: List[Type]


@dataclass
class ArrayLiteralExpr(Expression):
    elements: List[Expression]


@dataclass
class DictLiteralExpr(Expression):
    pairs: List[tuple[Expression, Expression]]


@dataclass
class SetLiteralExpr(Expression):
    elements: List[Expression]


@dataclass
class GcExpr(Expression):
    element_type: Type
    arguments: List[Expression]
    is_weak: bool = False


@dataclass
class StructInitExpr(Expression):
    struct_name: str
    fields: List[tuple[str, Expression]]


# Type Nodes
@dataclass
class BasicType(Type):
    name: str


@dataclass
class ArrayType(Type):
    element_type: Type
    size: Optional[Expression] = None


@dataclass
class DictType(Type):
    key_type: Type
    value_type: Type


@dataclass
class SetType(Type):
    element_type: Type


@dataclass
class VectorType(Type):
    element_type: Type
    size: Optional[Expression] = None


@dataclass
class ReferenceType(Type):
    referenced_type: Type
    is_mutable: bool = False


@dataclass
class PredicateType(Type):
    base_type: Type
    predicate: str


@dataclass
class GenericType(Type):
    name: str
    type_args: List[Type]


@dataclass
class ResultType(Type):
    ok_type: Type
    err_type: Type


@dataclass
class OptionType(Type):
    some_type: Type


@dataclass
class FuncType(Type):
    params: List[Type]
    return_type: Type


@dataclass
class GcType(Type):
    inner_type: Type
    is_weak: bool = False


# Formal Verification AST Nodes
@dataclass
class SpecTypeDecl(Statement):
    spec_name: str
    base_type: Type
    predicate: str


@dataclass
class FunctionSpec:
    requires: List[str]
    ensures: List[str]
    invariants: List[str]


@dataclass
class SpecBlock(Statement):
    specifications: FunctionSpec


@dataclass
class LoopInvariant(Statement):
    invariant: str
    condition: Expression


@dataclass
class GhostVarDecl(Statement):
    name: str
    type_annotation: Type
    initializer: Expression
    is_ghost: bool = True


@dataclass
class VerificationDirective(Statement):
    verification_level: str
    prover: Optional[str]
    dump_obligations: bool
    output_file: Optional[str]


@dataclass
class ConstitutionalDirective(Statement):
    compliance_level: str
    articles: List[str]
    safeguards: List[str]
    zero_cost_abstraction: bool


# GPU Programming AST Nodes
@dataclass
class GpuTargetDirective(Statement):
    properties: Dict[str, Union[str, List[str]]]


@dataclass
class MemorySpaceType(Type):
    space: str  # "global", "shared", "local", "constant", "unified"
    element_type: Type


@dataclass
class KernelFunctionDecl(Statement):
    name: str
    params: List['Param']
    return_type: Type
    requires_sync: Optional[str]
    shared_mem: Optional[int]
    body: List[Statement]
    is_gpu_kernel: bool = True


@dataclass
class KernelLaunchStmt(Statement):
    kernel_name: str
    arguments: List[Expression]
    config: Dict[str, Union[str, int, tuple]]
    is_kernel_launch: bool = True
    is_fire_and_forget: bool = False


@dataclass
class GpuIntrinsicExpr(Expression):
    intrinsic_type: str  # "thread_id", "sync_block", "atomic", etc.
    arguments: List[Expression]
    is_gpu_intrinsic: bool = True


@dataclass
class MemoryTransferExpr(Expression):
    transfer_type: str  # "to_device", "to_host"
    argument: Expression
    is_gpu_transfer: bool = True


# WebAssembly GC AST Nodes
@dataclass
class WasmTargetDirective(Statement):
    properties: Dict[str, Union[str, List[str]]]


@dataclass
class WasmGcType(Type):
    gc_type: str  # "reference", "struct", "array", "externref", "anyref"
    element_type: Optional[Type]


@dataclass
class WasmStructDecl(Statement):
    name: str
    fields: List[tuple[str, Type]]
    is_wasm_struct: bool = True


@dataclass
class RequiresJsDirective(Statement):
    js_capabilities: List[str]
    sandboxed: bool


@dataclass
class WasmGcOperationExpr(Expression):
    operation: str  # "alloc", "promote", "demote", "copy", "array_alloc", "null"
    arguments: List[Expression]
    wasm_gc_op: str


@dataclass
class JsCapabilityExpr(Expression):
    capability: str
    arguments: List[Expression]
    js_capability: str


# Special Statement Nodes
@dataclass
class BlockStmt(Statement):
    statements: List[Statement]


@dataclass
class UnsafeStmt(Statement):
    statements: List[Statement]


@dataclass
class AsmStmt(Statement):
    template: str
    inputs: List[tuple[str, Expression]]
    outputs: List[tuple[str, str]]
    clobbers: List[str]


@dataclass
class ExprStmt(Statement):
    expression: Expression


class YadroParser:
    """Recursive descent parser for YADRO language."""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.current = 0
        self.errors: List[ParseError] = []
        self.pending_class_attributes: List[str] = []
    
    def parse_program(self) -> Program:
        """Parse the entire token stream into a Program AST."""
        statements = []
        
        while not self.is_at_end():
            # Skip newlines and empty lines between statements
            while self.match(TokenType.Newline) or self.match(TokenType.Indent) or self.match(TokenType.Dedent):
                continue
            
            if self.is_at_end():
                break
            
            try:
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
        
        if statements:
            return Program(statements[0].line, statements[0].column, statements)
        else:
            return Program(1, 1, [])
    
    def parse_statement(self) -> Statement:
        """Parse a statement with proper block handling."""
        # Skip newlines but not Dedent tokens (they're important for block boundaries)
        while self.match(TokenType.Newline):
            continue
        
        # If we're at a Dedent token, don't parse a statement
        if self.check(TokenType.Dedent):
            return None
            
        if self.match(TokenType.Target):
            return self.parse_target_directive()
        elif self.match(TokenType.Plugin):
            return self.parse_plugin_directive()
        elif self.match(TokenType.Requires):
            return self.parse_requires_directive()
        elif self.match(TokenType.Import):
            return self.parse_import_directive()
        elif self.match(TokenType.Start):
            return self.parse_start_directive()
        elif self.match(TokenType.End):
            return self.parse_end_directive()
        elif self.match(TokenType.RequiresJs):
            return self.parse_requires_js_directive()
        elif self.match(TokenType.Verification):
            return self.parse_verification_directive()
        elif self.match(TokenType.Constitution):
            return self.parse_constitutional_directive()
        elif self.match(TokenType.Spec):
            return self.parse_spec_type_declaration()
        elif self.match(TokenType.Launch):
            return self.parse_kernel_launch()
        elif self.match(TokenType.WasmStruct):
            return self.parse_wasm_struct_declaration()
        
        # Check for attributes before declaration
        attributes = []
        if self.match(TokenType.Relaxed):
            attributes.append("relaxed")
            # Handle optional reason
            if self.match(TokenType.Lparen):
                while not self.check(TokenType.Rparen) and not self.is_at_end():
                    self.advance() # Skip content inside ()
                self.consume(TokenType.Rparen, "Expected ')' after attribute params")
        elif self.match(TokenType.UnsafeGpu):
            attributes.append("unsafe(gpu)")
        
        # Store attributes for next declaration if any
        if attributes:
            self.pending_attributes = attributes

        if self.match(TokenType.Temp):
            # Check if this is temp[T] class syntax by looking ahead
            # Pattern: temp [ ... ] class
            if self.check(TokenType.Lbrack):
                # Skip past [T] to check for class
                # Find matching ]
                bracket_count = 0
                i = self.current
                while i < len(self.tokens) and bracket_count >= 0:
                    if self.tokens[i].type == TokenType.Lbrack:
                        bracket_count += 1
                    elif self.tokens[i].type == TokenType.Rbrack:
                        bracket_count -= 1
                        if bracket_count == 0:
                            i += 1  # Move past the closing bracket
                            break
                    i += 1
                # Check if next token after ] is class, trait, or impl
                if i < len(self.tokens) and self.tokens[i].type in [TokenType.Class, TokenType.Trait, TokenType.Impl]:
                    # We already consumed temp, now consume [T]
                    self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
                    consumed_params = []
                    if not self.check(TokenType.Rbrack):
                        consumed_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                        while self.match(TokenType.Comma):
                            consumed_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                    self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
                    # Now consume class/trait/impl and call appropriate parser
                    if self.match(TokenType.Class):
                        return self.parse_class_decl(consumed_params)
                    elif self.match(TokenType.Trait):
                        return self.parse_trait_decl(consumed_params)
                    elif self.match(TokenType.Impl):
                        return self.parse_impl_decl(consumed_params)
                else:
                    return self.parse_generic_function_decl()
            else:
                return self.parse_generic_function_decl()
        elif self.match(TokenType.Fun):
            return self.parse_function_decl()
        elif self.match(TokenType.Sfun):
            return self.parse_function_decl()
        elif self.match(TokenType.Class):
            # Check for class[attribute] syntax
            if self.match(TokenType.Lbrack):
                # Parse class attributes like actor, linear, etc.
                attributes = []
                if not self.check(TokenType.Rbrack):
                    # Parse attribute name - could be identifier or keyword token
                    if self.match(TokenType.Actor):
                        attributes.append("actor")
                    elif self.match(TokenType.Linear):
                        attributes.append("linear")
                    else:
                        attr_token = self.consume(TokenType.IDENTIFIER, "Expected attribute name")
                        attributes.append(attr_token.value)
                    
                    while self.match(TokenType.Comma):
                        if self.match(TokenType.Actor):
                            attributes.append("actor")
                        elif self.match(TokenType.Linear):
                            attributes.append("linear")
                        else:
                            attr_token = self.consume(TokenType.IDENTIFIER, "Expected attribute name")
                            attributes.append(attr_token.value)
                self.consume(TokenType.Rbrack, "Expected ']' after class attributes")
                # Store attributes in parser state for parse_class_decl to use
                self.pending_class_attributes = attributes
            return self.parse_class_decl()
        elif self.match(TokenType.Trait):
            return self.parse_trait_decl()
        elif self.match(TokenType.Impl):
            return self.parse_impl_decl()
        elif self.match(TokenType.Protocol):
            return self.parse_protocol_decl()
        elif self.match(TokenType.Const):
            return self.parse_const_decl()
        elif self.match(TokenType.Del):
            return self.parse_del_stmt()
        elif self.match(TokenType.Ifblk):
            return self.parse_if_stmt()
        elif self.match(TokenType.Switch):
            return self.parse_switch_stmt()
        elif self.match(TokenType.Forlp):
            return self.parse_for_stmt()
        elif self.match(TokenType.Whilelp):
            return self.parse_while_stmt()
        elif self.match(TokenType.Repeat):
            return self.parse_repeat_stmt()
        elif self.match(TokenType.Return):
            return self.parse_return_stmt()
        elif self.match(TokenType.Break):
            return self.parse_break_stmt()
        elif self.match(TokenType.Continue):
            return self.parse_continue_stmt()
        elif self.match(TokenType.Unsafe):
            return self.parse_unsafe_stmt()
        elif self.match(TokenType.Asm):
            return self.parse_asm_stmt()
        elif self.match(TokenType.Spec):
            return self.parse_spec_type_declaration()
        elif self.match(TokenType.Ghost):
             return self.parse_ghost_decl()
        else:
            # Check for variable declaration (let/var) or class field (identifier: type)
            if self.check(TokenType.IDENTIFIER):
                current_token = self.peek()
                if current_token and current_token.value in ['let', 'var']:
                    return self.parse_var_decl()
                elif self.current + 1 < len(self.tokens):
                    next_token = self.tokens[self.current + 1]
                    if next_token and next_token.type == TokenType.Colon:
                        return self.parse_class_field()
            return self.parse_expr_stmt()
    
    def parse_expression(self) -> Expression:
        """Parse an expression with proper precedence."""
        return self.parse_assignment()
    
    def parse_expr_stmt(self) -> ExprStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after expression")
        return ExprStmt(expr.line, expr.column, expr)
    
    def parse_assignment(self) -> Expression:
        """Parse assignment expressions."""
        expr = self.parse_pipeline()
        
        if self.match(TokenType.Assign) or any(self.match(t) for t in [
            TokenType.PlusAssign, TokenType.MinusAssign, TokenType.StarAssign,
            TokenType.SlashAssign, TokenType.PercentAssign, TokenType.LshiftAssign,
            TokenType.RshiftAssign, TokenType.AmpAssign, TokenType.PipeAssign,
            TokenType.CaretAssign, TokenType.AddrAssign, TokenType.SwapAssign
        ]):
            operator = self.previous().value
            value = self.parse_assignment()
            return AssignExpr(expr.line, expr.column, expr, operator, value)
        
        return expr
    
    def is_operator_token(self, token: Token) -> bool:
        """Check if token is an operator."""
        if not token:
            return False
        
        operators = {
            TokenType.Plus, TokenType.Minus, TokenType.Star, TokenType.Slash, TokenType.Percent,
            TokenType.Lshift, TokenType.Rshift, TokenType.Lt, TokenType.Gt, TokenType.Le, TokenType.Ge,
            TokenType.Eq, TokenType.Ne, TokenType.And, TokenType.Or, TokenType.Xor, TokenType.Nand,
            TokenType.Not, TokenType.Amp, TokenType.Pipe, TokenType.Caret, TokenType.Tilde,
            TokenType.PlusAssign, TokenType.MinusAssign, TokenType.StarAssign, TokenType.SlashAssign,
            TokenType.PercentAssign, TokenType.LshiftAssign, TokenType.RshiftAssign, TokenType.AmpAssign,
            TokenType.PipeAssign, TokenType.CaretAssign, TokenType.AddrAssign, TokenType.SwapAssign,
            TokenType.PipeDiv, TokenType.Assign
        }
        
        return token.type in operators
    
    def parse_pipeline(self) -> Expression:
        """Parse pipeline expressions (>>> and <<<) with comprehensive support."""
        expr = self.parse_logical_or()
        
        if self.match(TokenType.PipelineRight) or self.match(TokenType.PipelineLeft):
            direction = self.previous().value
            expressions = [expr]
            
            # Continue collecting pipeline expressions
            # Parse the first expression after the pipeline operator
            expressions.append(self.parse_logical_or())
            
            # Continue while there are more pipeline operators
            while self.match(TokenType.PipelineRight) or self.match(TokenType.PipelineLeft):
                if self.previous().value != direction:
                    raise ParseError(f"Cannot mix pipeline operators {direction} and {self.previous().value}")
                expressions.append(self.parse_logical_or())
            
            return PipelineExpr(expr.line, expr.column, direction, expressions)
        
        return expr
    
    def is_at_statement_end(self) -> bool:
        """Check if current position is at the end of a statement."""
        return self.check(TokenType.Semicolon) or self.check(TokenType.EoF) or self.check(TokenType.Newline) or self.check(TokenType.Dedent)
    
    def parse_logical_or(self) -> Expression:
        """Parse logical OR expressions."""
        expr = self.parse_logical_xor()
        
        while self.match(TokenType.Or):
            operator = self.previous().value
            right = self.parse_logical_xor()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_xor(self) -> Expression:
        """Parse logical XOR expressions."""
        expr = self.parse_logical_nand()
        
        while self.match(TokenType.Xor):
            operator = self.previous().value
            right = self.parse_logical_nand()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_nand(self) -> Expression:
        """Parse logical NAND expressions."""
        expr = self.parse_logical_and()
        
        while self.match(TokenType.Nand):
            operator = self.previous().value
            right = self.parse_logical_and()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_logical_and(self) -> Expression:
        """Parse logical AND expressions."""
        expr = self.parse_equality()
        
        while self.match(TokenType.And):
            operator = self.previous().value
            right = self.parse_equality()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_equality(self) -> Expression:
        """Parse equality expressions."""
        expr = self.parse_comparison()
        
        while self.match(TokenType.Eq) or self.match(TokenType.Ne):
            operator = self.previous().value
            right = self.parse_comparison()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_comparison(self) -> Expression:
        """Parse comparison expressions."""
        expr = self.parse_bitwise_or()
        
        while self.match(TokenType.Lt) or self.match(TokenType.Gt) or \
              self.match(TokenType.Le) or self.match(TokenType.Ge):
            operator = self.previous().value
            right = self.parse_bitwise_or()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_or(self) -> Expression:
        """Parse bitwise OR expressions."""
        expr = self.parse_bitwise_xor()
        
        while self.match(TokenType.Pipe):
            operator = self.previous().value
            right = self.parse_bitwise_xor()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_xor(self) -> Expression:
        """Parse bitwise XOR expressions."""
        expr = self.parse_bitwise_and()
        
        while self.match(TokenType.Caret):
            operator = self.previous().value
            right = self.parse_bitwise_and()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_bitwise_and(self) -> Expression:
        """Parse bitwise AND expressions."""
        expr = self.parse_shift()
        
        while self.match(TokenType.Amp):
            operator = self.previous().value
            right = self.parse_shift()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_shift(self) -> Expression:
        """Parse shift expressions."""
        expr = self.parse_additive()
        
        while self.match(TokenType.Lshift) or self.match(TokenType.Rshift):
            operator = self.previous().value
            right = self.parse_additive()
            expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_additive(self) -> Expression:
        """Parse additive expressions."""
        expr = self.parse_multiplicative()
        
        while self.match(TokenType.Plus) or self.match(TokenType.Minus):
            operator = self.previous().value
            right = self.parse_multiplicative()
            if operator == '+':
                expr = AddExpr(expr.line, expr.column, expr, operator, right)
            else:
                expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_multiplicative(self) -> Expression:
        """Parse multiplicative expressions."""
        expr = self.parse_unary()
        
        while self.match(TokenType.Star) or self.match(TokenType.Slash) or \
              self.match(TokenType.Percent) or self.match(TokenType.PipeDiv):
            operator = self.previous().value
            right = self.parse_unary()
            if operator == '*':
                expr = MulExpr(expr.line, expr.column, expr, operator, right)
            else:
                expr = BinaryExpr(expr.line, expr.column, expr, operator, right)
        
        return expr
    
    def parse_unary(self) -> Expression:
        """Parse unary expressions."""
        if self.match(TokenType.Minus) or self.match(TokenType.Not) or \
           self.match(TokenType.Star) or \
           self.match(TokenType.NotKw) or self.match(TokenType.Await):
            operator = self.previous().value
            right = self.parse_unary()
            return UnaryExpr(right.line, right.column, operator, right)
        
        if self.match(TokenType.Tilde):
            # Check if this is a predicate expression: ~Type Name : Condition
            # or ~expr (bitwise not)
            # If next token looks like a predicate start, parse as predicate
            if self.is_predicate_start():
                 return self.parse_predicate_expr()
            
            operator = self.previous().value
            right = self.parse_unary()
            return UnaryExpr(right.line, right.column, operator, right)
        
        return self.parse_call()

    def is_predicate_start(self) -> bool:
        """Check if current token starts a predicate expression (~Type Name : ...)."""
        type_tokens = {
            TokenType.Int, TokenType.Float, TokenType.Bool, TokenType.String, TokenType.Char,
            TokenType.Array, TokenType.Darray, TokenType.Vector, TokenType.Dict, TokenType.Set,
            TokenType.Gc, TokenType.GcWeak, TokenType.Option, TokenType.Result,
            TokenType.WasmGc, TokenType.WasmStruct, TokenType.WasmArray, 
            TokenType.WasmExternref, TokenType.WasmAnyref,
            TokenType.Global, TokenType.Shared, TokenType.Local, TokenType.Constant, TokenType.Unified,
            TokenType.Func
        }
        
        # If it's a type keyword, it's a predicate
        if self.peek().type in type_tokens:
            return True
            
        # If it's an identifier, we need to peek ahead
        if self.check(TokenType.IDENTIFIER):
            # Check next token
            next_token = self.peek_next()
            if next_token:
                # ~ Identifier Identifier -> Predicate (Type Name)
                if next_token.type == TokenType.IDENTIFIER:
                    return True
                # ~ Identifier [ -> Predicate (Generic Type)
                if next_token.type == TokenType.Lbrack:
                    return True
                    
        return False

    def parse_predicate_expr(self) -> PredicateExpr:
        """Parse predicate expression: ~Type Name : Condition"""
        # Tilde already consumed
        start_token = self.previous()
        
        target_type = self.parse_type()
        
        name = self.consume(TokenType.IDENTIFIER, "Expected variable name in predicate").value
        
        self.consume(TokenType.Colon, "Expected ':' in predicate")
        
        # Parse condition (predicate)
        # Condition starts with ~ (e.g. ~value > 0)
        # But here ~ is part of the condition expression, not the start of another predicate decl
        condition = self.parse_expression()
        
        # Create PredicateExpr
        # Note: PredicateExpr definition in AST might differ. 
        # Test expects: ast.predicate == "value > 0" (string?)
        # Let's check AST definition if possible. Assuming it stores expression or string.
        # parserr.py imports PredicateExpr.
        # Based on test: assert ast.predicate == "value > 0"
        # It seems it expects a string representation of the condition?
        # Or maybe the test is checking string representation of the AST?
        # "str(condition)" might be what's needed.
        
        return PredicateExpr(start_token.line, start_token.column, name, str(condition))
    
    def parse_call(self) -> Expression:
        """Parse function calls, member access, array indexing, generic expressions, and predicates."""
        expr = self.parse_primary()
        
        while True:
            if self.match(TokenType.Lparen):
                expr = self.finish_call(expr)
            elif self.match(TokenType.Lbrack):
                # Check if this is array indexing or generic type arguments
                # Use lookahead to disambiguate: if content looks like a type, parse as generic; otherwise as index
                saved_pos = self.current
                is_generic = False
                
                if isinstance(expr, IdentifierExpr) and not self.check(TokenType.Rbrack):
                    # Check if next token is a type keyword
                    next_token = self.peek()
                    type_keywords = {
                        TokenType.Int, TokenType.Float, TokenType.Bool, TokenType.String, TokenType.Char,
                        TokenType.Array, TokenType.Darray, TokenType.Dict, TokenType.Set, TokenType.Vector,
                        TokenType.Gc, TokenType.GcWeak, TokenType.Result, TokenType.Option,
                        TokenType.Ref, TokenType.MutRef
                    }
                    if next_token.type in type_keywords:
                        is_generic = True
                    elif next_token.type == TokenType.IDENTIFIER:
                        # Could be a type name - check if it's a known type identifier
                        # For now, assume identifier after [ in expression context is more likely an index
                        # unless we're in a type annotation context (which we're not here)
                        is_generic = False
                
                self.current = saved_pos  # Restore position
                
                if is_generic and isinstance(expr, IdentifierExpr):
                    # Generic type expression like TypeName[T, U]
                    type_args = []
                    if not self.check(TokenType.Rbrack):
                        type_args.append(self.parse_type())
                        while self.match(TokenType.Comma):
                            type_args.append(self.parse_type())
                    self.consume(TokenType.Rbrack, "Expected ']' after type arguments")
                    expr = GenericExpr(expr.line, expr.column, expr, type_args)
                else:
                    # Array indexing: expr[index]
                    index = self.parse_expression()
                    self.consume(TokenType.Rbrack, "Expected ']' after index")
                    expr = IndexExpr(expr.line, expr.column, expr, index)
            elif self.match(TokenType.Dot):
                name = self.consume(TokenType.IDENTIFIER, "Expected property name after '.'").value
                expr = MemberExpr(expr.line, expr.column, expr, name)
            elif self.match(TokenType.ColonColon) or (self.check(TokenType.Colon) and self.peek_next() and self.peek_next().type == TokenType.Colon):
                if self.check(TokenType.Colon):
                    self.advance()
                    self.advance()
                name = self.consume(TokenType.IDENTIFIER, "Expected member name after '::'").value
                expr = MemberExpr(expr.line, expr.column, expr, name)
            elif self.match(TokenType.Predicate):
                # Predicate expression: expr ~ predicate
                predicate = self.consume(TokenType.IDENTIFIER, "Expected predicate name after '~'").value
                
                # Check for complex predicate with parameters
                if self.match(TokenType.Lparen):
                    # Complex predicate: expr ~ predicate(args...)
                    args = []
                    if not self.check(TokenType.Rparen):
                        args.append(self.parse_expression())
                        while self.match(TokenType.Comma):
                            args.append(self.parse_expression())
                    self.consume(TokenType.Rparen, "Expected ')' after predicate arguments")
                    # Create a complex predicate expression
                    predicate_expr = PredicateExpr(expr.line, expr.column, expr, predicate)
                    predicate_expr.args = args  # Add args attribute for complex predicates
                    expr = predicate_expr
                else:
                    # Simple predicate: expr ~ predicate
                    expr = PredicateExpr(expr.line, expr.column, expr, predicate)
            else:
                break
        
        return expr
    
    def parse_primary(self) -> Expression:
        """Parse primary expressions."""
        if self.match(TokenType.true):
            return LiteralExpr(self.previous().line, self.previous().column, True, "bool")
        if self.match(TokenType.false):
            return LiteralExpr(self.previous().line, self.previous().column, False, "bool")
        
        if self.match(TokenType.Int):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "int")
        
        if self.match(TokenType.Float):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "float")
        
        if self.match(TokenType.String):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "string")
        
        if self.match(TokenType.Char):
            return LiteralExpr(self.previous().line, self.previous().column, self.previous().value, "char")
        
        # Handle GPU intrinsics
        if self.match(TokenType.GpuThread):
            line, col = self.previous().line, self.previous().column
            args = []
            if self.match(TokenType.Lparen):
                if not self.check(TokenType.Rparen):
                    args.append(self.parse_expression())
                    while self.match(TokenType.Comma):
                        args.append(self.parse_expression())
                self.consume(TokenType.Rparen, "Expected ')'")
            return GpuIntrinsicExpr(line, col, "thread_id", args)
        elif self.match(TokenType.GpuSyncBlock):
            line, col = self.previous().line, self.previous().column
            args = []
            if self.match(TokenType.Lparen):
                self.consume(TokenType.Rparen, "Expected ')'")
            return GpuIntrinsicExpr(line, col, "sync_block", args)
        elif self.match(TokenType.GpuSyncGrid):
            line, col = self.previous().line, self.previous().column
            args = []
            if self.match(TokenType.Lparen):
                self.consume(TokenType.Rparen, "Expected ')'")
            return GpuIntrinsicExpr(line, col, "sync_grid", args)
        elif self.match(TokenType.GpuAtomic):
            return self.parse_gpu_atomic_expr()
        elif self.match(TokenType.GpuTransfer):
            return self.parse_gpu_transfer_expr()
        
        # Handle #requires_js(capability)
        if self.match(TokenType.RequiresJs):
            line, col = self.previous().line, self.previous().column
            args = []
            if self.match(TokenType.Lparen):
                if not self.check(TokenType.Rparen):
                    args.append(self.parse_expression())
                    while self.match(TokenType.Comma):
                        args.append(self.parse_expression())
                self.consume(TokenType.Rparen, "Expected ')' after arguments")
            
            # Extract capability from arguments if possible, or return a special expression
            capability = "unknown"
            if args and hasattr(args[0], 'js_capability'):
                capability = args[0].js_capability
            elif args and isinstance(args[0], CallExpr) and isinstance(args[0].callee, MemberExpr):
                # Handle dom::get_element_by_id pattern
                obj = args[0].callee.object
                if isinstance(obj, IdentifierExpr):
                    capability = obj.name
            
            # For now, return a JsCapabilityExpr that matches test expectations (if possible)
            # The test expects CallExpr with js_capability attribute
            # We can create a CallExpr and monkey-patch it, or better, return JsCapabilityExpr
            # and update tests. But let's try to match existing structure if possible.
            # JsCapabilityExpr is defined in AST nodes.
            return JsCapabilityExpr(line, col, capability, args, capability)
        
        # Handle WASM GC operations
        if self.match(TokenType.WasmAlloc):
            return self.parse_wasm_gc_operation_expr("alloc")
        elif self.match(TokenType.WasmPromote):
            return self.parse_wasm_gc_operation_expr("promote")
        elif self.match(TokenType.WasmDemote):
            return self.parse_wasm_gc_operation_expr("demote")
        elif self.match(TokenType.WasmCopy):
            return self.parse_wasm_gc_operation_expr("copy")
        elif self.match(TokenType.WasmArrayAlloc):
            return self.parse_wasm_gc_operation_expr("array_alloc")
        elif self.match(TokenType.WasmNull):
            return self.parse_wasm_gc_operation_expr("null")
        elif self.match(TokenType.JsCallback):
            return self.parse_js_capability_expr()
        
        # Handle GC expressions
        if self.match(TokenType.Gc):
            return self.parse_gc_expr(False)
        elif self.match(TokenType.GcWeak):
            return self.parse_gc_expr(True)
        
        if self.match(TokenType.Old):
            self.consume(TokenType.Lparen, "Expected '(' after old")
            expr = self.parse_expression()
            self.consume(TokenType.Rparen, "Expected ')' after old expression")
            return CallExpr(self.previous().line, self.previous().column, 
                          IdentifierExpr(self.previous().line, self.previous().column, "old"), [expr])

        if self.match(TokenType.IDENTIFIER):
            identifier = self.previous()
            
            # Handle old() expressions for verification (legacy check)
            if identifier.value == 'old':
                self.consume(TokenType.Lparen, "Expected '(' after old")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after old expression")
                return CallExpr(self.previous().line, self.previous().column, 
                              IdentifierExpr(self.previous().line, self.previous().column, "old"), [expr])
    
            # Check for Result/Option expressions
            if identifier.value == 'Ok':
                self.consume(TokenType.Lparen, "Expected '(' after Ok")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Ok expression")
                return ResultExpr(identifier.line, identifier.column, expr, True)
            elif identifier.value == 'Err':
                self.consume(TokenType.Lparen, "Expected '(' after Err")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Err expression")
                return ResultExpr(identifier.line, identifier.column, expr, False)
            elif identifier.value == 'Some':
                self.consume(TokenType.Lparen, "Expected '(' after Some")
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after Some expression")
                return OptionExpr(identifier.line, identifier.column, expr, True)
            elif identifier.value == 'None':
                return OptionExpr(identifier.line, identifier.column, None, False)
            elif identifier.value == 'match':
                return self.parse_match_expr()
            else:
                # Check for lambda expression: identifier => expression
                if self.match(TokenType.FatArrow):
                    # Simple lambda: x => expr
                    param = Param(identifier.value, None, False, None)
                    body_expr = self.parse_expression()
                    return LambdaExpr(identifier.line, identifier.column, [param], None, [ReturnStmt(body_expr.line, body_expr.column, body_expr)])
                # Check for StructInit: Identifier { field: value, ... }
                elif self.check(TokenType.Lbrace):
                    return self.parse_struct_init(identifier)
                else:
                    return IdentifierExpr(identifier.line, identifier.column, identifier.value)
        
        # Handle type keywords that can also be used as identifiers in expression context
        if self.match(TokenType.Array):
            # In expression context, "array" is likely a variable name, not a type
            array_token = self.previous()
            return IdentifierExpr(array_token.line, array_token.column, "array")
        
        if self.match(TokenType.Func):
            # In expression context, "func" might be an identifier (e.g. function call func())
            func_token = self.previous()
            return IdentifierExpr(func_token.line, func_token.column, "func")

        # Handle JS capabilities as identifiers
        if self.match(TokenType.Dom):
            return IdentifierExpr(self.previous().line, self.previous().column, "dom")
        if self.match(TokenType.Fetch):
            return IdentifierExpr(self.previous().line, self.previous().column, "fetch")
        if self.match(TokenType.Webcrypto):
            return IdentifierExpr(self.previous().line, self.previous().column, "webcrypto")

        # Handle GPU memory space keywords as identifiers in expression context
        if self.match(TokenType.Global):
            return IdentifierExpr(self.previous().line, self.previous().column, "global")
        if self.match(TokenType.Shared):
            return IdentifierExpr(self.previous().line, self.previous().column, "shared")
        if self.match(TokenType.Local):
            return IdentifierExpr(self.previous().line, self.previous().column, "local")
        if self.match(TokenType.Constant):
            return IdentifierExpr(self.previous().line, self.previous().column, "constant")
        if self.match(TokenType.Unified):
            return IdentifierExpr(self.previous().line, self.previous().column, "unified")
        
        if self.match(TokenType.Lparen):
            # Check for lambda expression: (params) -> return_type { body }
            if self.is_lambda_start():
                return self.parse_lambda_expr()
            else:
                expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after expression")
                return expr
        
        if self.match(TokenType.Ref):
            expr = self.parse_unary()
            return RefExpr(expr.line, expr.column, expr, False)
        
        if self.match(TokenType.MutRef):
            expr = self.parse_unary()
            return RefExpr(expr.line, expr.column, expr, True)
        
        # Add array literal parsing: [expr1, expr2, ...]
        if self.match(TokenType.Lbrack):
            return self.parse_array_literal()
        
        # Add dict literal parsing: {key1: value1, key2: value2, ...}
        if self.match(TokenType.Lbrace):
            # Check if this is a dict literal, set literal, or empty dict
            # Dict literal has key: value pairs
            # Set literal has value, value
            if self.check(TokenType.Rbrace):
                 # Empty dict {}
                 return self.parse_dict_literal()
            
            if self.is_dict_literal_start():
                return self.parse_dict_literal()
            elif self.is_set_literal_start():
                return self.parse_set_literal()
            else:
                raise ParseError(f"Unexpected token: '{'{'}' in expression context", self.peek())
        
        token = self.peek()
        token_value = token.value if token.value is not None else str(token.type)
        raise ParseError(f"Unexpected token: {token_value}", token)
    
    def parse_gc_expr(self, is_weak: bool) -> GcExpr:
        """Parse GC expression: gc[T](args) or gc<T>(args)"""
        gc_token = self.previous()
        
        # Parse type argument
        element_type = None
        if self.match(TokenType.Lbrack):
             element_type = self.parse_type()
             self.consume(TokenType.Rbrack, "Expected ']' after type argument")
        elif self.match(TokenType.Lt):
             element_type = self.parse_type()
             self.consume(TokenType.Gt, "Expected '>' after type argument")
        else:
             raise ParseError("Expected '[' or '<' after gc", self.peek())
             
        # Parse arguments
        self.consume(TokenType.Lparen, "Expected '(' after type argument")
        arguments = []
        if not self.check(TokenType.Rparen):
            arguments.append(self.parse_expression())
            while self.match(TokenType.Comma):
                arguments.append(self.parse_expression())
        self.consume(TokenType.Rparen, "Expected ')' after arguments")
        
        return GcExpr(gc_token.line, gc_token.column, element_type, arguments, is_weak)

    def is_lambda_start(self) -> bool:
        """Check if current position starts a lambda expression."""
        # Look ahead for pattern like (param: type) -> return_type {
        saved_pos = self.current
        try:
            # Skip parameters
            paren_count = 1
            while paren_count > 0 and not self.is_at_end():
                if self.check(TokenType.Lparen):
                    paren_count += 1
                elif self.check(TokenType.Rparen):
                    paren_count -= 1
                self.advance()
            
            # Check for -> or =>
            if self.check(TokenType.Arrow) or self.check(TokenType.FatArrow):
                return True
        finally:
            self.current = saved_pos
        return False
    
    def parse_lambda_expr(self) -> LambdaExpr:
        """Parse lambda expression: (params) -> return_type { body }"""
        lambda_token = self.previous()  # '(' token
        
        # Parse parameters (type annotation is optional for lambda parameters)
        params = []
        if not self.check(TokenType.Rparen):
            params.append(self.parse_lambda_param())
            while self.match(TokenType.Comma):
                params.append(self.parse_lambda_param())
        self.consume(TokenType.Rparen, "Expected ')' after lambda parameters")
        
        # Parse return type
        return_type = None
        if self.match(TokenType.Arrow):
            return_type = self.parse_type()
        elif self.match(TokenType.FatArrow):
            # FatArrow lambdas typically don't have explicit return types
            pass
        
        # Parse body - can be expression or block
        if self.match(TokenType.Lbrace):
            # Block body
            body = []
            while not self.check(TokenType.Rbrace) and not self.is_at_end():
                try:
                    body.append(self.parse_statement())
                except ParseError as e:
                    self.errors.append(e)
                    self.synchronize()
                    break
            self.consume(TokenType.Rbrace, "Expected '}' after lambda body")
        else:
            # Expression body
            expr = self.parse_expression()
            body = [ReturnStmt(expr.line, expr.column, expr)]
        
        return LambdaExpr(lambda_token.line, lambda_token.column, params, return_type, body)
    
    def parse_array_literal(self) -> ArrayLiteralExpr:
        """Parse array literal: [expr1, expr2, ...]"""
        lbracket_token = self.previous()  # '[' token
        
        elements = []
        if not self.check(TokenType.Rbrack):
            elements.append(self.parse_expression())
            while self.match(TokenType.Comma):
                elements.append(self.parse_expression())
        
        self.consume(TokenType.Rbrack, "Expected ']' after array elements")
        return ArrayLiteralExpr(lbracket_token.line, lbracket_token.column, elements)
    
    def parse_dict_literal(self) -> DictLiteralExpr:
        """Parse dict literal: {key1: value1, key2: value2, ...}"""
        lbrace_token = self.previous()  # '{' token
        
        pairs = []
        if not self.check(TokenType.Rbrace):
            # Parse first key-value pair
            key = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after dict key")
            value = self.parse_expression()
            pairs.append((key, value))
            
            # Parse additional pairs
            while self.match(TokenType.Comma):
                key = self.parse_expression()
                self.consume(TokenType.Colon, "Expected ':' after dict key")
                value = self.parse_expression()
                pairs.append((key, value))
        
        self.consume(TokenType.Rbrace, "Expected '}' after dict literal")
        return DictLiteralExpr(lbrace_token.line, lbrace_token.column, pairs)
    
    def parse_set_literal(self) -> SetLiteralExpr:
        """Parse set literal: {expr1, expr2, ...}"""
        lbrace_token = self.previous()
        
        elements = []
        if not self.check(TokenType.Rbrace):
            elements.append(self.parse_expression())
            while self.match(TokenType.Comma):
                elements.append(self.parse_expression())
        
        self.consume(TokenType.Rbrace, "Expected '}' after set literal")
        return SetLiteralExpr(lbrace_token.line, lbrace_token.column, elements)
    
    def parse_struct_init(self, struct_name_token: Token) -> StructInitExpr:
        """Parse struct initialization: StructName { field: value, ... }"""
        self.consume(TokenType.Lbrace, "Expected '{' after struct name")
        
        fields = []
        if not self.check(TokenType.Rbrace):
            # Parse first field
            field_name = self.consume(TokenType.IDENTIFIER, "Expected field name").value
            self.consume(TokenType.Colon, "Expected ':' after field name")
            value = self.parse_expression()
            fields.append((field_name, value))
            
            # Parse additional fields
            while self.match(TokenType.Comma):
                if self.check(TokenType.Rbrace):
                    break
                field_name = self.consume(TokenType.IDENTIFIER, "Expected field name").value
                self.consume(TokenType.Colon, "Expected ':' after field name")
                value = self.parse_expression()
                fields.append((field_name, value))
        
        self.consume(TokenType.Rbrace, "Expected '}' after struct initialization")
        return StructInitExpr(struct_name_token.line, struct_name_token.column, struct_name_token.value, fields)
    
    def is_dict_literal_start(self) -> bool:
        """Check if current position starts a dict literal vs a block."""
        # Look ahead to see if we have key: value pattern
        saved_pos = self.current
        try:
            # Skip whitespace/newlines
            while self.match(TokenType.Newline):
                continue
            
            if self.is_at_end():
                return False
            
            # Next token should be an expression (key)
            if not self.is_expression_start():
                return False
            
            # Skip the key expression (simplified check)
            # In a real implementation, we'd need to parse the expression
            # For now, just check if the next non-expression token is ':'
            
            # Reset and do a simple check
            self.current = saved_pos
            
            # Skip any leading whitespace/newlines
            while self.match(TokenType.Newline):
                continue
            
            # Check if we have something that looks like a key followed by ':'
            # This is a simplified heuristic
            token_count = 0
            found_colon = False
            
            while token_count < 5 and not self.is_at_end():  # Look ahead up to 5 tokens
                token = self.advance()
                token_count += 1
                
                if token.type == TokenType.Colon:
                    found_colon = True
                    break
                elif token.type in [TokenType.Comma, TokenType.Rbrace]:
                    break
            
            self.current = saved_pos
            return found_colon
            
        except:
            self.current = saved_pos
            return False
    
    def is_set_literal_start(self) -> bool:
        """Check if current position starts a set literal."""
        saved_pos = self.current
        try:
             while self.match(TokenType.Newline):
                 continue
             if self.is_at_end():
                 return False
             return self.is_expression_start()
        finally:
             self.current = saved_pos
    
    def is_expression_start(self) -> bool:
        """Check if current token can start an expression."""
        if self.is_at_end():
            return False
        
        current = self.peek()
        expression_starters = {
            TokenType.true, TokenType.false, TokenType.Int, TokenType.Float,
            TokenType.String, TokenType.Char, TokenType.IDENTIFIER,
            TokenType.Lparen, TokenType.Lbrack, TokenType.Lbrace,
            TokenType.Ref, TokenType.MutRef, TokenType.Minus, TokenType.Not,
            TokenType.Not
        }
        
        return current.type in expression_starters
    
    def parse_match_expr(self) -> MatchExpr:
        """Parse match expression: match expr { pattern => expr, ... }"""
        match_token = self.advance()  # consume 'match'
        
        # Parse the expression to match on
        expr = self.parse_expression()
        
        # Parse match arms
        self.consume(TokenType.Lbrace, "Expected '{' after match expression")
        
        arms = []
        while not self.check(TokenType.Rbrace) and not self.is_at_end():
            # Parse pattern
            pattern = self.parse_expression()
            
            # Parse '=>'
            self.consume(TokenType.Arrow, "Expected '=>' after match pattern")
            
            # Parse expression
            arm_expr = self.parse_expression()
            
            arms.append((pattern, arm_expr))
            
            # Check for comma (except for last arm)
            if not self.check(TokenType.Rbrace):
                self.consume(TokenType.Comma, "Expected ',' after match arm")
        
        self.consume(TokenType.Rbrace, "Expected '}' after match arms")
        
        return MatchExpr(match_token.line, match_token.column, expr, arms)
    
    def parse_block(self, end_tokens: List[TokenType] = None, max_depth: int = 100) -> List[Statement]:
        """Parse a block of statements until end tokens or dedent with depth protection."""
        if end_tokens is None:
            end_tokens = [TokenType.Fun, TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl]
        
        statements = []
        depth = 0
        
        # Consume initial Indent token if present (indentation-based block)
        if self.match(TokenType.Indent):
            pass  # Indent consumed, now parse block content
        
        while not self.is_at_end() and depth < max_depth:
            # Skip newlines but NOT Dedent tokens - they're important for block boundaries
            while self.match(TokenType.Newline) or self.match(TokenType.Indent):
                continue
            
            # Check for block termination conditions
            if self.check(TokenType.EoF):
                break
                
            # Check for end tokens FIRST (before Dedent)
            if any(self.check(token) for token in end_tokens):
                break
                
            if self.check(TokenType.Dedent):
                # Always consume the Dedent token
                self.advance()
                break
            
            # Handle nested structures with braces
            if self.check(TokenType.Lbrace):
                depth += 1
                self.advance()  # consume '{'
                continue
            elif self.check(TokenType.Rbrace):
                if depth == 0:
                    break
                depth -= 1
                self.advance()  # consume '}'
                continue
            
            try:
                stmt = self.parse_statement()
                if stmt:  # Only add non-null statements
                    statements.append(stmt)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                # Try to continue parsing the block
                continue
        
        if depth > 0:
            raise ParseError("Unclosed brace in block", self.peek())
            
        return statements
    
    def is_at_statement_start(self) -> bool:
        """Check if current position is at the start of a new statement/declaration."""
        if self.is_at_end():
            return False
            
        current_token = self.peek()
        
        # Check if we're at a token that starts a statement
        statement_starters = {
            TokenType.Target, TokenType.Plugin, TokenType.Requires, TokenType.Import,
            TokenType.Start, TokenType.End, TokenType.Temp, TokenType.Fun, TokenType.Class,
            TokenType.Trait, TokenType.Impl, TokenType.Const, TokenType.Del, TokenType.Ifblk,
            TokenType.Switch, TokenType.Forlp, TokenType.Whilelp, TokenType.Repeat,
            TokenType.Return, TokenType.Break, TokenType.Continue, TokenType.Unsafe, TokenType.Asm
        }
        
        if current_token.type in statement_starters:
            return True
            
        # Check for variable declarations (let/var)
        if current_token.type == TokenType.IDENTIFIER and current_token.value in ['let', 'var']:
            return True
            
        return False
    def match(self, token_type: TokenType) -> bool:
        """Check if current token matches given type."""
        if self.check(token_type):
            self.advance()
            return True
        return False
    
    def check(self, token_type: TokenType) -> bool:
        """Check if current token is of given type."""
        if self.is_at_end():
            return False
        return self.peek().type == token_type
    
    def advance(self) -> Token:
        """Consume current token and advance."""
        if not self.is_at_end():
            self.current += 1
        return self.previous()
    
    def is_at_end(self) -> bool:
        """Check if we've reached end of tokens."""
        return self.peek().type == TokenType.EoF
    
    def peek(self) -> Token:
        """Return current token without consuming it."""
        return self.tokens[self.current]
    
    def peek_next(self) -> Token:
        """Return next token without consuming it."""
        if self.current + 1 < len(self.tokens):
            return self.tokens[self.current + 1]
        return None
    
    def previous(self) -> Token:
        """Get previous token."""
        return self.tokens[self.current - 1]
    
    def consume(self, token_type: TokenType, message: str) -> Token:
        """Consume token of expected type or raise error."""
        if self.check(token_type):
            return self.advance()
        raise ParseError(message, self.peek())
    
    def consume_statement_end(self, message: str = "Expected ';' or newline after statement"):
        """Consume statement terminator (semicolon or newline)."""
        if self.match(TokenType.Semicolon):
            return
        if self.match(TokenType.Newline):
            return
        
        # Check for block terminators or continuation keywords that imply end of previous statement
        # Do not consume them, just return to let the caller handle them
        if any(self.check(token) for token in [TokenType.Until, TokenType.Elseblk, TokenType.Elsif, TokenType.Case, TokenType.Default, TokenType.Rbrace]):
            return
            
        # If neither, try to continue (for error recovery)
        # But raise error if we're clearly at end of statement
        if not self.is_at_end() and not self.check(TokenType.Dedent):
            raise ParseError(message, self.peek())
    
    def synchronize(self):
        """Synchronize parser after error to continue parsing."""
        self.advance()
        
        while not self.is_at_end():
            # Skip tokens until we find a synchronization point
            if self.previous().type == TokenType.Semicolon:
                return
            
            if self.previous().type == TokenType.Newline:
                # Check if next token starts a new statement
                if self.is_at_statement_start():
                    return
            
            # Check for block boundaries
            if self.previous().type in [TokenType.Rbrace, TokenType.Dedent]:
                return
            
            # Check for major statement starters
            if self.peek().type in [TokenType.Fun, TokenType.Class, TokenType.Trait, 
                                   TokenType.Impl, TokenType.Ifblk, TokenType.Whilelp,
                                   TokenType.Forlp, TokenType.Repeat, TokenType.Switch,
                                   TokenType.Return, TokenType.Break, TokenType.Continue,
                                   TokenType.Del, TokenType.Const, TokenType.Target,
                                   TokenType.Import, TokenType.Requires, TokenType.Plugin,
                                   TokenType.Start, TokenType.End]:
                return
            
            # Check for variable declarations and class fields
            if self.peek().type == TokenType.IDENTIFIER:
                next_next = self.tokens[self.current + 1] if self.current + 1 < len(self.tokens) else None
                if next_next and (next_next.value in ['let', 'var'] or next_next.type == TokenType.Colon):
                    return
            
            # Check for end of file
            if self.peek().type == TokenType.EoF:
                return
            
            self.advance()
    
    # Statement parsing methods (to be implemented)
    def parse_target_directive(self) -> TargetDirective:
        """Parse #target directive, supporting both single-line and multiline formats."""
        properties = {}
        
        # Check for multiline format (newline immediately after #target)
        if self.match(TokenType.Newline):
            # Multiline format: #target\nos = "linux"\narch = "x86-64"
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.match(TokenType.Newline):
                    continue
                if self.check(TokenType.Dedent):
                    break
                
                key = None
                if self.check(TokenType.IDENTIFIER):
                    key = self.advance().value
                elif self.check(TokenType.Gpu):
                    key = self.advance().value
                elif self.check(TokenType.Wasm):
                    key = self.advance().value
                
                if key:
                    if self.match(TokenType.Assign):
                        if self.check(TokenType.String):
                            value = self.advance().value
                        elif self.check(TokenType.IDENTIFIER):
                            value = self.advance().value
                        elif self.check(TokenType.Lbrack):
                            # Handle array values like ["cuda-12.4", "rocm-6.0"]
                            self.advance()  # [
                            array_values = []
                            while not self.check(TokenType.Rbrack) and not self.is_at_end():
                                if self.check(TokenType.String):
                                    array_values.append(self.advance().value)
                                if self.match(TokenType.Comma):
                                    continue
                            self.consume(TokenType.Rbrack, "Expected ']' after array values")
                            value = array_values
                        elif self.match(TokenType.true):
                            value = True
                        elif self.match(TokenType.false):
                            value = False
                        else:
                            # Skip invalid value
                            self.advance()
                            continue
                        properties[key] = value
                else:
                    self.advance()  # Skip other tokens
            return TargetDirective(self.previous().line, self.previous().column, properties)
        elif self.check(TokenType.String):
            # Single-line format: #target "string";
            target = self.consume(TokenType.String, "Expected target string after #target").value
            self.consume(TokenType.Semicolon, "Expected ';' after target directive")
            return TargetDirective(self.previous().line, self.previous().column, target)
        else:
            # Single-line key-value format: #target os="linux"
            while not self.is_at_end() and not self.check(TokenType.Newline) and not self.check(TokenType.Semicolon):
                key = None
                if self.check(TokenType.IDENTIFIER):
                    key = self.advance().value
                elif self.check(TokenType.Gpu):
                    key = self.advance().value
                elif self.check(TokenType.Wasm):
                    key = self.advance().value
                
                if key:
                    if self.match(TokenType.Assign):
                        if self.check(TokenType.String):
                            value = self.advance().value
                        elif self.check(TokenType.IDENTIFIER):
                            value = self.advance().value
                        elif self.check(TokenType.Lbrack):
                            self.advance() # [
                            array_values = []
                            while not self.check(TokenType.Rbrack) and not self.is_at_end():
                                if self.check(TokenType.String):
                                    array_values.append(self.advance().value)
                                if self.match(TokenType.Comma):
                                    continue
                            self.consume(TokenType.Rbrack, "Expected ']' after array values")
                            value = array_values
                        elif self.match(TokenType.true):
                            value = True
                        elif self.match(TokenType.false):
                            value = False
                        else:
                            # Skip invalid
                            self.advance()
                            continue
                        properties[key] = value
                else:
                    self.advance()
            
            # Consume terminator
            if self.match(TokenType.Semicolon):
                pass
            elif self.match(TokenType.Newline):
                pass
                
            return TargetDirective(self.previous().line, self.previous().column, properties)
    
    def parse_plugin_directive(self) -> PluginDirective:
        """Parse #plugin directive, supporting both single-line and multiline formats."""
        plugins = []
        
        # Check for multiline format (newline immediately after #plugin)
        if self.match(TokenType.Newline):
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.match(TokenType.Newline):
                    continue
                if self.check(TokenType.Dedent):
                    break
                
                plugin = ""
                if self.check(TokenType.String):
                    plugin = self.advance().value
                elif self.check(TokenType.IDENTIFIER):
                    plugin = self.advance().value
                    # Handle hyphenated identifiers and version specs
                    while self.match(TokenType.Minus) or self.match(TokenType.Eq) or self.match(TokenType.Dot):
                        op = self.previous().value
                        plugin += op
                        if self.check(TokenType.IDENTIFIER) or self.check(TokenType.Int):
                            plugin += str(self.advance().value)
                else:
                    self.advance() # Skip invalid
                    continue
                plugins.append(plugin)
            
            plugin_str = ",".join(plugins)
        else:
            # Single line
            plugin = ""
            if self.check(TokenType.String):
                plugin = self.consume(TokenType.String, "Expected plugin string after #plugin").value
            elif self.check(TokenType.IDENTIFIER):
                plugin = self.consume(TokenType.IDENTIFIER, "Expected plugin identifier").value
                # Handle hyphenated identifiers: safety-opt
                while self.match(TokenType.Minus):
                    plugin += "-"
                    plugin += self.consume(TokenType.IDENTIFIER, "Expected identifier after '-'").value
                # Handle version: linter==1.2
                if self.match(TokenType.Eq):
                    plugin += "="
                    if self.match(TokenType.Eq):
                        plugin += "="
                        if self.check(TokenType.Float) or self.check(TokenType.Int):
                             plugin += str(self.advance().value)
            else:
                raise ParseError("Expected plugin name (string or identifier) after #plugin", self.peek())
                
            self.consume_statement_end("Expected ';' or newline after plugin directive")
            plugin_str = plugin
            
        return PluginDirective(self.previous().line, self.previous().column, plugin_str)
    
    def parse_requires_directive(self) -> RequiresDirective:
        """Parse #requires directive, supporting both single-line and multiline formats."""
        # Skip newline if present (multiline format)
        if self.match(TokenType.Newline):
            # Multiline format: #requires\n"kernel32.dll"\n"libc.so.6"
            # Collect all string literals
            requires = []
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.match(TokenType.Newline):
                    continue
                if self.check(TokenType.Dedent):
                    break
                if self.check(TokenType.String):
                    requires.append(self.advance().value)
                else:
                    self.advance()  # Skip other tokens
            version = "\n".join(requires) if requires else ""
        else:
            # Single-line format: #requires "kernel32.dll";
            version = self.consume(TokenType.String, "Expected version string after #requires").value
            self.consume_statement_end("Expected ';' or newline after requires directive")
        return RequiresDirective(self.previous().line, self.previous().column, version)
    
    def parse_import_directive(self) -> ImportDirective:
        """Parse #import directive, supporting both single-line and multiline formats."""
        modules = []
        
        # Check for multiline format (newline immediately after #import)
        if self.match(TokenType.Newline):
            while not self.is_at_end() and not self.is_at_statement_start():
                if self.match(TokenType.Newline):
                    continue
                if self.check(TokenType.Dedent):
                    break
                
                # Allow IDENTIFIER or specific keywords that might be used in module paths
                if self.check(TokenType.IDENTIFIER) or self.check(TokenType.Vector) or self.check(TokenType.Set) or self.check(TokenType.Dict) or self.check(TokenType.Option) or self.check(TokenType.Result):
                    module_parts = []
                    module_parts.append(self.advance().value)
                    
                    while self.match(TokenType.Dot):
                        if self.check(TokenType.IDENTIFIER) or self.check(TokenType.Vector) or self.check(TokenType.Set) or self.check(TokenType.Dict) or self.check(TokenType.Option) or self.check(TokenType.Result):
                            module_parts.append(self.advance().value)
                        else:
                            raise ParseError("Expected module part", self.peek())
                    
                    module = ".".join(module_parts)
                    
                    # Check for 'as' keyword
                    if self.check(TokenType.IDENTIFIER) and self.peek().value == "as":
                        self.advance()  # consume 'as'
                        alias = self.consume(TokenType.IDENTIFIER, "Expected alias").value
                        module += f" as {alias}"
                    
                    modules.append(module)
                else:
                    self.advance() # Skip invalid
            
            module_str = "\n".join(modules)
            alias = None
        else:
            # Single-line format: #import std.core.cli;
            module_parts = []
            module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module name after #import").value)
            
            while self.match(TokenType.Dot):
                module_parts.append(self.consume(TokenType.IDENTIFIER, "Expected module part after '.'").value)
            
            module_str = ".".join(module_parts)
            alias = None
            
            # Check for 'as' keyword
            if self.check(TokenType.IDENTIFIER) and self.peek().value == "as":
                self.advance()  # consume 'as'
                alias = self.consume(TokenType.IDENTIFIER, "Expected alias after 'as'").value
            
            self.consume_statement_end("Expected ';' or newline after import directive")
            
        return ImportDirective(self.previous().line, self.previous().column, module_str, alias)
    
    def parse_start_directive(self) -> StartDirective:
        function = self.consume(TokenType.IDENTIFIER, "Expected function name after #start").value
        self.consume_statement_end("Expected ';' or newline after start directive")
        return StartDirective(self.previous().line, self.previous().column, function)
    
    def parse_end_directive(self) -> EndDirective:
        function = self.consume(TokenType.IDENTIFIER, "Expected function name after #end").value
        self.consume_statement_end("Expected ';' or newline after end directive")
        return EndDirective(self.previous().line, self.previous().column, function)
    
    def parse_requires_js_directive(self) -> RequiresJsDirective:
        """Parse #requires_js directive."""
        # Optional newline
        if self.match(TokenType.Newline):
            pass
            
        capabilities = []
        sandboxed = False
        
        while not self.check(TokenType.Semicolon) and not self.is_at_end():
            # Skip newlines between properties
            if self.match(TokenType.Newline):
                continue
                
            if self.match(TokenType.Capabilities):
                self.consume(TokenType.Assign, "Expected '=' after capabilities")
                self.consume(TokenType.Lbrack, "Expected '[' after capabilities")
                while not self.check(TokenType.Rbrack) and not self.is_at_end():
                    if self.check(TokenType.String):
                        capabilities.append(self.advance().value)
                    if self.match(TokenType.Comma):
                        continue
                self.consume(TokenType.Rbrack, "Expected ']' after capabilities list")
            elif self.match(TokenType.Sandboxed):
                self.consume(TokenType.Assign, "Expected '=' after sandboxed")
                sandboxed = self.match(TokenType.true)
            else:
                # Skip unknown tokens to prevent infinite loop
                self.advance()
        
        # Consume semicolon if present, or newline if that's the terminator
        if self.match(TokenType.Semicolon):
            pass  # Successfully consumed semicolon
        elif self.match(TokenType.Newline):
            pass  # Successfully consumed newline as terminator
        
        return RequiresJsDirective(self.previous().line, self.previous().column, capabilities, sandboxed)
    
    def parse_verification_directive(self) -> VerificationDirective:
        """Parse #verification directive."""
        self.consume(TokenType.Newline, "Expected newline after #verification")
        verification_level = "check"
        prover = None
        dump_obligations = False
        output_file = None
        
        while not self.check(TokenType.Semicolon) and not self.is_at_end():
            # Skip newlines between properties
            if self.match(TokenType.Newline):
                continue
                
            if self.match(TokenType.Level):
                self.consume(TokenType.Assign, "Expected '=' after level")
                verification_level = self.consume(TokenType.String, "Expected verification level").value
            elif self.match(TokenType.Prover):
                self.consume(TokenType.Assign, "Expected '=' after prover")
                prover = self.consume(TokenType.String, "Expected prover name").value
            elif self.check(TokenType.IDENTIFIER):
                name = self.peek().value
                if name == "dump_obligations":
                    self.advance()
                    self.consume(TokenType.Assign, "Expected '=' after dump_obligations")
                    dump_obligations = self.match(TokenType.true)
                elif name == "output_file":
                    self.advance()
                    self.consume(TokenType.Assign, "Expected '=' after output_file")
                    output_file = self.consume(TokenType.String, "Expected output file name").value
                else:
                    self.advance()
            else:
                # Skip unknown tokens to prevent infinite loop
                self.advance()
        
        # Consume semicolon if present, or newline if that's the terminator
        if self.match(TokenType.Semicolon):
            pass  # Successfully consumed semicolon
        elif self.match(TokenType.Newline):
            pass  # Successfully consumed newline as terminator
        
        return VerificationDirective(self.previous().line, self.previous().column, verification_level, prover, dump_obligations, output_file)
    
    def parse_constitutional_directive(self) -> ConstitutionalDirective:
        """Parse #constitution directive."""
        self.consume(TokenType.Newline, "Expected newline after #constitution")
        compliance_level = "standard"
        articles = []
        safeguards = []
        zero_cost_abstraction = True
        
        while not self.check(TokenType.Semicolon) and not self.is_at_end():
            # Skip newlines between properties
            if self.match(TokenType.Newline):
                continue
                
            if self.match(TokenType.Compliance):
                self.consume(TokenType.Assign, "Expected '=' after compliance")
                compliance_level = self.consume(TokenType.String, "Expected compliance level").value
            elif self.match(TokenType.Articles):
                self.consume(TokenType.Assign, "Expected '=' after articles")
                self.consume(TokenType.Lbrack, "Expected '[' after articles")
                while not self.check(TokenType.Rbrack) and not self.is_at_end():
                    if self.check(TokenType.String):
                        articles.append(self.advance().value)
                    if self.match(TokenType.Comma):
                        continue
                self.consume(TokenType.Rbrack, "Expected ']' after articles list")
            elif self.match(TokenType.Safeguards):
                self.consume(TokenType.Assign, "Expected '=' after safeguards")
                self.consume(TokenType.Lbrack, "Expected '[' after safeguards")
                while not self.check(TokenType.Rbrack) and not self.is_at_end():
                    if self.check(TokenType.String):
                        safeguards.append(self.advance().value)
                    if self.match(TokenType.Comma):
                        continue
                self.consume(TokenType.Rbrack, "Expected ']' after safeguards list")
            elif self.match(TokenType.IDENTIFIER) and self.previous().value == "zero_cost_abstraction":
                self.consume(TokenType.Assign, "Expected '=' after zero_cost_abstraction")
                zero_cost_abstraction = self.match(TokenType.true)
            else:
                # Skip unknown tokens to prevent infinite loop
                self.advance()
        
        # Consume semicolon if present, or newline if that's the terminator
        if self.match(TokenType.Semicolon):
            pass  # Successfully consumed semicolon
        elif self.match(TokenType.Newline):
            pass  # Successfully consumed newline as terminator
        
        return ConstitutionalDirective(self.previous().line, self.previous().column, compliance_level, articles, safeguards, zero_cost_abstraction)
    
    def parse_spec_type_declaration(self) -> SpecTypeDecl:
        """Parse spec type declarations."""
        spec_name = self.consume(TokenType.IDENTIFIER, "Expected spec type name").value
        self.consume(TokenType.Assign, "Expected '=' after spec type name")
        base_type = self.parse_type()
        self.consume(TokenType.Where, "Expected 'where' after base type")
        predicate = self.parse_expression()
        self.consume_statement_end("Expected ';' after spec type declaration")
        return SpecTypeDecl(self.previous().line, self.previous().column, spec_name, base_type, str(predicate))

    def parse_ghost_decl(self) -> VarDecl:
        """Parse ghost variable declaration: #[ghost] type name = value"""
        # #[ghost] is already consumed
        
        # Parse type
        type_annotation = self.parse_type()
        
        # Parse name
        name_token = self.consume(TokenType.IDENTIFIER, "Expected variable name")
        name = name_token.value
        
        initializer = None
        if self.match(TokenType.Assign):
            initializer = self.parse_expression()
            
        self.consume_statement_end("Expected ';' or newline after ghost declaration")
        
        decl = VarDecl(name_token.line, name_token.column, name, type_annotation, initializer, False)
        decl.is_ghost = True
        return decl
    
    def parse_kernel_launch(self) -> KernelLaunchStmt:
        """Parse kernel launch statements."""
        if self.check(TokenType.IDENTIFIER) or self.check(TokenType.Kernel):
            kernel_name = self.advance().value
        else:
            raise ParseError("Expected kernel name after launch", self.peek())
            
        self.consume(TokenType.Lparen, "Expected '(' after kernel name")
        
        # Parse kernel arguments
        arguments = []
        while not self.check(TokenType.Rparen) and not self.is_at_end():
            arguments.append(self.parse_expression())
            if self.match(TokenType.Comma):
                continue
        
        self.consume(TokenType.Rparen, "Expected ')' after kernel arguments")
        
        # Parse configuration
        config = {}
        if self.match(TokenType.Config):
            self.consume(TokenType.Colon, "Expected ':' after config")
            while not self.is_at_statement_start():
                if self.check(TokenType.IDENTIFIER):
                    key = self.advance().value
                    if self.match(TokenType.Assign):
                        if self.check(TokenType.IDENTIFIER):
                            value = self.advance().value
                        elif self.check(TokenType.Lparen):
                            # Handle tuple values like (1024, 1024)
                            self.advance()  # (
                            tuple_values = []
                            while not self.check(TokenType.Rparen) and not self.is_at_end():
                                if self.check(TokenType.Int):
                                    tuple_values.append(int(self.advance().value))
                                if self.match(TokenType.Comma):
                                    continue
                            self.consume(TokenType.Rparen, "Expected ')' after tuple values")
                            value = tuple(tuple_values)
                        else:
                            self.error(f"Expected value after '{key}=' in launch config")
                        config[key] = value
                else:
                    break
        
        return KernelLaunchStmt(self.previous().line, self.previous().column, kernel_name, arguments, config)
    
    def parse_wasm_struct_declaration(self) -> WasmStructDecl:
        """Parse WASM struct declarations."""
        # The WasmStruct token has already been consumed by parse_statement
        struct_name = self.consume(TokenType.IDENTIFIER, "Expected struct name").value
        self.consume(TokenType.Colon, "Expected ':' after struct name")
        
        # Optional newline
        if self.match(TokenType.Newline):
            pass
        
        fields = []
        # Parse fields until we encounter dedent or end of file
        while not self.check(TokenType.Dedent) and not self.is_at_end():
            # Skip indentation tokens
            if self.match(TokenType.Indent):
                continue
            
            if self.check(TokenType.Newline):
                self.advance()  # Skip empty lines
                continue
                
            if self.check(TokenType.IDENTIFIER) or self.check(TokenType.String) or self.check(TokenType.WasmGc) or self.check(TokenType.WasmStruct) or self.check(TokenType.WasmArray) or self.check(TokenType.WasmExternref) or self.check(TokenType.WasmAnyref) or self.check(TokenType.Global) or self.check(TokenType.Shared) or self.check(TokenType.Local) or self.check(TokenType.Constant) or self.check(TokenType.Unified):
                field_type = self.parse_type()
                field_name = self.consume(TokenType.IDENTIFIER, "Expected field name after type").value
                fields.append((field_name, field_type))
                
                # Skip newline after field definition
                if self.match(TokenType.Newline):
                    continue
            else:
                # Skip unknown tokens to prevent infinite loop
                self.advance()
        
        # Consume the dedent token if present
        if self.match(TokenType.Dedent):
            pass
        
        return WasmStructDecl(self.previous().line, self.previous().column, struct_name, fields)
    
    def parse_type_parameter(self) -> str:
        """Parse a type parameter with optional constraints."""
        param_name = self.consume(TokenType.IDENTIFIER, "Expected type parameter name").value
        
        # Check for constraints: T: Comparable + Send
        constraints = []
        if self.match(TokenType.Colon):
            # Parse first constraint
            if self.check(TokenType.IDENTIFIER):
                constraints.append(self.consume(TokenType.IDENTIFIER, "Expected constraint").value)
            
            # Parse additional constraints with +
            while self.match(TokenType.Plus):
                if self.check(TokenType.IDENTIFIER):
                    constraints.append(self.consume(TokenType.IDENTIFIER, "Expected constraint").value)
                else:
                    raise ParseError("Expected constraint after '+'")
        
        # Return parameter with constraints
        if constraints:
            return f"{param_name}: {' + '.join(constraints)}"
        return param_name
    
    def parse_generic_function_decl(self) -> FunctionDecl:
        """Parse generic function declaration with temp[T] prefix."""
        temp_token = self.previous()  # 'temp' token
        
        # Parse type parameters
        self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
        type_params = []
        if not self.check(TokenType.Rbrack):
            type_params.append(self.parse_type_parameter())
            while self.match(TokenType.Comma):
                type_params.append(self.parse_type_parameter())
        self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse 'fun' keyword
        self.consume(TokenType.Fun, "Expected 'fun' after type parameters")
        fun_token = self.previous()
        
        # Use shared helper
        name, params, return_type, attributes, is_static, is_method = self._parse_function_signature_internal(fun_token)
        
        # Handle where clause (constraints)
        if self.match(TokenType.Where):
            # Parse constraints: where T: Copy, U: Clone
            while True:
                # Parse type parameter name
                if self.check(TokenType.IDENTIFIER):
                    self.advance() # Name
                
                if self.match(TokenType.Colon):
                    # Parse bounds
                    while True:
                        if self.check(TokenType.IDENTIFIER):
                            self.advance() # Bound
                        
                        if self.match(TokenType.Plus):
                            continue
                        else:
                            break
                
                if self.match(TokenType.Comma):
                    continue
                else:
                    break

        # Check if this is an FFI function (no body)
        if any("ffi" in attr or "extern" in attr for attr in attributes):
            # FFI functions have no body
            body = []
            # Optional colon for FFI
            if self.match(TokenType.Colon):
                pass
            # Optional semicolon
            self.match(TokenType.Semicolon)
        else:
            # Parse function body
            self.consume(TokenType.Colon, "Expected ':' before function body")
            
            # Check if there's actually content for the body
            if self.check(TokenType.EoF):
                raise ParseError("Expected function body", self.peek())
            body = self.parse_block()
            if not body:
                raise ParseError("Expected function body", self.peek())
        
        return FunctionDecl(fun_token.line, fun_token.column, name, type_params, params, return_type, body, attributes, is_static, is_method)
    
    def _parse_function_signature_internal(self, fun_token: Token) -> tuple:
        """Internal helper to parse function signature."""
        # Parse function attributes: fun[async], fun[thread], fun[const], fun[ffi], fun[class]
        attributes = []
        if self.match(TokenType.Lbrack):
            # Parse attribute list: [async], [thread], [const], [ffi("lib.so", abi="cdecl")], [class]
            while True:
                if self.match(TokenType.Async):
                    attributes.append("async")
                elif self.match(TokenType.Thread):
                    attributes.append("thread")
                elif self.match(TokenType.Const):
                    attributes.append("const")
                elif self.match(TokenType.Ffi):
                    # Parse FFI attribute: ffi("lib.so", abi="cdecl")
                    ffi_attr = "ffi"
                    if self.match(TokenType.Lparen):
                        if self.check(TokenType.String):
                            lib_name = self.consume(TokenType.String, "Expected library name").value
                            ffi_attr = f'ffi("{lib_name}"'
                            # Check for abi parameter
                            if self.match(TokenType.Comma):
                                if self.check(TokenType.IDENTIFIER) and self.peek().value == "abi":
                                    self.advance()  # consume 'abi'
                                    self.consume(TokenType.Assign, "Expected '=' after 'abi'")
                                    abi = self.consume(TokenType.String, "Expected ABI name").value
                                    ffi_attr += f', abi="{abi}"'
                            self.consume(TokenType.Rparen, "Expected ')' after FFI parameters")
                            ffi_attr += ")"
                        else:
                            self.consume(TokenType.Rparen, "Expected ')' after FFI")
                    attributes.append(ffi_attr)
                elif self.match(TokenType.Class):
                    attributes.append("class")
                elif self.check(TokenType.IDENTIFIER) or self.check(TokenType.Gpu):
                     # Generic attribute parsing (e.g. gpu(kernel))
                    attr_name = self.advance().value
                    attr_str = attr_name
                    if self.match(TokenType.Lparen):
                        attr_str += "("
                        while not self.check(TokenType.Rparen) and not self.is_at_end():
                            if self.check(TokenType.IDENTIFIER):
                                attr_str += self.advance().value
                            elif self.check(TokenType.Kernel):
                                attr_str += self.advance().value
                            elif self.check(TokenType.Gpu):
                                attr_str += self.advance().value
                            elif self.check(TokenType.String):
                                attr_str += f'"{self.advance().value}"'
                            elif self.check(TokenType.Int):
                                attr_str += str(self.advance().value)
                            
                            if self.match(TokenType.Comma):
                                attr_str += ", "
                            elif self.match(TokenType.Assign):
                                attr_str += "="
                            elif not self.check(TokenType.Rparen):
                                # Skip unknown tokens in attribute args
                                self.advance()
                        self.consume(TokenType.Rparen, "Expected ')' after attribute arguments")
                        attr_str += ")"
                    attributes.append(attr_str)
                else:
                    break
                
                # Check for more attributes (comma-separated or just adjacent brackets?)
                # YADRO syntax seems to be fun[attr][attr] or fun[attr, attr]
                # The loop assumes [attr, attr].
                # If syntax is [attr][attr], we need to handle that.
                # Current code handles [attr, attr].
                if not self.match(TokenType.Comma):
                    break
            
            self.consume(TokenType.Rbrack, "Expected ']' after function attributes")
            
            # Check for another attribute block [attr]
            while self.match(TokenType.Lbrack):
                 # ... duplicate logic? or better structure?
                 # For now, let's assume we can have multiple bracket groups
                 # Recurse or loop?
                 # Let's just loop again for attributes
                 while True:
                    if self.match(TokenType.Async):
                        attributes.append("async")
                    elif self.match(TokenType.Thread):
                        attributes.append("thread")
                    elif self.match(TokenType.Const):
                        attributes.append("const")
                    elif self.match(TokenType.Ffi):
                        # ... FFI logic ...
                        ffi_attr = "ffi"
                        if self.match(TokenType.Lparen):
                            # ... same FFI logic ...
                            while not self.check(TokenType.Rparen) and not self.is_at_end():
                                self.advance()
                            self.consume(TokenType.Rparen, "Expected ')'")
                        attributes.append(ffi_attr)
                    elif self.match(TokenType.Class):
                        attributes.append("class")
                    elif self.check(TokenType.IDENTIFIER) or self.check(TokenType.Gpu):
                        # Generic attribute
                        attr_name = self.advance().value
                        attr_str = attr_name
                        if self.match(TokenType.Lparen):
                            attr_str += "("
                            while not self.check(TokenType.Rparen) and not self.is_at_end():
                                if self.check(TokenType.IDENTIFIER):
                                    attr_str += self.advance().value
                                elif self.check(TokenType.Kernel):
                                    attr_str += self.advance().value
                                elif self.check(TokenType.Gpu):
                                    attr_str += self.advance().value
                                elif self.check(TokenType.String):
                                    attr_str += f'"{self.advance().value}"'
                                elif self.check(TokenType.Int):
                                    attr_str += str(self.advance().value)
                                
                                if self.match(TokenType.Comma):
                                    attr_str += ", "
                                elif self.match(TokenType.Assign):
                                    attr_str += "="
                                elif not self.check(TokenType.Rparen):
                                    self.advance()
                            self.consume(TokenType.Rparen, "Expected ')'")
                            attr_str += ")"
                        attributes.append(attr_str)
                    else:
                        break
                    if not self.match(TokenType.Comma):
                        break
                 self.consume(TokenType.Rbrack, "Expected ']' after function attributes")

        
        # Parse function name
        name = self.consume(TokenType.IDENTIFIER, "Expected function name").value
        
        # Parse parameters
        self.consume(TokenType.Lparen, "Expected '(' after function name")
        params = []
        if not self.check(TokenType.Rparen):
            params.append(self.parse_param())
            while self.match(TokenType.Comma):
                params.append(self.parse_param())
        self.consume(TokenType.Rparen, "Expected ')' after parameters")
        
        # Parse return type
        return_type = None
        if self.match(TokenType.Arrow):
            return_type = self.parse_type()
        
        # Check if this is a method (has [class] attribute or &self parameter)
        is_method = "class" in attributes
        if not is_method and params:
            # Check if first parameter is &self
            first_param = params[0]
            if first_param.name == "self" and isinstance(first_param.type_annotation, ReferenceType):
                is_method = True
        
        # Determine if this is a static method (has [class] attribute)
        is_static = "class" in attributes

        return name, params, return_type, attributes, is_static, is_method

    def parse_function_decl(self) -> FunctionDecl:
        """Parse function declaration including FFI attributes."""
        fun_token = self.previous()  # 'fun' token
        
        name, params, return_type, attributes, is_static, is_method = self._parse_function_signature_internal(fun_token)
        
        # Handle where clause (constraints)
        if self.match(TokenType.Where):
            # Parse constraints: where T: Copy, U: Clone
            while True:
                # Parse type parameter name
                if self.check(TokenType.IDENTIFIER):
                    self.advance() # Name
                
                if self.match(TokenType.Colon):
                    # Parse bounds
                    while True:
                        if self.check(TokenType.IDENTIFIER):
                            self.advance() # Bound
                        
                        if self.match(TokenType.Plus):
                            continue
                        else:
                            break
                
                if self.match(TokenType.Comma):
                    continue
                else:
                    break
        
        # Check if this is an FFI function (no body)
        if any("ffi" in attr or "extern" in attr for attr in attributes):
            # FFI functions have no body
            body = []
            # Optional colon for FFI
            if self.match(TokenType.Colon):
                pass
            # Optional semicolon
            self.match(TokenType.Semicolon)
        else:
            # Parse function body
            self.consume(TokenType.Colon, "Expected ':' before function body")
            
            # Check if there's actually content for the body
            if self.check(TokenType.EoF):
                raise ParseError("Expected function body", self.peek())
            body = self.parse_block()
            if not body:
                raise ParseError("Expected function body", self.peek())
        
        return FunctionDecl(fun_token.line, fun_token.column, name, [], params, return_type, body, attributes, is_static, is_method)
    
    def parse_lambda_param(self) -> Param:
        """Parse lambda parameter (type annotation optional): x or x: Type"""
        # Parse parameter name
        name_token = self.consume(TokenType.IDENTIFIER, "Expected parameter name")
        name = name_token.value
        
        # Type annotation is optional for lambda parameters
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        else:
            # If no type annotation, create a placeholder type
            # In a full implementation, this would be inferred
            type_annotation = BasicType(name_token.line, name_token.column, "inferred")
        
        return Param(name, type_annotation, False, None)
    
    def parse_param(self) -> Param:
        """Parse function parameter."""
        # Check for reference parameters: &self, &mut self
        is_ref = False
        is_mut_ref = False
        if self.match(TokenType.Ref):
            is_ref = True
        elif self.match(TokenType.MutRef):
            is_mut_ref = True
            is_ref = True  # &mut is also a reference
        
        # Check for mut keyword before parameter name
        is_mutable_param = False
        if self.check(TokenType.IDENTIFIER) and self.peek().value == "mut":
            is_mutable_param = True
            self.advance()  # Consume the 'mut' keyword
        
        # Parse parameter name
        name_token = self.consume(TokenType.IDENTIFIER, "Expected parameter name")
        name = name_token.value
        
        # Parse type annotation (required for parameters, unless it's &self which is special)
        if name == "self" and is_ref:
            # &self or &mut self - create a reference type with 'self' as the base type name
            # For now, use a BasicType with name "self" wrapped in ReferenceType
            base_type = BasicType(name_token.line, name_token.column, "self")
            type_annotation = ReferenceType(name_token.line, name_token.column, base_type, is_mut_ref)
        else:
            # Type annotation is optional - check for colon
            if self.match(TokenType.Colon):
                type_annotation = self.parse_type()
                # If we had & or &mut, wrap the type in ReferenceType
                if is_ref:
                    type_annotation = ReferenceType(type_annotation.line, type_annotation.column, type_annotation, is_mut_ref)
            else:
                # No type annotation - use None or infer later
                type_annotation = None
        
        # Check for mutability
        is_mutable = is_mut_ref or is_mutable_param
        
        # Check for default value: param: Type = default
        default_value = None
        if self.match(TokenType.Assign):
            default_value = self.parse_expression()
        
        return Param(name, type_annotation, is_mutable, default_value)
    
    def parse_class_field(self) -> VarDecl:
        """Parse class field declaration: name: type [= initializer]"""
        name_token = self.consume(TokenType.IDENTIFIER, "Expected field name")
        name = name_token.value
        
        self.consume(TokenType.Colon, "Expected ':' after field name")
        
        # Parse type annotation
        type_annotation = self.parse_type()
        
        # Check for optional initializer
        initializer = None
        if self.match(TokenType.Assign):
            initializer = self.parse_expression()
        
        # Consume statement end
        self.consume_statement_end("Expected ';' or newline after field declaration")
        
        # Create a VarDecl to represent the field
        return VarDecl(name_token.line, name_token.column, name, type_annotation, initializer, False)
    
    def parse_class_decl(self, temp_params_consumed: List[str] = None) -> ClassDecl:
        """Parse class declaration including actor classes and arena allocation."""
        class_token = self.previous()  # 'class' token
        
        # Parse type parameters (generics)
        type_params = temp_params_consumed if temp_params_consumed else []
        
        # Check if we have temp[T] before the class token (already consumed temp in statement parsing)
        # Look for the pattern: temp [...] class
        if not temp_params_consumed and (self.current >= 3 and 
            self.tokens[0].type == TokenType.Temp and
            self.tokens[1].type == TokenType.Lbrack):
            # Find the closing bracket and extract type parameters
            i = 2  # Start after '['
            while i < len(self.tokens) and self.tokens[i].type != TokenType.Rbrack:
                if self.tokens[i].type == TokenType.IDENTIFIER:
                    type_params.append(self.tokens[i].value)
                i += 1
            # Verify that the next token after ] is class
            if i + 1 < len(self.tokens) and self.tokens[i + 1].type == TokenType.Class:
                pass  # Pattern matches, type_params extracted
            else:
                type_params = []  # Reset if pattern doesn't match
        elif self.match(TokenType.Temp):
            # Handle case where temp wasn't consumed yet (regular temp class syntax)
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse class name
        name = self.consume(TokenType.IDENTIFIER, "Expected class name").value
        
        # Parse attributes (actor, linear, etc.)
        attributes = []
        
        # First, use any pending attributes from class[attribute] syntax
        if hasattr(self, 'pending_class_attributes') and self.pending_class_attributes:
            attributes.extend(self.pending_class_attributes)
            self.pending_class_attributes.clear()
        
        # Then check for inline attributes like class Name actor:
        if self.match(TokenType.Actor):
            attributes.append("actor")
            # Actor classes may have additional actor-specific parameters
            if self.match(TokenType.Lparen):
                # Parse actor configuration: class[actor](max_concurrent = 10)
                while not self.check(TokenType.Rparen) and not self.is_at_end():
                    if self.match(TokenType.IDENTIFIER):
                        param_name = self.previous().value
                        self.consume(TokenType.Assign, "Expected '=' after actor parameter name")
                        param_value = self.parse_expression()
                        # Store actor parameters (simplified - would need proper AST node)
                        attributes.append(f"{param_name}={param_value}")
                    if not self.match(TokenType.Comma):
                        break
                self.consume(TokenType.Rparen, "Expected ')' after actor parameters")
        elif self.match(TokenType.Linear):
            attributes.append("linear")
        
        # Parse inheritance (optional)
        base_class = None
        if self.match(TokenType.Lparen):
            # Inheritance: class Name(Parent):
            # Base class can be a complex type like BaseContainer[T]
            base_class_start = self.current
            while not self.check(TokenType.Rparen) and not self.is_at_end():
                self.advance()
            base_class_end = self.current  # Include all tokens up to but not including )
            # Extract the base class name as a string
            base_class_tokens = self.tokens[base_class_start:base_class_end]
            base_class = ''.join(token.value for token in base_class_tokens)
            self.consume(TokenType.Rparen, "Expected ')' after base class name")
        
        # Parse class body
        self.consume(TokenType.Colon, "Expected ':' before class body")
        
        # Skip newline after colon
        if self.match(TokenType.Newline):
            pass
        
        fields = []
        methods = []
        nested_classes = []
        
        # Parse class body using block parsing
        # Note: We removed TokenType.Class from end tokens to allow nested classes
        # Also removed TokenType.Temp to allow generic methods
        body_statements = self.parse_block([TokenType.Trait, TokenType.Impl])
        
        for stmt in body_statements:
            if isinstance(stmt, VarDecl):
                # Field declaration (could be let/var or just name: type)
                fields.append(stmt)
            elif isinstance(stmt, FunctionDecl):
                # Method declaration
                methods.append(stmt)
            elif isinstance(stmt, ClassDecl):
                # Nested class declaration
                nested_classes.append(stmt)
            else:
                # Could be other statements, handle as needed
                pass
        
        return ClassDecl(class_token.line, class_token.column, name, type_params, fields, methods, attributes, base_class, nested_classes)
    
    def parse_trait_decl(self, temp_params_consumed: List[str] = None) -> TraitDecl:
        """Parse trait declaration."""
        trait_token = self.previous()  # 'trait' token
        
        # Parse trait name
        name = self.consume(TokenType.IDENTIFIER, "Expected trait name").value
        
        # Parse type parameters (generics)
        type_params = temp_params_consumed if temp_params_consumed else []
        
        if not temp_params_consumed and self.match(TokenType.Temp):
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Parse super traits (optional) - only if there's more content after colon or parentheses
        super_traits = []
        colon_consumed = False
        
        # Check for type parameters: trait Name(T) or trait Name[T]
        if self.match(TokenType.Lparen):
            # Parse type parameters in parentheses: trait Name(T)
            if not self.check(TokenType.Rparen):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rparen, "Expected ')' after type parameters")
            # Consume the body colon after type parameters
            self.consume(TokenType.Colon, "Expected ':' after trait declaration")
            colon_consumed = True
        elif self.match(TokenType.Lbrack):
            # Parse type parameters: trait Name[T]
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
            # Check for colon after type parameters
            if self.match(TokenType.Colon):
                colon_consumed = True
        elif self.match(TokenType.Colon):
            colon_consumed = True
            # Check if this is inheritance (has identifier after colon) or body (no identifier)
            if self.check(TokenType.IDENTIFIER):
                # This is inheritance: trait Name: SuperTrait:
                super_traits.append(self.consume(TokenType.IDENTIFIER, "Expected super trait name").value)
                while self.match(TokenType.Comma):
                    super_traits.append(self.consume(TokenType.IDENTIFIER, "Expected super trait name").value)
                # Consume the body colon after inheritance
                self.consume(TokenType.Colon, "Expected ':' after trait inheritance")
            # If no identifier after colon, this is the body colon (already consumed)
        
        # Parse trait body
        # Note: colon might have been consumed above in inheritance parsing
        if not colon_consumed:  # No colon consumed yet, need to consume body colon
            self.consume(TokenType.Colon, "Expected ':' before trait body")
        
        methods = []
        
        # Parse trait methods using block parsing
        # Skip initial newline after colon
        if self.match(TokenType.Newline):
            pass
            
        # Consume initial Indent token if present
        if self.match(TokenType.Indent):
            pass
            
        while not self.is_at_end():
            # Skip newlines
            while self.match(TokenType.Newline):
                continue
                
            if self.check(TokenType.Dedent) or self.check(TokenType.EoF):
                break
                
            if self.is_at_statement_start():
                if any(self.check(token) for token in [TokenType.Class, TokenType.Trait, TokenType.Temp, TokenType.Impl]):
                    break
            
            try:
                if self.match(TokenType.Fun):
                    # Parse method signature manually (traits don't have bodies)
                    fun_token = self.previous()
                    
                    # Parse method name
                    method_name = self.consume(TokenType.IDENTIFIER, "Expected method name").value
                    
                    # Parse parameters
                    params = []
                    self.consume(TokenType.Lparen, "Expected '(' after method name")
                    if not self.check(TokenType.Rparen):
                        params.append(self.parse_param())
                        while self.match(TokenType.Comma):
                            params.append(self.parse_param())
                    self.consume(TokenType.Rparen, "Expected ')' after parameters")
                    
                    # Parse return type
                    return_type = None
                    if self.match(TokenType.Arrow):
                        return_type = self.parse_type()
                    
                    # Create method without body
                    method = FunctionDecl(fun_token.line, fun_token.column, method_name, [], params, return_type, [], [], False, True)
                    methods.append(method)
                else:
                    break
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
                # Don't break on ParseError, try to continue parsing other methods
                continue
        
        if not methods and not super_traits:
            raise ParseError("Trait must have at least one method or super trait", self.peek())
            
        return TraitDecl(trait_token.line, trait_token.column, name, type_params, methods, super_traits)
    
    def parse_protocol_decl(self) -> ProtocolDecl:
        """Parse protocol declaration."""
        protocol_token = self.previous()
        
        name = self.consume(TokenType.IDENTIFIER, "Expected protocol name").value
        
        self.consume(TokenType.Colon, "Expected ':' before protocol body")
        
        # Handle block
        is_indented = False
        if self.match(TokenType.Newline):
            if self.check(TokenType.Indent):
                self.consume(TokenType.Indent, "Expected indent after protocol:")
                is_indented = True
        
        methods = []
        while not self.is_at_end():
            if is_indented and self.check(TokenType.Dedent):
                break
            
            # Skip empty lines
            if self.match(TokenType.Newline):
                continue
                
            if self.match(TokenType.Fun):
                # Protocol methods don't have bodies usually, but we reuse parse_function_decl
                # However, parse_function_decl expects a body or semicolon.
                # In test: fun compare(&self, other: &Self) -> int (newline)
                # Let's manually parse signature
                
                fun_token = self.previous()

                fun_name = self.consume(TokenType.IDENTIFIER, "Expected method name").value
                
                type_params = []
                # Check for generic method in protocol? Maybe not needed for this test
                
                self.consume(TokenType.Lparen, "Expected '(' after method name")
                params = []
                if not self.check(TokenType.Rparen):
                    params.append(self.parse_param())
                    while self.match(TokenType.Comma):
                        params.append(self.parse_param())
                self.consume(TokenType.Rparen, "Expected ')' after parameters")
                
                return_type = None
                if self.match(TokenType.Arrow):
                    return_type = self.parse_type()
                
                # Consume newline or semicolon
                self.consume_statement_end("Expected newline after protocol method")
                
                # Create a FunctionDecl with empty body
                methods.append(FunctionDecl(
                    line=fun_token.line,
                    column=fun_token.column,
                    name=fun_name,
                    type_params=[],
                    params=params,
                    return_type=return_type,
                    body=[],
                    attributes=[],
                    is_method=True
                ))
            else:
                break
        
        if is_indented:
            self.consume(TokenType.Dedent, "Expected dedent after protocol block")
            
        return ProtocolDecl(protocol_token.line, protocol_token.column, name, methods)

    def parse_impl_decl(self, temp_params_consumed: List[str] = None) -> ImplDecl:
        """Parse implementation block."""
        impl_token = self.previous()  # 'impl' token
        
        # Parse trait name
        trait_name = self.consume(TokenType.IDENTIFIER, "Expected trait name").value
        
        # Parse type parameters (generics)
        type_params = temp_params_consumed if temp_params_consumed else []
        
        if not temp_params_consumed and self.match(TokenType.Temp):
            self.consume(TokenType.Lbrack, "Expected '[' after 'temp'")
            if not self.check(TokenType.Rbrack):
                type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
                while self.match(TokenType.Comma):
                    type_params.append(self.consume(TokenType.IDENTIFIER, "Expected type parameter").value)
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
        
        # Expect 'for' keyword
        self.consume(TokenType.Forlp, "Expected 'for' in implementation declaration")
        
        # Parse type name (could be generic like vector[T] or a basic type like int)
        if self.check(TokenType.IDENTIFIER):
            type_name = self.consume(TokenType.IDENTIFIER, "Expected type name").value
        else:
            # Handle basic type keywords (int, string, etc.)
            type_token = self.advance()
            type_name = type_token.value
        
        # Check for generic type parameters like vector[T]
        if self.match(TokenType.Lbrack):
            type_name += "["
            if not self.check(TokenType.Rbrack):
                if self.check(TokenType.IDENTIFIER):
                    type_name += self.consume(TokenType.IDENTIFIER, "Expected type parameter").value
                else:
                    # Handle basic type keywords (int, string, etc.)
                    type_token = self.advance()
                    type_name += type_token.value
                while self.match(TokenType.Comma):
                    type_name += ","
                    if self.check(TokenType.IDENTIFIER):
                        type_name += self.consume(TokenType.IDENTIFIER, "Expected type parameter").value
                    else:
                        # Handle basic type keywords
                        type_token = self.advance()
                        type_name += type_token.value
            self.consume(TokenType.Rbrack, "Expected ']' after type parameters")
            type_name += "]"
        
        # Parse impl body
        self.consume(TokenType.Colon, "Expected ':' before impl body")
        
        methods = []
        
        # Handle block indentation
        is_indented = False
        if self.match(TokenType.Newline):
            if self.match(TokenType.Indent):
                is_indented = True
        
        while not self.is_at_end():
            # Skip newlines
            while self.match(TokenType.Newline):
                continue
            
            if is_indented and self.check(TokenType.Dedent):
                break
                
            if any(self.check(token) for token in [TokenType.Class, TokenType.Trait, TokenType.Impl]):
                break
            
            if self.match(TokenType.Fun):
                fun_token = self.previous()
                # Parse function signature
                name, params, return_type, attributes, is_static, is_method = self._parse_function_signature_internal(fun_token)
                
                body = []
                if self.match(TokenType.Colon):
                    # Parse function body
                    # Check if FFI (no body)
                    if any("ffi" in attr or "extern" in attr for attr in attributes):
                        pass
                    else:
                        body = self.parse_block()
                
                methods.append(FunctionDecl(fun_token.line, fun_token.column, name, [], params, return_type, body, attributes, is_static, is_method))
            elif self.is_at_end():
                break
            else:
                # Unexpected token in impl block
                # For robustness, we could skip it or raise error
                # Raise error to be safe
                raise ParseError(f"Unexpected token in impl block: {self.peek().value}", self.peek())
        
        if is_indented:
            self.consume(TokenType.Dedent, "Expected dedent after impl block")
        
        if not methods:
            raise ParseError("Implementation must have at least one method", self.peek())
            
        return ImplDecl(impl_token.line, impl_token.column, trait_name, type_name, type_params, methods)
    
    def parse_var_decl(self) -> VarDecl:
        """Parse variable declaration (let/var)."""
        decl_token = self.consume(TokenType.IDENTIFIER, "Expected 'let' or 'var'")
        is_mutable = decl_token.value == 'var'
        
        name = self.consume(TokenType.IDENTIFIER, "Expected variable name").value
        
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        
        initializer = None
        if self.match(TokenType.Assign):
            initializer = self.parse_expression()
        
        self.consume_statement_end("Expected ';' or newline after variable declaration")
        
        return VarDecl(decl_token.line, decl_token.column, name, type_annotation, initializer, is_mutable)
    
    def parse_type(self) -> Type:
        """Parse type annotations including arena allocation, GPU memory spaces, and WASM GC types."""
        # Handle function types: func(T1, T2) -> R
        if self.match(TokenType.Func):
            self.consume(TokenType.Lparen, "Expected '(' after func")
            params = []
            if not self.check(TokenType.Rparen):
                params.append(self.parse_type())
                while self.match(TokenType.Comma):
                    params.append(self.parse_type())
            self.consume(TokenType.Rparen, "Expected ')' after func parameters")
            
            self.consume(TokenType.Arrow, "Expected '->' after func parameters")
            return_type = self.parse_type()
            
            # Use self.previous() which is the last token of parse_type() - might not be ideal for start pos
            # But line/column are just for debugging usually
            return FuncType(return_type.line, return_type.column, params, return_type)

        # Handle GPU memory space types first
        if self.check(TokenType.Global) or self.check(TokenType.Shared) or self.check(TokenType.Local) or self.check(TokenType.Constant) or self.check(TokenType.Unified):
            return self.parse_gpu_memory_type()
        
        # Handle WASM GC types
        if self.match(TokenType.WasmGc):
            return self.parse_wasm_gc_type(TokenType.WasmGc)
        elif self.match(TokenType.WasmStruct):
            return self.parse_wasm_gc_type(TokenType.WasmStruct)
        elif self.match(TokenType.WasmArray):
            return self.parse_wasm_gc_type(TokenType.WasmArray)
        elif self.match(TokenType.WasmExternref):
            return self.parse_wasm_gc_type(TokenType.WasmExternref)
        elif self.match(TokenType.WasmAnyref):
            return self.parse_wasm_gc_type(TokenType.WasmAnyref)
        
        if self.match(TokenType.Int):
            return BasicType(self.previous().line, self.previous().column, "int")
        elif self.match(TokenType.Float):
            return BasicType(self.previous().line, self.previous().column, "float")
        elif self.match(TokenType.Bool):
            return BasicType(self.previous().line, self.previous().column, "bool")
        elif self.match(TokenType.String):
            return BasicType(self.previous().line, self.previous().column, "string")
        elif self.match(TokenType.Char):
            return BasicType(self.previous().line, self.previous().column, "char")
        elif self.match(TokenType.Array):
            return self.parse_array_type()
        elif self.match(TokenType.Darray):
            # Treat darray same as array for now, or use specific method
            # Reusing parse_array_type but keeping token type distinction if needed
            return self.parse_array_type()
        elif self.match(TokenType.Vector):
            return self.parse_vector_type()
        elif self.match(TokenType.Dict):
            return self.parse_dict_type()
        elif self.match(TokenType.Set):
            return self.parse_set_type()
        elif self.match(TokenType.Gc) or self.match(TokenType.GcWeak):
            return self.parse_gc_type()
        elif self.match(TokenType.Option):
            return self.parse_option_type()
        elif self.match(TokenType.Result):
            return self.parse_result_type()
        elif self.match(TokenType.IDENTIFIER):
            # Could be a basic type, generic type, or user-defined type
            type_name = self.previous().value
            
            # Check for generic type arguments
            if self.match(TokenType.Lbrack):
                type_args = []
                if not self.check(TokenType.Rbrack):
                    type_args.append(self.parse_type())
                    while self.match(TokenType.Comma):
                        type_args.append(self.parse_type())
                self.consume(TokenType.Rbrack, "Expected ']' after type arguments")
                return GenericType(self.previous().line, self.previous().column, type_name, type_args)
            else:
                return BasicType(self.previous().line, self.previous().column, type_name)
        elif self.match(TokenType.Ref):
            inner_type = self.parse_type()
            return ReferenceType(inner_type.line, inner_type.column, inner_type, False)
        elif self.match(TokenType.MutRef):
            inner_type = self.parse_type()
            return ReferenceType(inner_type.line, inner_type.column, inner_type, True)
        else:
            raise ParseError(f"Expected type, found: {self.peek().value}", self.peek())
    
    def parse_gc_type(self) -> GcType:
        """Parse garbage collected type: gc[T] or gc_weak[T] with advanced options."""
        gc_token = self.previous()
        is_weak = False
        
        # Check for gc_weak
        if gc_token.value == "gc_weak":
            is_weak = True
        
        self.consume(TokenType.Lbrack, "Expected '[' after gc")
        inner_type = self.parse_type()
        
        # Check for arena allocation parameters
        arena_params = None
        if self.match(TokenType.Comma):
            # Parse arena allocation parameters: gc[T, arena_id] or gc[T, size]
            if self.match(TokenType.IDENTIFIER):
                # Named arena: gc[T, "my_arena"]
                if self.match(TokenType.String):
                    arena_name = self.previous().value
                    arena_params = {"name": arena_name}
                else:
                    # Arena identifier: gc[T, main]
                    arena_id = self.previous().value
                    arena_params = {"id": arena_id}
            elif self.match(TokenType.Int):
                # Sized arena: gc[T, 1024]
                arena_size = self.previous().value
                arena_params = {"size": arena_size}
        
        self.consume(TokenType.Rbrack, "Expected ']' after gc type")
        
        gc_type = GcType(gc_token.line, gc_token.column, inner_type, is_weak)
        gc_type.arena_params = arena_params  # Add arena parameters
        return gc_type
    
    def parse_option_type(self) -> OptionType:
        """Parse Option type: Option[T]"""
        option_token = self.previous()
        self.consume(TokenType.Lbrack, "Expected '[' after 'Option'")
        some_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after Option type")
        return OptionType(option_token.line, option_token.column, some_type)
    
    def parse_result_type(self) -> ResultType:
        """Parse Result type: Result[T, E]"""
        result_token = self.previous()
        self.consume(TokenType.Lbrack, "Expected '[' after 'Result'")
        ok_type = self.parse_type()
        self.consume(TokenType.Comma, "Expected ',' after Result ok type")
        err_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after Result type")
        return ResultType(result_token.line, result_token.column, ok_type, err_type)
    
    def parse_array_type(self) -> ArrayType:
        """Parse array type: array[element_type] or array[element_type, size]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'array'")
        element_type = self.parse_type()
        size = None
        if self.match(TokenType.Comma):
            size = self.parse_expression()
        self.consume(TokenType.Rbrack, "Expected ']' after array type")
        return ArrayType(element_type.line, element_type.column, element_type, size)
    
    def parse_vector_type(self) -> VectorType:
        """Parse vector type: vector[element_type] or vector[element_type, size]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'vector'")
        element_type = self.parse_type()
        size = None
        if self.match(TokenType.Comma):
            size = self.parse_expression()
        self.consume(TokenType.Rbrack, "Expected ']' after vector type")
        return VectorType(element_type.line, element_type.column, element_type, size)
    
    def parse_dict_type(self) -> DictType:
        """Parse dict type: dict[key_type, value_type]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'dict'")
        key_type = self.parse_type()
        self.consume(TokenType.Comma, "Expected ',' after dict key type")
        value_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after dict type")
        return DictType(key_type.line, key_type.column, key_type, value_type)
    
    def parse_set_type(self) -> SetType:
        """Parse set type: set[element_type]"""
        self.consume(TokenType.Lbrack, "Expected '[' after 'set'")
        element_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after set type")
        return SetType(element_type.line, element_type.column, element_type)
    
    def parse_const_decl(self) -> ConstDecl:
        name_token = self.consume(TokenType.IDENTIFIER, "Expected constant name after 'const'")
        name = name_token.value
        
        type_annotation = None
        if self.match(TokenType.Colon):
            type_annotation = self.parse_type()
        
        self.consume(TokenType.Assign, "Expected '=' after constant declaration")
        initializer = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after constant declaration")
        
        return ConstDecl(
            name=name,
            type_annotation=type_annotation,
            initializer=initializer,
            line=name_token.line,
            column=name_token.column
        )
    
    def parse_del_stmt(self) -> DelStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after del statement")
        return DelStmt(expr.line, expr.column, expr)
    
    def parse_block_or_statement(self, end_tokens: Optional[List[TokenType]] = None) -> List[Statement]:
        """Parse a block or a single statement."""
        statements = []
        
        # Check for single line statement (no newline after colon)
        if not self.match(TokenType.Newline):
            # Parse single statement
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            return statements
        
        # Check for indented block
        self.consume(TokenType.Indent, "Expected indent after newline")
        
        while not self.check(TokenType.Dedent) and not self.is_at_end():
            if end_tokens and any(self.check(token) for token in end_tokens):
                break
                
            try:
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()
        
        self.consume(TokenType.Dedent, "Expected dedent after block")
        return statements

    def parse_if_stmt(self) -> IfStmt:
        """Parse if statement with proper block handling."""
        if_token = self.previous()  # 'if' token
        
        condition = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after if condition")
        
        # Parse then branch
        then_branch = self.parse_block_or_statement()
        
        # Parse elsif branches
        elif_branches = []
        while self.match(TokenType.Elsif):
            elif_condition = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after elsif condition")
            elif_body = self.parse_block_or_statement()
            elif_branches.append((elif_condition, elif_body))
        
        # Parse else branch
        else_branch = None
        if self.match(TokenType.Elseblk):
            self.consume(TokenType.Colon, "Expected ':' after 'else'")
            else_branch = self.parse_block_or_statement()
        
        return IfStmt(if_token.line, if_token.column, condition, then_branch, elif_branches, else_branch)
    
    def parse_switch_stmt(self) -> SwitchStmt:
        """Parse switch statement with proper block handling."""
        switch_token = self.previous()  # 'switch' token
        
        expression = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after switch expression")
        
        # Handle optional block (newline + indent)
        is_indented = False
        if self.match(TokenType.Newline):
            if self.check(TokenType.Indent):
                self.consume(TokenType.Indent, "Expected indent after switch:")
                is_indented = True
        
        cases = []
        default_case = None
        
        # Parse cases
        while not self.is_at_end() and not self.check(TokenType.Default):
            if is_indented and self.check(TokenType.Dedent):
                break
                
            if self.is_at_statement_start() and not self.check(TokenType.Case):
                break
                
            self.consume(TokenType.Case, "Expected 'case' in switch statement")
            case_expr = self.parse_expression()
            self.consume(TokenType.Colon, "Expected ':' after case expression")
            
            case_body = self.parse_block_or_statement([TokenType.Case, TokenType.Default])
            cases.append((case_expr, case_body))
        
        # Parse default case
        if self.match(TokenType.Default):
            self.consume(TokenType.Colon, "Expected ':' after default")
            default_case = self.parse_block_or_statement()
        
        if is_indented:
            self.consume(TokenType.Dedent, "Expected dedent after switch block")
        
        return SwitchStmt(switch_token.line, switch_token.column, expression, cases, default_case)
    
    def parse_for_stmt(self) -> ForStmt:
        """Parse for loop with proper block handling."""
        for_token = self.previous()  # 'for' token
        
        # Check for optional type annotation
        if self.check(TokenType.IDENTIFIER):
             if self.current + 1 < len(self.tokens) and self.tokens[self.current + 1].type == TokenType.IDENTIFIER:
                 self.parse_type() # Consume type
        elif self.check(TokenType.Int) or self.check(TokenType.Float) or self.check(TokenType.Bool) or \
             self.check(TokenType.String) or self.check(TokenType.Char):
             self.parse_type() # Consume built-in type
        
        var_token = self.consume(TokenType.IDENTIFIER, "Expected variable name after 'for'")
        variable = var_token.value
        
        self.consume(TokenType.In, "Expected 'in' after for loop variable")
        iterable = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after for loop iterable")
        
        # Parse for loop body using block parsing
        body = self.parse_block_or_statement()
        
        return ForStmt(for_token.line, for_token.column, variable, iterable, body)
    
    def parse_while_stmt(self) -> WhileStmt:
        """Parse while loop with proper block handling."""
        while_token = self.previous()  # 'while' token
        
        condition = self.parse_expression()
        self.consume(TokenType.Colon, "Expected ':' after while condition")
        
        # Parse while loop body using block parsing
        body = self.parse_block_or_statement()
        
        return WhileStmt(while_token.line, while_token.column, condition, body)
    
    def parse_repeat_stmt(self) -> RepeatStmt:
        """Parse repeat loop with proper block handling."""
        repeat_token = self.previous()  # 'repeat' token
        
        self.consume(TokenType.Colon, "Expected ':' after 'repeat'")
        
        # Parse repeat body using block parsing
        body = self.parse_block_or_statement([TokenType.Until])
        
        self.consume(TokenType.Until, "Expected 'until' after repeat body")
        until_condition = self.parse_expression()
        # No semicolon required after until condition (per spec)
        self.consume_statement_end("Expected ';' or newline after repeat-until statement")
        
        return RepeatStmt(repeat_token.line, repeat_token.column, body, until_condition)
    
    def parse_return_stmt(self) -> ReturnStmt:
        expr = None
        if not self.check(TokenType.Semicolon) and not self.check(TokenType.Newline) and not self.check(TokenType.Dedent) and not self.check(TokenType.EoF):
            expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after return statement")
        return ReturnStmt(self.previous().line, self.previous().column, expr)
    
    def parse_break_stmt(self) -> BreakStmt:
        self.consume_statement_end("Expected ';' or newline after break statement")
        return BreakStmt(self.previous().line, self.previous().column)
    
    def parse_continue_stmt(self) -> ContinueStmt:
        self.consume_statement_end("Expected ';' or newline after continue statement")
        return ContinueStmt(self.previous().line, self.previous().column)
    
    def parse_unsafe_stmt(self) -> UnsafeStmt:
        """Parse unsafe block."""
        self.consume(TokenType.Colon, "Expected ':' after 'unsafe'")
        
        statements = self.parse_block()
        
        return UnsafeStmt(statements[0].line if statements else 1, statements[0].column if statements else 1, statements)
    
    def parse_asm_stmt(self) -> AsmStmt:
        """Parse assembly statement with comprehensive support."""
        self.consume(TokenType.Colon, "Expected ':' after 'asm'")
        
        # Parse assembly template (string)
        template = self.consume(TokenType.String, "Expected assembly template string").value
        
        # Parse inputs, outputs, and clobbers
        inputs = []
        outputs = []
        clobbers = []
        
        # Parse input constraints: "r"(expr)
        while self.match(TokenType.String) and self.previous().value.startswith('"'):
            constraint = self.previous().value
            if self.match(TokenType.Lparen):
                input_expr = self.parse_expression()
                self.consume(TokenType.Rparen, "Expected ')' after assembly input expression")
                inputs.append((constraint, input_expr))
            else:
                break
        
        # Parse output constraints: "=r"(variable)
        while self.match(TokenType.String) and self.previous().value.startswith('"='):
            constraint = self.previous().value
            if self.match(TokenType.Lparen):
                if self.match(TokenType.IDENTIFIER):
                    output_var = self.previous().value
                    self.consume(TokenType.Rparen, "Expected ')' after assembly output variable")
                    outputs.append((constraint, output_var))
                else:
                    raise ParseError("Expected variable name for assembly output")
            else:
                break
        
        # Parse clobbers: "cc", "memory"
        while self.match(TokenType.String):
            clobber = self.previous().value
            if clobber.startswith('"') and not clobber.startswith('"='):
                clobbers.append(clobber)
            else:
                break
        
        return AsmStmt(template, inputs, outputs, clobbers)
    
    def parse_expr_stmt(self) -> ExprStmt:
        expr = self.parse_expression()
        self.consume_statement_end("Expected ';' or newline after expression")
        return ExprStmt(expr.line, expr.column, expr)
    
    def finish_call(self, callee: Expression) -> CallExpr:
        """Finish parsing a function call."""
        arguments = []
        
        if not self.check(TokenType.Rparen):
            arguments.append(self.parse_expression())
            while self.match(TokenType.Comma):
                arguments.append(self.parse_expression())
        
        self.consume(TokenType.Rparen, "Expected ')' after arguments")
        return CallExpr(callee.line, callee.column, callee, arguments)
    
    def parse_gpu_atomic_expr(self) -> GpuIntrinsicExpr:
        """Parse GPU atomic expressions like #gpu_atomic("add", target, value, Acquire)."""
        self.consume(TokenType.Lparen, "Expected '(' after #gpu_atomic")
        
        # Parse atomic operation type
        op_type = self.consume(TokenType.String, "Expected atomic operation type").value
        
        # Consume comma if present
        if self.match(TokenType.Comma):
            pass
        
        # Parse arguments
        args = []
        while not self.check(TokenType.Rparen) and not self.is_at_end():
            args.append(self.parse_expression())
            if self.match(TokenType.Comma):
                continue
        
        self.consume(TokenType.Rparen, "Expected ')' after GPU atomic arguments")
        return GpuIntrinsicExpr(self.previous().line, self.previous().column, op_type, args)
    
    def parse_gpu_transfer_expr(self) -> MemoryTransferExpr:
        """Parse GPU transfer expressions like #gpu_transfer(data)."""
        self.consume(TokenType.Lparen, "Expected '(' after #gpu_transfer")
        argument = self.parse_expression()
        self.consume(TokenType.Rparen, "Expected ')' after GPU transfer argument")
        return MemoryTransferExpr(self.previous().line, self.previous().column, "to_device", argument)
    
    def parse_wasm_gc_operation_expr(self, operation: str) -> WasmGcOperationExpr:
        """Parse WASM GC operation expressions."""
        
        args = []
        if operation == "array_alloc":
            # Parse type parameter for array_alloc
            self.consume(TokenType.Lbrack, "Expected '[' after array_alloc")
            type_arg = self.parse_type()
            self.consume(TokenType.Rbrack, "Expected ']' after array_alloc type")
            args.append(type_arg)
        
        self.consume(TokenType.Lparen, "Expected '(' after WASM GC operation")
        if operation != "null":
            args.append(self.parse_expression())
        self.consume(TokenType.Rparen, "Expected ')' after WASM GC operation")
        
        return WasmGcOperationExpr(self.previous().line, self.previous().column, operation, args, operation)
    
    def parse_js_capability_expr(self) -> JsCapabilityExpr:
        """Parse JS capability expressions."""
        self.consume(TokenType.Lparen, "Expected '(' after js_callback::wrap")
        argument = self.parse_expression()
        self.consume(TokenType.Rparen, "Expected ')' after js_callback::wrap")
        return JsCapabilityExpr(self.previous().line, self.previous().column, "wrap", [argument], "dom")
    
    def parse_gpu_memory_type(self) -> MemorySpaceType:
        """Parse GPU memory space types."""
        if self.match(TokenType.Global):
            space = "global"
        elif self.match(TokenType.Shared):
            space = "shared"
        elif self.match(TokenType.Local):
            space = "local"
        elif self.match(TokenType.Constant):
            space = "constant"
        elif self.match(TokenType.Unified):
            space = "unified"
        else:
            raise ParseError("Expected GPU memory space (global, shared, local, constant, unified)", self.peek())
        
        self.consume(TokenType.Lbrack, "Expected '[' after memory space")
        element_type = self.parse_type()
        self.consume(TokenType.Rbrack, "Expected ']' after memory space type")
        
        return MemorySpaceType(self.previous().line, self.previous().column, space, element_type)
    
    def parse_wasm_gc_type(self, matched_token: TokenType) -> WasmGcType:
        """Parse WebAssembly GC heap types."""
        if matched_token == TokenType.WasmGc:
            gc_type = "reference"
            self.consume(TokenType.Lbrack, "Expected '[' after wasm_gc")
            element_type = self.parse_type()
            self.consume(TokenType.Rbrack, "Expected ']' after wasm_gc type")
            return WasmGcType(self.previous().line, self.previous().column, gc_type, element_type)
        elif matched_token == TokenType.WasmStruct:
            gc_type = "struct"
            # Parse struct name
            if self.check(TokenType.IDENTIFIER):
                struct_name = self.advance().value
                return WasmGcType(self.previous().line, self.previous().column, gc_type, None)
            else:
                raise ParseError("Expected struct name after wasm_struct", self.peek())
        elif matched_token == TokenType.WasmArray:
            gc_type = "array"
            self.consume(TokenType.Lbrack, "Expected '[' after wasm_array")
            element_type = self.parse_type()
            self.consume(TokenType.Rbrack, "Expected ']' after wasm_array type")
            return WasmGcType(self.previous().line, self.previous().column, gc_type, element_type)
        elif matched_token == TokenType.WasmExternref:
            return WasmGcType(self.previous().line, self.previous().column, "externref", None)
        elif matched_token == TokenType.WasmAnyref:
            return WasmGcType(self.previous().line, self.previous().column, "anyref", None)
        else:
            raise ParseError("Expected WASM GC type (wasm_gc, wasm_struct, wasm_array, wasm_externref, wasm_anyref)", self.peek())
