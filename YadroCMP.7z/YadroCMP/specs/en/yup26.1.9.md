# YUP 26.1.9: WebAssembly GC Integration Standard

**Metadata**  
YUP ID: 26.1.9  
Title: WebAssembly GC Integration Standard  
Author: CyrOil   
Status: Proposed  
Created: 2026-02-02  
Governs: YADRO Language Specification v0.2.0+  
Supersedes: N/A  
Constitutional Alignment: YUP 26.1.3 (Articles I.3, II.1, II.2, III.2, IV.2, V.Pillar1)  

---

## Abstract

This standard defines the integration of WebAssembly GC (garbage-collected heap types) into the YADRO ecosystem, enabling seamless execution of YADRO programs in browser and WASM runtime environments while preserving constitutional guarantees of static verification, explicit intent, and zero-cost abstraction. YUP 26.1.9 introduces explicit type annotations for WASM GC heap objects, a dual-heap memory model that bridges YADRO's linear ownership semantics with WASM's tracing GC, and compile-time enforcement of safe JS/WASM FFI boundaries—all without compromising YADRO's foundational ownership model or introducing hidden runtime costs.

---

## 1. Constitutional Foundation

WebAssembly GC presents a fundamental tension with YADRO's linear ownership model (Article V.Pillar1). This standard resolves this tension through explicit modeling rather than abstraction:

| Constitutional Principle | WASM GC Implementation Strategy |
|--------------------------|---------------------------------|
| **Article I.3 (Types Describe Behavior)** | WASM GC heap types explicitly marked (`wasm_gc[T]`); lifetimes tracked separately from linear memory |
| **Article II.1 (No Magic)** | No implicit promotion of linear types to GC heap; all GC allocations explicit via `wasm_gc::alloc()` |
| **Article II.2 (Declarative Configuration)** | Target declaration `#target wasm=...` required; GC features opt-in per module |
| **Article III.2 (Seamless Interoperation)** | Zero-cost conversion between linear and GC representations where semantically safe |
| **Article IV.2 (Modular Reasoning)** | GC heap boundaries enforced at module interfaces; JS FFI requires explicit capability declarations |
| **Article V.Pillar1 (Ownership Default)** | Linear types remain default; WASM GC is an *explicit opt-in* for interoperability scenarios |

---

## 2. Target Declaration & Configuration

### 2.1 WASM Target Specification (`#target` extension)

```yadro
// WASM with GC support (WASM MVP + GC proposal)
#target
arch = "wasm32"
wasm = "gc-2.0"           // WASM GC proposal version
wasm_features = [
    "bulk-memory",
    "reference-types",
    "gc",
    "typed-gc"
]

// WASM without GC (linear memory only)
#target
arch = "wasm32"
wasm = "mvp"              // WASM MVP (no GC)

// Hybrid target (WASM + JS interop)
#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true             // Enable JavaScript FFI
```

### 2.2 Package Manifest Configuration (`main.toml`)

```toml
[package]
name = "web-ui-components"
version = "1.0.0"

[build]
targets = [
  "wasm32-wasi+gc-2.0",    # WASI runtime with GC
  "wasm32-browser+gc-2.0"  # Browser runtime with JS FFI
]

[wasm.gc]
enabled = true
max_heap_size = "256MB"    # Optional heap size constraint
conservative_stack_scanning = false  # Require precise roots

[wasm.js_ffi]
allowed = ["dom", "fetch", "webcrypto"]  # Explicit JS capabilities
sandboxed = true          # Enforce capability boundaries
```

---

## 3. WASM GC Type System Extensions

### 3.1 WASM GC Heap Types (Constitutional Article I.3 Enforcement)

```yadro
// WASM GC heap reference (distinct from YADRO's native gc<T>)
wasm_gc[T]                // Reference to object in WASM GC heap
wasm_struct[T]            // WASM struct type (fixed layout)
wasm_array[T]             // WASM array type (homogeneous)
wasm_externref            // External reference (JS object)
wasm_anyref               // Universal reference type

// Example: WASM GC struct definition
wasm_struct Person:
    string name           // Stored in WASM GC heap
    u32 age
    wasm_gc[Person] parent  // Cyclic reference allowed in GC heap

// WASM GC array
wasm_array[u32] numbers = wasm_gc::array_alloc[u32](100)
```

**Constitutional Safeguard**: `wasm_gc[T]` is *distinct* from YADRO's native `gc[T]` (managed heap). The compiler statically enforces:
- No implicit conversion between linear memory and WASM GC heap
- No mixing of ownership semantics (`&T` references cannot cross heap boundaries)
- All WASM GC allocations explicitly marked with `wasm_gc::` prefix

### 3.2 Dual-Heap Memory Model

```
┌─────────────────────────────────────────────────────┐
│                 YADRO Runtime                        │
├──────────────────┬──────────────────┬───────────────┤
│ Linear Memory    │ Native GC Heap   │ WASM GC Heap  │
│ (Article V.P1)   │ (gc<T>)          │ (wasm_gc<T>)  │
├──────────────────┼──────────────────┼───────────────┤
│ • Unique ownership│ • Ref-counted    │ • Tracing GC  │
│ • &T/&mut T refs  │ • Manual cycles  │ • Cycles OK   │
│ • Zero-cost       │ • Moderate cost  │ • Runtime cost│
│ • Deterministic   │ • Deterministic  │ • Non-det.    │
└──────────────────┴──────────────────┴───────────────┘
         │                   │                  │
         └─────────┬─────────┴─────────┬────────┘
                   │                   │
          Explicit conversion    Explicit conversion
          (zero-cost where safe) (cost apparent in type)
```

**Constitutional Enforcement** (Article II.3):
- Conversions between heaps carry explicit cost signatures
- Non-deterministic GC behavior acknowledged via `#[non_deterministic]` attribute
- No hidden heap promotions—programmer intent always explicit

---

## 4. Ownership Semantics Across Heap Boundaries

### 4.1 Linear → WASM GC Conversion (Explicit Promotion)

```yadro
// Linear memory value (unique ownership)
Person linear_person = Person.new("Alice", 30, None)

// Explicit promotion to WASM GC heap
// Constitutional: ownership moves, linear_person invalidated
wasm_gc[Person] gc_person = wasm_gc::promote(linear_person)

// INVALID: Use after promotion (rejected by compiler)
// cli.print(linear_person.name)  // ERROR: value moved to GC heap

// Alternative: Copy semantics (requires #Copy trait)
#[derive(Copy)]
struct SimpleData:
    u32 id
    u32 flags

SimpleData linear_data = SimpleData{1, 0}
wasm_gc[SimpleData] gc_data = wasm_gc::copy(linear_data)
// linear_data remains valid (copy semantics)
```

### 4.2 WASM GC → Linear Conversion (Explicit Demotion)

```yadro
// Demotion requires ownership transfer from GC heap
// Constitutional: GC reference invalidated after demotion
Person linear_person = wasm_gc::demote(gc_person)?

// Demotion may fail if object has multiple references
// (WASM GC cannot guarantee unique ownership)
switch wasm_gc::try_demote(gc_person):
    case Ok(person):
        // Successfully moved to linear memory
        process(person)
    case Err(MultipleReferences):
        // Cannot demote—object still referenced elsewhere
        cli.print("Object has multiple GC references")
```

**Constitutional Safeguard** (Article I.1): The compiler statically verifies:
- No dangling references after heap transitions
- Demotion only permitted when uniqueness can be proven (via reference counting or static analysis)
- All heap boundary crossings explicit in source code

---

## 5. JavaScript FFI with Constitutional Safety

### 5.1 Explicit Capability Model (Article II.2)

```yadro
// Declare required JS capabilities explicitly
#requires_js
capabilities = ["dom", "fetch"]

// JS function import with explicit effect signature
fun[ffi("js")] fetch_url(string url) -> Task[wasm_externref]
effects:
    network_access   // Explicit network effect
    may_block        // Explicit blocking behavior

// DOM manipulation with capability enforcement
fun[ffi("js")] create_element(string tag) -> wasm_externref
requires_capabilities = ["dom"]  // Constitutional: capability check at compile time
```

### 5.2 Type-Safe JS Interop

```yadro
// Wrap JS objects in capability-safe wrappers
class[linear] DomElement:
    wasm_externref raw_element
    
    fun[class] set_text(&mut self, string text):
        #requires_js(dom::set_text(self.raw_element, text))
    
    // Destructor releases JS reference
    sfun drop(&mut self):
        #requires_js(dom::release(self.raw_element))

// Safe JS callback registration
fun setup_click_handler(DomElement element, fun() -> Unit handler):
    // Handler wrapped in capability-safe closure
    wasm_externref callback = js_callback::wrap(handler)
    
    // Register with explicit effect annotation
    #[effect(js_event)]
    #requires_js(dom::add_event_listener(
        element.raw_element,
        "click",
        callback
    ))
```

**Constitutional Enforcement**:
- All JS FFI calls require explicit `#requires_js` declaration
- Capability violations rejected at compile time (`MISSING_CAPABILITY: dom access without declaration`)
- JS callbacks tracked for lifetime safety (no dangling callbacks)

---

## 6. Integration with YadroCMP (YUP 26.1.4)

### 6.1 WASM GC Compilation Pipeline

```
YADRO Source (.yad)
       ↓
[Frontend: Parse WASM GC annotations]
       ↓
Typed AST + Heap metadata
       ↓
[Constitutional WASM GC Verification Pass]
       ├── Verify heap boundary crossings
       ├── Check capability requirements for JS FFI
       ├── Validate GC reference lifetimes
       └── Enforce explicit promotion/demotion
       ↓
WASM-Aware MIR
       ↓
┌──────────────────────────────────┐
│ WASM GC IR Generation            │
│ • wasm-struct.type declarations  │
│ • wasm-array.new instructions    │
│ • ref.cast / ref.as_non_null     │
│ • GC root tracking metadata      │
└──────────────────────────────────┘
       ↓
WebAssembly Text Format (.wat)
       ↓
WebAssembly Binary (.wasm)
       ↓
[Embed JS glue code for browser targets]
       ↓
Distributable Package (.wasm + .js)
```

### 6.2 Constitutional Verification Pass for WASM GC

The `YadroWasmGcConstitutionPass` enforces:

| Check | Constitutional Basis | Failure Diagnostic |
|-------|----------------------|-------------------|
| Implicit heap promotion | Article II.1 | `HIDDEN_GC_PROMOTION: linear value implicitly moved to GC heap` |
| Missing JS capability | Article II.2 | `MISSING_CAPABILITY: dom access without #requires_js(dom)` |
| Dangling GC reference | Article I.1 | `GC_REFERENCE_AFTER_DEMOTION: use of wasm_gc[T] after demotion` |
| Non-deterministic GC without annotation | Article IV.1 | `NON_DETERMINISTIC_GC: GC collection point not acknowledged` |
| Heap boundary violation | Article III.2 | `HEAP_BOUNDARY_VIOLATION: &T reference crossing heap boundary` |

---

## 7. YUPPI Integration for WASM Packages (YUP 26.1.2 Alignment)

### 7.1 WASM-Specific Package Metadata

```toml
[package]
name = "web-components"
version = "1.2.0"

[wasm.targets]
wasm32-wasi = { features = ["gc"], heap_size = "128MB" }
wasm32-browser = { features = ["gc", "js_ffi"], capabilities = ["dom", "fetch"] }

[wasm.exports]
main = "src/main.yad::wasm_entry_point"
js_glue = "glue.js"  # Optional JS glue code

[wasm.imports]
js = [
  { name = "env", module = "dom", capabilities = ["dom"] },
  { name = "net", module = "fetch", capabilities = ["fetch"] }
]
```

### 7.2 WASM Binary Distribution Format

WASM packages distributed via YUPPI include platform-specific artifacts:

```
web-package.ymd/
├── main.toml
├── src/
│   └── components.yad
├── wasm_bin/
│   ├── wasm32-wasi-gc/
│   │   ├── main.wasm
│   │   └── wasi-reactor.wasm
│   └── wasm32-browser-gc/
│       ├── main.wasm
│       ├── main.js          # JS glue code
│       └── package.json     # npm-compatible manifest
├── checksum.sha256
└── SECURITY.md              # Capability audit report
```

YadroCMP selects appropriate binary based on `#target wasm=...` declaration.

---

## 8. Safety Guarantees & Constitutional Boundaries

### 8.1 WASM GC Safety Tiers

| Tier | Annotation | Guarantees | Constitutional Basis |
|------|------------|------------|----------------------|
| **Linear-Only** | (default) | Pure linear memory, no GC | Article V.Pillar1 (ownership default) |
| **WASM GC** | `#target wasm=gc-2.0` | Explicit GC heap usage with safety checks | Article II.1 (explicit intent) |
| **JS FFI** | `#requires_js` | Capability-limited JS interop | Article II.2 (declarative configuration) |
| **Unsafe WASM** | `#[unsafe(wasm_gc)]` | Raw WASM instructions, bypass safety | Article III.3 (right to descend) |

```yadro
// Linear-only module (default safety)
fun process_data(darray[u8] data) -> Result[u64, Error]:
    // Pure linear memory operations
    return Ok(crc32(data))

// WASM GC module (explicit opt-in)
#target
arch = "wasm32"
wasm = "gc-2.0"

fun wasm_entry_point() -> wasm_gc[App]:
    // Explicit GC allocation
    wasm_gc[App] app = wasm_gc::alloc(App.new())
    return app

// JS FFI with capability enforcement
#requires_js
capabilities = ["dom"]

fun setup_ui() -> Result[Unit, JsError]:
    wasm_gc[DomElement] root = dom::get_element_by_id("root")?
    root.set_text("Hello from YADRO!")
    return Ok(())

// Unsafe WASM for performance-critical paths
#[unsafe(wasm_gc)]
fun custom_gc_barrier():
    asm.wasm("gc.barrier"):
        // Raw WASM GC instruction with explicit unsafe boundary
```

### 8.2 Non-Determinism Acknowledgment (Article IV.1)

WASM GC introduces non-deterministic collection timing. The compiler requires explicit acknowledgment:

```yadro
// Functions affected by GC non-determinism must declare it
fun[non_deterministic(gc_collection)]
measure_allocation_time() -> u64:
    u64 start = time::now()
    wasm_gc::alloc(HeavyObject.new())  // GC may trigger here
    return time::now() - start

// Deterministic alternative using arena allocation
fun measure_allocation_time_deterministic() -> u64:
    arena: Arena = Arena.new()  // Linear memory arena (deterministic)
    gc[HeavyObject] obj = arena.alloc(HeavyObject.new())
    // No GC non-determinism—arena freed at scope exit
    return time::now() - start
```

**Constitutional Enforcement**: Functions with non-deterministic behavior cannot be used in contexts requiring determinism (e.g., cryptographic constant-time operations, real-time systems) without explicit override.

---

## 9. Example: Constitutionally Verified WASM Application

```yadro
#import
std::core::cli
std::collections::darray
std::wasm_gc::heap      // WASM GC heap primitives
std::wasm_gc::dom       // DOM capability module

#requires_js
capabilities = ["dom", "fetch"]

#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true

// Linear memory data structure (deterministic)
struct TodoItem:
    u64 id
    string title
    bool completed

// WASM GC heap representation for JS interop
wasm_struct JsTodoItem:
    string title
    bool completed
    wasm_gc[JsTodo] parent  // Cyclic reference to parent list

// Convert linear → GC representation (explicit cost)
fun todo_to_js(TodoItem item) -> wasm_gc[JsTodoItem]:
    return wasm_gc::alloc(JsTodoItem{
        title: item.title,
        completed: item.completed,
        parent: wasm_gc::null()
    })

// Main application entry point
fun wasm_entry_point() -> wasm_gc[App]:
    // Initialize linear memory state
    darray[TodoItem] todos = [
        TodoItem{1, "Learn YADRO", false},
        TodoItem{2, "Build WASM app", true}
    ]
    
    // Explicit promotion to WASM GC heap for JS interop
    wasm_gc[darray[wasm_gc[JsTodoItem]]] js_todos = 
        wasm_gc::array_alloc[wasm_gc[JsTodoItem]](todos.len())
    
    u32 idx = 0
    for item in todos:
        js_todos[idx] = todo_to_js(item)
        idx += 1
    
    // Render to DOM with explicit capability check
    DomElement root = dom::get_element_by_id("app")?
    render_todos(root, js_todos)
    
    // Return GC-rooted application object
    return wasm_gc::alloc(App{ todos: js_todos })

// Constitutional guarantees:
// • All heap transitions explicit (Article II.1)
// • JS capabilities declared upfront (Article II.2)
// • No hidden GC behavior (Article II.1)
// • Linear memory remains default for core logic (Article V.Pillar1)
// • Non-determinism acknowledged where present (Article IV.1)
```

---

## 10. Governance & Evolution

### 10.1 WASM Feature Approval Process

New WASM proposals (e.g., WASM Threads, WASM Exceptions) require Architecture Council review to ensure:
1. Constitutional compliance with ownership semantics (Article V.Pillar1)
2. Explicit modeling of new capabilities/effects (Article II)
3. Verification feasibility for safety properties (Article I)
4. Backward compatibility with existing WASM code

### 10.2 Deprecation Policy

WASM features violating constitutional principles follow:
- 6-month warning period with migration path
- 3-month transition period with opt-in re-enabling
- Removal requires supermajority approval per Article VI.2

### 10.3 Security Considerations

- WASM packages subject to capability auditing (YUPPI `yadro yuppi audit --capabilities`)
- JS FFI sandboxing enforced at runtime via capability tokens
- WASM module signatures verified before execution
- Protection against Spectre-style side channels via explicit timing annotations

---

## 11. References

1. YUP 26.1.3: *The YADRO Constitution*  
2. YUP 26.1.4: *YadroCMP Compiler Implementation Standard*  
3. YUP 26.1.2: *Yadro User Project Package Index (YUPPI) Specification*  
4. WebAssembly GC Proposal: https://github.com/WebAssembly/gc  
5. WebAssembly Reference Types: https://github.com/WebAssembly/reference-types  
6. WASI (WebAssembly System Interface): https://wasi.dev/  

---

*This standard fulfills Article III.2's mandate for "Seamless Interoperation" by providing constitutionally safe bridging between YADRO's linear ownership model and WebAssembly's garbage-collected heap, while preserving Article II.1's prohibition on "magic" through explicit heap boundary declarations and Article V.Pillar1's ownership-as-default principle. WASM GC in YADRO remains transparent, safe, and opt-in—never sacrificing constitutional principles for ecosystem compatibility.*