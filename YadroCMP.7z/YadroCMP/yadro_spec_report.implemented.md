# YadroCMP — Отчёт о соответствии спецификациям YUP 26.1.x

## Объём проверки

| Спецификация | Название |
|---|---|
| YUP 26.1.1 | YADRO Language Specification (Core) |
| YUP 26.1.2 | YUPPI — Package Manager |
| YUP 26.1.3 | The YADRO Constitution |
| YUP 26.1.4 | YadroCMP Compiler Implementation Standard |
| YUP 26.1.5 | Formal Verification Integration Standard |
| YUP 26.1.7 | GPU Target Specialization Standard |
| YUP 26.1.9 | WebAssembly GC Integration Standard |

**Реализация:** каталог `yadrocmp/`  
**Метод:** полное статическое сопоставление всех требований спецификаций с исходным кодом компилятора (lexer → parser → ast → sema → mir → vir → codegen → driver → __main__).

---

## Легенда статусов

| Статус | Описание |
|--------|----------|
| ✅ Реализовано | Полностью покрыто кодом |
| ⚠️ Частично | Есть реализация, но с существенными пробелами |
| ❌ Не реализовано | В коде отсутствует |

---

# РАЗДЕЛ I — РЕАЛИЗОВАНО

## YUP 26.1.1 — Ядро языка

### 1.1 Лексика и базовый синтаксис

| Требование | Статус | Источник |
|---|---|---|
| Отступы кратны 4, табы раскрываются в пробелы | ✅ | `lexer.py` `_prepare_lines` |
| Комментарии `//` (строчные) | ✅ | `lexer.py` `_tokenize_line` |
| Комментарии `/* */` (блочные), включая многострочные | ✅ | `lexer.py` `_strip_block_comments` |
| Строковые литералы с escape-последовательностями `\n \t \\` | ✅ | `lexer.py` `_tokenize_line` |
| Символьные литералы `'x'`, escape в символах | ✅ | `lexer.py` `_tokenize_line` |
| Целочисленные литералы (decimal) | ✅ | `lexer.py` `_tokenize_line` |
| Шестнадцатеричные литералы `0x...` / `0X...` | ✅ | `lexer.py` `_tokenize_line` |
| Литералы с плавающей точкой | ✅ | `lexer.py` `_tokenize_line` |
| Булевы литералы `true` / `false` | ✅ | `lexer.py` `KEYWORDS` |
| `;` как разделитель нескольких стейтментов на одной строке | ✅ | `parser.py` `_consume_terminator` |
| `INDENT` / `DEDENT` / `NEWLINE` токены | ✅ | `lexer.py` `tokenize` |
| Атрибутный токен `#[` | ✅ | `lexer.py` `_tokenize_line` |

### 1.2 Директивы компилятора

| Требование | Статус | Источник |
|---|---|---|
| `#target` (os, arch, triple, cpu, features) | ✅ | `driver.py` `parse_directives`, `codegen.py` `resolve_target_triple` |
| `#requires` — внешние нативные библиотеки | ✅ | `driver.py` `parse_directives`, `codegen.py` `_emit_named_metadata` |
| `#plugin` — плагины компилятора | ✅ | `driver.py` `parse_directives`, `codegen.py` `_emit_named_metadata` |
| `#import` — импорт модулей с алиасами и неймспейсами | ✅ | `driver.py` `_merge_with_imports`, `_namespace_program` |
| `#start` / `#end` — главный блок программы | ✅ | `lexer.py`, `parser.py` `parse` |
| `#requires` связывается с линковкой | ✅ | `driver.py` `_link_executable`, `codegen.py` |
| `#target` влияет на target-triple LLVM | ✅ | `codegen.py` `emit_object`, `resolve_target_triple` |
| `#requires` и `#plugin` сериализуются как LLVM named metadata | ✅ | `codegen.py` `_emit_directive_metadata` |

### 1.3 Управляющие конструкции

| Требование | Статус | Источник |
|---|---|---|
| `if / elsif / else` | ✅ | `parser.py` `_parse_if`, `codegen.py` `_emit_if` |
| `switch / case / default` с паттерн-матчингом | ✅ | `parser.py` `_parse_switch`, `sema.py` `_analyze_switch_pattern`, `codegen.py` `_emit_switch` |
| `for Type var in range(start, end, step)` | ✅ | `parser.py` `_parse_for`, `codegen.py` `_emit_for` |
| `while condition:` | ✅ | `parser.py` `_parse_while`, `codegen.py` `_emit_while` |
| `repeat: ... until condition` | ✅ | `parser.py` `_parse_repeat`, `codegen.py` `_emit_repeat` |
| `break` / `continue` | ✅ | `parser.py`, `codegen.py` `_emit_stmt` |
| `return` | ✅ | `parser.py` `_parse_return`, `codegen.py` |
| `arena` блоки с runtime-аллокатором | ✅ | `parser.py`, `codegen.py` `_emit_arena_runtime` |
| Корректная очистка арены при `break/continue/return` | ✅ | `codegen.py` `_cleanup_arenas_to_scope_depth`, `_cleanup_all_arenas` |
| Loop invariants (`spec invariant`) в `while/for/repeat` | ✅ | `parser.py` `_parse_loop_invariants`, `ast.py` (поле `invariants`), `vir.py` `_collect_stmts` |

### 1.4 Функции, эффекты, async/thread/const/ffi

| Требование | Статус | Источник |
|---|---|---|
| Базовые функции с параметрами по умолчанию и возвратом | ✅ | `parser.py` `_parse_function_decl`, `sema.py` `_analyze_function` |
| `fun[async]` → `Task[T]` | ✅ | `sema.py` `_analyze_function`, `codegen.py` |
| `fun[thread]` → `ThreadId` | ✅ | `sema.py`, `codegen.py` `_emit_thread_runtime` |
| `fun[const]` — compile-time вычисление | ✅ | `sema.py` `_eval_const_expr`, `_eval_const_block` |
| `fun[ffi("lib", abi="...")]` — FFI с ABI | ✅ | `parser.py`, `sema.py` `_validate_ffi_requires`, `codegen.py` `_ffi_calling_convention` |
| `fun[class]` — статические методы | ✅ | `parser.py`, `sema.py` `_analyze_method` |
| Дженерики `temp<Type>` | ✅ | `parser.py`, `sema.py` `_analyze_specialization` |
| `where`-блоки для trait-ограничений | ✅ | `parser.py`, `sema.py` `_validate_where_bounds_decl` |
| `effects`-блок и атрибут `#[effect(...)]` | ✅ | `parser.py`, `sema.py` `_validate_effects`, `_attribute_effects` |
| Валидация несовместимых модификаторов (async+thread, ffi+const и т.д.) | ✅ | `sema.py` `_validate_function_modifiers` |
| `ffi` проверяет наличие библиотеки в `#requires` | ✅ | `sema.py` `_validate_ffi_requires` |
| `const` переменные и `const` функции вычисляются в compile-time | ✅ | `sema.py` `_validate_const_body`, `_eval_const_function` |
| `#[unsafe]:` блоки и inline-asm | ✅ | `parser.py` `_parse_unsafe_block`, `_parse_asm_stmt`, `codegen.py` |
| Объявления переменных с параметризованными типами `Task[T]` | ✅ | `parser.py` `_looks_like_type_apply_decl` |

### 1.5 Типы, владение и заимствование

| Требование | Статус | Источник |
|---|---|---|
| Базовые типы `int float bool string char Unit void ThreadId` | ✅ | `typesys.py` `BUILTINS`, `lexer.py` `TYPES` |
| `array[T, N]` — фиксированный массив | ✅ | `ast.py` `TypeArray`, `sema.py`, `codegen.py` |
| `darray[T]` — динамический массив | ✅ | `ast.py` `TypeDArray`, `codegen.py` |
| `gc<T>` / `gc[T]` — управляемая куча с ref-counting | ✅ | `ast.py` `TypeGc`, `codegen.py` `_emit_gc_runtime` (inline RC-GC) |
| `gc_weak<T>` — слабые ссылки | ✅ | `ast.py` `TypeGcWeak`, `codegen.py` `_emit_gc_weak_new` |
| `&T` / `&mut T` — ссылки | ✅ | `ast.py` `TypeRef`, `typesys.py`, `sema.py` |
| `Option[T]` / `Result[T, E]` | ✅ | `typesys.py`, `sema.py` `_analyze_constructor` |
| `dict[K, V]` / `set[T]` | ✅ | `ast.py`, `sema.py`, `codegen.py` |
| `vector[T, dims]` — SIMD | ✅ | `sema.py`, `codegen.py` (LLVM VectorType) |
| Правила move/borrow | ✅ | `sema.py` `_mark_move`, `_mark_borrow` |
| Проверка регионов ссылок | ✅ | `sema.py` `_with_region`, `_current_region` |
| Refined types `~int`, предикаты с `where` | ✅ | `parser.py` `_parse_refined_type_def`, `sema.py` `_validate_refined_params` |
| `spec` типы (`spec S = T where pred`) | ✅ | `parser.py` `_parse_spec_type_def`, `sema.py` `_validate_spec_types` |
| Деструктуризация массивов `int a, b = *vals` | ✅ | `ast.py` `DestructureDecl`, `parser.py`, `codegen.py` |
| Деструктуризация dict `keys . vals = *map` | ✅ | `ast.py` `DictDestructureDecl`, `parser.py`, `codegen.py` |
| `del` для gc и вызов `drop` | ✅ | `ast.py` `DelStmt`, `parser.py`, `codegen.py` |
| Только типы с `#Copy` могут копироваться неявно | ✅ | `sema.py` `_is_copy` |

### 1.6 Result/Option и обработка ошибок

| Требование | Статус | Источник |
|---|---|---|
| Конструкторы `Ok / Err / Some / None` | ✅ | `sema.py` `_analyze_constructor`, `codegen.py` `_emit_constructor` |
| Оператор `?` — раннее возвращение на `Err` | ✅ | `ast.py` `TryExpr`, `parser.py`, `codegen.py` |
| `or` для `Option` — значение по умолчанию | ✅ | `sema.py`, `codegen.py` |
| Паттерн-матчинг `switch res: case Ok(x): case Err(e):` | ✅ | `parser.py` `_parse_pattern`, `sema.py` `_analyze_switch_pattern` |

### 1.7 Классы, трейты, протоколы

| Требование | Статус | Источник |
|---|---|---|
| Классы с наследованием и полями | ✅ | `parser.py` `_parse_class`, `sema.py` `_analyze_class` |
| Методы экземпляра и `fun[class]` статические методы | ✅ | `sema.py` `_analyze_method`, `_register_method_signature` |
| `class[linear]` — линейные типы, запрет `copy` | ✅ | `sema.py` `_validate_class_behavior` |
| `class[actor]` — требование метода `receive` | ✅ | `sema.py` `_validate_class_behavior` |
| Class invariants (`spec invariant:` в теле класса) | ✅ | `parser.py` `_parse_class_invariants`, `ast.py` `ClassDef.invariants`, `vir.py` `_collect_class` |
| `trait` определения с сигнатурами методов | ✅ | `parser.py` `_parse_trait`, `sema.py` `_analyze_trait` |
| `impl Trait for Type` | ✅ | `parser.py` `_parse_impl`, `sema.py` `_analyze_impl` |
| Динамическая диспетчеризация через vtable | ✅ | `codegen.py` `_declare_trait_vtables`, `_declare_trait_shim` |
| `protocol` — только compile-time, не trait-объект | ✅ | `parser.py`, `sema.py` (флаг `is_protocol`) |
| Mangle имён методов и trait-impl функций | ✅ | `sema.py` `_mangle_method_name`, `codegen.py` `_mangle_method_name` |

### 1.8 Операторы

| Требование | Статус | Источник |
|---|---|---|
| Арифметика `+ - * / %`, целочисленное деление `\|` | ✅ | `lexer.py`, `parser.py`, `codegen.py` `_emit_arith` |
| Битовые `<< >> & \| ^ ~` | ✅ | `lexer.py`, `codegen.py` `_emit_bitwise`, `_emit_shift` |
| Логические `and or xor nand` | ✅ | `lexer.py` `KEYWORDS`, `codegen.py` `_emit_logic` |
| Сравнения `== != < > <= >=` | ✅ | `lexer.py`, `codegen.py` `_emit_compare` |
| Составные присваивания `+= -= *= /= %= <<= >>= &= \|= ^=` | ✅ | `lexer.py`, `ast.py` `CompoundAssign`, `codegen.py` |
| Спец-операторы `@=` (взятие адреса) и `$=` (swap) | ✅ | `lexer.py`, `ast.py` `SwapStmt` |
| Пайплайн `>>> <<<` (переписывается в вызовы) | ✅ | `lexer.py`, `parser.py` `_parse_pipeline`, `_apply_pipeline` |
| Унарные `- ! & &mut * ~` | ✅ | `parser.py` `_parse_unary`, `codegen.py` |
| Индексирование `[]` и доступ к полям `.` | ✅ | `parser.py` `_parse_postfix`, `codegen.py` `_emit_index_ptr` |
| Short-circuit `and` / `or` | ✅ | `codegen.py` `_emit_short_circuit` |

### 1.9 Компилятор — пайплайн (YUP 26.1.1 + YUP 26.1.4)

| Требование | Статус | Источник |
|---|---|---|
| Директивы → лексер → парсер → AST | ✅ | `driver.py` `compile_source` |
| Семантический анализ + borrow checking | ✅ | `sema.py` `analyze` |
| MIR с оптимизационными хинтами | ✅ | `mir.py` `lower_to_mir`, `_collect_opt_hints` |
| VIR — сбор proof obligations | ✅ | `vir.py` `collect_obligations` |
| Конституциональная верификация (YUP 26.1.3 / YUP 26.1.4 §3.2) | ✅ | `vir.py` `check_constitution`, `sema.py` `_check_constitution_rules` |
| LLVM IR генерация | ✅ | `codegen.py` `emit_llvm_ir` |
| Компиляция в объектный файл (emit=obj) | ✅ | `codegen.py` `emit_object` |
| Компиляция в бинарник через clang linker (emit=bin) | ✅ | `driver.py` `_link_executable` |
| Cross-compilation через `#target` | ✅ | `codegen.py` `resolve_target_triple`, поддержка x86_64/aarch64/wasm32 |
| LLVM optimization pipeline (pmb, -O0…-O3) | ✅ | `codegen.py` `emit_object` (PassManagerBuilder) |
| MIR opt hints: `inline/noinline/pure/readnone/const_fold/loop_unroll` | ✅ | `mir.py` `_collect_opt_hints` |
| Инлайн RC-GC runtime (`__yadro_gc_alloc/inc/dec/weak_*`) | ✅ | `codegen.py` `_emit_gc_runtime` |
| Arena runtime (alloc/dealloc) | ✅ | `codegen.py` `_emit_arena_runtime` |
| Thread runtime | ✅ | `codegen.py` `_emit_thread_runtime` |

---

## YUP 26.1.3 — Конституция (реализованные части)

| Требование | Статус | Источник |
|---|---|---|
| Article II.3: `[thread]` функции должны возвращать `ThreadId` | ✅ | `vir.py` `check_constitution`, `sema.py` `_check_constitution_rules` |
| Article I.1: `[const]` функции с нетривиальным телом без `spec` получают предупреждение | ✅ | `vir.py` `check_constitution` |
| Article V.Pillar1: `linear` классы с методами без `&mut self` получают note | ✅ | `sema.py` `_check_constitution_rules` |
| Article II.1: unsafe-блоки изолированы через `#[unsafe]` | ✅ | `sema.py`, `vir.py` |
| `CONSTITUTIONAL_VIOLATION: [Article X.Y]: ...` формат диагностик | ✅ | `vir.py` `ConstitutionalViolation.format()` |

---

## YUP 26.1.4 — Стандарт компилятора (реализованные части)

| Требование | Статус | Источник |
|---|---|---|
| CLI команда `yadro compile` с флагами `--emit --verify --dump-obligations` | ✅ | `__main__.py` |
| CLI команда `yadro verify` (standalone VIR pass, без codegen) | ✅ | `__main__.py` |
| CLI команда `yadro lint` (через ruff) | ✅ | `__main__.py` |
| `--emit llvm` / `obj` / `bin` | ✅ | `driver.py` `compile_source` |
| `--verify none/check/require/certify` | ✅ | `driver.py`, `vir.py` |
| `--dump-obligations` — вывод таблицы proof obligations | ✅ | `__main__.py`, `vir.py` `dump_obligations` |
| Минимальные требования к системе (LLVM как бэкенд) | ✅ | `codegen.py` (llvmlite) |

---

## YUP 26.1.5 — Формальная верификация (реализованные части)

| Требование | Статус | Источник |
|---|---|---|
| Парсинг `spec:` блоков (requires/ensures/invariants) | ✅ | `parser.py` `_parse_spec_block` |
| Парсинг loop invariants (`spec invariant` в while/for/repeat) | ✅ | `parser.py` `_parse_loop_invariants` |
| Парсинг class invariants | ✅ | `parser.py` `_parse_class_invariants` |
| Тип-чекинг предикатов spec через sema | ✅ | `sema.py` `_validate_spec_block`, `_analyze_spec_predicate` |
| Refined parameters (`~T param : predicate`) | ✅ | `sema.py` `_validate_refined_params` |
| VIR модуль — `ObligationKind`, `VerificationStatus`, `ProofObligation` | ✅ | `vir.py` |
| Сбор REQUIRES/ENSURES/INVARIANT/CLASS_INVARIANT/REFINED_PARAM/SPEC_TYPE | ✅ | `vir.py` `collect_obligations` |
| Лёгкая статическая разрядка (constant folding, trivial predicates) | ✅ | `vir.py` `_static_discharge`, `_is_trivially_true` |
| `format_diagnostics` с уровнями `check/require/certify` | ✅ | `vir.py` `format_diagnostics` |
| `dump_obligations` — человекочитаемый дамп всех obligations | ✅ | `vir.py` `dump_obligations` |
| Верификация на уровне `require/certify` блокирует компиляцию | ✅ | `driver.py` `compile_source` |
| Архитектура VIR → LLVM (obligations не влияют на runtime) | ✅ | `vir.py`, `driver.py` |
| `spec` типы и их предикаты (`spec S = T where ...`) | ✅ | `ast.py` `SpecTypeDef`, `vir.py` `_collect_spec_type` |

---

# РАЗДЕЛ II — ЧАСТИЧНО РЕАЛИЗОВАНО

## YUP 26.1.1 — Ядро языка (частичности)

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| `class[linear]` поведение | ⚠️ Частично | Валидация: запрет `copy`, проверка `drop` сигнатуры, note для `&mut self` | Полноценная линейная семантика (no-escape, no-copy во всех путях) |
| `class[actor]` поведение | ⚠️ Частично | Валидация: требование `receive(&mut self, msg)` | Реальный actor-рантайм, message queue, изоляция состояния |
| GC с inline runtime | ⚠️ Частично | Полный RC-GC инлайн (alloc/inc/dec/weak_*), magic sentinel | Нет трейсинга циклических ссылок; `gc_weak` не upgrade-ается обратно |
| `fun[async]` | ⚠️ Частично | `Task[T]` как LLVM-структура, флаг готовности | Нет настоящего event loop / executor, нет `await` оператора |
| `fun[thread]` | ⚠️ Частично | Регистрирует `ThreadId`, emits функцию | Нет реального spawning через `pthread_create` или аналог |
| Правила move/borrow | ⚠️ Частично | Базовая проверка moved/borrowed переменных в scopes | Нет полного lifetime анализа, нет проверки NLL (non-lexical lifetimes) |

## YUP 26.1.3 — Конституция (частичности)

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| Полный `YadroConstitutionPass` (YUP 26.1.4 §3.2) | ⚠️ Частично | Articles I.1, II.1, II.3, V.Pillar1 проверены | Articles IV.1 (глобальное изменяемое состояние), IV.3 (эффекты в сигнатуре) |
| `--constitution=strict/balanced/permissive` флаги CLI | ⚠️ Частично | Частично покрыто `--verify=require/check/none` | Нет явного `--constitution` флага |

## YUP 26.1.4 — Стандарт компилятора (частичности)

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| MIR с конституциональной верификацией | ⚠️ Частично | MIR с opt hints + VIR constitutional checks | Нет отдельного "Verified MIR" как фазы, нет расширенного анализа |
| LLVM optimization pipeline | ⚠️ Частично | PassManagerBuilder с opt_level, FPM + MPM | Конфигурация хрупкая (best-effort try/except), нет таргет-специфичных passes |

## YUP 26.1.5 — Формальная верификация (частичности)

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| Статическая разрядка предикатов | ⚠️ Частично | Bool literals, integer comparisons, and/or, same-var identity | Symbolic execution, algebraic simplification, z3/CVC5 calls |
| Ghost переменные `#[ghost]` | ⚠️ Частично | `#[ghost]` парсится как атрибут (`ATTR` токен) | Нет erase-before-codegen логики, ghost переменные попадают в LLVM IR |
| `spec old(e)` | ⚠️ Частично | `old` резолвится как обычный вызов функции | Нет специальной семантики "значение на входе функции" |

---

# РАЗДЕЛ III — НЕ РЕАЛИЗОВАНО

## YUP 26.1.2 — YUPPI (пакетная система)

| Требование | Статус | Примечание |
|---|---|---|
| Структура пакета `package-name.ymd/` | ❌ | В репозитории нет ни одного компонента менеджера пакетов |
| Манифест `main.toml` (парсинг, валидация) | ❌ | |
| Build-скрипт `setup.yad` | ❌ | |
| `checksum.sha256` верификация целостности | ❌ | |
| Алгоритм разрешения зависимостей | ❌ | |
| Semantic versioning и version constraints | ❌ | |
| `yadro yuppi install/uninstall/update/add/remove` | ❌ | |
| `yadro yuppi init/build/test/publish/audit` | ❌ | |
| `yadro yuppi search/info/versions/outdated` | ❌ | |
| `yadro yuppi repo add/list/remove/update` | ❌ | |
| Repository server API (`/index.json`, `/packages/...`) | ❌ | |
| Repository index JSON format | ❌ | |
| Build cache (source/build/metadata) | ❌ | |
| Build sandboxing (ограничение filesystem/network/syscalls) | ❌ | |
| PGP/GPG подписи пакетов | ❌ | |
| `yadro yuppi tree` — граф зависимостей | ❌ | |

## YUP 26.1.3 — Конституция (нереализованные части)

| Требование | Статус | Примечание |
|---|---|---|
| Article IV.1: запрет глобального изменяемого состояния | ❌ | Нет статической проверки global mutable vars |
| Article IV.3: side-effects в типе функции (за пределами known effects) | ❌ | |
| Article II.2: декларативная конфигурация (полная enforcement) | ❌ | |
| `--constitution=strict` как отдельный флаг CLI | ❌ | |
| `yadro constitution --explain <article>` | ❌ | |
| `yadro constitution --audit <package>` | ❌ | |
| Machine-readable constitution JSON (`yup-26.1.3.json`) | ❌ | |

## YUP 26.1.4 — Стандарт компилятора (нереализованные части)

| Требование | Статус | Примечание |
|---|---|---|
| `yadro-check` — отдельный статический анализатор | ❌ | |
| `yadro-doc` — генератор документации | ❌ | |
| `yadro-lsp` — Language Server Protocol | ❌ | Нет LSP-сервера; нет real-time diagnostics/hover/borrow viz в IDE |
| `yadro constitution --explain/--audit` команды | ❌ | |
| Cranelift backend (альтернатива LLVM) | ❌ | Только LLVM backend |
| `yadro yuppi build` интеграция | ❌ | YUPPI не реализован |
| Распределение бинарей (`yadro-cmp.ymd`) | ❌ | Нет пакетной сборки компилятора |
| `yadro compile --constitution-check-only` | ❌ | Флаг не реализован |
| Reproducible builds (`reprotest`) | ❌ | |
| Formal methods верификация самого компилятора (YUP 27.x) | ❌ | Долгосрочная цель |

## YUP 26.1.5 — Формальная верификация (нереализованные части)

| Требование | Статус | Примечание |
|---|---|---|
| Интеграция с Why3 (первичный prover) | ❌ | Нет вызовов внешнего прувера |
| Интеграция с Coq (интерактивные доказательства) | ❌ | |
| Интеграция с F* (refinement types, crypto) | ❌ | |
| Интеграция с Crucible (symbolic execution над LLVM IR) | ❌ | |
| `yadro verify --prover=coq/why3/fstar` | ❌ | |
| `yadro verify --dump-obligations` экспорт в `.v` / Why3 формат | ❌ | Только human-readable текст |
| Ghost variable erasure перед codegen | ❌ | `#[ghost]` атрибут парсится, но переменные попадают в LLVM IR |
| `spec old(e)` — значение выражения на входе функции | ❌ | `old` резолвится как обычный вызов |
| `spec_axiom` / `#[unsafe(axiom)]` | ❌ | |
| Proof certificate генерация (`.proof` файлы) | ❌ | |
| `yadro verify --reproducible` | ❌ | |
| Loop termination (decreasing measure) | ❌ | |
| Certify tier (machine-checkable certificates) | ❌ | Уровень `certify` принят CLI, но сертификаты не генерируются |
| YUPPI: `verified = true` в `main.toml` + transitive proof chain | ❌ | YUPPI не реализован |
| `yadro yuppi audit --verification` | ❌ | |
| DWARF debug info с embedded verification metadata | ❌ | |

## YUP 26.1.7 — GPU (полностью не реализовано)

| Требование | Статус | Примечание |
|---|---|---|
| `#target` расширения для GPU (`backend = "cuda"/"vulkan"/"metal"`) | ❌ | |
| GPU memory space типы (`@shared T`, `@global T`, `@constant T`) | ❌ | |
| `fun[kernel]` объявления | ❌ | |
| Kernel launch синтаксис (`<<<grid, block>>>`) | ❌ | |
| Host/Device boundary enforcement | ❌ | |
| GPU barrier primitives (`syncthreads`, `memfence`) | ❌ | |
| SPIR-V backend | ❌ | |
| NVPTX backend | ❌ | |
| `main.toml` GPU-специфичные метаданные | ❌ | |
| Constitutional Verification Pass для GPU кода | ❌ | |

## YUP 26.1.9 — WebAssembly GC (полностью не реализовано)

| Требование | Статус | Примечание |
|---|---|---|
| `#target` расширения для WASM GC (`backend = "wasm-gc"`) | ❌ | |
| WASM GC heap types (`wasm_struct`, `wasm_array`, `wasm_funcref`) | ❌ | |
| Dual-heap memory model (linear ownership + WASM GC heap) | ❌ | |
| Явное повышение linear → WASM GC (`promote_to_gc`) | ❌ | |
| Явное понижение WASM GC → linear (`demote_from_gc`) | ❌ | |
| JavaScript FFI с constitutional safety model | ❌ | |
| `js_capability` тип и explicit capability model | ❌ | |
| Type-safe JS interop (`#[js_export]`, `#[js_import]`) | ❌ | |
| WASM GC compilation pipeline в codegen | ❌ | |
| `main.toml` WASM-специфичные метаданные | ❌ | |

---

# РАЗДЕЛ IV — СВОДНАЯ ТАБЛИЦА ПО СПЕЦИФИКАЦИЯМ

| Спецификация | Статус | Покрытие |
|---|---|---|
| YUP 26.1.1 Ядро языка | ⚠️ Частично | ~80% — основная функциональность реализована; actor/linear runtime, полный borrow checker и async executor отсутствуют |
| YUP 26.1.2 YUPPI | ❌ Не реализовано | 0% — ни одного компонента пакетной системы |
| YUP 26.1.3 Конституция | ⚠️ Частично | ~40% — Articles I.1, II.1, II.3, V.Pillar1 проверены; IV.1, IV.3 отсутствуют |
| YUP 26.1.4 Компилятор | ⚠️ Частично | ~55% — основной pipeline + CLI реализованы; LSP, doc, check, Cranelift, YUPPI-интеграция отсутствуют |
| YUP 26.1.5 Формальная верификация | ⚠️ Частично | ~40% — VIR с obligation collection + static discharge есть; внешние provers, ghost erasure, `old()`, certificates отсутствуют |
| YUP 26.1.7 GPU | ❌ Не реализовано | 0% — нет ни одной GPU-специфичной конструкции |
| YUP 26.1.9 WASM GC | ❌ Не реализовано | 0% — нет WASM GC backend |

---

# РАЗДЕЛ V — ПРИОРИТЕТЫ РЕАЛИЗАЦИИ

## Высокий приоритет (критично для корректной работы языка)

1. **Ghost variable erasure** (YUP 26.1.5) — `#[ghost]` переменные сейчас попадают в LLVM IR, нарушая принцип zero-cost verification
2. **`spec old(e)`** (YUP 26.1.5) — без него post-conditions не могут описывать изменения состояния
3. **Полный borrow checker / NLL** (YUP 26.1.1) — текущая проверка move/borrow не покрывает все случаи из спецификации
4. **Article IV.1 enforcement** (YUP 26.1.3) — запрет глобального изменяемого состояния является конституционным требованием
5. **`fun[thread]` реальный spawning** (YUP 26.1.1) — сейчас thread-функции не создают реальные OS-потоки

## Средний приоритет (важно для экосистемы)

6. **YUPPI базовая реализация** (YUP 26.1.2) — `main.toml`, `yadro yuppi init/build/install`
7. **Why3 интеграция** (YUP 26.1.5) — минимальный external prover для discharge proof obligations
8. **`yadro-lsp`** (YUP 26.1.4) — Language Server Protocol для IDE поддержки
9. **`--constitution=strict` флаг** (YUP 26.1.4) — явный конституциональный режим
10. **`fun[async]` с реальным executor** (YUP 26.1.1) — сейчас async не имеет event loop

## Низкий приоритет (специализированные targets)

11. **GPU backend / SPIR-V** (YUP 26.1.7)
12. **WASM GC backend** (YUP 26.1.9)
13. **Cranelift backend** (YUP 26.1.4)
14. **Proof certificates / Certify tier** (YUP 26.1.5)