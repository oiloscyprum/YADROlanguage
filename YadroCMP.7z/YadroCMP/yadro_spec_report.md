# Отчет о соответствии реализации YADRO спецификациям (YUP 26.1.x)

## Объем проверки
- Спецификации: [yup26.1.1.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.1.md#L1-L311), [yup26.1.2.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.2.md), [yup26.1.3.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.3.md), [yup26.1.4.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.4.md), [yup26.1.5.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.5.md), [yup26.1.7.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.7.md), [yup26.1.9.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.9.md)
- Реализация: каталог [yadrocmp](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp)
- Метод: статическое сопоставление требований с текущей реализацией компилятора (лексер → парсер → семантика → MIR → LLVM IR).

## Сводка
- Реализованы: базовая лексика/синтаксис (включая `/* */`, `;`, hex-литералы), типы (int/float/bool/string/char/Unit/void/ThreadId, array/darray, ref, gc/gc_weak, Option/Result), функции/классы/traits/impl, базовая семантика типов и заимствований, генерация LLVM IR. Источники: [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L8-L253), [typesys.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/typesys.py#L38-L55), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L638-L918), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L487-L735), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L202-L855).
- Частично реализованы: владение/заимствование (без части правил из спецификации), CTFE (только ограничения в const-функциях), эффекты/unsafe, GC/GC_weak (завязано на runtime-функции), коллекции dict/set/vector (только типы), `const`-переменные и деструктуризация (без кодогена), расширенные операторы (битовые/сдвиги/составные присваивания) — синтаксис без полной семантики. Источники: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L320-L918), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L368-L918).
- Не реализованы: YUPPI, формальная верификация (solver/runtime проверок), GPU, WASM GC, inline-asm и полноценные backend/оптимизации. Источники: [yup26.1.2.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.2.md), [yup26.1.5.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.5.md), [yup26.1.7.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.7.md), [yup26.1.9.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.9.md).

## YUP 26.1.1 — Ядро языка

### Лексика и базовый синтаксис
- Реализовано: отступы кратны 4, `//` и `/* */` комментарии, строковые/символьные/числовые/hex/булевы литералы, `;` как разделитель стейтментов, ключевые слова для функций, классов, трейтов, циклов и логики. Источник: [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L8-L253), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L14-L104), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L353-L450).
- Реализовано: директивы `#start/#end` задают единственный блок `main_block`, стейтменты вне блока запрещены. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L14-L93).
- Реализовано: `spec`-блоки, refined-типы и refined-параметры на уровне синтаксиса. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L592-L644), [ast.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/ast.py#L83-L196).

### Директивы компилятора
- Реализовано: `#target`, `#requires`, `#plugin`, `#import` парсятся и сохраняются; импорты разрешаются по .yad, поддерживаются алиасы и неймспейсы. Источник: [driver.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/driver.py#L14-L217).
- Реализовано: `#requires` привязывается к линковке, `#target` влияет на выбор target triple/CPU/features при генерации объекта/бинари. Источник: [driver.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/driver.py#L97-L154), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1323-L1409).
- Реализовано: `#requires` и `#plugin` сериализуются как named metadata и строковые массивы на уровне LLVM-модуля. Источник: [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L104-L127).

### Контрольные конструкции
- Реализовано: `if/elsif/else`, `switch/case/default`, `for ... in range`, `while`, `repeat ... until`, `break/continue`, `return`, `arena` блоки. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L147-L558), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L932-L1017), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L260-L780).
- Реализовано: `arena` включает runtime-аллокатор и корректную очистку при break/continue/return через встроенные runtime-функции. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L430-L520), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L106-L700).

### Функции, эффекты, async/thread/const/ffi
- Реализовано: функции с модификаторами `[async|thread|const|ffi|class]`, generic `temp<>`, where-блоки, блок `effects`. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L64-L145), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L866-L921).
- Частично: `async`/`thread` ограничиваются проверкой возвращаемого типа (`Task[T]`/`ThreadId`), без runtime-модели. Источник: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L866-L1106), [typesys.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/typesys.py#L38-L55).
- Частично: `const` функции поддерживают ограничения на выражения, но нет вычисления в compile-time. Источник: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L932-L1017).
- Частично: `ffi` требует `#requires`, поддерживает опциональную проверку `#plugin`, запрещает тело, но нет ABI/линковки. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L104-L132), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L985-L1536), [driver.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/driver.py#L93-L116).
- Частично: эффекты валидируются на уровне наличия требуемых эффектов и `unsafe` (через `ffi` или атрибут), но нет перечня/системы эффектов из спецификации. Источник: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1376-L1393), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L113-L129).
- Не реализовано: блоки `#[unsafe]:` и inline-asm, т.к. отсутствует синтаксис и кодоген. Источник: [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L209-L218), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L597-L714).

### Типы, владение и заимствование
- Реализовано: базовые типы, `void` как алиас `Unit`, `array`, `darray`, `gc`, `gc_weak`, `&`/`&mut`, `Option`/`Result`, тип-параметры. Источник: [typesys.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/typesys.py#L38-L55), [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L45-L46), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L837-L892).
- Реализовано: правила move/borrow и простая проверка регионов ссылок. Источник: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1278-L1306), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1029-L1068).
- Частично: модель `gc/gc_weak` использует runtime-вызовы (`__yadro_gc_*`), но runtime отсутствует. Источник: [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1126-L1177).
- Частично: `dict`, `set`, `vector` распознаются как типы, но нет семантики выражений и кодогена; `const`-переменные и деструктуризация парсятся и валидируются, но не кодогенерируются. Источники: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L320-L389), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L871-L918), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L607-L629), [ast.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/ast.py#L179-L247).
- Реализовано: refined types (`~int`), предикаты и spec-типы с where. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L592-L644), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1530-L1586).

### Result/Option и обработка ошибок
- Реализовано: конструкторы `Ok/Err/Some/None`, оператор `?`, pattern matching в `switch`. Источник: [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1200-L1248), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L657-L714), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1070-L1120).
- Не реализовано: `or` для `Option` (в языке остался только логический `or`). Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L600-L606).

### Классы, трейты, протоколы
- Реализовано: классы с наследованием, методы, `fun[class]` для статических методов, traits и impl, типажные ограничения `where`, динамические trait-объекты с vtable. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L147-L228), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1088-L1160), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L92-L208).
- Частично: `protocol` парсится, но семантически не отличается от `trait`. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L42-L47).
- Не реализовано: модификаторы классов `linear/actor` и их поведение. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L147-L184), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L866-L887).

### Операторы
- Реализовано: `+ - * / %`, сравнения, логические `and/or/xor/nand`, унарные `- ! & &mut * ~`, индексирование и доступ к полям, pipe `>>>/<<<` (переписывается в вызовы). Источник: [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L238-L249), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L638-L808), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L1003-L1012).
- Частично: битовые `| & ^`, сдвиги `<< >>`, составные присваивания `+= -= *= /= %= <<= >>= &= |= ^=`, спец-операторы `@=` и `$=` распознаются синтаксически, но семантика для них не реализована. Источники: [lexer.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/lexer.py#L238-L249), [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L410-L447), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L563-L582).

### Компиляторный пайплайн
- Реализовано: директивы → лексер → парсер → семантика → MIR (тонкая оболочка) → LLVM IR / объект. Источник: [driver.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/driver.py#L93-L171), [mir.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/mir.py#L7-L14), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1209-L1224).
- Не реализовано: этапы оптимизаций, альтернативные backend'ы (Cranelift), формальная проверка предикатов. Источник: [mir.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/mir.py#L7-L14), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1209-L1224).

## YUP 26.1.2 — YUPPI (пакетная система)
- Не реализовано: структура пакета, манифест, сборка, зависимостям и загрузка. В репозитории отсутствуют компоненты менеджера пакетов или обработчики `package.ymd`. Источник: [yup26.1.2.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.2.md).

## YUP 26.1.3 — Конституция
- Не реализовано: enforcement правил конституции в компиляторе. Реализация содержит только локальные проверки `unsafe` и `ffi`. Источник: [yup26.1.3.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.3.md), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1376-L1393).

## YUP 26.1.4 — Стандарт компилятора
- Частично: соответствует минимальному пайплайну (лексер/парсер/семантика/LLVM). Источник: [driver.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/driver.py#L93-L171), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L36-L1224).
- Не реализовано: расширенный MIR, оптимизационные проходы, multi-target, линкер, стандартные этапы валидации. Источник: [mir.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/mir.py#L7-L14).

## YUP 26.1.5 — Формальная верификация
- Частично: `spec`-блоки, инварианты и предикаты парсятся и проверяются типами (bool), но отсутствует runtime/solver‑проверка и доказательство. Источник: [parser.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/parser.py#L592-L644), [sema.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/sema.py#L1530-L1586).

## YUP 26.1.7 — GPU
- Не реализовано: GPU-таргеты, shader-пайплайн, хост/девайс разграничение. В кодогенерации отсутствуют пути для GPU. Источник: [yup26.1.7.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.7.md), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1209-L1224).

## YUP 26.1.9 — WASM GC
- Не реализовано: генерация WASM GC и соответствующих типов. Реализация ограничена LLVM backend. Источник: [yup26.1.9.md](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/specs/en/yup26.1.9.md), [codegen.py](file:///c:/Users/Admin/Downloads/YadroCMP/YadroCMP/yadrocmp/codegen.py#L1209-L1224).
