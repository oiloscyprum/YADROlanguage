from typing import List, Optional, Tuple

from . import ast
from .errors import Diagnostic, YadroError
from .token import Token


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.pending_attributes: List[ast.Attribute] = []

    def parse(self, directives: List[ast.Directive]) -> ast.Program:
        spec_types: List[ast.SpecTypeDef] = []
        functions: List[ast.FunctionDef] = []
        traits: List[ast.TraitDef] = []
        impls: List[ast.ImplDef] = []
        classes: List[ast.ClassDef] = []
        main_block: List[ast.Stmt] = []
        outside_main: List[ast.Stmt] = []
        in_main = False
        saw_main = False
        while not self._check("EOF"):
            if self._check("ATTR") and self._is_unsafe_block_start():
                stmt = self._parse_statement()
                if in_main:
                    main_block.append(stmt)
                else:
                    outside_main.append(stmt)
                continue
            if self._check("ATTR"):
                self._parse_attribute_line()
                continue
            if self._match("START"):
                if in_main:
                    token = self._previous()
                    raise YadroError(Diagnostic("Nested #start is not allowed", token.line, token.column))
                if outside_main:
                    token = self._previous()
                    raise YadroError(Diagnostic("Statements before #start are not allowed", token.line, token.column))
                in_main = True
                saw_main = True
                self._consume("NEWLINE", "Expected newline after #start")
                continue
            if self._match("END"):
                if not in_main:
                    token = self._previous()
                    raise YadroError(Diagnostic("#end without matching #start", token.line, token.column))
                in_main = False
                saw_main = True
                self._consume("NEWLINE", "Expected newline after #end")
                continue
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._check(";"):
                self._advance()
                continue
            if self._check("SPEC"):
                spec_types.append(self._parse_spec_type_def())
                continue
            if self._check("~"):
                spec_types.append(self._parse_refined_type_def())
                continue
            if self._check("FUN"):
                functions.append(self._parse_function_decl())
                continue
            if self._check("TEMP"):
                functions.append(self._parse_function_decl())
                continue
            if self._check("TRAIT"):
                traits.append(self._parse_trait())
                continue
            if self._check("PROTOCOL"):
                traits.append(self._parse_trait(is_protocol=True))
                continue
            if self._check("IMPL"):
                impls.append(self._parse_impl())
                continue
            if self._check("CLASS"):
                classes.append(self._parse_class())
                continue
            if self.pending_attributes:
                token = self._peek()
                raise YadroError(Diagnostic("Attribute must precede declaration", token.line, token.column))
            stmt = self._parse_statement()
            if saw_main and not in_main:
                raise YadroError(Diagnostic("Statement outside #start/#end block", stmt.line, stmt.column))
            if in_main:
                main_block.append(stmt)
            else:
                outside_main.append(stmt)
        if saw_main:
            if outside_main:
                stmt = outside_main[0]
                raise YadroError(Diagnostic("Statement outside #start/#end block", stmt.line, stmt.column))
            return ast.Program(directives, spec_types, classes, traits, impls, functions, main_block)
        if outside_main:
            stmt = outside_main[0]
            raise YadroError(Diagnostic("Statement outside #start/#end block", stmt.line, stmt.column))
        return ast.Program(directives, spec_types, classes, traits, impls, functions, [])

    def _parse_function_decl(self) -> ast.FunctionDef:
        attributes = self._take_pending_attributes()
        type_params: List[str] = []
        if self._match("TEMP"):
            self._consume("<", "Expected '<' after temp")
            while True:
                name = self._consume("IDENT", "Expected type parameter name")
                type_params.append(name.value)
                if self._match(","):
                    continue
                break
            self._consume(">", "Expected '>' after type parameters")
        fun_token = self._consume("FUN", "Expected 'fun'")
        modifiers, modifier_args = self._parse_modifiers()
        if self._match("IDENT", "NEW"):
            name = self._previous()
        else:
            token = self._peek()
            raise YadroError(Diagnostic("Expected function name", token.line, token.column))
        self._consume("(", "Expected '(' after function name")
        params = []
        if not self._check(")"):
            while True:
                params.append(self._parse_param())
                if self._match(","):
                    continue
                break
        self._consume(")", "Expected ')' after parameters")
        self._consume("->", "Expected '->' before return type")
        return_type = self._parse_type_expr()
        where_bounds: List[Tuple[str, str]] = []
        if self._match("WHERE"):
            while True:
                param = self._consume("IDENT", "Expected type parameter name")
                self._consume(":", "Expected ':' in where clause")
                trait = self._consume("IDENT", "Expected trait name")
                where_bounds.append((param.value, trait.value))
                if self._match(","):
                    continue
                break
        effects: List[str] = []
        body: List[ast.Stmt] = []
        spec: Optional[ast.SpecBlock] = None
        if self._match(":"):
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented function body")
            body = self._parse_block()
            self._consume("DEDENT", "Expected end of function body")
        else:
            self._consume("NEWLINE", "Expected newline after function signature")
            if self._check("SPEC"):
                spec = self._parse_spec_block()
                self._consume(":", "Expected ':' after spec block")
                self._consume("NEWLINE", "Expected newline after ':'")
                self._consume("INDENT", "Expected indented function body")
                body = self._parse_block()
                self._consume("DEDENT", "Expected end of function body")
            else:
                if self._check("IDENT") and self._peek().value == "effects":
                    self._advance()
                    self._consume(":", "Expected ':' after effects")
                    self._consume("NEWLINE", "Expected newline after effects")
                    self._consume("INDENT", "Expected indented effects block")
                    while not self._check("DEDENT") and not self._check("EOF"):
                        if self._check("NEWLINE"):
                            self._advance()
                            continue
                        if self._check("IDENT"):
                            effect = self._advance()
                            effects.append(effect.value)
                            self._consume("NEWLINE", "Expected newline after effect")
                            continue
                        token = self._peek()
                        raise YadroError(Diagnostic("Expected effect name", token.line, token.column))
                    self._consume("DEDENT", "Expected end of effects block")
                if "ffi" not in modifiers:
                    raise YadroError(Diagnostic("Function body required", fun_token.line, fun_token.column))
        return ast.FunctionDef(
            name=name.value,
            type_params=type_params,
            params=params,
            return_type=return_type,
            where_bounds=where_bounds,
            body=body,
            modifiers=modifiers,
            attributes=attributes,
            effects=effects,
            modifier_args=modifier_args,
            line=fun_token.line,
            column=fun_token.column,
            spec=spec,
        )

    def _parse_class(self) -> ast.ClassDef:
        attributes = self._take_pending_attributes()
        class_token = self._consume("CLASS", "Expected 'class'")
        modifiers, modifier_args = self._parse_modifiers()
        name = self._consume("IDENT", "Expected class name")
        base = None
        if self._match("("):
            base_token = self._consume("IDENT", "Expected base class name")
            base = base_token.value
            self._consume(")", "Expected ')' after base class")
        self._consume(":", "Expected ':' before class body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented class body")
        fields: List[ast.FieldDef] = []
        methods: List[ast.FunctionDef] = []
        invariants: List[ast.Expr] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._check("SPEC"):
                invariants.extend(self._parse_class_invariants())
                continue
            if self._check("FUN") or self._check("TEMP"):
                methods.append(self._parse_function_decl())
                continue
            type_expr = self._parse_type_expr()
            name_token = self._consume("IDENT", "Expected field name")
            self._consume("NEWLINE", "Expected newline after field")
            fields.append(ast.FieldDef(type_expr, name_token.value, name_token.line, name_token.column))
        self._consume("DEDENT", "Expected end of class body")
        return ast.ClassDef(
            name=name.value,
            base=base,
            modifiers=modifiers,
            attributes=attributes,
            modifier_args=modifier_args,
            fields=fields,
            methods=methods,
            line=class_token.line,
            column=class_token.column,
            invariants=invariants,
        )

    def _parse_trait(self, is_protocol: bool = False) -> ast.TraitDef:
        attributes = self._take_pending_attributes()
        trait_token = self._consume("PROTOCOL" if is_protocol else "TRAIT", "Expected 'protocol' or 'trait'")
        name = self._consume("IDENT", "Expected trait name")
        type_params: List[str] = []
        if self._match("["):
            while True:
                param = self._consume("IDENT", "Expected trait type parameter")
                type_params.append(param.value)
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after trait parameters")
        self._consume(":", "Expected ':' before trait body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented trait body")
        methods: List[ast.TraitMethodSig] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            methods.append(self._parse_trait_method())
        self._consume("DEDENT", "Expected end of trait body")
        return ast.TraitDef(name.value, type_params, methods, is_protocol, attributes, trait_token.line, trait_token.column)

    def _parse_trait_method(self) -> ast.TraitMethodSig:
        attributes = self._take_pending_attributes()
        type_params: List[str] = []
        if self._match("TEMP"):
            self._consume("<", "Expected '<' after temp")
            while True:
                param = self._consume("IDENT", "Expected trait method type parameter")
                type_params.append(param.value)
                if self._match(","):
                    continue
                break
            self._consume(">", "Expected '>' after trait method parameters")
        fun_token = self._consume("FUN", "Expected 'fun'")
        modifiers, modifier_args = self._parse_modifiers()
        if self._match("IDENT", "NEW"):
            name = self._previous()
        else:
            token = self._peek()
            raise YadroError(Diagnostic("Expected method name", token.line, token.column))
        self._consume("(", "Expected '(' after method name")
        params = []
        if not self._check(")"):
            while True:
                params.append(self._parse_param())
                if self._match(","):
                    continue
                break
        self._consume(")", "Expected ')' after parameters")
        self._consume("->", "Expected '->' before return type")
        return_type = self._parse_type_expr()
        where_bounds: List[Tuple[str, str]] = []
        if self._match("WHERE"):
            while True:
                param = self._consume("IDENT", "Expected type parameter name")
                self._consume(":", "Expected ':' in where clause")
                trait = self._consume("IDENT", "Expected trait name")
                where_bounds.append((param.value, trait.value))
                if self._match(","):
                    continue
                break
        self._consume("NEWLINE", "Expected newline after trait method")
        return ast.TraitMethodSig(
            name=name.value,
            type_params=type_params,
            params=params,
            return_type=return_type,
            where_bounds=where_bounds,
            modifiers=modifiers,
            attributes=attributes,
            modifier_args=modifier_args,
            line=fun_token.line,
            column=fun_token.column,
        )

    def _parse_impl(self) -> ast.ImplDef:
        attributes = self._take_pending_attributes()
        impl_token = self._consume("IMPL", "Expected 'impl'")
        trait_name = self._consume("IDENT", "Expected trait name")
        self._consume("FOR", "Expected 'for' after trait name")
        for_type = self._parse_type_expr()
        self._consume(":", "Expected ':' before impl body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented impl body")
        methods: List[ast.FunctionDef] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            methods.append(self._parse_function_decl())
        self._consume("DEDENT", "Expected end of impl body")
        return ast.ImplDef(trait_name.value, for_type, methods, attributes, impl_token.line, impl_token.column)

    def _parse_param(self) -> ast.Param:
        start_pos = self.pos
        if self._check("IDENT") and self._peek().value == "self":
            name = self._advance()
            return ast.Param(ast.TypeName("self", name.line, name.column), "self", None, name.line, name.column)
        if self._check("&"):
            amp = self._advance()
            mutable = False
            if self._match("MUT"):
                mutable = True
            if self._check("IDENT") and self._peek().value == "self":
                name = self._advance()
                type_expr = ast.TypeRef(ast.TypeName("self", name.line, name.column), mutable, amp.line, amp.column)
                return ast.Param(type_expr, "self", None, name.line, name.column)
            self.pos = start_pos
        refined = False
        if self._match("~"):
            refined = True
        type_name = self._parse_type_expr()
        name = self._consume("IDENT", "Expected parameter name")
        predicate = None
        if self._match(":"):
            if not refined:
                token = self._previous()
                raise YadroError(Diagnostic("Predicate only allowed for refined parameter", token.line, token.column))
            predicate = self._parse_expression()
        default = None
        if self._match("="):
            default = self._parse_expression()
        return ast.Param(type_name, name.value, default, name.line, name.column, refined, predicate)

    def _parse_type_expr(self) -> ast.TypeExpr:
        if self._match("&"):
            token = self._previous()
            mutable = False
            if self._match("MUT"):
                mutable = True
            element = self._parse_type_expr()
            return ast.TypeRef(element, mutable, token.line, token.column)
        if self._check("INT"):
            token = self._advance()
            return ast.TypeConstInt(int(token.value, 0), token.line, token.column)
        if self._check("TYPE"):
            token = self._advance()
            return ast.TypeName(token.value, token.line, token.column)
        token = self._consume("IDENT", "Expected type name")
        name = token.value
        while self._match("."):
            part = self._consume("IDENT", "Expected type name")
            name = f"{name}.{part.value}"
        if name in {"array", "darray", "gc", "gc_weak"} and self._match("["):
            element = self._parse_type_expr()
            if name == "array":
                self._consume(",", "Expected ',' after array element type")
                size_token = self._consume("INT", "Expected array size")
                size = int(size_token.value)
                self._consume("]", "Expected ']' after array type")
                return ast.TypeArray(element, size, token.line, token.column)
            self._consume("]", "Expected ']' after type")
            if name == "darray":
                return ast.TypeDArray(element, token.line, token.column)
            if name == "gc_weak":
                return ast.TypeGcWeak(element, token.line, token.column)
            return ast.TypeGc(element, token.line, token.column)
        if self._match("["):
            args: List[ast.TypeExpr] = []
            if not self._check("]"):
                while True:
                    args.append(self._parse_type_expr())
                    if self._match(","):
                        continue
                    break
            self._consume("]", "Expected ']' after type arguments")
            return ast.TypeApply(name, args, token.line, token.column)
        return ast.TypeName(name, token.line, token.column)

    def _parse_block(self) -> List[ast.Stmt]:
        statements: List[ast.Stmt] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._check(";"):
                self._advance()
                continue
            if self._check("ATTR"):
                self._parse_attribute_line()
                continue
            statements.append(self._parse_statement())
        return statements

    def _parse_statement(self) -> ast.Stmt:
        if self._check("ATTR") and self._is_unsafe_block_start():
            return self._parse_unsafe_block()
        if self._check("ATTR"):
            self._parse_attribute_line()
            if self._check("DEDENT") or self._check("EOF"):
                token = self._peek()
                raise YadroError(Diagnostic("Attribute must precede a statement", token.line, token.column))
            return self._parse_statement()
        if self._match("CONST"):
            return self._parse_const_decl()
        if self._match("DEL"):
            token = self._previous()
            target = self._parse_expression()
            self._consume_terminator("Expected newline after del")
            return ast.DelStmt(target, token.line, token.column)
        if self._match("ARENA"):
            token = self._previous()
            self._consume(":", "Expected ':' after arena")
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented block")
            body = self._parse_block()
            self._consume("DEDENT", "Expected end of arena block")
            return ast.ArenaStmt(body, token.line, token.column)
        if self._match("IF"):
            return self._parse_if()
        if self._match("SWITCH"):
            return self._parse_switch()
        if self._match("WHILE"):
            return self._parse_while()
        if self._match("FOR"):
            return self._parse_for()
        if self._match("REPEAT"):
            return self._parse_repeat()
        if self._match("ASM"):
            return self._parse_asm_stmt()
        if self._match("BREAK"):
            token = self._previous()
            self._consume("NEWLINE", "Expected newline after break")
            return ast.BreakStmt(token.line, token.column)
        if self._match("CONTINUE"):
            token = self._previous()
            self._consume("NEWLINE", "Expected newline after continue")
            return ast.ContinueStmt(token.line, token.column)
        if self._match("RETURN"):
            return self._parse_return()
        if (
            self._check("TYPE")
            or self._check("&")
            or (self._check("IDENT") and self._check_next("IDENT"))
            or self._looks_like_type_apply_decl()
            or (
                self._check("IDENT")
                and self._check_next("[")
                and self._peek().value in {"array", "darray", "gc", "gc_weak"}
            )
        ):
            return self._parse_var_decl()
        if self._check("IDENT"):
            saved = self.pos
            target = self._parse_assignment_target()
            if target is not None and self._match("=", "+=", "-=", "*=", "/=", "%=", "<<=", ">>=", "&=", "|=", "^=", "@=", "$="):
                op_token = self._previous()
                value = self._parse_expression()
                self._consume_terminator("Expected newline after assignment")
                if op_token.type == "$=":
                    return ast.SwapStmt(target, value, op_token.line, op_token.column)
                if op_token.type == "@=":
                    value = ast.UnaryOp("&", value, op_token.line, op_token.column)
                    if isinstance(target, ast.VarRef):
                        return ast.Assign(target.name, value, target.line, target.column)
                    if isinstance(target, ast.MemberAccess):
                        return ast.AssignMember(target.target, target.name, value, target.line, target.column)
                    if isinstance(target, ast.IndexExpr):
                        return ast.AssignIndex(target.target, target.index, value, target.line, target.column)
                if op_token.type != "=":
                    op = op_token.type[:-1]
                    return ast.CompoundAssign(target, op, value, op_token.line, op_token.column)
                if isinstance(target, ast.VarRef):
                    return ast.Assign(target.name, value, target.line, target.column)
                if isinstance(target, ast.MemberAccess):
                    return ast.AssignMember(target.target, target.name, value, target.line, target.column)
                if isinstance(target, ast.IndexExpr):
                    return ast.AssignIndex(target.target, target.index, value, target.line, target.column)
            self.pos = saved
        expr = self._parse_expression()
        self._consume_terminator("Expected newline after expression")
        return ast.ExprStmt(expr, expr.line, expr.column)

    def _is_unsafe_block_start(self) -> bool:
        if not self._check("ATTR"):
            return False
        if self.pos + 1 >= len(self.tokens):
            return False
        name = self.tokens[self.pos + 1]
        if name.type != "IDENT" or name.value != "unsafe":
            return False
        idx = self.pos + 2
        if idx < len(self.tokens) and self.tokens[idx].type == "(":
            depth = 1
            idx += 1
            while idx < len(self.tokens) and depth > 0:
                if self.tokens[idx].type == "(":
                    depth += 1
                elif self.tokens[idx].type == ")":
                    depth -= 1
                idx += 1
            if depth != 0:
                return False
        if idx >= len(self.tokens) or self.tokens[idx].type != "]":
            return False
        idx += 1
        return idx < len(self.tokens) and self.tokens[idx].type == ":"

    def _parse_unsafe_block(self) -> ast.UnsafeBlock:
        token = self._consume("ATTR", "Expected attribute start")
        name = self._consume("IDENT", "Expected attribute name")
        if name.value != "unsafe":
            raise YadroError(Diagnostic("Expected unsafe attribute", name.line, name.column))
        if self._match("("):
            self._parse_modifier_args()
        self._consume("]", "Expected ']' after attribute")
        self._consume(":", "Expected ':' after unsafe attribute")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of unsafe block")
        return ast.UnsafeBlock(body, token.line, token.column)

    def _parse_asm_stmt(self) -> ast.InlineAsm:
        token = self._previous()
        self._consume("(", "Expected '(' after asm")
        template = self._consume("STRING", "Expected asm template string")
        self._consume(")", "Expected ')' after asm template")
        inputs: List[Tuple[str, ast.Expr]] = []
        outputs: List[Tuple[str, str]] = []
        if self._match(":"):
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented asm block")
            while not self._check("DEDENT") and not self._check("EOF"):
                if self._check("NEWLINE"):
                    self._advance()
                    continue
                kind = self._consume("IDENT", "Expected asm clause")
                self._consume("(", "Expected '(' after asm clause")
                constraint = self._consume("STRING", "Expected asm constraint string")
                self._consume(")", "Expected ')' after asm constraint")
                if kind.value == "input":
                    expr = self._parse_expression()
                    inputs.append((constraint.value, expr))
                elif kind.value == "output":
                    name = self._consume("IDENT", "Expected output variable")
                    outputs.append((constraint.value, name.value))
                else:
                    raise YadroError(Diagnostic("Unknown asm clause", kind.line, kind.column))
                self._consume("NEWLINE", "Expected newline after asm clause")
            self._consume("DEDENT", "Expected end of asm block")
        else:
            self._consume("NEWLINE", "Expected newline after asm")
        return ast.InlineAsm(template.value, inputs, outputs, token.line, token.column)

    def _parse_assignment_target(self) -> Optional[ast.Expr]:
        expr = self._parse_postfix()
        if isinstance(expr, (ast.VarRef, ast.MemberAccess, ast.IndexExpr)):
            return expr
        return None

    def _parse_if(self) -> ast.IfStmt:
        if_token = self._previous()
        condition = self._parse_expression()
        self._consume(":", "Expected ':' after condition")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        then_body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        elifs: List[Tuple[ast.Expr, List[ast.Stmt]]] = []
        else_body: List[ast.Stmt] = []
        while self._match("ELSIF"):
            cond = self._parse_expression()
            self._consume(":", "Expected ':' after condition")
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented block")
            body = self._parse_block()
            self._consume("DEDENT", "Expected end of block")
            elifs.append((cond, body))
        if self._match("ELSE"):
            self._consume(":", "Expected ':' after else")
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented block")
            else_body = self._parse_block()
            self._consume("DEDENT", "Expected end of block")
        return ast.IfStmt(condition, then_body, elifs, else_body, if_token.line, if_token.column)

    def _parse_while(self) -> ast.WhileStmt:
        token = self._previous()
        condition = self._parse_expression()
        invariants: List[ast.Expr] = []
        if self._match(":"):
            self._consume("NEWLINE", "Expected newline after ':'")
        else:
            self._consume("NEWLINE", "Expected newline after condition")
            if self._check("SPEC"):
                invariants = self._parse_loop_invariants()
            self._consume(":", "Expected ':' after while header")
            self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        return ast.WhileStmt(condition, body, token.line, token.column, invariants)

    def _parse_for(self) -> ast.ForStmt:
        token = self._previous()
        var_type = self._parse_type_expr()
        name = self._consume("IDENT", "Expected loop variable name")
        self._consume("IN", "Expected 'in' after loop variable")
        self._consume("RANGE", "Expected 'range' after 'in'")
        self._consume("(", "Expected '(' after range")
        start = self._parse_expression()
        self._consume(",", "Expected ',' after range start")
        end = self._parse_expression()
        step = None
        if self._match(","):
            step = self._parse_expression()
        self._consume(")", "Expected ')' after range")
        invariants: List[ast.Expr] = []
        if self._match(":"):
            self._consume("NEWLINE", "Expected newline after ':'")
        else:
            self._consume("NEWLINE", "Expected newline after range")
            if self._check("SPEC"):
                invariants = self._parse_loop_invariants()
            self._consume(":", "Expected ':' after for header")
            self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        return ast.ForStmt(var_type, name.value, start, end, step, body, token.line, token.column, invariants)

    def _parse_repeat(self) -> ast.RepeatStmt:
        token = self._previous()
        self._consume(":", "Expected ':' after repeat")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        self._consume("UNTIL", "Expected 'until' after repeat block")
        condition = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after until condition")
        return ast.RepeatStmt(body, condition, token.line, token.column)

    def _parse_spec_type_def(self) -> ast.SpecTypeDef:
        spec_token = self._consume("SPEC", "Expected 'spec'")
        name = self._consume("IDENT", "Expected spec type name")
        type_params: List[str] = []
        if self._match("["):
            while True:
                param = self._consume("IDENT", "Expected type parameter name")
                type_params.append(param.value)
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after type parameters")
        self._consume("=", "Expected '=' after spec name")
        base_type = self._parse_type_expr()
        self._consume("WHERE", "Expected 'where' after base type")
        predicate = self._parse_expression()
        self._consume_terminator("Expected newline after spec definition")
        return ast.SpecTypeDef(name.value, type_params, base_type, predicate, spec_token.line, spec_token.column)

    def _parse_refined_type_def(self) -> ast.SpecTypeDef:
        token = self._consume("~", "Expected '~'")
        base_type = self._parse_type_expr()
        name = self._consume("IDENT", "Expected refined type name")
        self._consume("=", "Expected '=' after refined type name")
        predicate = self._parse_expression()
        self._consume_terminator("Expected newline after refined type definition")
        return ast.SpecTypeDef(name.value, [], base_type, predicate, token.line, token.column)

    def _parse_spec_block(self) -> ast.SpecBlock:
        spec_token = self._consume("SPEC", "Expected 'spec'")
        self._consume(":", "Expected ':' after spec")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented spec block")
        requires: List[ast.Expr] = []
        ensures: List[ast.Expr] = []
        invariants: List[ast.Expr] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._match("REQUIRES"):
                requires.append(self._parse_expression())
            elif self._match("ENSURES"):
                ensures.append(self._parse_expression())
            elif self._match("INVARIANT"):
                invariants.append(self._parse_expression())
            else:
                token = self._peek()
                raise YadroError(Diagnostic("Expected spec clause", token.line, token.column))
            self._consume("NEWLINE", "Expected newline after spec clause")
        self._consume("DEDENT", "Expected end of spec block")
        return ast.SpecBlock(requires, ensures, invariants, spec_token.line, spec_token.column)

    def _parse_class_invariants(self) -> List[ast.Expr]:
        self._consume("SPEC", "Expected 'spec'")
        if not self._match("INVARIANT"):
            token = self._peek()
            raise YadroError(Diagnostic("Expected 'invariant' after spec", token.line, token.column))
        self._consume(":", "Expected ':' after invariant")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented invariant block")
        invariants: List[ast.Expr] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            invariants.append(self._parse_expression())
            self._consume("NEWLINE", "Expected newline after invariant")
        self._consume("DEDENT", "Expected end of invariant block")
        return invariants

    def _parse_loop_invariants(self) -> List[ast.Expr]:
        invariants: List[ast.Expr] = []
        while self._check("SPEC"):
            self._advance()
            if not self._match("INVARIANT"):
                token = self._peek()
                raise YadroError(Diagnostic("Expected 'invariant' after spec", token.line, token.column))
            invariants.append(self._parse_expression())
            self._consume("NEWLINE", "Expected newline after invariant")
        return invariants

    def _parse_switch(self) -> ast.SwitchStmt:
        token = self._previous()
        expr = self._parse_expression()
        self._consume(":", "Expected ':' after switch expression")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented switch body")
        cases: List[ast.SwitchCase] = []
        default_body: List[ast.Stmt] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._match("CASE"):
                value = self._parse_pattern()
                self._consume(":", "Expected ':' after case value")
                self._consume("NEWLINE", "Expected newline after ':'")
                self._consume("INDENT", "Expected indented case block")
                body = self._parse_block()
                self._consume("DEDENT", "Expected end of case block")
                cases.append(ast.SwitchCase(value, body))
                continue
            if self._match("DEFAULT"):
                self._consume(":", "Expected ':' after default")
                self._consume("NEWLINE", "Expected newline after ':'")
                self._consume("INDENT", "Expected indented default block")
                default_body = self._parse_block()
                self._consume("DEDENT", "Expected end of default block")
                continue
            token = self._peek()
            raise YadroError(Diagnostic("Expected case or default in switch", token.line, token.column))
        self._consume("DEDENT", "Expected end of switch body")
        return ast.SwitchStmt(expr, cases, default_body, token.line, token.column)

    def _parse_pattern(self) -> ast.Pattern:
        if self._match("INT"):
            token = self._previous()
            return ast.PatternLiteral(ast.IntLiteral(int(token.value), token.line, token.column), token.line, token.column)
        if self._match("FLOAT"):
            token = self._previous()
            return ast.PatternLiteral(ast.FloatLiteral(float(token.value), token.line, token.column), token.line, token.column)
        if self._match("STRING"):
            token = self._previous()
            return ast.PatternLiteral(ast.StringLiteral(token.value, token.line, token.column), token.line, token.column)
        if self._match("CHAR"):
            token = self._previous()
            return ast.PatternLiteral(ast.CharLiteral(token.value, token.line, token.column), token.line, token.column)
        if self._match("TRUE"):
            token = self._previous()
            return ast.PatternLiteral(ast.BoolLiteral(True, token.line, token.column), token.line, token.column)
        if self._match("FALSE"):
            token = self._previous()
            return ast.PatternLiteral(ast.BoolLiteral(False, token.line, token.column), token.line, token.column)
        if self._match("IDENT"):
            token = self._previous()
            if token.value == "_":
                return ast.PatternWildcard(token.line, token.column)
            if self._match("("):
                args: List[str] = []
                if not self._check(")"):
                    while True:
                        name = self._consume("IDENT", "Expected pattern binding name")
                        args.append(name.value)
                        if self._match(","):
                            continue
                        break
                self._consume(")", "Expected ')' after pattern args")
                return ast.PatternConstructor(token.value, args, token.line, token.column)
            return ast.PatternConstructor(token.value, [], token.line, token.column)
        token = self._peek()
        raise YadroError(Diagnostic("Invalid pattern", token.line, token.column))

    def _parse_return(self) -> ast.ReturnStmt:
        token = self._previous()
        if self._check("NEWLINE"):
            self._advance()
            return ast.ReturnStmt(None, token.line, token.column)
        value = self._parse_expression()
        self._consume_terminator("Expected newline after return value")
        return ast.ReturnStmt(value, token.line, token.column)

    def _looks_like_type_apply_decl(self) -> bool:
        if not (self._check("IDENT") and self._check_next("[")):
            return False
        depth = 0
        idx = self.pos + 1
        while idx < len(self.tokens):
            token = self.tokens[idx]
            if token.type == "[":
                depth += 1
            elif token.type == "]":
                depth -= 1
                if depth == 0:
                    if idx + 1 < len(self.tokens):
                        return self.tokens[idx + 1].type == "IDENT"
                    return False
            idx += 1
        return False

    def _parse_var_decl(self) -> ast.VarDecl:
        type_name = self._parse_type_expr()
        name = self._consume("IDENT", "Expected variable name")
        if self._match("."):
            value_type = self._parse_type_expr()
            value_name = self._consume("IDENT", "Expected variable name")
            self._consume("=", "Expected '=' after variable name")
            if self._match("*"):
                star = self._previous()
                expr = ast.UnpackExpr(self._parse_expression(), star.line, star.column)
            else:
                expr = self._parse_expression()
            self._consume_terminator("Expected newline after variable declaration")
            return ast.DictDestructureDecl(type_name, name.value, value_type, value_name.value, expr, name.line, name.column)
        if self._match(","):
            names = [name.value]
            while True:
                next_name = self._consume("IDENT", "Expected variable name")
                names.append(next_name.value)
                if self._match(","):
                    continue
                break
            self._consume("=", "Expected '=' after variable names")
            if self._match("*"):
                star = self._previous()
                expr = ast.UnpackExpr(self._parse_expression(), star.line, star.column)
            else:
                expr = self._parse_expression()
            self._consume_terminator("Expected newline after variable declaration")
            return ast.DestructureDecl(type_name, names, expr, name.line, name.column)
        self._consume("=", "Expected '=' after variable name")
        expr = self._parse_expression()
        self._consume_terminator("Expected newline after variable declaration")
        return ast.VarDecl(type_name, name.value, expr, name.line, name.column)

    def _parse_assignment(self) -> ast.Assign:
        name = self._consume("IDENT", "Expected variable name")
        self._consume("=", "Expected '=' after variable name")
        expr = self._parse_expression()
        self._consume_terminator("Expected newline after assignment")
        return ast.Assign(name.value, expr, name.line, name.column)

    def _parse_expression(self) -> ast.Expr:
        return self._parse_pipeline()

    def _parse_pipeline(self) -> ast.Expr:
        exprs = [self._parse_or()]
        ops: List[str] = []
        while self._match(">>>", "<<<"):
            ops.append(self._previous().type)
            exprs.append(self._parse_or())
        if not ops:
            return exprs[0]
        if any(op == "<<<" for op in ops) and any(op == ">>>" for op in ops):
            token = self._previous()
            raise YadroError(Diagnostic("Cannot mix <<< and >>> in one pipeline", token.line, token.column))
        if ops[0] == ">>>":
            result = exprs[0]
            for next_expr in exprs[1:]:
                result = self._apply_pipeline(result, next_expr)
            return result
        result = exprs[-1]
        for func_expr in reversed(exprs[:-1]):
            result = self._apply_pipeline(result, func_expr)
        return result

    def _parse_or(self) -> ast.Expr:
        expr = self._parse_and()
        while self._match("OR", "XOR", "NAND"):
            op = self._previous().value
            right = self._parse_and()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_and(self) -> ast.Expr:
        expr = self._parse_bitwise_or()
        while self._match("AND"):
            op = self._previous().value
            right = self._parse_bitwise_or()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_bitwise_or(self) -> ast.Expr:
        expr = self._parse_bitwise_xor()
        while self._match("|"):
            op = self._previous().value
            right = self._parse_bitwise_xor()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_bitwise_xor(self) -> ast.Expr:
        expr = self._parse_bitwise_and()
        while self._match("^"):
            op = self._previous().value
            right = self._parse_bitwise_and()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_bitwise_and(self) -> ast.Expr:
        expr = self._parse_equality()
        while self._match("&"):
            op = self._previous().value
            right = self._parse_equality()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_equality(self) -> ast.Expr:
        expr = self._parse_comparison()
        while self._match("==", "!="):
            op = self._previous().value
            right = self._parse_comparison()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_comparison(self) -> ast.Expr:
        expr = self._parse_shift()
        while self._match("<", "<=", ">", ">="):
            op = self._previous().value
            right = self._parse_shift()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_shift(self) -> ast.Expr:
        expr = self._parse_term()
        while self._match("<<", ">>"):
            op = self._previous().value
            right = self._parse_term()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_term(self) -> ast.Expr:
        expr = self._parse_factor()
        while self._match("+", "-"):
            op = self._previous().value
            right = self._parse_factor()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_factor(self) -> ast.Expr:
        expr = self._parse_unary()
        while self._match("*", "/", "%"):
            op = self._previous().value
            right = self._parse_unary()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_unary(self) -> ast.Expr:
        if self._match("-", "!", "&", "*", "~"):
            op = self._previous().value
            if op == "&" and self._match("MUT"):
                op = "&mut"
            expr = self._parse_unary()
            return ast.UnaryOp(op, expr, expr.line, expr.column)
        return self._parse_postfix()

    def _parse_postfix(self) -> ast.Expr:
        expr = self._parse_primary()
        while True:
            if self._match("["):
                index = self._parse_expression()
                self._consume("]", "Expected ']' after index")
                expr = ast.IndexExpr(expr, index, expr.line, expr.column)
                continue
            if self._match("."):
                if self._match("IDENT", "NEW"):
                    name = self._previous()
                else:
                    token = self._peek()
                    raise YadroError(Diagnostic("Expected member name", token.line, token.column))
                type_args: List[ast.TypeExpr] = []
                if self._check("["):
                    saved = self.pos
                    self._advance()
                    depth = 1
                    while depth > 0 and not self._check("EOF"):
                        if self._match("["):
                            depth += 1
                        elif self._match("]"):
                            depth -= 1
                        else:
                            self._advance()
                    if depth == 0 and self._check("("):
                        self.pos = saved
                        self._consume("[", "Expected '[' after member name")
                        if not self._check("]"):
                            while True:
                                type_args.append(self._parse_type_expr())
                                if self._match(","):
                                    continue
                                break
                        self._consume("]", "Expected ']' after type arguments")
                    else:
                        self.pos = saved
                if self._match("("):
                    args = []
                    if not self._check(")"):
                        while True:
                            args.append(self._parse_expression())
                            if self._match(","):
                                continue
                            break
                    self._consume(")", "Expected ')' after arguments")
                    expr = ast.MethodCall(expr, name.value, type_args, args, name.line, name.column)
                else:
                    if type_args:
                        raise YadroError(Diagnostic("Type arguments require a call", name.line, name.column))
                    expr = ast.MemberAccess(expr, name.value, name.line, name.column)
                continue
            if self._match("?"):
                expr = ast.TryExpr(expr, expr.line, expr.column)
                continue
            break
        return expr

    def _parse_primary(self) -> ast.Expr:
        if self._match("NEW"):
            token = self._previous()
            type_expr = self._parse_type_expr()
            self._consume("(", "Expected '(' after type")
            args: List[ast.Expr] = []
            if not self._check(")"):
                while True:
                    args.append(self._parse_expression())
                    if self._match(","):
                        continue
                    break
            self._consume(")", "Expected ')' after arguments")
            return ast.NewExpr(type_expr, args, token.line, token.column)
        if self._match("INT"):
            token = self._previous()
            return ast.IntLiteral(int(token.value, 0), token.line, token.column)
        if self._match("FLOAT"):
            token = self._previous()
            return ast.FloatLiteral(float(token.value), token.line, token.column)
        if self._match("STRING"):
            token = self._previous()
            return ast.StringLiteral(token.value, token.line, token.column)
        if self._match("CHAR"):
            token = self._previous()
            return ast.CharLiteral(token.value, token.line, token.column)
        if self._match("TRUE"):
            token = self._previous()
            return ast.BoolLiteral(True, token.line, token.column)
        if self._match("FALSE"):
            token = self._previous()
            return ast.BoolLiteral(False, token.line, token.column)
        if self._match("IDENT"):
            token = self._previous()
            type_args: List[ast.TypeExpr] = []
            if self._check("["):
                saved = self.pos
                self._advance()
                depth = 1
                while depth > 0 and not self._check("EOF"):
                    if self._match("["):
                        depth += 1
                    elif self._match("]"):
                        depth -= 1
                    else:
                        self._advance()
                if depth == 0 and self._check("("):
                    self.pos = saved
                    self._consume("[", "Expected '[' after identifier")
                    if not self._check("]"):
                        while True:
                            type_args.append(self._parse_type_expr())
                            if self._match(","):
                                continue
                            break
                    self._consume("]", "Expected ']' after type arguments")
                else:
                    self.pos = saved
            if self._match("("):
                args = []
                if not self._check(")"):
                    while True:
                        args.append(self._parse_expression())
                        if self._match(","):
                            continue
                        break
                self._consume(")", "Expected ')' after arguments")
                return ast.Call(token.value, args, type_args, token.line, token.column)
            if type_args:
                raise YadroError(Diagnostic("Type arguments require a call", token.line, token.column))
            return ast.VarRef(token.value, token.line, token.column)
        if self._match("["):
            token = self._previous()
            items: List[ast.Expr] = []
            if not self._check("]"):
                while True:
                    items.append(self._parse_expression())
                    if self._match(","):
                        continue
                    break
            self._consume("]", "Expected ']' after array literal")
            return ast.ArrayLiteral(items, token.line, token.column)
        if self._match("{"):
            token = self._previous()
            if self._check("}"):
                self._consume("}", "Expected '}' after literal")
                raise YadroError(Diagnostic("Empty map/set literal is not supported", token.line, token.column))
            first = self._parse_expression()
            if self._match(":"):
                pairs: List[Tuple[ast.Expr, ast.Expr]] = []
                value = self._parse_expression()
                pairs.append((first, value))
                while self._match(","):
                    if self._check("}"):
                        break
                    key = self._parse_expression()
                    self._consume(":", "Expected ':' in map literal")
                    val = self._parse_expression()
                    pairs.append((key, val))
                self._consume("}", "Expected '}' after map literal")
                return ast.DictLiteral(pairs, token.line, token.column)
            items = [first]
            while self._match(","):
                if self._check("}"):
                    break
                items.append(self._parse_expression())
            self._consume("}", "Expected '}' after set literal")
            return ast.SetLiteral(items, token.line, token.column)
        if self._match("("):
            expr = self._parse_expression()
            self._consume(")", "Expected ')'")
            return expr
        raise YadroError(Diagnostic("Unexpected token", self._peek().line, self._peek().column))

    def _parse_modifiers(self) -> tuple[List[str], dict]:
        modifiers: List[str] = []
        modifier_args: dict = {}
        if not self._match("["):
            return modifiers, modifier_args
        while not self._check("]"):
            if self._check("IDENT") or self._check("CLASS") or self._check("CONST") or self._check("ASYNC") or self._check("THREAD"):
                token = self._advance()
                name = token.value
                args = {}
                if self._match("("):
                    args = self._parse_modifier_args()
                modifiers.append(name)
                if args:
                    modifier_args[name] = args
            else:
                token = self._peek()
                raise YadroError(Diagnostic("Expected modifier", token.line, token.column))
            if self._match(","):
                continue
            break
        self._consume("]", "Expected ']' after modifiers")
        return modifiers, modifier_args

    def _parse_modifier_args(self) -> dict:
        args: dict = {}
        positional: List[object] = []
        if not self._check(")"):
            while True:
                if self._check("IDENT") and self._check_next("="):
                    key = self._advance()
                    self._consume("=", "Expected '=' in modifier argument")
                    value = self._parse_modifier_value()
                    args[key.value] = value
                else:
                    value = self._parse_modifier_value()
                    positional.append(value)
                if self._match(","):
                    continue
                break
        self._consume(")", "Expected ')' after modifier arguments")
        if positional:
            args["$"] = positional
        return args

    def _parse_modifier_value(self) -> object:
        if self._match("STRING"):
            return self._previous().value
        if self._match("INT"):
            return int(self._previous().value)
        if self._match("IDENT"):
            return self._previous().value
        token = self._peek()
        raise YadroError(Diagnostic("Expected modifier argument", token.line, token.column))

    def _parse_attribute_line(self) -> None:
        token = self._consume("ATTR", "Expected attribute start")
        name = self._consume("IDENT", "Expected attribute name")
        args: dict = {}
        if self._match("("):
            args = self._parse_modifier_args()
        self._consume("]", "Expected ']' after attribute")
        self._consume("NEWLINE", "Expected newline after attribute")
        self.pending_attributes.append(ast.Attribute(name.value, args, token.line, token.column))

    def _take_pending_attributes(self) -> List[ast.Attribute]:
        attrs = self.pending_attributes
        self.pending_attributes = []
        return attrs

    def _parse_const_decl(self) -> ast.ConstDecl:
        token = self._previous()
        type_name = self._parse_type_expr()
        name = self._consume("IDENT", "Expected constant name")
        self._consume("=", "Expected '=' after constant name")
        expr = self._parse_expression()
        self._consume_terminator("Expected newline after const declaration")
        return ast.ConstDecl(type_name, name.value, expr, token.line, token.column)

    def _apply_pipeline(self, value_expr: ast.Expr, fn_expr: ast.Expr) -> ast.Expr:
        if isinstance(fn_expr, ast.Call):
            return ast.Call(fn_expr.callee, [value_expr, *fn_expr.args], fn_expr.type_args, fn_expr.line, fn_expr.column)
        if isinstance(fn_expr, ast.VarRef):
            return ast.Call(fn_expr.name, [value_expr], [], fn_expr.line, fn_expr.column)
        if isinstance(fn_expr, ast.MethodCall):
            return ast.MethodCall(fn_expr.target, fn_expr.name, fn_expr.type_args, [value_expr, *fn_expr.args], fn_expr.line, fn_expr.column)
        if isinstance(fn_expr, ast.MemberAccess):
            return ast.MethodCall(fn_expr.target, fn_expr.name, [], [value_expr], fn_expr.line, fn_expr.column)
        raise YadroError(Diagnostic("Pipeline target must be callable", fn_expr.line, fn_expr.column))

    def _consume_terminator(self, message: str) -> None:
        if self._match("NEWLINE"):
            return
        if self._match(";"):
            if self._check("NEWLINE"):
                self._advance()
            return
        token = self._peek()
        raise YadroError(Diagnostic(message, token.line, token.column))

    def _match(self, *types: str) -> bool:
        for t in types:
            if self._check(t):
                self._advance()
                return True
        return False

    def _consume(self, token_type: str, message: str) -> Token:
        if self._check(token_type):
            return self._advance()
        token = self._peek()
        raise YadroError(Diagnostic(message, token.line, token.column))

    def _check(self, token_type: str) -> bool:
        return self._peek().type == token_type

    def _check_next(self, token_type: str) -> bool:
        if self.pos + 1 >= len(self.tokens):
            return False
        return self.tokens[self.pos + 1].type == token_type

    def _advance(self) -> Token:
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _previous(self) -> Token:
        return self.tokens[self.pos - 1]
