from typing import List, Optional, Tuple

from . import ast
from .errors import Diagnostic, YadroError
from .token import Token


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def parse(self, directives: List[ast.Directive]) -> ast.Program:
        functions: List[ast.FunctionDef] = []
        traits: List[ast.TraitDef] = []
        impls: List[ast.ImplDef] = []
        classes: List[ast.ClassDef] = []
        main_block: List[ast.Stmt] = []
        in_main = False
        while not self._check("EOF"):
            if self._match("START"):
                in_main = True
                self._consume("NEWLINE", "Expected newline after #start")
                continue
            if self._match("END"):
                in_main = False
                self._consume("NEWLINE", "Expected newline after #end")
                continue
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._check("FUN"):
                functions.append(self._parse_function_decl())
                continue
            if self._check("TEMP"):
                functions.append(self._parse_function_decl())
                continue
            if self._check("TRAIT"):
                traits.append(self._parse_trait())
                continue
            if self._check("IMPL"):
                impls.append(self._parse_impl())
                continue
            if self._check("CLASS"):
                classes.append(self._parse_class())
                continue
            stmt = self._parse_statement()
            if in_main:
                main_block.append(stmt)
            else:
                main_block.append(stmt)
        return ast.Program(directives, classes, traits, impls, functions, main_block)

    def _parse_function_decl(self) -> ast.FunctionDef:
        type_params: List[str] = []
        if self._match("TEMP"):
            self._consume("<", "Expected '<' after temp")
            while True:
                name = self._consume("IDENT", "Expected type parameter name")
                type_params.append(name.value)
                if self._match(","):
                    continue
                break
            self._consume(">", "Expected '>' after type parameters")
        fun_token = self._consume("FUN", "Expected 'fun'")
        modifiers = []
        if self._match("["):
            while not self._check("]"):
                if self._check("IDENT") or self._check("CLASS"):
                    token = self._advance()
                    modifiers.append(token.value)
                else:
                    token = self._peek()
                    raise YadroError(Diagnostic("Expected modifier", token.line, token.column))
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after modifiers")
        if self._match("IDENT", "NEW"):
            name = self._previous()
        else:
            token = self._peek()
            raise YadroError(Diagnostic("Expected function name", token.line, token.column))
        self._consume("(", "Expected '(' after function name")
        params = []
        if not self._check(")"):
            while True:
                params.append(self._parse_param())
                if self._match(","):
                    continue
                break
        self._consume(")", "Expected ')' after parameters")
        self._consume("->", "Expected '->' before return type")
        return_type = self._parse_type_expr()
        where_bounds: List[Tuple[str, str]] = []
        if self._match("WHERE"):
            while True:
                param = self._consume("IDENT", "Expected type parameter name")
                self._consume(":", "Expected ':' in where clause")
                trait = self._consume("IDENT", "Expected trait name")
                where_bounds.append((param.value, trait.value))
                if self._match(","):
                    continue
                break
        self._consume(":", "Expected ':' before function body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented function body")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of function body")
        return ast.FunctionDef(
            name=name.value,
            type_params=type_params,
            params=params,
            return_type=return_type,
            where_bounds=where_bounds,
            body=body,
            modifiers=modifiers,
            line=fun_token.line,
            column=fun_token.column,
        )

    def _parse_class(self) -> ast.ClassDef:
        class_token = self._consume("CLASS", "Expected 'class'")
        modifiers = []
        if self._match("["):
            while not self._check("]"):
                if self._check("IDENT") or self._check("CLASS"):
                    token = self._advance()
                    modifiers.append(token.value)
                else:
                    token = self._peek()
                    raise YadroError(Diagnostic("Expected class modifier", token.line, token.column))
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after modifiers")
        name = self._consume("IDENT", "Expected class name")
        base = None
        if self._match("("):
            base_token = self._consume("IDENT", "Expected base class name")
            base = base_token.value
            self._consume(")", "Expected ')' after base class")
        self._consume(":", "Expected ':' before class body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented class body")
        fields: List[ast.FieldDef] = []
        methods: List[ast.FunctionDef] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._check("FUN") or self._check("TEMP"):
                methods.append(self._parse_function_decl())
                continue
            type_expr = self._parse_type_expr()
            name_token = self._consume("IDENT", "Expected field name")
            self._consume("NEWLINE", "Expected newline after field")
            fields.append(ast.FieldDef(type_expr, name_token.value, name_token.line, name_token.column))
        self._consume("DEDENT", "Expected end of class body")
        return ast.ClassDef(
            name=name.value,
            base=base,
            modifiers=modifiers,
            fields=fields,
            methods=methods,
            line=class_token.line,
            column=class_token.column,
        )

    def _parse_trait(self) -> ast.TraitDef:
        trait_token = self._consume("TRAIT", "Expected 'trait'")
        name = self._consume("IDENT", "Expected trait name")
        type_params: List[str] = []
        if self._match("["):
            while True:
                param = self._consume("IDENT", "Expected trait type parameter")
                type_params.append(param.value)
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after trait parameters")
        self._consume(":", "Expected ':' before trait body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented trait body")
        methods: List[ast.TraitMethodSig] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            methods.append(self._parse_trait_method())
        self._consume("DEDENT", "Expected end of trait body")
        return ast.TraitDef(name.value, type_params, methods, trait_token.line, trait_token.column)

    def _parse_trait_method(self) -> ast.TraitMethodSig:
        fun_token = self._consume("FUN", "Expected 'fun'")
        modifiers = []
        if self._match("["):
            while not self._check("]"):
                if self._check("IDENT") or self._check("CLASS"):
                    token = self._advance()
                    modifiers.append(token.value)
                else:
                    token = self._peek()
                    raise YadroError(Diagnostic("Expected modifier", token.line, token.column))
                if self._match(","):
                    continue
                break
            self._consume("]", "Expected ']' after modifiers")
        if self._match("IDENT", "NEW"):
            name = self._previous()
        else:
            token = self._peek()
            raise YadroError(Diagnostic("Expected method name", token.line, token.column))
        self._consume("(", "Expected '(' after method name")
        params = []
        if not self._check(")"):
            while True:
                params.append(self._parse_param())
                if self._match(","):
                    continue
                break
        self._consume(")", "Expected ')' after parameters")
        self._consume("->", "Expected '->' before return type")
        return_type = self._parse_type_expr()
        self._consume("NEWLINE", "Expected newline after trait method")
        return ast.TraitMethodSig(name.value, params, return_type, modifiers, fun_token.line, fun_token.column)

    def _parse_impl(self) -> ast.ImplDef:
        impl_token = self._consume("IMPL", "Expected 'impl'")
        trait_name = self._consume("IDENT", "Expected trait name")
        self._consume("FOR", "Expected 'for' after trait name")
        for_type = self._parse_type_expr()
        self._consume(":", "Expected ':' before impl body")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented impl body")
        methods: List[ast.FunctionDef] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            methods.append(self._parse_function_decl())
        self._consume("DEDENT", "Expected end of impl body")
        return ast.ImplDef(trait_name.value, for_type, methods, impl_token.line, impl_token.column)

    def _parse_param(self) -> ast.Param:
        start_pos = self.pos
        if self._check("IDENT") and self._peek().value == "self":
            name = self._advance()
            return ast.Param(ast.TypeName("self", name.line, name.column), "self", None, name.line, name.column)
        if self._check("&"):
            amp = self._advance()
            mutable = False
            if self._match("MUT"):
                mutable = True
            if self._check("IDENT") and self._peek().value == "self":
                name = self._advance()
                type_expr = ast.TypeRef(ast.TypeName("self", name.line, name.column), mutable, amp.line, amp.column)
                return ast.Param(type_expr, "self", None, name.line, name.column)
            self.pos = start_pos
        type_name = self._parse_type_expr()
        name = self._consume("IDENT", "Expected parameter name")
        default = None
        if self._match("="):
            default = self._parse_expression()
        return ast.Param(type_name, name.value, default, name.line, name.column)

    def _parse_type_expr(self) -> ast.TypeExpr:
        if self._match("&"):
            token = self._previous()
            mutable = False
            if self._match("MUT"):
                mutable = True
            element = self._parse_type_expr()
            return ast.TypeRef(element, mutable, token.line, token.column)
        if self._check("TYPE"):
            token = self._advance()
            return ast.TypeName(token.value, token.line, token.column)
        token = self._consume("IDENT", "Expected type name")
        if token.value in {"array", "darray", "gc"} and self._match("["):
            element = self._parse_type_expr()
            if token.value == "array":
                self._consume(",", "Expected ',' after array element type")
                size_token = self._consume("INT", "Expected array size")
                size = int(size_token.value)
                self._consume("]", "Expected ']' after array type")
                return ast.TypeArray(element, size, token.line, token.column)
            self._consume("]", "Expected ']' after type")
            if token.value == "darray":
                return ast.TypeDArray(element, token.line, token.column)
            return ast.TypeGc(element, token.line, token.column)
        if self._match("["):
            args: List[ast.TypeExpr] = []
            if not self._check("]"):
                while True:
                    args.append(self._parse_type_expr())
                    if self._match(","):
                        continue
                    break
            self._consume("]", "Expected ']' after type arguments")
            return ast.TypeApply(token.value, args, token.line, token.column)
        return ast.TypeName(token.value, token.line, token.column)

    def _parse_block(self) -> List[ast.Stmt]:
        statements: List[ast.Stmt] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            statements.append(self._parse_statement())
        return statements

    def _parse_statement(self) -> ast.Stmt:
        if self._match("DEL"):
            token = self._previous()
            target = self._parse_expression()
            self._consume("NEWLINE", "Expected newline after del")
            return ast.DelStmt(target, token.line, token.column)
        if self._match("IF"):
            return self._parse_if()
        if self._match("SWITCH"):
            return self._parse_switch()
        if self._match("WHILE"):
            return self._parse_while()
        if self._match("FOR"):
            return self._parse_for()
        if self._match("REPEAT"):
            return self._parse_repeat()
        if self._match("BREAK"):
            token = self._previous()
            self._consume("NEWLINE", "Expected newline after break")
            return ast.BreakStmt(token.line, token.column)
        if self._match("CONTINUE"):
            token = self._previous()
            self._consume("NEWLINE", "Expected newline after continue")
            return ast.ContinueStmt(token.line, token.column)
        if self._match("RETURN"):
            return self._parse_return()
        if (
            self._check("TYPE")
            or self._check("&")
            or (self._check("IDENT") and self._check_next("IDENT"))
            or (
                self._check("IDENT")
                and self._check_next("[")
                and self._peek().value in {"array", "darray", "gc"}
            )
        ):
            return self._parse_var_decl()
        if self._check("IDENT"):
            saved = self.pos
            target = self._parse_assignment_target()
            if target is not None and self._match("="):
                value = self._parse_expression()
                self._consume("NEWLINE", "Expected newline after assignment")
                if isinstance(target, ast.VarRef):
                    return ast.Assign(target.name, value, target.line, target.column)
                if isinstance(target, ast.MemberAccess):
                    return ast.AssignMember(target.target, target.name, value, target.line, target.column)
                if isinstance(target, ast.IndexExpr):
                    return ast.AssignIndex(target.target, target.index, value, target.line, target.column)
            self.pos = saved
        expr = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after expression")
        return ast.ExprStmt(expr, expr.line, expr.column)

    def _parse_assignment_target(self) -> Optional[ast.Expr]:
        expr = self._parse_postfix()
        if isinstance(expr, (ast.VarRef, ast.MemberAccess, ast.IndexExpr)):
            return expr
        return None

    def _parse_if(self) -> ast.IfStmt:
        if_token = self._previous()
        condition = self._parse_expression()
        self._consume(":", "Expected ':' after condition")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        then_body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        elifs: List[Tuple[ast.Expr, List[ast.Stmt]]] = []
        else_body: List[ast.Stmt] = []
        while self._match("ELSIF"):
            cond = self._parse_expression()
            self._consume(":", "Expected ':' after condition")
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented block")
            body = self._parse_block()
            self._consume("DEDENT", "Expected end of block")
            elifs.append((cond, body))
        if self._match("ELSE"):
            self._consume(":", "Expected ':' after else")
            self._consume("NEWLINE", "Expected newline after ':'")
            self._consume("INDENT", "Expected indented block")
            else_body = self._parse_block()
            self._consume("DEDENT", "Expected end of block")
        return ast.IfStmt(condition, then_body, elifs, else_body, if_token.line, if_token.column)

    def _parse_while(self) -> ast.WhileStmt:
        token = self._previous()
        condition = self._parse_expression()
        self._consume(":", "Expected ':' after condition")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        return ast.WhileStmt(condition, body, token.line, token.column)

    def _parse_for(self) -> ast.ForStmt:
        token = self._previous()
        var_type = self._parse_type_expr()
        name = self._consume("IDENT", "Expected loop variable name")
        self._consume("IN", "Expected 'in' after loop variable")
        self._consume("RANGE", "Expected 'range' after 'in'")
        self._consume("(", "Expected '(' after range")
        start = self._parse_expression()
        self._consume(",", "Expected ',' after range start")
        end = self._parse_expression()
        step = None
        if self._match(","):
            step = self._parse_expression()
        self._consume(")", "Expected ')' after range")
        self._consume(":", "Expected ':' after range")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        return ast.ForStmt(var_type, name.value, start, end, step, body, token.line, token.column)

    def _parse_repeat(self) -> ast.RepeatStmt:
        token = self._previous()
        self._consume(":", "Expected ':' after repeat")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented block")
        body = self._parse_block()
        self._consume("DEDENT", "Expected end of block")
        self._consume("UNTIL", "Expected 'until' after repeat block")
        condition = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after until condition")
        return ast.RepeatStmt(body, condition, token.line, token.column)

    def _parse_switch(self) -> ast.SwitchStmt:
        token = self._previous()
        expr = self._parse_expression()
        self._consume(":", "Expected ':' after switch expression")
        self._consume("NEWLINE", "Expected newline after ':'")
        self._consume("INDENT", "Expected indented switch body")
        cases: List[ast.SwitchCase] = []
        default_body: List[ast.Stmt] = []
        while not self._check("DEDENT") and not self._check("EOF"):
            if self._check("NEWLINE"):
                self._advance()
                continue
            if self._match("CASE"):
                value = self._parse_pattern()
                self._consume(":", "Expected ':' after case value")
                self._consume("NEWLINE", "Expected newline after ':'")
                self._consume("INDENT", "Expected indented case block")
                body = self._parse_block()
                self._consume("DEDENT", "Expected end of case block")
                cases.append(ast.SwitchCase(value, body))
                continue
            if self._match("DEFAULT"):
                self._consume(":", "Expected ':' after default")
                self._consume("NEWLINE", "Expected newline after ':'")
                self._consume("INDENT", "Expected indented default block")
                default_body = self._parse_block()
                self._consume("DEDENT", "Expected end of default block")
                continue
            token = self._peek()
            raise YadroError(Diagnostic("Expected case or default in switch", token.line, token.column))
        self._consume("DEDENT", "Expected end of switch body")
        return ast.SwitchStmt(expr, cases, default_body, token.line, token.column)

    def _parse_pattern(self) -> ast.Pattern:
        if self._match("INT"):
            token = self._previous()
            return ast.PatternLiteral(ast.IntLiteral(int(token.value), token.line, token.column), token.line, token.column)
        if self._match("FLOAT"):
            token = self._previous()
            return ast.PatternLiteral(ast.FloatLiteral(float(token.value), token.line, token.column), token.line, token.column)
        if self._match("STRING"):
            token = self._previous()
            return ast.PatternLiteral(ast.StringLiteral(token.value, token.line, token.column), token.line, token.column)
        if self._match("CHAR"):
            token = self._previous()
            return ast.PatternLiteral(ast.CharLiteral(token.value, token.line, token.column), token.line, token.column)
        if self._match("TRUE"):
            token = self._previous()
            return ast.PatternLiteral(ast.BoolLiteral(True, token.line, token.column), token.line, token.column)
        if self._match("FALSE"):
            token = self._previous()
            return ast.PatternLiteral(ast.BoolLiteral(False, token.line, token.column), token.line, token.column)
        if self._match("IDENT"):
            token = self._previous()
            if token.value == "_":
                return ast.PatternWildcard(token.line, token.column)
            if self._match("("):
                args: List[str] = []
                if not self._check(")"):
                    while True:
                        name = self._consume("IDENT", "Expected pattern binding name")
                        args.append(name.value)
                        if self._match(","):
                            continue
                        break
                self._consume(")", "Expected ')' after pattern args")
                return ast.PatternConstructor(token.value, args, token.line, token.column)
            return ast.PatternConstructor(token.value, [], token.line, token.column)
        token = self._peek()
        raise YadroError(Diagnostic("Invalid pattern", token.line, token.column))

    def _parse_return(self) -> ast.ReturnStmt:
        token = self._previous()
        if self._check("NEWLINE"):
            self._advance()
            return ast.ReturnStmt(None, token.line, token.column)
        value = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after return value")
        return ast.ReturnStmt(value, token.line, token.column)

    def _parse_var_decl(self) -> ast.VarDecl:
        type_name = self._parse_type_expr()
        name = self._consume("IDENT", "Expected variable name")
        self._consume("=", "Expected '=' after variable name")
        expr = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after variable declaration")
        return ast.VarDecl(type_name, name.value, expr, name.line, name.column)

    def _parse_assignment(self) -> ast.Assign:
        name = self._consume("IDENT", "Expected variable name")
        self._consume("=", "Expected '=' after variable name")
        expr = self._parse_expression()
        self._consume("NEWLINE", "Expected newline after assignment")
        return ast.Assign(name.value, expr, name.line, name.column)

    def _parse_expression(self) -> ast.Expr:
        return self._parse_or()

    def _parse_or(self) -> ast.Expr:
        expr = self._parse_and()
        while self._match("OR", "XOR", "NAND"):
            op = self._previous().value
            right = self._parse_and()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_and(self) -> ast.Expr:
        expr = self._parse_equality()
        while self._match("AND"):
            op = self._previous().value
            right = self._parse_equality()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_equality(self) -> ast.Expr:
        expr = self._parse_comparison()
        while self._match("==", "!="):
            op = self._previous().value
            right = self._parse_comparison()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_comparison(self) -> ast.Expr:
        expr = self._parse_term()
        while self._match("<", "<=", ">", ">="):
            op = self._previous().value
            right = self._parse_term()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_term(self) -> ast.Expr:
        expr = self._parse_factor()
        while self._match("+", "-"):
            op = self._previous().value
            right = self._parse_factor()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_factor(self) -> ast.Expr:
        expr = self._parse_unary()
        while self._match("*", "/", "%"):
            op = self._previous().value
            right = self._parse_unary()
            expr = ast.BinaryOp(op, expr, right, expr.line, expr.column)
        return expr

    def _parse_unary(self) -> ast.Expr:
        if self._match("-", "!", "&", "*"):
            op = self._previous().value
            if op == "&" and self._match("MUT"):
                op = "&mut"
            expr = self._parse_unary()
            return ast.UnaryOp(op, expr, expr.line, expr.column)
        return self._parse_postfix()

    def _parse_postfix(self) -> ast.Expr:
        expr = self._parse_primary()
        while True:
            if self._match("["):
                index = self._parse_expression()
                self._consume("]", "Expected ']' after index")
                expr = ast.IndexExpr(expr, index, expr.line, expr.column)
                continue
            if self._match("."):
                if self._match("IDENT", "NEW"):
                    name = self._previous()
                else:
                    token = self._peek()
                    raise YadroError(Diagnostic("Expected member name", token.line, token.column))
                if self._match("("):
                    args = []
                    if not self._check(")"):
                        while True:
                            args.append(self._parse_expression())
                            if self._match(","):
                                continue
                            break
                    self._consume(")", "Expected ')' after arguments")
                    expr = ast.MethodCall(expr, name.value, args, name.line, name.column)
                else:
                    expr = ast.MemberAccess(expr, name.value, name.line, name.column)
                continue
            break
        return expr

    def _parse_primary(self) -> ast.Expr:
        if self._match("NEW"):
            token = self._previous()
            type_expr = self._parse_type_expr()
            self._consume("(", "Expected '(' after type")
            args: List[ast.Expr] = []
            if not self._check(")"):
                while True:
                    args.append(self._parse_expression())
                    if self._match(","):
                        continue
                    break
            self._consume(")", "Expected ')' after arguments")
            return ast.NewExpr(type_expr, args, token.line, token.column)
        if self._match("INT"):
            token = self._previous()
            return ast.IntLiteral(int(token.value), token.line, token.column)
        if self._match("FLOAT"):
            token = self._previous()
            return ast.FloatLiteral(float(token.value), token.line, token.column)
        if self._match("STRING"):
            token = self._previous()
            return ast.StringLiteral(token.value, token.line, token.column)
        if self._match("CHAR"):
            token = self._previous()
            return ast.CharLiteral(token.value, token.line, token.column)
        if self._match("TRUE"):
            token = self._previous()
            return ast.BoolLiteral(True, token.line, token.column)
        if self._match("FALSE"):
            token = self._previous()
            return ast.BoolLiteral(False, token.line, token.column)
        if self._match("IDENT"):
            token = self._previous()
            type_args: List[ast.TypeExpr] = []
            if self._check("["):
                saved = self.pos
                self._advance()
                depth = 1
                while depth > 0 and not self._check("EOF"):
                    if self._match("["):
                        depth += 1
                    elif self._match("]"):
                        depth -= 1
                    else:
                        self._advance()
                if depth == 0 and self._check("("):
                    self.pos = saved
                    self._consume("[", "Expected '[' after identifier")
                    if not self._check("]"):
                        while True:
                            type_args.append(self._parse_type_expr())
                            if self._match(","):
                                continue
                            break
                    self._consume("]", "Expected ']' after type arguments")
                else:
                    self.pos = saved
            if self._match("("):
                args = []
                if not self._check(")"):
                    while True:
                        args.append(self._parse_expression())
                        if self._match(","):
                            continue
                        break
                self._consume(")", "Expected ')' after arguments")
                return ast.Call(token.value, args, type_args, token.line, token.column)
            if type_args:
                raise YadroError(Diagnostic("Type arguments require a call", token.line, token.column))
            return ast.VarRef(token.value, token.line, token.column)
        if self._match("["):
            token = self._previous()
            items: List[ast.Expr] = []
            if not self._check("]"):
                while True:
                    items.append(self._parse_expression())
                    if self._match(","):
                        continue
                    break
            self._consume("]", "Expected ']' after array literal")
            return ast.ArrayLiteral(items, token.line, token.column)
        if self._match("("):
            expr = self._parse_expression()
            self._consume(")", "Expected ')'")
            return expr
        raise YadroError(Diagnostic("Unexpected token", self._peek().line, self._peek().column))

    def _match(self, *types: str) -> bool:
        for t in types:
            if self._check(t):
                self._advance()
                return True
        return False

    def _consume(self, token_type: str, message: str) -> Token:
        if self._check(token_type):
            return self._advance()
        token = self._peek()
        raise YadroError(Diagnostic(message, token.line, token.column))

    def _check(self, token_type: str) -> bool:
        return self._peek().type == token_type

    def _check_next(self, token_type: str) -> bool:
        if self.pos + 1 >= len(self.tokens):
            return False
        return self.tokens[self.pos + 1].type == token_type

    def _advance(self) -> Token:
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _previous(self) -> Token:
        return self.tokens[self.pos - 1]
