from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass(frozen=True)
class Type:
    kind: str
    element: Optional["Type"] = None
    size: Optional[int] = None
    mutable: bool = False
    type_args: List["Type"] = field(default_factory=list)
    var_name: Optional[str] = None
    region: Optional[int] = None

    @property
    def name(self) -> str:
        if self.kind == "ref":
            prefix = "&mut " if self.mutable else "&"
            return f"{prefix}{self.element.name}"
        if self.kind == "array":
            return f"array[{self.element.name},{self.size}]"
        if self.kind == "darray":
            return f"darray[{self.element.name}]"
        if self.kind == "gc":
            return f"gc[{self.element.name}]"
        if self.kind == "gc_weak":
            return f"gc_weak[{self.element.name}]"
        if self.kind == "var":
            return self.var_name or "T"
        if self.kind == "trait":
            return self.var_name or "trait"
        if self.type_args:
            args = ", ".join(t.name for t in self.type_args)
            return f"{self.kind}[{args}]"
        return self.kind


INT = Type("int")
FLOAT = Type("float")
BOOL = Type("bool")
STRING = Type("string")
CHAR = Type("char")
UNIT = Type("Unit")
THREAD_ID = Type("ThreadId")


BUILTINS: Dict[str, Type] = {
    "int": INT,
    "float": FLOAT,
    "bool": BOOL,
    "string": STRING,
    "char": CHAR,
    "Unit": UNIT,
    "void": UNIT,
    "ThreadId": THREAD_ID,
}


def is_numeric(typ: Type) -> bool:
    return typ in (INT, FLOAT, CHAR)
