from typing import Dict, List, Optional, Tuple

from llvmlite import binding, ir

from . import ast
from .errors import Diagnostic, YadroError
from .mir import MirModule
from .sema import FunctionSig, SemanticResult
from .typesys import BOOL, CHAR, FLOAT, INT, STRING, Type, UNIT


class Codegen:
    def __init__(self, module_name: str) -> None:
        self.module = ir.Module(name=module_name)
        self.builder: Optional[ir.IRBuilder] = None
        self.function: Optional[ir.Function] = None
        self.locals: Dict[str, ir.AllocaInstr] = {}
        self.locals_types: Dict[str, Type] = {}
        self.scope_stack: List[List[str]] = []
        self.semantic: Optional[SemanticResult] = None
        self.string_constants: Dict[str, ir.GlobalVariable] = {}
        self.loop_stack: List[tuple[ir.Block, ir.Block, int]] = []
        self.class_types: Dict[str, ir.IdentifiedStructType] = {}
        self.class_vtable_types: Dict[str, ir.IdentifiedStructType] = {}
        self.class_vtables: Dict[str, ir.GlobalVariable] = {}
        self.trait_vtable_types: Dict[str, ir.IdentifiedStructType] = {}
        self.trait_object_types: Dict[str, ir.IdentifiedStructType] = {}
        self.trait_vtables: Dict[str, Dict[str, ir.GlobalVariable]] = {}
        self.trait_shims: List[ir.Function] = []
        self.option_types: Dict[str, ir.Type] = {}
        self.result_types: Dict[str, ir.Type] = {}
        self.task_types: Dict[str, ir.Type] = {}
        self.gc_inc_fn: Optional[ir.Function] = None
        self.gc_dec_fn: Optional[ir.Function] = None
        self.gc_alloc_fn: Optional[ir.Function] = None
        self.arena_stack: List[int] = []
        self.function_modifiers: Dict[str, List[str]] = {}
        self.current_function_modifiers: List[str] = []
        self.current_async_payload: Optional[Type] = None
        self.current_function_return: Optional[Type] = None

    def emit(self, mir: MirModule) -> ir.Module:
        self.semantic = mir.semantic
        self._emit_directive_metadata(mir.semantic)
        self._emit_arena_runtime()
        self._emit_thread_runtime()
        self.function_modifiers = {}
        for func in mir.program.functions:
            self.function_modifiers[func.name] = func.modifiers
        for func in mir.semantic.specialized_functions:
            self.function_modifiers[func.name] = func.modifiers
        for func in mir.semantic.impl_functions:
            self.function_modifiers[func.name] = func.modifiers
        for cls in mir.program.classes:
            for method in cls.methods:
                mangled = self._mangle_method_name(cls.name, method.name)
                self.function_modifiers[mangled] = method.modifiers
        self._declare_classes(mir.semantic)
        self._declare_traits(mir.semantic)
        for func in mir.program.functions:
            if func.type_params:
                continue
            if "thread" in func.modifiers:
                self._declare_thread_function(func)
            else:
                self._declare_function(func)
        for func in mir.semantic.specialized_functions:
            if "thread" in func.modifiers:
                self._declare_thread_function(func)
            else:
                self._declare_function(func)
        for func in mir.semantic.impl_functions:
            if func.type_params:
                continue
            if "thread" in func.modifiers:
                self._declare_thread_function(func)
            else:
                self._declare_function(func)
        for cls in mir.program.classes:
            for method in cls.methods:
                self._declare_method(cls, method)
        self._declare_class_vtables(mir.semantic)
        self._declare_trait_vtables(mir.semantic)
        self._emit_trait_shims(mir.semantic)
        for func in mir.program.functions:
            if func.type_params:
                continue
            if "ffi" in func.modifiers:
                continue
            if "thread" in func.modifiers:
                self._emit_thread_function(func)
            else:
                self._emit_function(func)
        for func in mir.semantic.specialized_functions:
            if "ffi" in func.modifiers:
                continue
            if "thread" in func.modifiers:
                self._emit_thread_function(func)
            else:
                self._emit_function(func)
        for func in mir.semantic.impl_functions:
            if func.type_params:
                continue
            if "ffi" in func.modifiers:
                continue
            if "thread" in func.modifiers:
                self._emit_thread_function(func)
            else:
                self._emit_function(func)
        for cls in mir.program.classes:
            for method in cls.methods:
                if "ffi" in method.modifiers:
                    continue
                if "thread" in method.modifiers:
                    self._emit_thread_method(cls, method)
                else:
                    self._emit_method(cls, method)
        if mir.program.main_block:
            self._emit_main(mir.program.main_block)
        return self.module

    def _declare_classes(self, semantic: SemanticResult) -> None:
        for name in semantic.classes:
            if name not in self.class_types:
                self.class_types[name] = self.module.context.get_identified_type(name)
        for name, info in semantic.classes.items():
            fields = [info.fields[field_name] for field_name in info.field_order]
            field_types = [self._llvm_type(field) for field in fields]
            vtable_ptr = ir.IntType(8).as_pointer()
            self.class_types[name].set_body(vtable_ptr, *field_types)

    def _declare_traits(self, semantic: SemanticResult) -> None:
        for name in semantic.traits:
            if name not in self.trait_vtable_types:
                self.trait_vtable_types[name] = self.module.context.get_identified_type(f"{name}.trait_vtable")
            if name not in self.trait_object_types:
                self.trait_object_types[name] = self.module.context.get_identified_type(f"{name}.trait_obj")
        for name, trait in semantic.traits.items():
            method_types = [ir.IntType(8).as_pointer() for _ in trait.method_order]
            self.trait_vtable_types[name].set_body(*method_types)
            obj_type = self.trait_object_types[name]
            obj_type.set_body(ir.IntType(8).as_pointer(), self.trait_vtable_types[name].as_pointer())

    def _emit_directive_metadata(self, semantic: SemanticResult) -> None:
        self._emit_string_array("__yadro_requires", sorted(semantic.required_libs))
        self._emit_string_array("__yadro_plugins", sorted(semantic.plugins))
        self._emit_named_metadata("yadro.requires", sorted(semantic.required_libs))
        self._emit_named_metadata("yadro.plugins", sorted(semantic.plugins))

    def _emit_arena_runtime(self) -> None:
        if "__yadro_arena_enter" in self.module.globals:
            return
        i8_ptr = ir.IntType(8).as_pointer()
        i64 = ir.IntType(64)
        i32 = ir.IntType(32)
        frame_type = self.module.context.get_identified_type("__yadro_arena_frame")
        frame_ptr = frame_type.as_pointer()
        frame_type.set_body(i8_ptr, i64, i64, frame_ptr)
        current = ir.GlobalVariable(self.module, frame_ptr, name="__yadro_arena_current")
        current.linkage = "internal"
        current.initializer = ir.Constant(frame_ptr, None)
        depth = ir.GlobalVariable(self.module, i64, name="__yadro_arena_depth")
        depth.linkage = "internal"
        depth.initializer = ir.Constant(i64, 0)
        marks_type = ir.ArrayType(i8_ptr, 1024)
        marks = ir.GlobalVariable(self.module, marks_type, name="__yadro_arena_marks")
        marks.linkage = "internal"
        marks.initializer = ir.Constant(marks_type, [ir.Constant(i8_ptr, None) for _ in range(1024)])
        malloc = self._get_runtime_fn("malloc", i8_ptr, [i64])
        free = self._get_runtime_fn("free", ir.VoidType(), [i8_ptr])
        default_capacity = ir.Constant(i64, 1048576)
        frame_size = ir.Constant(i64, 32)

        enter_fn = ir.Function(self.module, ir.FunctionType(ir.VoidType(), []), name="__yadro_arena_enter")
        builder = ir.IRBuilder(enter_fn.append_basic_block("entry"))
        depth_val = builder.load(depth)
        mark_ptr = builder.gep(marks, [ir.Constant(i32, 0), depth_val], inbounds=True)
        curr = builder.load(current)
        builder.store(builder.bitcast(curr, i8_ptr), mark_ptr)
        builder.store(builder.add(depth_val, ir.Constant(i64, 1)), depth)
        raw_frame = builder.call(malloc, [frame_size])
        frame = builder.bitcast(raw_frame, frame_ptr)
        raw_buf = builder.call(malloc, [default_capacity])
        builder.store(raw_buf, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 0)], inbounds=True))
        builder.store(default_capacity, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 1)], inbounds=True))
        builder.store(ir.Constant(i64, 0), builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 2)], inbounds=True))
        builder.store(curr, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 3)], inbounds=True))
        builder.store(frame, current)
        builder.ret_void()

        exit_fn = ir.Function(self.module, ir.FunctionType(ir.VoidType(), []), name="__yadro_arena_exit")
        builder = ir.IRBuilder(exit_fn.append_basic_block("entry"))
        depth_val = builder.load(depth)
        has_depth = builder.icmp_unsigned("!=", depth_val, ir.Constant(i64, 0))
        with_depth = exit_fn.append_basic_block("with_depth")
        done = exit_fn.append_basic_block("done")
        builder.cbranch(has_depth, with_depth, done)
        builder.position_at_end(with_depth)
        depth_next = builder.sub(depth_val, ir.Constant(i64, 1))
        builder.store(depth_next, depth)
        mark_ptr = builder.gep(marks, [ir.Constant(i32, 0), depth_next], inbounds=True)
        mark_raw = builder.load(mark_ptr)
        mark = builder.bitcast(mark_raw, frame_ptr)
        loop = exit_fn.append_basic_block("loop")
        free_block = exit_fn.append_basic_block("free")
        builder.branch(loop)
        builder.position_at_end(loop)
        curr = builder.load(current)
        at_mark = builder.icmp_unsigned("==", curr, mark)
        builder.cbranch(at_mark, done, free_block)
        builder.position_at_end(free_block)
        buf = builder.load(builder.gep(curr, [ir.Constant(i32, 0), ir.Constant(i32, 0)], inbounds=True))
        prev = builder.load(builder.gep(curr, [ir.Constant(i32, 0), ir.Constant(i32, 3)], inbounds=True))
        builder.call(free, [buf])
        builder.call(free, [builder.bitcast(curr, i8_ptr)])
        builder.store(prev, current)
        builder.branch(loop)
        builder.position_at_end(done)
        builder.ret_void()

        alloc_fn = ir.Function(self.module, ir.FunctionType(i8_ptr, [i64]), name="__yadro_arena_alloc")
        builder = ir.IRBuilder(alloc_fn.append_basic_block("entry"))
        size = alloc_fn.args[0]
        curr = builder.load(current)
        has_curr = builder.icmp_unsigned("!=", curr, ir.Constant(frame_ptr, None))
        with_curr = alloc_fn.append_basic_block("with_curr")
        no_curr = alloc_fn.append_basic_block("no_curr")
        builder.cbranch(has_curr, with_curr, no_curr)
        builder.position_at_end(no_curr)
        builder.ret(builder.call(malloc, [size]))
        builder.position_at_end(with_curr)
        offset_ptr = builder.gep(curr, [ir.Constant(i32, 0), ir.Constant(i32, 2)], inbounds=True)
        capacity_ptr = builder.gep(curr, [ir.Constant(i32, 0), ir.Constant(i32, 1)], inbounds=True)
        buf_ptr = builder.gep(curr, [ir.Constant(i32, 0), ir.Constant(i32, 0)], inbounds=True)
        offset = builder.load(offset_ptr)
        capacity = builder.load(capacity_ptr)
        new_offset = builder.add(offset, size)
        fits = builder.icmp_unsigned("<=", new_offset, capacity)
        fits_block = alloc_fn.append_basic_block("fits")
        grow_block = alloc_fn.append_basic_block("grow")
        builder.cbranch(fits, fits_block, grow_block)
        builder.position_at_end(fits_block)
        buffer = builder.load(buf_ptr)
        ptr = builder.gep(buffer, [offset], inbounds=True)
        builder.store(new_offset, offset_ptr)
        builder.ret(ptr)
        builder.position_at_end(grow_block)
        bigger = builder.icmp_unsigned(">", size, default_capacity)
        cap = builder.select(bigger, size, default_capacity)
        raw_frame = builder.call(malloc, [frame_size])
        frame = builder.bitcast(raw_frame, frame_ptr)
        raw_buf = builder.call(malloc, [cap])
        builder.store(raw_buf, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 0)], inbounds=True))
        builder.store(cap, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 1)], inbounds=True))
        builder.store(size, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 2)], inbounds=True))
        builder.store(curr, builder.gep(frame, [ir.Constant(i32, 0), ir.Constant(i32, 3)], inbounds=True))
        builder.store(frame, current)
        builder.ret(raw_buf)

    def _emit_thread_runtime(self) -> None:
        if "__yadro_thread_register" in self.module.globals:
            return
        i64 = ir.IntType(64)
        counter = ir.GlobalVariable(self.module, i64, name="__yadro_thread_next")
        counter.linkage = "internal"
        counter.initializer = ir.Constant(i64, 1)
        fn = ir.Function(self.module, ir.FunctionType(i64, []), name="__yadro_thread_register")
        builder = ir.IRBuilder(fn.append_basic_block("entry"))
        current = builder.load(counter)
        next_value = builder.add(current, ir.Constant(i64, 1))
        builder.store(next_value, counter)
        builder.ret(current)

    def _emit_string_array(self, name: str, values: List[str]) -> None:
        if not values:
            return
        array_type = ir.ArrayType(ir.IntType(8).as_pointer(), len(values))
        entries = [self._string_constant(value) for value in values]
        global_var = ir.GlobalVariable(self.module, array_type, name=name)
        global_var.linkage = "internal"
        global_var.global_constant = True
        global_var.initializer = ir.Constant(array_type, entries)

    def _emit_named_metadata(self, name: str, values: List[str]) -> None:
        if not values:
            return
        named = self.module.add_named_metadata(name)
        for value in values:
            named.add(ir.MetaDataString(self.module, value))

    def _declare_class_vtables(self, semantic: SemanticResult) -> None:
        for name in semantic.classes:
            if name not in self.class_vtable_types:
                self.class_vtable_types[name] = self.module.context.get_identified_type(f"{name}.vtable")
        for name, info in semantic.classes.items():
            method_types = [ir.IntType(8).as_pointer() for _ in info.vtable_order]
            self.class_vtable_types[name].set_body(*method_types)
            entries: List[ir.Constant] = []
            for idx, method_name in enumerate(info.vtable_order):
                method_info = info.methods[method_name]
                fn = self.module.get_global(method_info.sig.name)
                entries.append(fn.bitcast(ir.IntType(8).as_pointer()))
            vtable = ir.GlobalVariable(self.module, self.class_vtable_types[name], name=f"{name}.vtable")
            vtable.linkage = "internal"
            vtable.global_constant = True
            vtable.initializer = ir.Constant(self.class_vtable_types[name], entries)
            self.class_vtables[name] = vtable

    def _declare_trait_vtables(self, semantic: SemanticResult) -> None:
        for trait_name, classes in semantic.impls.items():
            trait = semantic.traits[trait_name]
            if any(method.type_params for method in trait.methods.values()):
                continue
            vtable_type = self.trait_vtable_types[trait_name]
            for impl_type in classes:
                class_name = impl_type.kind
                entries: List[ir.Constant] = []
                for idx, method_name in enumerate(trait.method_order):
                    shim = self._declare_trait_shim(trait_name, class_name, method_name, trait.methods[method_name], trait.method_self.get(method_name, False))
                    entries.append(shim.bitcast(ir.IntType(8).as_pointer()))
                vtable = ir.GlobalVariable(self.module, vtable_type, name=f"{trait_name}.{class_name}.vtable")
                vtable.linkage = "internal"
                vtable.global_constant = True
                vtable.initializer = ir.Constant(vtable_type, entries)
                self.trait_vtables.setdefault(trait_name, {})[class_name] = vtable

    def _declare_trait_shim(self, trait_name: str, class_name: str, method_name: str, sig: FunctionSig, has_self: bool) -> ir.Function:
        shim_name = f"__trait_shim.{trait_name}.{class_name}.{method_name}"
        if shim_name in self.module.globals:
            return self.module.get_global(shim_name)
        arg_types: List[ir.Type] = []
        if has_self:
            arg_types.append(ir.IntType(8).as_pointer())
            arg_types.extend(self._llvm_type(t) for t in sig.param_types[1:])
        else:
            arg_types.extend(self._llvm_type(t) for t in sig.param_types)
        ret_type = self._llvm_type(sig.return_type)
        fn_type = ir.FunctionType(ret_type, arg_types)
        shim = ir.Function(self.module, fn_type, name=shim_name)
        self.trait_shims.append(shim)
        return shim

    def _emit_trait_shims(self, semantic: SemanticResult) -> None:
        for shim in self.trait_shims:
            parts = shim.name.split(".")
            trait_name = parts[1]
            class_name = parts[2]
            method_name = parts[3]
            trait = semantic.traits[trait_name]
            has_self = trait.method_self.get(method_name, False)
            impl_name = self._mangle_trait_impl_name(trait_name, class_name, method_name)
            impl_fn = self.module.get_global(impl_name)
            entry = shim.append_basic_block("entry")
            builder = ir.IRBuilder(entry)
            args: List[ir.Value] = []
            if has_self:
                raw_self = shim.args[0]
                self_ptr_type = self._llvm_type(Type(class_name))
                self_ptr = builder.bitcast(raw_self, self_ptr_type)
                args.append(self_ptr)
                for arg in shim.args[1:]:
                    args.append(arg)
            else:
                args.extend(shim.args)
            result = builder.call(impl_fn, args)
            ret_type = shim.function_type.return_type
            if isinstance(ret_type, ir.VoidType):
                builder.ret_void()
            else:
                builder.ret(result)

    def _mangle_trait_impl_name(self, trait_name: str, class_name: str, method_name: str) -> str:
        return f"{trait_name}.{class_name}.{method_name}"

    def _ffi_calling_convention(self, func: ast.FunctionDef) -> Optional[int]:
        if "ffi" not in func.modifiers:
            return None
        args = func.modifier_args.get("ffi", {})
        abi = args.get("abi")
        positional = args.get("$", [])
        if abi is None and len(positional) > 1 and isinstance(positional[1], str):
            abi = positional[1]
        if not isinstance(abi, str):
            return None
        mapping = {
            "cdecl": 0,
            "c": 0,
            "stdcall": 64,
            "fastcall": 65,
            "thiscall": 70,
            "sysv": 78,
            "win64": 79,
        }
        return mapping.get(abi)

    def _declare_function(self, func: ast.FunctionDef) -> None:
        arg_types = [self._llvm_type(self._type_of_param(func, p)) for p in func.params]
        ret_type = self._llvm_type(self._type_of_return(func))
        fn_type = ir.FunctionType(ret_type, arg_types)
        fn = ir.Function(self.module, fn_type, name=func.name)
        calling_convention = self._ffi_calling_convention(func)
        if calling_convention is not None:
            if hasattr(fn, "calling_convention"):
                fn.calling_convention = calling_convention
            elif hasattr(fn, "call_conv"):
                fn.call_conv = calling_convention

    def _declare_thread_function(self, func: ast.FunctionDef) -> None:
        arg_types = [self._llvm_type(self._type_of_param(func, p)) for p in func.params]
        ret_type = self._llvm_type(self._type_of_return(func))
        public_type = ir.FunctionType(ret_type, arg_types)
        body_type = ir.FunctionType(ir.VoidType(), arg_types)
        if func.name not in self.module.globals:
            ir.Function(self.module, public_type, name=func.name)
        body_name = f"{func.name}.__thread_body"
        if body_name not in self.module.globals:
            ir.Function(self.module, body_type, name=body_name)

    def _declare_method(self, cls: ast.ClassDef, method: ast.FunctionDef) -> None:
        mangled = self._mangle_method_name(cls.name, method.name)
        method_def = self._method_def(method, mangled)
        if "thread" in method.modifiers:
            self._declare_thread_function(method_def)
        else:
            self._declare_function(method_def)

    def _emit_function(self, func: ast.FunctionDef) -> None:
        fn = self.module.get_global(func.name)
        return_type = self._type_of_return(func)
        expected_return = return_type
        if "async" in func.modifiers and return_type.kind == "Task" and return_type.type_args:
            expected_return = return_type.type_args[0]
        self._emit_function_body(func, fn, expected_return)

    def _emit_method(self, cls: ast.ClassDef, method: ast.FunctionDef) -> None:
        mangled = self._mangle_method_name(cls.name, method.name)
        method_def = self._method_def(method, mangled)
        self._emit_function(method_def)

    def _emit_thread_method(self, cls: ast.ClassDef, method: ast.FunctionDef) -> None:
        mangled = self._mangle_method_name(cls.name, method.name)
        method_def = self._method_def(method, mangled)
        self._emit_thread_function(method_def)

    def _emit_thread_function(self, func: ast.FunctionDef) -> None:
        public_fn = self.module.get_global(func.name)
        body_name = f"{func.name}.__thread_body"
        body_fn = self.module.get_global(body_name)
        self._emit_function_body(func, body_fn, expected_return=UNIT)
        entry = public_fn.append_basic_block("entry")
        self.function = public_fn
        self.builder = ir.IRBuilder(entry)
        self.locals = {}
        self.locals_types = {}
        self.scope_stack = []
        self.loop_stack = []
        thread_fn = self._get_runtime_fn("__yadro_thread_register", ir.IntType(64), [])
        thread_id = self.builder.call(thread_fn, [])
        args = list(public_fn.args)
        for idx, param in enumerate(func.params):
            args[idx].name = param.name
        self.builder.call(body_fn, args)
        self.builder.ret(thread_id)

    def _emit_function_body(self, func: ast.FunctionDef, fn: ir.Function, expected_return: Type) -> None:
        self.function = fn
        entry = fn.append_basic_block("entry")
        self.builder = ir.IRBuilder(entry)
        self.locals = {}
        self.locals_types = {}
        self.scope_stack = []
        self.loop_stack = []
        self._enter_scope()
        self.current_function_modifiers = func.modifiers
        self.current_function_return = self._type_of_return(func)
        if "async" in func.modifiers and self.current_function_return.kind == "Task":
            self.current_async_payload = self.current_function_return.type_args[0] if self.current_function_return.type_args else None
        else:
            self.current_async_payload = None
        for idx, param in enumerate(func.params):
            param_val = fn.args[idx]
            param_val.name = param.name
            alloca = self._alloca(param.name, param_val.type)
            self.builder.store(param_val, alloca)
            self.locals[param.name] = alloca
            self.locals_types[param.name] = self._type_of_param(func, param)
            self.scope_stack[-1].append(param.name)
        self._emit_block(func.body, expected_return=expected_return)
        self._exit_scope()
        if not self.builder.block.is_terminated:
            if fn.function_type.return_type == ir.VoidType():
                self.builder.ret_void()
            else:
                raise YadroError(Diagnostic(f"Missing return in function '{func.name}'", func.line, func.column))

    def _emit_main(self, body: List[ast.Stmt]) -> None:
        fn_type = ir.FunctionType(ir.IntType(32), [])
        fn = ir.Function(self.module, fn_type, name="main")
        self.function = fn
        entry = fn.append_basic_block("entry")
        self.builder = ir.IRBuilder(entry)
        self.locals = {}
        self.locals_types = {}
        self.scope_stack = []
        self.loop_stack = []
        self._enter_scope()
        self._emit_block(body, expected_return=INT)
        self._exit_scope()
        if not self.builder.block.is_terminated:
            self.builder.ret(ir.Constant(ir.IntType(32), 0))

    def _emit_block(self, body: List[ast.Stmt], expected_return: Type) -> None:
        self._enter_scope()
        for stmt in body:
            self._emit_stmt(stmt, expected_return)
            if self.builder and self.builder.block.is_terminated:
                break
        self._exit_scope()

    def _emit_stmt(self, stmt: ast.Stmt, expected_return: Type) -> None:
        if isinstance(stmt, ast.VarDecl):
            decl_type = self.semantic.decl_types.get(id(stmt))
            value = self._emit_expr(stmt.value)
            value_type = self.semantic.expr_types[id(stmt.value)]
            if decl_type is None:
                decl_type = value_type
            value = self._coerce_value(value, value_type, decl_type)
            alloca = self._alloca(stmt.name, self._llvm_type(decl_type))
            self.builder.store(value, alloca)
            self.locals[stmt.name] = alloca
            self.locals_types[stmt.name] = decl_type
            self.scope_stack[-1].append(stmt.name)
            if decl_type.kind == "gc":
                self._emit_gc_inc(value, decl_type)
            if decl_type.kind == "gc_weak":
                self._emit_gc_weak_inc(value, decl_type)
            return
        if isinstance(stmt, ast.ConstDecl):
            decl_type = self.semantic.decl_types.get(id(stmt))
            value = self._emit_expr(stmt.value)
            value_type = self.semantic.expr_types[id(stmt.value)]
            if decl_type is None:
                decl_type = value_type
            value = self._coerce_value(value, value_type, decl_type)
            alloca = self._alloca(stmt.name, self._llvm_type(decl_type))
            self.builder.store(value, alloca)
            self.locals[stmt.name] = alloca
            self.locals_types[stmt.name] = decl_type
            self.scope_stack[-1].append(stmt.name)
            if decl_type.kind == "gc":
                self._emit_gc_inc(value, decl_type)
            if decl_type.kind == "gc_weak":
                self._emit_gc_weak_inc(value, decl_type)
            return
        if isinstance(stmt, ast.DestructureDecl):
            decl_type = self.semantic.decl_types.get(id(stmt))
            value_expr = stmt.value
            if isinstance(value_expr, ast.UnpackExpr):
                value_expr = value_expr.expr
            value_ptr = self._emit_expr(value_expr)
            value_type = self.semantic.expr_types[id(value_expr)]
            element_type = value_type.element if value_type.kind in {"array", "darray"} else value_type
            for idx, name in enumerate(stmt.names):
                alloca = self._alloca(name, self._llvm_type(decl_type or element_type))
                elem_ptr = self.builder.gep(value_ptr, [ir.Constant(ir.IntType(64), idx)], inbounds=True)
                elem_value = self.builder.load(elem_ptr)
                elem_value = self._coerce_value(elem_value, element_type, decl_type or element_type)
                self.builder.store(elem_value, alloca)
                self.locals[name] = alloca
                self.locals_types[name] = decl_type or element_type
                self.scope_stack[-1].append(name)
                if (decl_type or element_type).kind == "gc":
                    self._emit_gc_inc(elem_value, decl_type or element_type)
                if (decl_type or element_type).kind == "gc_weak":
                    self._emit_gc_weak_inc(elem_value, decl_type or element_type)
            return
        if isinstance(stmt, ast.DictDestructureDecl):
            key_type, value_type = self.semantic.dict_destructure_types[id(stmt)]
            value_expr = stmt.value
            if isinstance(value_expr, ast.UnpackExpr):
                value_expr = value_expr.expr
            dict_ptr = self._emit_expr(value_expr)
            dict_type = self.semantic.expr_types[id(value_expr)]
            key_elem_type = dict_type.type_args[0]
            value_elem_type = dict_type.type_args[1]
            suffix = f"{self._type_tag(key_elem_type)}_{self._type_tag(value_elem_type)}"
            keys_fn = self._get_runtime_fn(
                f"__yadro_dict_keys${suffix}",
                self._llvm_type(key_type),
                [ir.IntType(8).as_pointer()],
            )
            values_fn = self._get_runtime_fn(
                f"__yadro_dict_values${suffix}",
                self._llvm_type(value_type),
                [ir.IntType(8).as_pointer()],
            )
            keys_value = self.builder.call(keys_fn, [dict_ptr])
            values_value = self.builder.call(values_fn, [dict_ptr])
            keys_alloca = self._alloca(stmt.key_name, self._llvm_type(key_type))
            values_alloca = self._alloca(stmt.value_name, self._llvm_type(value_type))
            self.builder.store(keys_value, keys_alloca)
            self.builder.store(values_value, values_alloca)
            self.locals[stmt.key_name] = keys_alloca
            self.locals[stmt.value_name] = values_alloca
            self.locals_types[stmt.key_name] = key_type
            self.locals_types[stmt.value_name] = value_type
            self.scope_stack[-1].append(stmt.key_name)
            self.scope_stack[-1].append(stmt.value_name)
            return
        if isinstance(stmt, ast.Assign):
            if stmt.name not in self.locals:
                raise YadroError(Diagnostic(f"Undefined variable '{stmt.name}'", stmt.line, stmt.column))
            target_type = self.locals_types[stmt.name]
            value = self._emit_expr(stmt.value)
            value_type = self.semantic.expr_types[id(stmt.value)]
            value = self._coerce_value(value, value_type, target_type)
            if target_type.kind == "gc":
                current = self.builder.load(self.locals[stmt.name])
                self._emit_gc_dec(current, target_type)
            if target_type.kind == "gc_weak":
                current = self.builder.load(self.locals[stmt.name])
                self._emit_gc_weak_dec(current, target_type)
            self.builder.store(value, self.locals[stmt.name])
            if target_type.kind == "gc":
                self._emit_gc_inc(value, target_type)
            if target_type.kind == "gc_weak":
                self._emit_gc_weak_inc(value, target_type)
            return
        if isinstance(stmt, ast.AssignMember):
            ptr = self._emit_member_ptr(stmt.target, stmt.name, stmt.line, stmt.column)
            target_type = self.semantic.expr_types[id(stmt.target)]
            if target_type.kind == "ref":
                target_type = target_type.element
            field_type = self.semantic.classes[target_type.kind].fields[stmt.name]
            value = self._emit_expr(stmt.value)
            value_type = self.semantic.expr_types[id(stmt.value)]
            value = self._coerce_value(value, value_type, field_type)
            self.builder.store(value, ptr)
            return
        if isinstance(stmt, ast.AssignIndex):
            target_type = self.semantic.expr_types[id(stmt.target)]
            if target_type.kind == "ref":
                target_type = target_type.element
            if target_type.kind == "vector":
                if isinstance(stmt.target, ast.VarRef):
                    if stmt.target.name not in self.locals:
                        raise YadroError(Diagnostic(f"Undefined variable '{stmt.target.name}'", stmt.line, stmt.column))
                    ptr = self.locals[stmt.target.name]
                elif isinstance(stmt.target, ast.MemberAccess):
                    ptr = self._emit_member_ptr(stmt.target.target, stmt.target.name, stmt.line, stmt.column)
                else:
                    raise YadroError(Diagnostic("Vector assignment requires direct target", stmt.line, stmt.column))
                vector_value = self.builder.load(ptr)
                value = self._emit_expr(stmt.value)
                element_type = target_type.element
                value_type = self.semantic.expr_types[id(stmt.value)]
                value = self._coerce_value(value, value_type, element_type)
                index_value = self._emit_expr(stmt.index)
                if isinstance(index_value.type, ir.IntType) and index_value.type.width != 32:
                    index_value = self.builder.trunc(index_value, ir.IntType(32))
                updated = self.builder.insert_element(vector_value, value, index_value)
                self.builder.store(updated, ptr)
                return
            ptr = self._emit_index_ptr(stmt.target, stmt.index)
            value = self._emit_expr(stmt.value)
            element_type = target_type.element if target_type.kind in {"array", "darray"} else target_type
            value_type = self.semantic.expr_types[id(stmt.value)]
            value = self._coerce_value(value, value_type, element_type)
            self.builder.store(value, ptr)
            return
        if isinstance(stmt, ast.CompoundAssign):
            ptr, target_type = self._lvalue_ptr_and_type(stmt.target, stmt.line, stmt.column)
            current = self.builder.load(ptr)
            rhs = self._emit_expr(stmt.value)
            op = stmt.op
            if op in {"+", "-", "*", "/", "%"}:
                result = self._emit_arith(op, current, rhs)
            elif op in {"|", "&", "^"}:
                result = self._emit_bitwise(op, current, rhs)
            elif op in {"<<", ">>"}:
                result = self._emit_shift(op, current, rhs)
            else:
                raise YadroError(Diagnostic("Unsupported compound operator", stmt.line, stmt.column))
            result = self._coerce_value(result, self.semantic.expr_types.get(id(stmt.value), self.locals_types.get(getattr(stmt.target, "name", ""), None)) or self.semantic.expr_types.get(id(stmt.target), target_type), target_type)
            if target_type.kind == "gc":
                prev = self.builder.load(ptr)
                self._emit_gc_dec(prev, target_type)
            if target_type.kind == "gc_weak":
                prev = self.builder.load(ptr)
                self._emit_gc_weak_dec(prev, target_type)
            self.builder.store(result, ptr)
            if target_type.kind == "gc":
                self._emit_gc_inc(result, target_type)
            if target_type.kind == "gc_weak":
                self._emit_gc_weak_inc(result, target_type)
            return
        if isinstance(stmt, ast.SwapStmt):
            ptr_a, type_a = self._lvalue_ptr_and_type(stmt.left, stmt.line, stmt.column)
            ptr_b, type_b = self._lvalue_ptr_and_type(stmt.right, stmt.line, stmt.column)
            val_a = self.builder.load(ptr_a)
            val_b = self.builder.load(ptr_b)
            if type_a.kind == "gc":
                self._emit_gc_dec(val_a, type_a)
            if type_b.kind == "gc":
                self._emit_gc_dec(val_b, type_b)
            self.builder.store(self._coerce_value(val_b, type_b, type_a), ptr_a)
            self.builder.store(self._coerce_value(val_a, type_a, type_b), ptr_b)
            if type_a.kind == "gc":
                self._emit_gc_inc(self.builder.load(ptr_a), type_a)
            if type_b.kind == "gc":
                self._emit_gc_inc(self.builder.load(ptr_b), type_b)
            return
        if isinstance(stmt, ast.DelStmt):
            value = self._emit_expr(stmt.target)
            target_type = self.semantic.expr_types[id(stmt.target)]
            if target_type.kind == "gc":
                self._emit_gc_dec(value, target_type)
            if target_type.kind == "ref":
                target_type = target_type.element
            if target_type.kind in self.semantic.classes:
                info = self.semantic.classes[target_type.kind]
                method = info.methods.get("drop")
                if method is not None and not method.is_class:
                    obj_ptr = value
                    vtable_ptr_ptr = self.builder.gep(obj_ptr, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), 0)], inbounds=True)
                    vtable_ptr = self.builder.load(vtable_ptr_ptr)
                    vtable_type = self.class_vtable_types[target_type.kind]
                    vtable_ptr = self.builder.bitcast(vtable_ptr, vtable_type.as_pointer())
                    method_index = info.vtable_order.index("drop")
                    fn_ptr_ptr = self.builder.gep(vtable_ptr, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), method_index)], inbounds=True)
                    fn_ptr = self.builder.load(fn_ptr_ptr)
                    fn_type = ir.FunctionType(self._llvm_type(method.sig.return_type), [self._llvm_type(method.sig.param_types[0])])
                    fn = self.builder.bitcast(fn_ptr, fn_type.as_pointer())
                    self_arg = self.builder.bitcast(obj_ptr, self._llvm_type(method.sig.param_types[0]))
                    self.builder.call(fn, [self_arg])
            return
        if isinstance(stmt, ast.ExprStmt):
            self._emit_expr(stmt.expr)
            return
        if isinstance(stmt, ast.ArenaStmt):
            self._emit_arena_enter()
            self._emit_block(stmt.body, expected_return)
            if self.builder and not self.builder.block.is_terminated:
                self._emit_arena_exit()
            return
        if isinstance(stmt, ast.UnsafeBlock):
            self._emit_block(stmt.body, expected_return)
            return
        if isinstance(stmt, ast.InlineAsm):
            input_values: List[ir.Value] = []
            input_types: List[ir.Type] = []
            for _, expr in stmt.inputs:
                value = self._emit_expr(expr)
                expr_type = self.semantic.expr_types[id(expr)]
                input_values.append(value)
                input_types.append(self._llvm_type(expr_type))
            output_ptr = None
            output_type = None
            if stmt.outputs:
                _, name = stmt.outputs[0]
                if name not in self.locals:
                    raise YadroError(Diagnostic(f"Undefined variable '{name}'", stmt.line, stmt.column))
                output_ptr = self.locals[name]
                output_type = self.locals_types[name]
                output_llvm = self._llvm_type(output_type)
            else:
                output_llvm = ir.VoidType()
            constraints = ",".join([c for c, _ in stmt.outputs] + [c for c, _ in stmt.inputs])
            asm_type = ir.FunctionType(output_llvm, input_types)
            asm = ir.InlineAsm(asm_type, stmt.template, constraints, side_effect=True)
            result = self.builder.call(asm, input_values)
            if output_ptr is not None and output_type is not None:
                result = self._coerce_value(result, output_type, output_type)
                self.builder.store(result, output_ptr)
            return
        if isinstance(stmt, ast.ReturnStmt):
            self._cleanup_all_scopes()
            self._cleanup_all_arenas()
            if (
                "async" in self.current_function_modifiers
                and self.current_function_return
                and self.current_function_return.kind == "Task"
            ):
                if stmt.value is None:
                    if expected_return == UNIT:
                        task_value = self._build_task_value(self.current_function_return, None)
                        self.builder.ret(task_value)
                    else:
                        raise YadroError(Diagnostic("Return value required", stmt.line, stmt.column))
                else:
                    value = self._emit_expr(stmt.value)
                    value_type = self.semantic.expr_types[id(stmt.value)]
                    value = self._coerce_value(value, value_type, expected_return)
                    task_value = self._build_task_value(self.current_function_return, value)
                    self.builder.ret(task_value)
                return
            if stmt.value is None:
                if self._llvm_type(expected_return) == ir.VoidType():
                    self.builder.ret_void()
                elif expected_return == INT:
                    self.builder.ret(ir.Constant(ir.IntType(32), 0))
                else:
                    raise YadroError(Diagnostic("Return value required", stmt.line, stmt.column))
            else:
                value = self._emit_expr(stmt.value)
                value_type = self.semantic.expr_types[id(stmt.value)]
                value = self._coerce_value(value, value_type, expected_return)
                self.builder.ret(value)
            return
        if isinstance(stmt, ast.IfStmt):
            self._emit_if(stmt, expected_return)
            return
        if isinstance(stmt, ast.WhileStmt):
            self._emit_while(stmt, expected_return)
            return
        if isinstance(stmt, ast.ForStmt):
            self._emit_for(stmt, expected_return)
            return
        if isinstance(stmt, ast.RepeatStmt):
            self._emit_repeat(stmt, expected_return)
            return
        if isinstance(stmt, ast.SwitchStmt):
            self._emit_switch(stmt, expected_return)
            return
        if isinstance(stmt, ast.BreakStmt):
            if not self.loop_stack:
                raise YadroError(Diagnostic("Break used outside of loop", stmt.line, stmt.column))
            break_block, _, loop_scope_depth = self.loop_stack[-1]
            self._cleanup_arenas_to_scope_depth(loop_scope_depth)
            self.builder.branch(break_block)
            return
        if isinstance(stmt, ast.ContinueStmt):
            if not self.loop_stack:
                raise YadroError(Diagnostic("Continue used outside of loop", stmt.line, stmt.column))
            _, continue_block, loop_scope_depth = self.loop_stack[-1]
            self._cleanup_arenas_to_scope_depth(loop_scope_depth)
            self.builder.branch(continue_block)
            return
        raise YadroError(Diagnostic("Unsupported statement", stmt.line, stmt.column))

    def _emit_if(self, stmt: ast.IfStmt, expected_return: Type) -> None:
        merge_block = self.function.append_basic_block("if_end")
        branches = [(stmt.condition, stmt.then_body)] + stmt.elifs
        next_block = None
        for idx, (cond, body) in enumerate(branches):
            cond_val = self._emit_expr(cond)
            then_block = self.function.append_basic_block(f"if_then_{idx}")
            next_block = self.function.append_basic_block(f"if_next_{idx}")
            self.builder.cbranch(self._as_bool(cond_val), then_block, next_block)
            self.builder.position_at_end(then_block)
            self._emit_block(body, expected_return)
            if not self.builder.block.is_terminated:
                self.builder.branch(merge_block)
            self.builder.position_at_end(next_block)
        if stmt.else_body:
            self._emit_block(stmt.else_body, expected_return)
            if not self.builder.block.is_terminated:
                self.builder.branch(merge_block)
        else:
            self.builder.branch(merge_block)
        self.builder.position_at_end(merge_block)

    def _emit_while(self, stmt: ast.WhileStmt, expected_return: Type) -> None:
        loop_cond = self.function.append_basic_block("loop_cond")
        loop_body = self.function.append_basic_block("loop_body")
        loop_end = self.function.append_basic_block("loop_end")
        self.builder.branch(loop_cond)
        self.builder.position_at_end(loop_cond)
        cond_val = self._emit_expr(stmt.condition)
        self.builder.cbranch(self._as_bool(cond_val), loop_body, loop_end)
        self.builder.position_at_end(loop_body)
        loop_scope_depth = len(self.scope_stack) + 1
        self.loop_stack.append((loop_end, loop_cond, loop_scope_depth))
        self._emit_block(stmt.body, expected_return)
        self.loop_stack.pop()
        if not self.builder.block.is_terminated:
            self.builder.branch(loop_cond)
        self.builder.position_at_end(loop_end)

    def _emit_for(self, stmt: ast.ForStmt, expected_return: Type) -> None:
        start_val = self._emit_expr(stmt.start)
        end_val = self._emit_expr(stmt.end)
        step_val = self._emit_expr(stmt.step) if stmt.step is not None else ir.Constant(ir.IntType(64), 1)
        alloca = self._alloca(stmt.name, start_val.type)
        self.builder.store(start_val, alloca)
        self.locals[stmt.name] = alloca
        loop_cond = self.function.append_basic_block("for_cond")
        loop_body = self.function.append_basic_block("for_body")
        loop_incr = self.function.append_basic_block("for_incr")
        loop_end = self.function.append_basic_block("for_end")
        self.builder.branch(loop_cond)
        self.builder.position_at_end(loop_cond)
        current = self.builder.load(alloca)
        zero = ir.Constant(ir.IntType(64), 0)
        step_neg = self.builder.icmp_signed("<", step_val, zero)
        cond_forward = self.builder.icmp_signed("<", current, end_val)
        cond_backward = self.builder.icmp_signed(">", current, end_val)
        cond_val = self.builder.select(step_neg, cond_backward, cond_forward)
        self.builder.cbranch(cond_val, loop_body, loop_end)
        self.builder.position_at_end(loop_body)
        loop_scope_depth = len(self.scope_stack) + 1
        self.loop_stack.append((loop_end, loop_incr, loop_scope_depth))
        self._emit_block(stmt.body, expected_return)
        self.loop_stack.pop()
        if not self.builder.block.is_terminated:
            self.builder.branch(loop_incr)
        self.builder.position_at_end(loop_incr)
        current = self.builder.load(alloca)
        next_val = self.builder.add(current, step_val)
        self.builder.store(next_val, alloca)
        self.builder.branch(loop_cond)
        self.builder.position_at_end(loop_end)

    def _emit_repeat(self, stmt: ast.RepeatStmt, expected_return: Type) -> None:
        loop_body = self.function.append_basic_block("repeat_body")
        loop_cond = self.function.append_basic_block("repeat_cond")
        loop_end = self.function.append_basic_block("repeat_end")
        self.builder.branch(loop_body)
        self.builder.position_at_end(loop_body)
        loop_scope_depth = len(self.scope_stack) + 1
        self.loop_stack.append((loop_end, loop_cond, loop_scope_depth))
        self._emit_block(stmt.body, expected_return)
        self.loop_stack.pop()
        if not self.builder.block.is_terminated:
            self.builder.branch(loop_cond)
        self.builder.position_at_end(loop_cond)
        cond_val = self._emit_expr(stmt.condition)
        self.builder.cbranch(self._as_bool(cond_val), loop_end, loop_body)
        self.builder.position_at_end(loop_end)

    def _emit_arena_enter(self) -> None:
        if not self.builder:
            return
        arena_enter = self._get_runtime_fn("__yadro_arena_enter", ir.VoidType(), [])
        self.builder.call(arena_enter, [])
        self.arena_stack.append(len(self.scope_stack))

    def _emit_arena_exit(self) -> None:
        if not self.builder or not self.arena_stack:
            return
        arena_exit = self._get_runtime_fn("__yadro_arena_exit", ir.VoidType(), [])
        self.builder.call(arena_exit, [])
        self.arena_stack.pop()

    def _cleanup_arenas_to_scope_depth(self, scope_depth: int) -> None:
        if not self.builder or (self.builder and self.builder.block.is_terminated):
            return
        while self.arena_stack and self.arena_stack[-1] >= scope_depth:
            self._emit_arena_exit()

    def _cleanup_all_arenas(self) -> None:
        if not self.builder or (self.builder and self.builder.block.is_terminated):
            return
        while self.arena_stack:
            self._emit_arena_exit()

    def _emit_switch(self, stmt: ast.SwitchStmt, expected_return: Type) -> None:
        value = self._emit_expr(stmt.expr)
        expr_type = self.semantic.expr_types[id(stmt.expr)]
        merge_block = self.function.append_basic_block("switch_end")
        if expr_type.kind in {"Result", "Option"}:
            tag = self.builder.extract_value(value, 0)
            next_block = None
            for idx, case in enumerate(stmt.cases):
                case_block = self.function.append_basic_block(f"switch_case_{idx}")
                next_block = self.function.append_basic_block(f"switch_next_{idx}")
                cond = self._emit_pattern_condition(expr_type, tag, case.value)
                self.builder.cbranch(self._as_bool(cond), case_block, next_block)
                self.builder.position_at_end(case_block)
                self._bind_pattern(expr_type, value, case.value)
                self._emit_block(case.body, expected_return)
                if not self.builder.block.is_terminated:
                    self.builder.branch(merge_block)
                self.builder.position_at_end(next_block)
        else:
            next_block = None
            for idx, case in enumerate(stmt.cases):
                case_block = self.function.append_basic_block(f"switch_case_{idx}")
                next_block = self.function.append_basic_block(f"switch_next_{idx}")
                if isinstance(case.value, ast.PatternLiteral):
                    case_value = self._emit_expr(case.value.value)
                else:
                    case_value = self._emit_expr(case.value)
                cond = self._emit_compare("==", value, case_value)
                self.builder.cbranch(self._as_bool(cond), case_block, next_block)
                self.builder.position_at_end(case_block)
                self._emit_block(case.body, expected_return)
                if not self.builder.block.is_terminated:
                    self.builder.branch(merge_block)
                self.builder.position_at_end(next_block)
        if stmt.default_body:
            self._emit_block(stmt.default_body, expected_return)
            if not self.builder.block.is_terminated:
                self.builder.branch(merge_block)
        else:
            self.builder.branch(merge_block)
        self.builder.position_at_end(merge_block)

    def _enter_scope(self) -> None:
        self.scope_stack.append([])

    def _exit_scope(self) -> None:
        if not self.scope_stack:
            return
        names = self.scope_stack.pop()
        if self.builder and self.builder.block.is_terminated:
            return
        for name in reversed(names):
            typ = self.locals_types.get(name)
            if typ and typ.kind == "gc":
                value = self.builder.load(self.locals[name])
                self._emit_gc_dec(value, typ)
            if typ and typ.kind == "gc_weak":
                value = self.builder.load(self.locals[name])
                self._emit_gc_weak_dec(value, typ)

    def _cleanup_all_scopes(self) -> None:
        if self.builder and self.builder.block.is_terminated:
            return
        for scope in reversed(self.scope_stack):
            for name in reversed(scope):
                typ = self.locals_types.get(name)
                if typ and typ.kind == "gc":
                    value = self.builder.load(self.locals[name])
                    self._emit_gc_dec(value, typ)
                if typ and typ.kind == "gc_weak":
                    value = self.builder.load(self.locals[name])
                    self._emit_gc_weak_dec(value, typ)

    def _emit_expr(self, expr: ast.Expr) -> ir.Value:
        if isinstance(expr, ast.IntLiteral):
            return ir.Constant(ir.IntType(64), expr.value)
        if isinstance(expr, ast.FloatLiteral):
            return ir.Constant(ir.DoubleType(), expr.value)
        if isinstance(expr, ast.BoolLiteral):
            return ir.Constant(ir.IntType(1), 1 if expr.value else 0)
        if isinstance(expr, ast.StringLiteral):
            return self._string_constant(expr.value)
        if isinstance(expr, ast.CharLiteral):
            return ir.Constant(ir.IntType(8), ord(expr.value))
        if isinstance(expr, ast.VarRef):
            if expr.name not in self.locals:
                if self.semantic and expr.name in self.semantic.classes:
                    class_type = self.class_types[expr.name].as_pointer()
                    return ir.Constant(class_type, None)
                raise YadroError(Diagnostic(f"Undefined variable '{expr.name}'", expr.line, expr.column))
            return self.builder.load(self.locals[expr.name])
        if isinstance(expr, ast.UnaryOp):
            if expr.op == "-":
                operand = self._emit_expr(expr.operand)
                if isinstance(operand.type, ir.DoubleType):
                    return self.builder.fsub(ir.Constant(ir.DoubleType(), 0.0), operand)
                return self.builder.sub(ir.Constant(operand.type, 0), operand)
            if expr.op == "!":
                operand = self._emit_expr(expr.operand)
                return self.builder.icmp_signed("==", operand, ir.Constant(operand.type, 0))
            if expr.op == "~":
                operand = self._emit_expr(expr.operand)
                if isinstance(operand.type, ir.DoubleType):
                    raise YadroError(Diagnostic("Bitwise '~' requires integer", expr.line, expr.column))
                # Promote small ints to i64 for operations on mixed types
                if isinstance(operand.type, ir.IntType) and operand.type.width < 64:
                    operand = self.builder.zext(operand, ir.IntType(64))
                return self.builder.not_(operand)
            if expr.op in {"&", "&mut"}:
                if isinstance(expr.operand, ast.VarRef):
                    if expr.operand.name not in self.locals:
                        raise YadroError(Diagnostic(f"Undefined variable '{expr.operand.name}'", expr.line, expr.column))
                    return self.locals[expr.operand.name]
                if isinstance(expr.operand, ast.IndexExpr):
                    return self._emit_index_ptr(expr.operand.target, expr.operand.index)
            if expr.op == "*":
                operand = self._emit_expr(expr.operand)
                return self.builder.load(operand)
        if isinstance(expr, ast.BinaryOp):
            if expr.op == "or" and self.semantic:
                left_type = self.semantic.expr_types.get(id(expr.left))
                if left_type and left_type.kind == "Option":
                    inner_type = left_type.type_args[0]
                    left = self._emit_expr(expr.left)
                    tag = self.builder.extract_value(left, 0)
                    is_some = self.builder.icmp_signed("==", tag, ir.Constant(ir.IntType(1), 1))
                    some_block = self.function.append_basic_block("opt_or_some")
                    none_block = self.function.append_basic_block("opt_or_none")
                    cont_block = self.function.append_basic_block("opt_or_cont")
                    self.builder.cbranch(is_some, some_block, none_block)
                    self.builder = ir.IRBuilder(some_block)
                    payload = self.builder.extract_value(left, 1)
                    self.builder.branch(cont_block)
                    some_block = self.builder.block
                    self.builder = ir.IRBuilder(none_block)
                    right_val = self._emit_expr(expr.right)
                    right_type = self.semantic.expr_types[id(expr.right)]
                    right_val = self._coerce_value(right_val, right_type, inner_type)
                    self.builder.branch(cont_block)
                    none_block = self.builder.block
                    self.builder = ir.IRBuilder(cont_block)
                    phi = self.builder.phi(self._llvm_type(inner_type))
                    phi.add_incoming(payload, some_block)
                    phi.add_incoming(right_val, none_block)
                    return phi
            left = self._emit_expr(expr.left)
            right = self._emit_expr(expr.right)
            if expr.op in {"+", "-", "*", "/", "%"}:
                return self._emit_arith(expr.op, left, right)
            if expr.op in {"==", "!=", "<", "<=", ">", ">="}:
                return self._emit_compare(expr.op, left, right)
            if expr.op in {"and", "or"}:
                return self._emit_short_circuit(expr.op, expr.left, expr.right)
            if expr.op in {"xor", "nand"}:
                return self._emit_logic(expr.op, left, right)
            if expr.op in {"|", "&", "^"}:
                return self._emit_bitwise(expr.op, left, right)
            if expr.op in {"<<", ">>"}:
                return self._emit_shift(expr.op, left, right)
        if isinstance(expr, ast.Call):
            if self.semantic and id(expr) in self.semantic.copy_calls:
                value = self._emit_expr(expr.args[0])
                value_type = self.semantic.expr_types[id(expr.args[0])]
                if value_type.kind == "ref":
                    value = self.builder.load(value)
                    value_type = value_type.element
                return self._emit_copy_value(value, value_type)
            if expr.callee in {"Ok", "Err", "Some", "None"}:
                return self._emit_constructor(expr)
            if expr.callee == "gc":
                return self._emit_gc_alloc(expr)
            if expr.callee == "gc_weak":
                value = self._emit_expr(expr.args[0])
                value_type = self.semantic.expr_types[id(expr.args[0])]
                return self._emit_gc_weak_new(value, value_type)
            if self.semantic and expr.callee in self.semantic.classes:
                return self._emit_class_call(expr)
            fn = self.module.get_global(expr.callee)
            sig = self.semantic.functions[expr.callee]
            args: List[ir.Value] = []
            for arg, param_type in zip(expr.args, sig.param_types):
                value = self._emit_expr(arg)
                value_type = self.semantic.expr_types[id(arg)]
                value = self._coerce_value(value, value_type, param_type)
                args.append(value)
            return self.builder.call(fn, args)
        if isinstance(expr, ast.MemberAccess):
            ptr = self._emit_member_ptr(expr.target, expr.name, expr.line, expr.column)
            return self.builder.load(ptr)
        if isinstance(expr, ast.MethodCall):
            return self._emit_method_call(expr)
        if isinstance(expr, ast.NewExpr):
            return self._emit_new(expr)
        if isinstance(expr, ast.TryExpr):
            if not self.semantic or not self.function:
                raise YadroError(Diagnostic("Try operator requires function context", expr.line, expr.column))
            result_value = self._emit_expr(expr.expr)
            result_type = self.semantic.expr_types[id(expr.expr)]
            if result_type.kind not in {"Option", "Result"}:
                raise YadroError(Diagnostic("Try operator requires Option or Result", expr.line, expr.column))
            tag = self.builder.extract_value(result_value, 0)
            is_ok = self.builder.icmp_signed("==", tag, ir.Constant(ir.IntType(1), 1))
            ok_block = self.function.append_basic_block("try_ok")
            err_block = self.function.append_basic_block("try_err")
            cont_block = self.function.append_basic_block("try_cont")
            self.builder.cbranch(is_ok, ok_block, err_block)
            err_builder = ir.IRBuilder(err_block)
            sig = self.semantic.functions.get(self.function.name)
            if sig is None or sig.return_type != result_type:
                raise YadroError(Diagnostic("Try operator type mismatch", expr.line, expr.column))
            err_builder.ret(result_value)
            ok_builder = ir.IRBuilder(ok_block)
            payload = ok_builder.extract_value(result_value, 1)
            ok_builder.branch(cont_block)
            self.builder = ir.IRBuilder(cont_block)
            return payload
        if isinstance(expr, ast.UnpackExpr):
            return self._emit_expr(expr.expr)
        if isinstance(expr, ast.ArrayLiteral):
            target_type = self.semantic.expr_types[id(expr)]
            llvm_target = self._llvm_type(target_type)
            if isinstance(llvm_target, ir.VectorType):
                vector_value = ir.Undef(llvm_target)
                for idx, item in enumerate(expr.items):
                    value = self._emit_expr(item)
                    if isinstance(value.type, ir.IntType) and isinstance(llvm_target.element, ir.DoubleType):
                        value = self.builder.sitofp(value, llvm_target.element)
                    index_const = ir.Constant(ir.IntType(32), idx)
                    vector_value = self.builder.insert_element(vector_value, value, index_const)
                return vector_value
            array_type = llvm_target
            element_type = array_type.pointee
            raw_type = ir.ArrayType(element_type, len(expr.items))
            alloca = self._alloca("arraytmp", raw_type)
            for idx, item in enumerate(expr.items):
                value = self._emit_expr(item)
                if isinstance(value.type, ir.IntType) and isinstance(element_type, ir.DoubleType):
                    value = self.builder.sitofp(value, element_type)
                elem_ptr = self.builder.gep(alloca, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), idx)], inbounds=True)
                self.builder.store(value, elem_ptr)
            zero = ir.Constant(ir.IntType(32), 0)
            return self.builder.gep(alloca, [zero, zero], inbounds=True)
        if isinstance(expr, ast.DictLiteral):
            dict_type = self.semantic.expr_types[id(expr)]
            key_type = dict_type.type_args[0]
            value_type = dict_type.type_args[1]
            suffix = f"{self._type_tag(key_type)}_{self._type_tag(value_type)}"
            i8_ptr = ir.IntType(8).as_pointer()
            new_fn = self._get_runtime_fn(f"__yadro_dict_new${suffix}", i8_ptr, [])
            set_fn = self._get_runtime_fn(
                f"__yadro_dict_set${suffix}",
                ir.VoidType(),
                [i8_ptr, self._llvm_type(key_type), self._llvm_type(value_type)],
            )
            dict_ptr = self.builder.call(new_fn, [])
            for key_expr, val_expr in expr.items:
                key_val = self._emit_expr(key_expr)
                val_val = self._emit_expr(val_expr)
                key_val = self._coerce_value(key_val, self.semantic.expr_types[id(key_expr)], key_type)
                val_val = self._coerce_value(val_val, self.semantic.expr_types[id(val_expr)], value_type)
                self.builder.call(set_fn, [dict_ptr, key_val, val_val])
            return dict_ptr
        if isinstance(expr, ast.SetLiteral):
            set_type = self.semantic.expr_types[id(expr)]
            element_type = set_type.type_args[0]
            suffix = self._type_tag(element_type)
            i8_ptr = ir.IntType(8).as_pointer()
            new_fn = self._get_runtime_fn(f"__yadro_set_new${suffix}", i8_ptr, [])
            add_fn = self._get_runtime_fn(
                f"__yadro_set_add${suffix}",
                ir.VoidType(),
                [i8_ptr, self._llvm_type(element_type)],
            )
            set_ptr = self.builder.call(new_fn, [])
            for item in expr.items:
                item_val = self._emit_expr(item)
                item_val = self._coerce_value(item_val, self.semantic.expr_types[id(item)], element_type)
                self.builder.call(add_fn, [set_ptr, item_val])
            return set_ptr
        if isinstance(expr, ast.IndexExpr):
            target_type = self.semantic.expr_types[id(expr.target)]
            if target_type.kind == "ref":
                target_type = target_type.element
            if target_type.kind == "vector":
                vector_value = self._emit_expr(expr.target)
                index_value = self._emit_expr(expr.index)
                if isinstance(index_value.type, ir.IntType) and index_value.type.width != 32:
                    index_value = self.builder.trunc(index_value, ir.IntType(32))
                return self.builder.extract_element(vector_value, index_value)
            ptr = self._emit_index_ptr(expr.target, expr.index)
            return self.builder.load(ptr)
        raise YadroError(Diagnostic("Unsupported expression", expr.line, expr.column))

    def _coerce_value(self, value: ir.Value, from_type: Type, to_type: Type) -> ir.Value:
        if from_type == to_type:
            return value
        if to_type == FLOAT and from_type == INT:
            return self.builder.sitofp(value, ir.DoubleType())
        if to_type == FLOAT and from_type == CHAR:
            return self.builder.sitofp(value, ir.DoubleType())
        if to_type == INT and from_type == BOOL:
            return self.builder.zext(value, ir.IntType(64))
        if to_type == INT and from_type == CHAR:
            return self.builder.zext(value, ir.IntType(64))
        if to_type == CHAR and from_type == INT:
            return self.builder.trunc(value, ir.IntType(8))
        if to_type == BOOL and from_type == INT:
            return self.builder.icmp_signed("!=", value, ir.Constant(ir.IntType(64), 0))
        if to_type.kind == "gc_weak" and from_type.kind == "gc":
            return self._emit_gc_weak_new(value, to_type)
        if to_type.kind == "trait":
            trait_name = to_type.var_name or ""
            if from_type.kind in self.semantic.classes:
                return self._build_trait_object(value, trait_name, from_type.kind)
            if from_type.kind == "ref" and from_type.element.kind in self.semantic.classes:
                return self._build_trait_object(value, trait_name, from_type.element.kind)
        return value

    def _build_trait_object(self, value: ir.Value, trait_name: str, class_name: str) -> ir.Value:
        if trait_name not in self.trait_vtables or class_name not in self.trait_vtables[trait_name]:
            raise YadroError(Diagnostic(f"Missing trait vtable for {trait_name} and {class_name}", 0, 0))
        data_ptr = self.builder.bitcast(value, ir.IntType(8).as_pointer())
        vtable_ptr = self.trait_vtables[trait_name][class_name]
        obj_type = self.trait_object_types[trait_name]
        return self._build_struct(obj_type, [data_ptr, vtable_ptr])

    def _emit_arith(self, op: str, left: ir.Value, right: ir.Value) -> ir.Value:
        if isinstance(left.type, ir.DoubleType) or isinstance(right.type, ir.DoubleType):
            left = self._to_double(left)
            right = self._to_double(right)
            if op == "+":
                return self.builder.fadd(left, right)
            if op == "-":
                return self.builder.fsub(left, right)
            if op == "*":
                return self.builder.fmul(left, right)
            if op == "/":
                return self.builder.fdiv(left, right)
            if op == "%":
                return self.builder.frem(left, right)
        if op == "+":
            return self.builder.add(left, right)
        if op == "-":
            return self.builder.sub(left, right)
        if op == "*":
            return self.builder.mul(left, right)
        if op == "/":
            return self.builder.sdiv(left, right)
        if op == "%":
            return self.builder.srem(left, right)
        raise YadroError(Diagnostic("Unsupported arithmetic operator", 0, 0))

    def _emit_compare(self, op: str, left: ir.Value, right: ir.Value) -> ir.Value:
        if isinstance(left.type, ir.PointerType) or isinstance(right.type, ir.PointerType):
            pred = {
                "==": "==",
                "!=": "!=",
                "<": "<",
                "<=": "<=",
                ">": ">",
                ">=": ">=",
            }[op]
            return self.builder.icmp_unsigned(pred, left, right)
        if isinstance(left.type, ir.DoubleType) or isinstance(right.type, ir.DoubleType):
            left = self._to_double(left)
            right = self._to_double(right)
            pred = {
                "==": "==",
                "!=": "!=",
                "<": "<",
                "<=": "<=",
                ">": ">",
                ">=": ">=",
            }[op]
            return self.builder.fcmp_ordered(pred, left, right)
        pred = {
            "==": "==",
            "!=": "!=",
            "<": "<",
            "<=": "<=",
            ">": ">",
            ">=": ">=",
        }[op]
        return self.builder.icmp_signed(pred, left, right)

    def _to_int64(self, value: ir.Value) -> ir.Value:
        if isinstance(value.type, ir.IntType) and value.type.width == 64:
            return value
        if isinstance(value.type, ir.IntType):
            return self.builder.zext(value, ir.IntType(64))
        raise YadroError(Diagnostic("Expected integer value", 0, 0))

    def _emit_bitwise(self, op: str, left: ir.Value, right: ir.Value) -> ir.Value:
        left64 = self._to_int64(left) if not isinstance(left.type, ir.IntType) or left.type.width != 64 else left
        right64 = self._to_int64(right) if not isinstance(right.type, ir.IntType) or right.type.width != 64 else right
        if op == "|":
            return self.builder.or_(left64, right64)
        if op == "&":
            return self.builder.and_(left64, right64)
        if op == "^":
            return self.builder.xor(left64, right64)
        raise YadroError(Diagnostic("Unsupported bitwise operator", 0, 0))

    def _emit_shift(self, op: str, left: ir.Value, right: ir.Value) -> ir.Value:
        left64 = self._to_int64(left)
        right64 = self._to_int64(right)
        if op == "<<":
            return self.builder.shl(left64, right64)
        if op == ">>":
            return self.builder.ashr(left64, right64)
        raise YadroError(Diagnostic("Unsupported shift operator", 0, 0))

    def _emit_logic(self, op: str, left: ir.Value, right: ir.Value) -> ir.Value:
        if op == "and":
            return self.builder.and_(left, right)
        if op == "or":
            return self.builder.or_(left, right)
        if op == "xor":
            return self.builder.xor(left, right)
        if op == "nand":
            return self.builder.not_(self.builder.and_(left, right))
        raise YadroError(Diagnostic("Unsupported logical operator", 0, 0))

    def _emit_short_circuit(self, op: str, left_expr: ast.Expr, right_expr: ast.Expr) -> ir.Value:
        current_block = self.builder.block
        left_val = self._emit_expr(left_expr)
        left_bool = self._as_bool(left_val)
        rhs_block = self.function.append_basic_block("logic_rhs")
        merge_block = self.function.append_basic_block("logic_merge")
        if op == "and":
            self.builder.cbranch(left_bool, rhs_block, merge_block)
        else:
            self.builder.cbranch(left_bool, merge_block, rhs_block)
        self.builder.position_at_end(rhs_block)
        right_val = self._emit_expr(right_expr)
        right_bool = self._as_bool(right_val)
        self.builder.branch(merge_block)
        rhs_block = self.builder.block
        self.builder.position_at_end(merge_block)
        phi = self.builder.phi(ir.IntType(1))
        if op == "and":
            phi.add_incoming(ir.Constant(ir.IntType(1), 0), current_block)
        else:
            phi.add_incoming(ir.Constant(ir.IntType(1), 1), current_block)
        phi.add_incoming(right_bool, rhs_block)
        return phi

    def _as_bool(self, value: ir.Value) -> ir.Value:
        if isinstance(value.type, ir.IntType) and value.type.width == 1:
            return value
        if isinstance(value.type, ir.PointerType):
            return self.builder.icmp_unsigned("!=", value, ir.Constant(value.type, None))
        return self.builder.icmp_signed("!=", value, ir.Constant(value.type, 0))

    def _alloca(self, name: str, typ: ir.Type) -> ir.AllocaInstr:
        entry = self.function.entry_basic_block
        builder = ir.IRBuilder(entry)
        return builder.alloca(typ, name=name)

    def _llvm_type(self, typ: Type) -> ir.Type:
        if typ == INT:
            return ir.IntType(64)
        if typ == FLOAT:
            return ir.DoubleType()
        if typ == BOOL:
            return ir.IntType(1)
        if typ == STRING:
            return ir.IntType(8).as_pointer()
        if typ == CHAR:
            return ir.IntType(8)
        if typ == UNIT:
            return ir.VoidType()
        if typ.kind == "ThreadId":
            return ir.IntType(64)
        if typ.kind in self.class_types:
            return self.class_types[typ.kind].as_pointer()
        if typ.kind == "classref":
            return self._llvm_type(typ.element)
        if typ.kind == "trait":
            if typ.var_name not in self.trait_object_types:
                raise YadroError(Diagnostic(f"Unknown trait '{typ.var_name}'", 0, 0))
            return self.trait_object_types[typ.var_name]
        if typ.kind in {"dict", "set"}:
            return ir.IntType(8).as_pointer()
        if typ.kind == "vector":
            element = typ.element
            if element is None:
                raise YadroError(Diagnostic("vector requires element type", 0, 0))
            element_type = self._llvm_type(element)
            if not isinstance(element_type, (ir.IntType, ir.DoubleType)):
                raise YadroError(Diagnostic("vector element type must be numeric or bool", 0, 0))
            if typ.size is None:
                raise YadroError(Diagnostic("vector requires size", 0, 0))
            return ir.VectorType(element_type, typ.size)
        if typ.kind in {"array", "darray", "ref", "gc", "gc_weak"}:
            return self._llvm_type(typ.element).as_pointer()
        if typ.kind == "Option":
            key = typ.name
            if key not in self.option_types:
                payload = self._llvm_type(typ.type_args[0])
                self.option_types[key] = ir.LiteralStructType([ir.IntType(1), payload])
            return self.option_types[key]
        if typ.kind == "Result":
            key = typ.name
            if key not in self.result_types:
                ok_type = self._llvm_type(typ.type_args[0])
                err_type = self._llvm_type(typ.type_args[1])
                self.result_types[key] = ir.LiteralStructType([ir.IntType(1), ok_type, err_type])
            return self.result_types[key]
        if typ.kind == "Task":
            key = typ.name
            if key not in self.task_types:
                payload = typ.type_args[0] if typ.type_args else UNIT
                payload_type = self._llvm_type(payload)
                if isinstance(payload_type, ir.VoidType):
                    self.task_types[key] = ir.LiteralStructType([ir.IntType(1)])
                else:
                    self.task_types[key] = ir.LiteralStructType([ir.IntType(1), payload_type])
            return self.task_types[key]
        raise YadroError(Diagnostic(f"Unknown type '{typ.name}'", 0, 0))

    def _type_of_param(self, func: ast.FunctionDef, param: ast.Param) -> Type:
        if not self.semantic:
            raise YadroError(Diagnostic("Semantic info missing", func.line, func.column))
        return self.semantic.functions[func.name].param_types[func.params.index(param)]

    def _type_of_return(self, func: ast.FunctionDef) -> Type:
        if not self.semantic:
            raise YadroError(Diagnostic("Semantic info missing", func.line, func.column))
        return self.semantic.functions[func.name].return_type

    def _mangle_method_name(self, class_name: str, method_name: str) -> str:
        return f"{class_name}.{method_name}"

    def _type_tag(self, typ: Type) -> str:
        name = typ.name
        name = name.replace("&mut ", "refmut_")
        name = name.replace("&", "ref_")
        return (
            name.replace("[", "_")
            .replace("]", "_")
            .replace(",", "_")
            .replace(" ", "_")
            .replace(".", "_")
        )

    def _method_def(self, method: ast.FunctionDef, name: str) -> ast.FunctionDef:
        return ast.FunctionDef(
            name=name,
            type_params=method.type_params,
            params=method.params,
            return_type=method.return_type,
            where_bounds=method.where_bounds,
            body=method.body,
            modifiers=method.modifiers,
            attributes=method.attributes,
            effects=method.effects,
            modifier_args=method.modifier_args,
            line=method.line,
            column=method.column,
        )

    def _to_double(self, value: ir.Value) -> ir.Value:
        if isinstance(value.type, ir.DoubleType):
            return value
        return self.builder.sitofp(value, ir.DoubleType())

    def _emit_index_ptr(self, target_expr: ast.Expr, index_expr: ast.Expr) -> ir.Value:
        target = self._emit_expr(target_expr)
        index = self._emit_expr(index_expr)
        index = self.builder.sext(index, ir.IntType(64)) if isinstance(index.type, ir.IntType) and index.type.width < 64 else index
        return self.builder.gep(target, [index], inbounds=True)

    def _lvalue_ptr_and_type(self, expr: ast.Expr, line: int, column: int) -> tuple[ir.Value, Type]:
        if isinstance(expr, ast.VarRef):
            if expr.name not in self.locals:
                raise YadroError(Diagnostic(f"Undefined variable '{expr.name}'", line, column))
            return self.locals[expr.name], self.locals_types[expr.name]
        if isinstance(expr, ast.MemberAccess):
            ptr = self._emit_member_ptr(expr.target, expr.name, line, column)
            target_type = self.semantic.expr_types[id(expr.target)]
            if target_type.kind == "ref":
                target_type = target_type.element
            field_type = self.semantic.classes[target_type.kind].fields[expr.name]
            return ptr, field_type
        if isinstance(expr, ast.IndexExpr):
            ptr = self._emit_index_ptr(expr.target, expr.index)
            target_type = self.semantic.expr_types[id(expr.target)]
            if target_type.kind == "ref":
                target_type = target_type.element
            element_type = target_type.element if target_type.kind in {"array", "darray"} else target_type
            return ptr, element_type
        raise YadroError(Diagnostic("Invalid assignment target", line, column))

    def _emit_member_ptr(self, target: object, name: str, line: int, column: int, class_name: Optional[str] = None) -> ir.Value:
        if isinstance(target, ir.Value):
            target_value = target
        else:
            target_value = self._emit_expr(target)
        if not isinstance(target_value.type, ir.PointerType):
            raise YadroError(Diagnostic("Member access requires pointer", line, column))
        if class_name is None:
            target_type = self.semantic.expr_types[id(target)]
            class_name = target_type.kind
            if class_name == "ref":
                class_name = target_type.element.kind
                target_value = self.builder.load(target_value)
        if class_name not in self.semantic.classes:
            raise YadroError(Diagnostic("Member access requires class type", line, column))
        info = self.semantic.classes[class_name]
        if name not in info.field_order:
            raise YadroError(Diagnostic(f"Unknown field '{name}'", line, column))
        index = info.field_order.index(name) + 1
        zero = ir.Constant(ir.IntType(32), 0)
        idx = ir.Constant(ir.IntType(32), index)
        return self.builder.gep(target_value, [zero, idx], inbounds=True)

    def _emit_method_call(self, expr: ast.MethodCall) -> ir.Value:
        target_type = self.semantic.expr_types[id(expr.target)]
        is_classref = target_type.kind == "classref"
        if self.semantic and id(expr) in self.semantic.copy_calls:
            value = self._emit_expr(expr.target)
            value_type = target_type
            if value_type.kind == "ref":
                value = self.builder.load(value)
                value_type = value_type.element
            return self._emit_copy_value(value, value_type)
        impl_call = self.semantic.trait_method_calls.get(id(expr)) if self.semantic else None
        if impl_call:
            impl_name, has_self = impl_call
            sig = self.semantic.functions[impl_name]
            fn = self.module.get_global(impl_name)
            args: List[ir.Value] = []
            if has_self:
                obj_ptr = self._emit_expr(expr.target)
                self_arg = self.builder.bitcast(obj_ptr, self._llvm_type(sig.param_types[0]))
                args.append(self_arg)
                expected_params = sig.param_types[1:]
            else:
                expected_params = sig.param_types
            for arg, param_type in zip(expr.args, expected_params):
                value = self._emit_expr(arg)
                value_type = self.semantic.expr_types[id(arg)]
                value = self._coerce_value(value, value_type, param_type)
                args.append(value)
            return self.builder.call(fn, args)
        if target_type.kind == "trait":
            trait_name = target_type.var_name or ""
            trait = self.semantic.traits[trait_name]
            method_index = trait.method_order.index(expr.name)
            sig = trait.methods[expr.name]
            has_self = trait.method_self.get(expr.name, False)
            target_value = self._emit_expr(expr.target)
            data_ptr = self.builder.extract_value(target_value, 0)
            vtable_ptr = self.builder.extract_value(target_value, 1)
            vtable_t = self.trait_vtable_types[trait_name]
            vtable_ptr = self.builder.bitcast(vtable_ptr, vtable_t.as_pointer())
            fn_ptr_ptr = self.builder.gep(vtable_ptr, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), method_index)], inbounds=True)
            fn_ptr = self.builder.load(fn_ptr_ptr)
            arg_types: List[ir.Type] = []
            if has_self:
                arg_types.append(ir.IntType(8).as_pointer())
                arg_types.extend(self._llvm_type(t) for t in sig.param_types[1:])
            else:
                arg_types.extend(self._llvm_type(t) for t in sig.param_types)
            fn_type = ir.FunctionType(self._llvm_type(sig.return_type), arg_types)
            fn = self.builder.bitcast(fn_ptr, fn_type.as_pointer())
            args: List[ir.Value] = []
            if has_self:
                args.append(data_ptr)
            expected_params = sig.param_types[1:] if has_self else sig.param_types
            for arg, param_type in zip(expr.args, expected_params):
                value = self._emit_expr(arg)
                value_type = self.semantic.expr_types[id(arg)]
                value = self._coerce_value(value, value_type, param_type)
                args.append(value)
            return self.builder.call(fn, args)
        if is_classref:
            class_type = target_type.element
        else:
            class_type = target_type.element if target_type.kind == "ref" else target_type
        info = self.semantic.classes[class_type.kind]
        method = info.methods[expr.name]
        if method.is_class:
            specialized = self.semantic.call_specializations.get(id(expr))
            if specialized:
                sig = self.semantic.functions[specialized]
                fn = self.module.get_global(specialized)
                param_types = sig.param_types
            else:
                mangled = self._mangle_method_name(class_type.kind, expr.name)
                fn = self.module.get_global(mangled)
                param_types = method.sig.param_types
            args: List[ir.Value] = []
            for arg, param_type in zip(expr.args, param_types):
                value = self._emit_expr(arg)
                value_type = self.semantic.expr_types[id(arg)]
                value = self._coerce_value(value, value_type, param_type)
                args.append(value)
            return self.builder.call(fn, args)
        specialized = self.semantic.call_specializations.get(id(expr))
        if specialized:
            sig = self.semantic.functions[specialized]
            fn = self.module.get_global(specialized)
            args: List[ir.Value] = []
            obj_ptr = self._emit_expr(expr.target)
            self_arg = self.builder.bitcast(obj_ptr, self._llvm_type(sig.param_types[0]))
            args.append(self_arg)
            for arg, param_type in zip(expr.args, sig.param_types[1:]):
                value = self._emit_expr(arg)
                value_type = self.semantic.expr_types[id(arg)]
                value = self._coerce_value(value, value_type, param_type)
                args.append(value)
            return self.builder.call(fn, args)
        obj_ptr = self._emit_expr(expr.target)
        vtable_ptr_ptr = self.builder.gep(obj_ptr, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), 0)], inbounds=True)
        vtable_ptr = self.builder.load(vtable_ptr_ptr)
        vtable_type = self.class_vtable_types[class_type.kind]
        vtable_ptr = self.builder.bitcast(vtable_ptr, vtable_type.as_pointer())
        method_index = info.vtable_order.index(expr.name)
        fn_ptr_ptr = self.builder.gep(vtable_ptr, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), method_index)], inbounds=True)
        fn_ptr = self.builder.load(fn_ptr_ptr)
        fn_type = ir.FunctionType(self._llvm_type(method.sig.return_type), [self._llvm_type(method.sig.param_types[0])] + [self._llvm_type(t) for t in method.sig.param_types[1:]])
        fn = self.builder.bitcast(fn_ptr, fn_type.as_pointer())
        args: List[ir.Value] = []
        self_arg = self.builder.bitcast(obj_ptr, self._llvm_type(method.sig.param_types[0]))
        args.append(self_arg)
        for arg, param_type in zip(expr.args, method.sig.param_types[1:]):
            value = self._emit_expr(arg)
            value_type = self.semantic.expr_types[id(arg)]
            value = self._coerce_value(value, value_type, param_type)
            args.append(value)
        return self.builder.call(fn, args)

    def _emit_new(self, expr: ast.NewExpr) -> ir.Value:
        target_type = self.semantic.expr_types[id(expr)]
        if target_type.kind not in self.class_types:
            raise YadroError(Diagnostic("new requires class type", expr.line, expr.column))
        struct_type = self.class_types[target_type.kind]
        alloca = self._alloca("obj", struct_type)
        info = self.semantic.classes[target_type.kind]
        vtable_ptr = self.class_vtables[target_type.kind]
        vtable_slot = self.builder.gep(alloca, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), 0)], inbounds=True)
        self.builder.store(self.builder.bitcast(vtable_ptr, ir.IntType(8).as_pointer()), vtable_slot)
        for idx, field_name in enumerate(info.field_order):
            if idx < len(expr.args):
                value = self._emit_expr(expr.args[idx])
                value_type = self.semantic.expr_types[id(expr.args[idx])]
                field_type = info.fields[field_name]
                value = self._coerce_value(value, value_type, field_type)
            else:
                field_type = info.fields[field_name]
                value = self._zero_value(self._llvm_type(field_type))
            ptr = self._emit_member_ptr(alloca, field_name, expr.line, expr.column, class_name=target_type.kind)
            self.builder.store(value, ptr)
        return alloca

    def _emit_class_call(self, expr: ast.Call) -> ir.Value:
        class_name = expr.callee
        struct_type = self.class_types[class_name]
        alloca = self._alloca("obj", struct_type)
        info = self.semantic.classes[class_name]
        vtable_ptr = self.class_vtables[class_name]
        vtable_slot = self.builder.gep(alloca, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), 0)], inbounds=True)
        self.builder.store(self.builder.bitcast(vtable_ptr, ir.IntType(8).as_pointer()), vtable_slot)
        for idx, field_name in enumerate(info.field_order):
            if idx < len(expr.args):
                value = self._emit_expr(expr.args[idx])
                value_type = self.semantic.expr_types[id(expr.args[idx])]
                field_type = info.fields[field_name]
                value = self._coerce_value(value, value_type, field_type)
            else:
                field_type = info.fields[field_name]
                value = self._zero_value(self._llvm_type(field_type))
            ptr = self._emit_member_ptr(alloca, field_name, expr.line, expr.column, class_name=class_name)
            self.builder.store(value, ptr)
        return alloca

    def _emit_constructor(self, expr: ast.Call) -> ir.Value:
        result_type = self.semantic.expr_types[id(expr)]
        llvm_type = self._llvm_type(result_type)
        if result_type.kind == "Option":
            tag = ir.Constant(ir.IntType(1), 1 if expr.callee == "Some" else 0)
            if expr.callee == "Some":
                payload = self._emit_expr(expr.args[0])
                value_type = self.semantic.expr_types[id(expr.args[0])]
                payload = self._coerce_value(payload, value_type, result_type.type_args[0])
            else:
                payload = self._zero_value(llvm_type.elements[1])
            return self._build_struct(llvm_type, [tag, payload])
        if result_type.kind == "Result":
            is_ok = expr.callee == "Ok"
            tag = ir.Constant(ir.IntType(1), 1 if is_ok else 0)
            if is_ok:
                ok_payload = self._emit_expr(expr.args[0])
                value_type = self.semantic.expr_types[id(expr.args[0])]
                ok_payload = self._coerce_value(ok_payload, value_type, result_type.type_args[0])
                err_payload = self._zero_value(llvm_type.elements[2])
            else:
                err_payload = self._emit_expr(expr.args[0])
                value_type = self.semantic.expr_types[id(expr.args[0])]
                err_payload = self._coerce_value(err_payload, value_type, result_type.type_args[1])
                ok_payload = self._zero_value(llvm_type.elements[1])
            return self._build_struct(llvm_type, [tag, ok_payload, err_payload])
        raise YadroError(Diagnostic("Unsupported constructor", expr.line, expr.column))

    def _emit_pattern_condition(self, expr_type: Type, tag: ir.Value, pattern: ast.Pattern) -> ir.Value:
        if isinstance(pattern, ast.PatternWildcard):
            return ir.Constant(ir.IntType(1), 1)
        if isinstance(pattern, ast.PatternConstructor):
            if expr_type.kind == "Option":
                return self.builder.icmp_signed("==", tag, ir.Constant(ir.IntType(1), 1 if pattern.name == "Some" else 0))
            if expr_type.kind == "Result":
                return self.builder.icmp_signed("==", tag, ir.Constant(ir.IntType(1), 1 if pattern.name == "Ok" else 0))
        raise YadroError(Diagnostic("Unsupported pattern", 0, 0))

    def _bind_pattern(self, expr_type: Type, value: ir.Value, pattern: ast.Pattern) -> None:
        if isinstance(pattern, ast.PatternConstructor):
            if expr_type.kind == "Option" and pattern.name == "Some" and pattern.args:
                payload = self.builder.extract_value(value, 1)
                self._bind_pattern_arg(pattern.args[0], payload)
            if expr_type.kind == "Result":
                if pattern.name == "Ok" and pattern.args:
                    payload = self.builder.extract_value(value, 1)
                    self._bind_pattern_arg(pattern.args[0], payload)
                if pattern.name == "Err" and pattern.args:
                    payload = self.builder.extract_value(value, 2)
                    self._bind_pattern_arg(pattern.args[0], payload)

    def _bind_pattern_arg(self, name: str, value: ir.Value) -> None:
        alloca = self._alloca(name, value.type)
        self.builder.store(value, alloca)
        self.locals[name] = alloca

    def _emit_gc_alloc(self, expr: ast.Call) -> ir.Value:
        element_value = self._emit_expr(expr.args[0])
        if self.arena_stack:
            alloc_fn = self._get_runtime_fn("__yadro_arena_alloc", ir.IntType(8).as_pointer(), [ir.IntType(64)])
        else:
            alloc_fn = self._get_runtime_fn("__yadro_gc_alloc", ir.IntType(8).as_pointer(), [ir.IntType(64)])
        size = ir.Constant(ir.IntType(64), 8)
        raw_ptr = self.builder.call(alloc_fn, [size])
        typed_ptr = self.builder.bitcast(raw_ptr, element_value.type.as_pointer())
        self.builder.store(element_value, typed_ptr)
        return typed_ptr

    def _emit_gc_inc(self, value: ir.Value, typ: Type) -> None:
        if typ.kind != "gc":
            return
        inc_fn = self._get_runtime_fn("__yadro_gc_inc", ir.VoidType(), [ir.IntType(8).as_pointer()])
        self.builder.call(inc_fn, [self.builder.bitcast(value, ir.IntType(8).as_pointer())])

    def _emit_gc_dec(self, value: ir.Value, typ: Type) -> None:
        if typ.kind != "gc":
            return
        dec_fn = self._get_runtime_fn("__yadro_gc_dec", ir.VoidType(), [ir.IntType(8).as_pointer()])
        self.builder.call(dec_fn, [self.builder.bitcast(value, ir.IntType(8).as_pointer())])

    def _emit_copy_value(self, value: ir.Value, typ: Type) -> ir.Value:
        if typ.kind == "gc":
            self._emit_gc_inc(value, typ)
        if typ.kind == "gc_weak":
            self._emit_gc_weak_inc(value, typ)
        return value

    def _emit_gc_weak_new(self, value: ir.Value, typ: Type) -> ir.Value:
        new_fn = self._get_runtime_fn("__yadro_gc_weak_new", ir.IntType(8).as_pointer(), [ir.IntType(8).as_pointer()])
        raw = self.builder.bitcast(value, ir.IntType(8).as_pointer())
        weak_raw = self.builder.call(new_fn, [raw])
        return self.builder.bitcast(weak_raw, value.type)

    def _emit_gc_weak_inc(self, value: ir.Value, typ: Type) -> None:
        if typ.kind != "gc_weak":
            return
        inc_fn = self._get_runtime_fn("__yadro_gc_weak_inc", ir.VoidType(), [ir.IntType(8).as_pointer()])
        self.builder.call(inc_fn, [self.builder.bitcast(value, ir.IntType(8).as_pointer())])

    def _emit_gc_weak_dec(self, value: ir.Value, typ: Type) -> None:
        if typ.kind != "gc_weak":
            return
        dec_fn = self._get_runtime_fn("__yadro_gc_weak_dec", ir.VoidType(), [ir.IntType(8).as_pointer()])
        self.builder.call(dec_fn, [self.builder.bitcast(value, ir.IntType(8).as_pointer())])

    def _get_runtime_fn(self, name: str, ret: ir.Type, args: List[ir.Type]) -> ir.Function:
        if name in self.module.globals:
            return self.module.get_global(name)
        fn_type = ir.FunctionType(ret, args)
        return ir.Function(self.module, fn_type, name=name)

    def _build_struct(self, typ: ir.Type, values: List[ir.Value]) -> ir.Value:
        alloca = self._alloca("tmpstruct", typ)
        for idx, value in enumerate(values):
            ptr = self.builder.gep(alloca, [ir.Constant(ir.IntType(32), 0), ir.Constant(ir.IntType(32), idx)], inbounds=True)
            self.builder.store(value, ptr)
        return self.builder.load(alloca)

    def _build_task_value(self, task_type: Type, payload: Optional[ir.Value]) -> ir.Value:
        llvm_task = self._llvm_type(task_type)
        ready = ir.Constant(ir.IntType(1), 1)
        if isinstance(llvm_task, ir.LiteralStructType) and len(llvm_task.elements) == 1:
            return self._build_struct(llvm_task, [ready])
        if payload is None:
            payload = self._zero_value(llvm_task.elements[1])
        return self._build_struct(llvm_task, [ready, payload])

    def _zero_value(self, typ: ir.Type) -> ir.Constant:
        if isinstance(typ, ir.PointerType):
            return ir.Constant(typ, None)
        if isinstance(typ, ir.IntType):
            return ir.Constant(typ, 0)
        if isinstance(typ, ir.DoubleType):
            return ir.Constant(typ, 0.0)
        if isinstance(typ, ir.LiteralStructType):
            return ir.Constant(typ, [self._zero_value(t) for t in typ.elements])
        return ir.Constant(typ, None)

    def _string_constant(self, value: str) -> ir.Value:
        if value in self.string_constants:
            return self.string_constants[value].bitcast(ir.IntType(8).as_pointer())
        byte_values = bytearray(value.encode("utf-8")) + b"\x00"
        const_type = ir.ArrayType(ir.IntType(8), len(byte_values))
        global_var = ir.GlobalVariable(self.module, const_type, name=f".str.{len(self.string_constants)}")
        global_var.linkage = "internal"
        global_var.global_constant = True
        global_var.initializer = ir.Constant(const_type, byte_values)
        self.string_constants[value] = global_var
        return global_var.bitcast(ir.IntType(8).as_pointer())


def _normalize_target_token(value: str) -> str:
    return value.strip().lower().replace("_", "-")


def _extract_target_payload(directives: List[ast.Directive]) -> Optional[dict]:
    for directive in directives:
        if directive.kind == "target" and isinstance(directive.payload, dict):
            return directive.payload
    return None


def resolve_target_triple(directives: List[ast.Directive]) -> Optional[str]:
    payload = _extract_target_payload(directives)
    if not payload:
        return None
    triple = payload.get("triple")
    if isinstance(triple, str) and triple:
        return triple
    os_value = payload.get("os") or payload.get("platform")
    arch_value = payload.get("arch") or payload.get("backend")
    abi_value = payload.get("abi")
    if not os_value or not arch_value:
        return None
    os_token = _normalize_target_token(str(os_value))
    arch_token = _normalize_target_token(str(arch_value))
    abi_token = _normalize_target_token(str(abi_value)) if abi_value else None
    arch_map = {
        "x86-64": "x86_64",
        "x86_64": "x86_64",
        "amd64": "x86_64",
        "aarch64": "aarch64",
        "arm64": "aarch64",
        "wasm32": "wasm32",
    }
    os_map = {
        "linux": "linux",
        "windows": "windows",
        "win": "windows",
        "macos": "macos",
        "darwin": "macos",
        "osx": "macos",
        "wasi": "wasi",
    }
    arch = arch_map.get(arch_token)
    os_name = os_map.get(os_token)
    if not arch or not os_name:
        return None
    if os_name == "linux":
        return f"{arch}-unknown-linux-{abi_token or 'gnu'}"
    if os_name == "windows":
        return f"{arch}-pc-windows-{abi_token or 'msvc'}"
    if os_name == "macos":
        return f"{arch}-apple-darwin"
    if os_name == "wasi":
        return f"{arch}-unknown-wasi"
    return None


def _resolve_target_options(directives: List[ast.Directive]) -> Tuple[Optional[str], Optional[str]]:
    payload = _extract_target_payload(directives)
    if not payload:
        return None, None
    cpu = payload.get("cpu")
    features = payload.get("features")
    cpu_value = str(cpu) if isinstance(cpu, str) and cpu else None
    features_value = str(features) if isinstance(features, str) and features else None
    return cpu_value, features_value


def emit_llvm_ir(mir: MirModule) -> str:
    codegen = Codegen("yadro_module")
    module = codegen.emit(mir)
    return str(module)


def emit_object(mir: MirModule) -> bytes:
    binding.initialize()
    binding.initialize_native_target()
    binding.initialize_native_asmprinter()
    llvm_ir = emit_llvm_ir(mir)
    llvm_module = binding.parse_assembly(llvm_ir)
    llvm_module.verify()
    triple = resolve_target_triple(mir.program.directives)
    cpu, features = _resolve_target_options(mir.program.directives)
    try:
        if triple:
            target = binding.Target.from_triple(triple)
            target_machine = target.create_target_machine(cpu=cpu or "", features=features or "")
            llvm_module.triple = triple
            llvm_module.data_layout = str(target_machine.target_data)
        else:
            target = binding.Target.from_default_triple()
            target_machine = target.create_target_machine()
            llvm_module.triple = target.triple
            llvm_module.data_layout = str(target_machine.target_data)
    except Exception as exc:
        raise YadroError(Diagnostic(f"Unsupported target: {exc}", 1, 1)) from exc
    return target_machine.emit_object(llvm_module)
