from dataclasses import dataclass

from . import ast
from .sema import SemanticResult


@dataclass
class MirModule:
    program: ast.Program
    semantic: SemanticResult


def lower_to_mir(semantic: SemanticResult) -> MirModule:
    return MirModule(semantic.program, semantic)
