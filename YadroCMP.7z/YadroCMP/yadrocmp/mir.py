"""
Mid-Level Intermediate Representation (MIR)

Implements the MIR stage of the YadroCMP compiler pipeline as defined in
YUP 26.1.4 §3.1:

  Source (.yad)
    ↓ [Lexer/Parser]
  AST
    ↓ [Semantic Analysis + Constitutional Checks]
  Typed AST
    ↓ [MIR Generation]          ← this module
  Mid-level IR (YADRO-specific)
    ↓ [Constitutional Verification Pass]
  Verified MIR
    ↓ [LLVM IR Generation]
  LLVM IR

The MIR layer has two responsibilities:

  1. Carry semantic analysis results to the code generator in a structured
     form (MirModule).

  2. Annotate the module with MirOptHint records that guide the LLVM code
     generator toward constitutionally-sound optimisations (YUP 26.1.4 §3.2).
     Hints never change semantics – they are purely advisory.

Constitutional alignment (YUP 26.1.3):
  Article II.3 (Cost Must Be Apparent)  – hints make optimization intent
                                          explicit rather than leaving it to
                                          LLVM heuristics.
  Article III.1 (Abstraction without Overhead) – const/pure functions are
                                          marked for inlining / CSE.
  Article IV.1  (Against Global Entropy) – pure functions with no effects are
                                          explicitly identified for the
                                          optimizer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from . import ast
from .sema import SemanticResult

# ---------------------------------------------------------------------------
# MirOptHint  – optimization annotations
# ---------------------------------------------------------------------------


@dataclass
class MirOptHint:
    """
    A single optimization hint produced by the MIR lowering pass.

    The code generator reads these hints and uses them to configure LLVM
    function attributes, inlining thresholds, and pass-manager settings.

    Hint kinds
    ----------
    "inline"
        The function is a strong candidate for inlining at all call sites.
        Applied to: const functions, small pure functions (≤ 4 statements).

    "noinline"
        Never inline this function (e.g. thread entry points where inlining
        would destroy the thread-boundary semantics).

    "pure"
        The function has no observable side effects (no effects set, no ffi,
        no async/thread modifiers).  The optimizer may hoist, CSE, or
        eliminate calls to pure functions.

    "const_fold"
        The function is a compile-time constant function ([const] modifier).
        Its return value may be computed at compile time.

    "loop_unroll"
        A loop with a statically-known, small trip-count that the code
        generator should consider unrolling.

    "readnone"
        LLVM ``readnone`` attribute: the function does not read or write
        memory through pointer arguments.  Implies "pure".
    """

    kind: str  # One of the kinds described above
    target: str  # Mangled name of the function this hint applies to
    value: Optional[object] = None  # Optional payload (e.g. unroll factor)


# ---------------------------------------------------------------------------
# MirModule  – the top-level MIR container
# ---------------------------------------------------------------------------


@dataclass
class MirModule:
    """
    The Mid-Level IR module.

    Bundles the original AST, semantic analysis results, and the list of
    optimizer hints produced during MIR lowering.
    """

    program: ast.Program
    semantic: SemanticResult
    opt_hints: List[MirOptHint] = field(default_factory=list)

    def hints_for(self, name: str) -> List[MirOptHint]:
        """Return all hints that apply to function *name*."""
        return [h for h in self.opt_hints if h.target == name]

    def has_hint(self, name: str, kind: str) -> bool:
        """Return True if function *name* has an optimization hint of *kind*."""
        return any(h.target == name and h.kind == kind for h in self.opt_hints)


# ---------------------------------------------------------------------------
# MIR lowering  (Typed AST → MirModule)
# ---------------------------------------------------------------------------


def lower_to_mir(semantic: SemanticResult) -> MirModule:
    """
    Lower the typed AST + semantic results to MIR.

    This is a single-pass transformation: it creates a MirModule and
    populates it with optimization hints derived from the semantic
    information that is already available after type-checking.

    Per YUP 26.1.4 §3.1, further optimization passes (e.g. constant
    propagation, alias analysis) would run here in a mature implementation.
    For the current version the pass is intentionally lightweight so as not
    to risk constitutional violations from over-aggressive transformations
    (YUP 26.1.3 Article II.1).
    """
    hints = _collect_opt_hints(semantic)
    return MirModule(program=semantic.program, semantic=semantic, opt_hints=hints)


# ---------------------------------------------------------------------------
# Optimization hint collection
# ---------------------------------------------------------------------------


def _collect_opt_hints(semantic: SemanticResult) -> List[MirOptHint]:
    """
    Derive MirOptHint records from semantic analysis results.

    Strategy
    --------
    1. Const functions ([const] modifier):
       - "const_fold" + "inline" because their return values are computed
         at compile time and call sites should see the folded constant
         (Article III.1: zero-cost abstraction).

    2. Pure functions (no effects, no ffi/async/thread):
       - "pure" so the optimizer knows calls are side-effect-free.
       - "readnone" if the function takes no pointer parameters.
       - "inline" for small bodies (≤ 4 statements).

    3. Thread-entry functions ([thread] modifier):
       - "noinline" because inlining a thread entry point would silently
         remove the thread boundary (Article II.1: No Magic).

    4. FFI functions ([ffi] modifier):
       - "noinline" – we cannot make assumptions about external code.
       - No "pure" annotation unless the programmer adds #[effect(...)]
         explicitly (Article II.1: No Magic).
    """
    hints: List[MirOptHint] = []

    # Build a fast lookup: function name → AST FunctionDef
    func_defs = {f.name: f for f in semantic.program.functions}

    for name, _sig in semantic.functions.items():
        func_ast = func_defs.get(name)
        if func_ast is None:
            # Specialisation or impl function – apply minimal hints
            _hints_for_specialization(hints, name, semantic)
            continue

        modifiers = func_ast.modifiers
        effects = semantic.function_effects.get(name, set())

        # ---- Thread entry points -----------------------------------------------
        if "thread" in modifiers:
            hints.append(MirOptHint("noinline", name))
            continue

        # ---- Const functions ---------------------------------------------------
        if "const" in modifiers or name in semantic.const_functions:
            hints.append(MirOptHint("const_fold", name))
            hints.append(MirOptHint("inline", name))
            continue

        # ---- FFI declarations --------------------------------------------------
        if "ffi" in modifiers:
            hints.append(MirOptHint("noinline", name))
            continue

        # ---- Async functions ---------------------------------------------------
        # Async functions may suspend; do not mark as pure or inline freely.
        if "async" in modifiers:
            continue

        # ---- Pure functions ----------------------------------------------------
        has_ptr_params = _has_pointer_params(func_ast, semantic)

        if not effects:
            hints.append(MirOptHint("pure", name))
            if not has_ptr_params:
                hints.append(MirOptHint("readnone", name))

        # ---- Small-body inline candidates ------------------------------------
        body_size = _body_size(func_ast)
        if body_size <= 4 and "ffi" not in modifiers and "thread" not in modifiers:
            hints.append(MirOptHint("inline", name))

        # ---- Loop unroll hints -----------------------------------------------
        _collect_loop_hints(hints, name, func_ast.body)

    # Impl functions (trait implementations) – apply pure/inline where possible
    for func in semantic.impl_functions:
        if func.type_params:
            continue
        effects = semantic.function_effects.get(func.name, set())
        if (
            not effects
            and "ffi" not in func.modifiers
            and "thread" not in func.modifiers
        ):
            hints.append(MirOptHint("pure", func.name))
        if _body_size(func) <= 4:
            hints.append(MirOptHint("inline", func.name))

    return hints


def _hints_for_specialization(
    hints: List[MirOptHint],
    name: str,
    semantic: SemanticResult,
) -> None:
    """Apply minimal hints to specialised / impl-generated functions."""
    effects = semantic.function_effects.get(name, set())
    if not effects:
        hints.append(MirOptHint("pure", name))
    # Specialisations tend to be small wrappers; inline them
    hints.append(MirOptHint("inline", name))


def _has_pointer_params(func: ast.FunctionDef, semantic: SemanticResult) -> bool:
    """Return True if the function signature contains any reference or gc parameters."""
    sig = semantic.functions.get(func.name)
    if sig is None:
        return False
    for pt in sig.param_types:
        if pt.kind in {"ref", "gc", "gc_weak", "darray", "dict", "set", "array"}:
            return True
    return False


def _body_size(func: ast.FunctionDef) -> int:
    """Return the number of top-level statements in a function body."""
    return len(func.body)


def _collect_loop_hints(
    hints: List[MirOptHint],
    func_name: str,
    stmts: List[ast.Stmt],
) -> None:
    """
    Detect for-loops with small constant trip counts and emit unroll hints.

    A loop is eligible for unrolling when:
      - It is a ``for`` loop with literal start / end / step values.
      - The computed trip count is ≤ 8.
    """
    for stmt in stmts:
        if isinstance(stmt, ast.ForStmt):
            trip = _const_trip_count(stmt)
            if trip is not None and 1 <= trip <= 8:
                hints.append(MirOptHint("loop_unroll", func_name, value=trip))
            # Recurse into body
            _collect_loop_hints(hints, func_name, stmt.body)

        elif isinstance(stmt, ast.WhileStmt):
            _collect_loop_hints(hints, func_name, stmt.body)

        elif isinstance(stmt, ast.RepeatStmt):
            _collect_loop_hints(hints, func_name, stmt.body)

        elif isinstance(stmt, ast.IfStmt):
            _collect_loop_hints(hints, func_name, stmt.then_body)
            for _, body in stmt.elifs:
                _collect_loop_hints(hints, func_name, body)
            if stmt.else_body:
                _collect_loop_hints(hints, func_name, stmt.else_body)

        elif isinstance(stmt, (ast.UnsafeBlock, ast.ArenaStmt)):
            _collect_loop_hints(hints, func_name, stmt.body)


def _const_trip_count(stmt: ast.ForStmt) -> Optional[int]:
    """
    Return the trip count of a for-loop if all bounds are integer literals.
    Returns None when any bound is non-constant.
    """
    if not isinstance(stmt.start, ast.IntLiteral):
        return None
    if not isinstance(stmt.end, ast.IntLiteral):
        return None

    start = stmt.start.value
    end = stmt.end.value

    if stmt.step is None:
        step = 1
    elif isinstance(stmt.step, ast.IntLiteral):
        step = stmt.step.value
    elif isinstance(stmt.step, ast.UnaryOp) and stmt.step.op == "-":
        if isinstance(stmt.step.operand, ast.IntLiteral):
            step = -stmt.step.operand.value
        else:
            return None
    else:
        return None

    if step == 0:
        return None

    if step > 0:
        count = max(0, (end - start + step - 1) // step)
    else:
        count = max(0, (start - end - step - 1) // (-step))

    return count
