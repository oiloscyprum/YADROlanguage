from dataclasses import dataclass
from typing import Dict, List, Optional

from . import ast
from .errors import Diagnostic, YadroError
from .typesys import (
    BOOL,
    BUILTINS,
    CHAR,
    FLOAT,
    INT,
    STRING,
    THREAD_ID,
    UNIT,
    Type,
    is_numeric,
)


@dataclass(frozen=True)
class FunctionSig:
    name: str
    param_types: List[Type]
    return_type: Type
    type_params: List[str]
    where_bounds: List[tuple[str, str]]


@dataclass
class SemanticResult:
    program: ast.Program
    functions: Dict[str, FunctionSig]
    classes: Dict[str, "ClassInfo"]
    traits: Dict[str, "TraitInfo"]
    impls: Dict[str, List[Type]]
    impl_functions: List[ast.FunctionDef]
    specialized_functions: List[ast.FunctionDef]
    decl_types: Dict[int, Type]
    expr_types: Dict[int, Type]
    dict_destructure_types: Dict[int, tuple[Type, Type]]
    call_specializations: Dict[int, str]
    trait_method_calls: Dict[int, tuple[str, bool]]
    copy_calls: set[int]
    required_libs: set[str]
    plugins: set[str]
    # MIR-visible semantic data (YUP 26.1.4)
    function_effects: Dict[str, set[str]] = None  # type: ignore[assignment]
    const_functions: set[str] = None  # type: ignore[assignment]
    # YUP 26.1.5 – spec/verification diagnostics (warnings, not errors)
    verification_warnings: List[str] = None  # type: ignore[assignment]
    # YUP 26.1.3 – constitutional diagnostics
    constitution_notes: List[str] = None  # type: ignore[assignment]
    # YUP 26.1.5 – ghost variables (erased before codegen, zero-cost)
    ghost_vars: set[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.function_effects is None:
            object.__setattr__(self, "function_effects", {})
        if self.const_functions is None:
            object.__setattr__(self, "const_functions", set())
        if self.verification_warnings is None:
            object.__setattr__(self, "verification_warnings", [])
        if self.constitution_notes is None:
            object.__setattr__(self, "constitution_notes", [])
        if self.ghost_vars is None:
            object.__setattr__(self, "ghost_vars", set())


@dataclass
class ClassInfo:
    name: str
    typ: Type
    fields: Dict[str, Type]
    field_order: List[str]
    methods: Dict[str, "MethodInfo"]
    base: Optional[str]
    vtable_order: List[str]
    modifiers: List[str]


@dataclass
class MethodInfo:
    name: str
    sig: FunctionSig
    is_class: bool


@dataclass
class TraitInfo:
    name: str
    type_params: List[str]
    methods: Dict[str, FunctionSig]
    method_order: List[str]
    method_self: Dict[str, bool]
    is_protocol: bool = False


class _ConstReturn(Exception):
    def __init__(self, value: object):
        self.value = value


class SemanticAnalyzer:
    def __init__(self) -> None:
        self.expr_types: Dict[int, Type] = {}
        self.decl_types: Dict[int, Type] = {}
        self.dict_destructure_types: Dict[int, tuple[Type, Type]] = {}
        self.functions: Dict[str, FunctionSig] = {}
        self.classes: Dict[str, ClassInfo] = {}
        self.traits: Dict[str, TraitInfo] = {}
        self.impls: Dict[str, List[Type]] = {}
        self.impl_functions: List[ast.FunctionDef] = []
        self.specialized_functions: List[ast.FunctionDef] = []
        self.call_specializations: Dict[int, str] = {}
        self.trait_method_calls: Dict[int, tuple[str, bool]] = {}
        self.copy_calls: set[int] = set()
        self.function_effects: Dict[str, set[str]] = {}
        self.scopes: List[Dict[str, Type]] = []
        self.loop_depth = 0
        self.current_class: Optional[Type] = None
        self.type_params: List[str] = []
        self.type_bindings: Dict[str, Type] = {}
        self.moved: List[set[str]] = []
        self.borrowed: List[Dict[str, str]] = []
        self.param_names: set[str] = set()
        self.ref_sources: Dict[int, str] = {}
        self.current_trait: Optional[str] = None
        self.method_defs: Dict[tuple[str, str], ast.FunctionDef] = {}
        self.impl_method_defs: Dict[tuple[str, str, str], ast.FunctionDef] = {}
        self.traits_with_generic_methods: set[str] = set()
        self.current_return_type: Optional[Type] = None
        self.const_functions: set[str] = set()
        self.current_effects: Optional[set[str]] = None
        self.required_libs: set[str] = set()
        self.plugins: set[str] = set()
        self.allowed_effects = {"unsafe", "network_access", "may_block", "js_event"}
        self.allowed_ffi_abis = {
            "cdecl",
            "c",
            "stdcall",
            "fastcall",
            "thiscall",
            "sysv",
            "win64",
        }
        self.const_scopes: List[set[str]] = []
        self.const_values: List[Dict[str, object]] = []
        self.spec_types: Dict[str, ast.SpecTypeDef] = {}
        self.in_spec = False
        # YUP 26.1.5 – ghost variable names (erased before codegen)
        self.ghost_vars: set[str] = set()
        # YUP 26.1.3 – Article IV.1: track mutable variables in main_block
        self._main_block_vars: set[str] = set()
        # Per-function name for Article IV.1 checking
        self._current_function_name: Optional[str] = None

    def analyze(
        self, program: ast.Program, verify_level: str = "check"
    ) -> SemanticResult:  # noqa: C901
        self._verify_level = verify_level
        self._collect_directives(program.directives)
        self.spec_types = {}
        for spec in program.spec_types:
            if spec.name in self.spec_types or spec.name in BUILTINS:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate spec type '{spec.name}'", spec.line, spec.column
                    )
                )
            self.spec_types[spec.name] = spec
        self.function_defs = {func.name: func for func in program.functions}
        for cls in program.classes:
            self._validate_attributes(cls.attributes, cls.line, cls.column)
            self._validate_class_modifiers(cls.modifiers, cls.line, cls.column)
            if (
                cls.name in self.classes
                or cls.name in BUILTINS
                or cls.name in self.spec_types
            ):
                raise YadroError(
                    Diagnostic(f"Duplicate class '{cls.name}'", cls.line, cls.column)
                )
            self.classes[cls.name] = ClassInfo(
                cls.name, Type(cls.name), {}, [], {}, cls.base, [], cls.modifiers
            )
        for trait in program.traits:
            self._validate_attributes(trait.attributes, trait.line, trait.column)
            if trait.name in self.traits or trait.name in self.spec_types:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate trait '{trait.name}'", trait.line, trait.column
                    )
                )
            self.traits[trait.name] = TraitInfo(
                trait.name, trait.type_params, {}, [], {}, trait.is_protocol
            )
        self.traits_with_generic_methods = {
            trait.name
            for trait in program.traits
            if any(method.type_params for method in trait.methods)
        }
        self._validate_spec_types(program.spec_types)
        for impl in program.impls:
            self._validate_attributes(impl.attributes, impl.line, impl.column)
        for func in program.functions:
            self._validate_attributes(func.attributes, func.line, func.column)
            self._validate_effects(func.effects, func.line, func.column)
            if func.name in self.functions:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate function '{func.name}'", func.line, func.column
                    )
                )
            self._validate_function_modifiers(
                func.modifiers,
                func.modifier_args,
                func.line,
                func.column,
                context="function",
            )
            self._validate_ffi_requires(func)
            self._validate_where_bounds_decl(
                func.where_bounds, func.type_params, func.line, func.column
            )
            self.type_params = func.type_params
            param_types = [self._resolve_type(p.type_name) for p in func.params]
            return_type = self._resolve_type(func.return_type)
            self.type_params = []
            self.functions[func.name] = FunctionSig(
                func.name, param_types, return_type, func.type_params, func.where_bounds
            )
            self.function_effects[func.name] = self._effective_effects(
                func.effects, func.modifiers, func.attributes
            )
            if "const" in func.modifiers:
                self.const_functions.add(func.name)
        for cls in program.classes:
            self._analyze_class(cls)
        for trait in program.traits:
            self._analyze_trait(trait)
        for impl in program.impls:
            self._analyze_impl(impl)
        for func in program.functions:
            self._analyze_function(func)
        self.current_return_type = INT
        self._analyze_block(program.main_block, expected_return=INT)
        self.current_return_type = None
        result = SemanticResult(
            program,
            self.functions,
            self.classes,
            self.traits,
            self.impls,
            self.impl_functions,
            self.specialized_functions,
            self.decl_types,
            self.expr_types,
            self.dict_destructure_types,
            self.call_specializations,
            self.trait_method_calls,
            self.copy_calls,
            set(self.required_libs),
            set(self.plugins),
            dict(self.function_effects),
            set(self.const_functions),
            ghost_vars=set(self.ghost_vars),
        )
        # YUP 26.1.5 – collect spec / verification warnings
        self._collect_spec_warnings(program, result)
        # YUP 26.1.3 – constitutional checks (Articles I.1, II.1, II.3, V.Pillar1)
        self._check_constitution_rules(program, result)
        # YUP 26.1.3 – Article IV.1: Against Global Entropy
        self._check_article_iv1(program, result)
        return result

    def _analyze_class(self, cls: ast.ClassDef) -> None:
        info = self.classes[cls.name]
        for field in cls.fields:
            if field.name in info.fields:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate field '{field.name}'", field.line, field.column
                    )
                )
            info.fields[field.name] = self._resolve_type(field.type_name)
        if cls.base is not None and cls.base not in self.classes:
            raise YadroError(
                Diagnostic(f"Unknown base class '{cls.base}'", cls.line, cls.column)
            )
        info.base = cls.base
        base_fields: List[str] = []
        if cls.base is not None:
            base_fields = self.classes[cls.base].field_order
            for name, method_info in self.classes[cls.base].methods.items():
                info.methods[name] = method_info
        info.field_order = base_fields + [f.name for f in cls.fields]
        if cls.invariants:
            bindings = {name: typ for name, typ in info.fields.items()}
            if cls.base is not None:
                bindings.update(self.classes[cls.base].fields)
            bindings["self"] = info.typ
            for invariant in cls.invariants:
                self._analyze_spec_predicate(
                    invariant, bindings, invariant.line, invariant.column
                )
        for method in cls.methods:
            self._validate_attributes(method.attributes, method.line, method.column)
            self._validate_effects(method.effects, method.line, method.column)
            self._validate_function_modifiers(
                method.modifiers,
                method.modifier_args,
                method.line,
                method.column,
                context="method",
            )
            self.method_defs[(cls.name, method.name)] = method
            self._register_method_signature(cls, method)
            self._analyze_method(cls, method)
        vtable = []
        if cls.base is not None:
            vtable = list(self.classes[cls.base].vtable_order)
        for method in cls.methods:
            if "class" in method.modifiers:
                continue
            if method.name in vtable:
                vtable[vtable.index(method.name)] = method.name
            else:
                vtable.append(method.name)
        info.vtable_order = vtable
        self._validate_class_behavior(cls)

    def _analyze_function(self, func: ast.FunctionDef) -> None:
        self.type_params = func.type_params
        self.scopes.append({})
        self.moved.append(set())
        self.borrowed.append({})
        self.param_names = {p.name for p in func.params}
        previous_effects = self.current_effects
        self.current_effects = self.function_effects.get(
            func.name,
            self._effective_effects(func.effects, func.modifiers, func.attributes),
        )
        for param in func.params:
            param_type = self._resolve_type(param.type_name)
            param_type = self._with_region(param_type, self._current_region())
            self.scopes[-1][param.name] = param_type
            if param.default is not None:
                default_type = self._analyze_expr(param.default)
                self._ensure_assignable(
                    param_type, default_type, param.line, param.column
                )
        return_type = self._resolve_type(func.return_type)
        expected_return = return_type
        if "async" in func.modifiers:
            if return_type.kind != "Task" or len(return_type.type_args) != 1:
                raise YadroError(
                    Diagnostic(
                        "async function must return Task[T]", func.line, func.column
                    )
                )
            expected_return = return_type.type_args[0]
        if "thread" in func.modifiers:
            if return_type.kind != "ThreadId":
                raise YadroError(
                    Diagnostic(
                        "thread function must return ThreadId", func.line, func.column
                    )
                )
            expected_return = UNIT
        if "const" in func.modifiers and func.body:
            self._validate_const_body(func.body)
        self._validate_refined_params(func.params)
        if func.spec is not None:
            self._validate_spec_block(func.spec, return_type)
        previous_return = self.current_return_type
        self.current_return_type = return_type
        if "ffi" in func.modifiers and not func.body:
            self.scopes.pop()
            self.moved.pop()
            self.borrowed.pop()
            self.current_return_type = previous_return
            self.type_params = []
            self.param_names = set()
            self.current_effects = previous_effects
            return
        has_return = self._analyze_block(func.body, expected_return=expected_return)
        if return_type != UNIT and "thread" not in func.modifiers and not has_return:
            raise YadroError(
                Diagnostic(
                    f"Missing return in function '{func.name}'", func.line, func.column
                )
            )
        self.scopes.pop()
        self.moved.pop()
        self.borrowed.pop()
        self.current_return_type = previous_return
        self.type_params = []
        self.param_names = set()
        self.current_effects = previous_effects

    def _analyze_method(self, cls: ast.ClassDef, method: ast.FunctionDef) -> None:
        requires_self = "class" not in method.modifiers
        previous_effects = self.current_effects
        mangled = self._mangle_method_name(cls.name, method.name)
        self.current_effects = self.function_effects.get(
            mangled,
            self._effective_effects(
                method.effects, method.modifiers, method.attributes
            ),
        )
        if requires_self:
            if not method.params:
                raise YadroError(
                    Diagnostic(
                        "Method requires self parameter", method.line, method.column
                    )
                )
            first = method.params[0]
            if first.name != "self":
                raise YadroError(
                    Diagnostic(
                        "First parameter of method must be self",
                        first.line,
                        first.column,
                    )
                )
        self.current_class = self.classes[cls.name].typ
        self.type_params = method.type_params
        self.scopes.append({})
        self.moved.append(set())
        self.borrowed.append({})
        self.param_names = {p.name for p in method.params}
        for param in method.params:
            param_type = self._resolve_type(param.type_name)
            param_type = self._with_region(param_type, self._current_region())
            self.scopes[-1][param.name] = param_type
            if param.default is not None:
                default_type = self._analyze_expr(param.default)
                self._ensure_assignable(
                    param_type, default_type, param.line, param.column
                )
        return_type = self._resolve_type(method.return_type)
        expected_return = return_type
        if "async" in method.modifiers:
            if return_type.kind != "Task" or len(return_type.type_args) != 1:
                raise YadroError(
                    Diagnostic(
                        "async method must return Task[T]", method.line, method.column
                    )
                )
            expected_return = return_type.type_args[0]
        if "thread" in method.modifiers:
            if return_type.kind != "ThreadId":
                raise YadroError(
                    Diagnostic(
                        "thread method must return ThreadId", method.line, method.column
                    )
                )
            expected_return = UNIT
        if "const" in method.modifiers:
            self._validate_const_body(method.body)
        self._validate_refined_params(method.params)
        if method.spec is not None:
            self._validate_spec_block(method.spec, return_type)
        previous_return = self.current_return_type
        self.current_return_type = return_type
        has_return = self._analyze_block(method.body, expected_return=expected_return)
        if return_type != UNIT and "thread" not in method.modifiers and not has_return:
            raise YadroError(
                Diagnostic(
                    f"Missing return in method '{method.name}'",
                    method.line,
                    method.column,
                )
            )
        self.scopes.pop()
        self.moved.pop()
        self.borrowed.pop()
        self.current_class = None
        self.current_return_type = previous_return
        self.type_params = []
        self.param_names = set()
        self.current_effects = previous_effects

    def _register_method_signature(
        self, cls: ast.ClassDef, method: ast.FunctionDef
    ) -> None:
        self.current_class = self.classes[cls.name].typ
        self._validate_where_bounds_decl(
            method.where_bounds, method.type_params, method.line, method.column
        )
        param_types = [self._resolve_type(p.type_name) for p in method.params]
        return_type = self._resolve_type(method.return_type)
        self.current_class = None
        mangled = self._mangle_method_name(cls.name, method.name)
        if mangled in self.functions:
            raise YadroError(
                Diagnostic(
                    f"Duplicate function '{mangled}'", method.line, method.column
                )
            )
        sig = FunctionSig(
            mangled, param_types, return_type, method.type_params, method.where_bounds
        )
        self.functions[mangled] = sig
        self.function_effects[mangled] = self._effective_effects(
            method.effects, method.modifiers, method.attributes
        )
        self.classes[cls.name].methods[method.name] = MethodInfo(
            method.name, sig, "class" in method.modifiers
        )
        if "const" in method.modifiers:
            self.const_functions.add(mangled)
        if cls.base:
            base_info = self.classes[cls.base]
            if method.name in base_info.methods:
                base_sig = base_info.methods[method.name].sig
                if (
                    base_sig.param_types != sig.param_types
                    or base_sig.return_type != sig.return_type
                ):
                    raise YadroError(
                        Diagnostic(
                            f"Method '{method.name}' does not match base signature",
                            method.line,
                            method.column,
                        )
                    )

    def _analyze_block(self, stmts: List[ast.Stmt], expected_return: Type) -> bool:
        self.scopes.append({})
        self.moved.append(set())
        self.borrowed.append({})
        self.const_scopes.append(set())
        self.const_values.append({})
        # NLL improvement: track which variables were declared in THIS scope
        # so we can release their borrows when they go out of scope.
        scope_declared: set[str] = set()
        # NLL improvement: track ref variables declared here and what they borrow.
        # When a ref goes out of scope its borrow on the source is released.
        scope_ref_sources: dict[str, str] = {}  # ref_var_name -> source_var_name
        has_return = False
        for stmt in stmts:
            if isinstance(stmt, ast.VarDecl):
                var_type = self._resolve_type(stmt.type_name)
                var_type = self._with_region(var_type, self._current_region())
                expr_type = self._analyze_expr(stmt.value, expected=var_type)
                self._ensure_assignable(var_type, expr_type, stmt.line, stmt.column)
                self.scopes[-1][stmt.name] = var_type
                self.decl_types[id(stmt)] = var_type
                scope_declared.add(stmt.name)
                # NLL: if this variable is a reference, record what it borrows
                # so we can release that borrow when the ref goes out of scope.
                if var_type.kind == "ref":
                    src = self.ref_sources.get(id(stmt.value))
                    if src is not None:
                        scope_ref_sources[stmt.name] = src
                # YUP 26.1.5: ghost variables exist only for spec analysis
                if getattr(stmt, "ghost", False):
                    self.ghost_vars.add(stmt.name)
            elif isinstance(stmt, ast.ConstDecl):
                var_type = self._resolve_type(stmt.type_name)
                var_type = self._with_region(var_type, self._current_region())
                self._validate_const_expr(stmt.value)
                expr_type = self._analyze_expr(stmt.value, expected=var_type)
                self._ensure_assignable(var_type, expr_type, stmt.line, stmt.column)
                self.scopes[-1][stmt.name] = var_type
                scope_declared.add(stmt.name)
                self.const_scopes[-1].add(stmt.name)
                const_value = self._eval_const_expr(stmt.value)
                self.const_values[-1][stmt.name] = const_value
                stmt.value = self._const_literal_expr(
                    const_value, stmt.value.line, stmt.value.column
                )
                self.expr_types[id(stmt.value)] = var_type
                self.decl_types[id(stmt)] = var_type
            elif isinstance(stmt, ast.DestructureDecl):
                var_type = self._resolve_type(stmt.type_name)
                var_type = self._with_region(var_type, self._current_region())
                value_expr = stmt.value
                if isinstance(value_expr, ast.UnpackExpr):
                    value_expr = value_expr.expr
                value_type = self._analyze_expr(value_expr)
                if value_type.kind not in {"array", "darray"}:
                    raise YadroError(
                        Diagnostic(
                            "Destructuring requires array or darray",
                            stmt.line,
                            stmt.column,
                        )
                    )
                if (
                    value_type.kind == "array"
                    and value_type.size is not None
                    and value_type.size != len(stmt.names)
                ):
                    raise YadroError(
                        Diagnostic(
                            "Destructuring count does not match array size",
                            stmt.line,
                            stmt.column,
                        )
                    )
                self._ensure_assignable(
                    var_type, value_type._elem, stmt.line, stmt.column
                )
                for name in stmt.names:
                    self.scopes[-1][name] = var_type
                self.decl_types[id(stmt)] = var_type
            elif isinstance(stmt, ast.DictDestructureDecl):
                key_type = self._resolve_type(stmt.key_type)
                value_type = self._resolve_type(stmt.value_type)
                key_type = self._with_region(key_type, self._current_region())
                value_type = self._with_region(value_type, self._current_region())
                value_expr = stmt.value
                if isinstance(value_expr, ast.UnpackExpr):
                    value_expr = value_expr.expr
                dict_type = self._analyze_expr(value_expr)
                if dict_type.kind != "dict" or len(dict_type.type_args) != 2:
                    raise YadroError(
                        Diagnostic(
                            "Dict destructuring requires dict", stmt.line, stmt.column
                        )
                    )
                if key_type.kind != "darray" or value_type.kind != "darray":
                    raise YadroError(
                        Diagnostic(
                            "Dict destructuring requires darray types",
                            stmt.line,
                            stmt.column,
                        )
                    )
                dict_key_type = dict_type.type_args[0]
                dict_value_type = dict_type.type_args[1]
                self._ensure_assignable(
                    key_type._elem, dict_key_type, stmt.line, stmt.column
                )
                self._ensure_assignable(
                    value_type._elem, dict_value_type, stmt.line, stmt.column
                )
                self.scopes[-1][stmt.key_name] = key_type
                self.scopes[-1][stmt.value_name] = value_type
                self.dict_destructure_types[id(stmt)] = (key_type, value_type)
            elif isinstance(stmt, ast.Assign):
                if self._is_const_var(stmt.name):
                    raise YadroError(
                        Diagnostic(
                            f"Cannot assign to const '{stmt.name}'",
                            stmt.line,
                            stmt.column,
                        )
                    )
                var_type = self._lookup_var(stmt.name, stmt.line, stmt.column)
                expr_type = self._analyze_expr(stmt.value, expected=var_type)
                self._ensure_assignable(var_type, expr_type, stmt.line, stmt.column)
                self._mark_move(stmt.name, var_type, stmt.line, stmt.column)
                # NLL improvement: re-assigning a variable clears its moved
                # state so it can be used again after the new value is stored.
                for moved_scope in self.moved:
                    moved_scope.discard(stmt.name)
                # Also clear any stale borrows for this variable — a full
                # reassignment ends the previous value's lifetime.
                for borrow_scope in self.borrowed:
                    borrow_scope.pop(stmt.name, None)
            elif isinstance(stmt, ast.CompoundAssign):
                target_type = self._analyze_lvalue(stmt.target, stmt.line, stmt.column)
                expr_type = self._analyze_expr(stmt.value)
                result_type = self._compound_result_type(
                    stmt.op, target_type, expr_type, stmt.line, stmt.column
                )
                self._ensure_assignable(
                    target_type, result_type, stmt.line, stmt.column
                )
            elif isinstance(stmt, ast.AssignMember):
                if isinstance(stmt.target, ast.VarRef) and stmt.target.name == "self":
                    target_type = self._lookup_var(
                        stmt.target.name, stmt.target.line, stmt.target.column
                    )
                    self.expr_types[id(stmt.target)] = target_type
                else:
                    target_type = self._analyze_expr(stmt.target, mode="borrow")
                if target_type.kind == "ref":
                    target_type = target_type._elem
                if target_type.kind not in self.classes:
                    raise YadroError(
                        Diagnostic(
                            "Member assignment requires class type",
                            stmt.line,
                            stmt.column,
                        )
                    )
                info = self.classes[target_type.kind]
                if stmt.name not in info.fields:
                    raise YadroError(
                        Diagnostic(
                            f"Unknown field '{stmt.name}'", stmt.line, stmt.column
                        )
                    )
                field_type = info.fields[stmt.name]
                expr_type = self._analyze_expr(stmt.value, expected=field_type)
                self._ensure_assignable(field_type, expr_type, stmt.line, stmt.column)
            elif isinstance(stmt, ast.AssignIndex):
                target_type = self._analyze_expr(stmt.target)
                if target_type.kind not in {"array", "darray"}:
                    raise YadroError(
                        Diagnostic(
                            "Index assignment requires array or darray",
                            stmt.line,
                            stmt.column,
                        )
                    )
                index_type = self._analyze_expr(stmt.index)
                self._ensure_assignable(INT, index_type, stmt.line, stmt.column)
                expr_type = self._analyze_expr(stmt.value, expected=target_type._elem)
                self._ensure_assignable(
                    target_type._elem, expr_type, stmt.line, stmt.column
                )
            elif isinstance(stmt, ast.SwapStmt):
                left_type = self._analyze_lvalue(stmt.left, stmt.line, stmt.column)
                right_type = self._analyze_lvalue(stmt.right, stmt.line, stmt.column)
                self._ensure_assignable(left_type, right_type, stmt.line, stmt.column)
                self._ensure_assignable(right_type, left_type, stmt.line, stmt.column)
            elif isinstance(stmt, ast.IfStmt):
                cond_type = self._analyze_expr(stmt.condition)
                self._ensure_assignable(BOOL, cond_type, stmt.line, stmt.column)
                then_has = self._analyze_block(stmt.then_body, expected_return)
                elif_has = any(
                    self._analyze_block(body, expected_return) for _, body in stmt.elifs
                )
                else_has = (
                    self._analyze_block(stmt.else_body, expected_return)
                    if stmt.else_body
                    else False
                )
                has_return = has_return or (then_has and elif_has and else_has)
            elif isinstance(stmt, ast.WhileStmt):
                cond_type = self._analyze_expr(stmt.condition)
                self._ensure_assignable(BOOL, cond_type, stmt.line, stmt.column)
                if stmt.invariants:
                    bindings = self._spec_bindings()
                    for invariant in stmt.invariants:
                        self._analyze_spec_predicate(
                            invariant, bindings, invariant.line, invariant.column
                        )
                self.loop_depth += 1
                self._analyze_block(stmt.body, expected_return)
                self.loop_depth -= 1
            elif isinstance(stmt, ast.ForStmt):
                var_type = self._resolve_type(stmt.var_type)
                self._ensure_assignable(INT, var_type, stmt.line, stmt.column)
                start_type = self._analyze_expr(stmt.start)
                end_type = self._analyze_expr(stmt.end)
                self._ensure_assignable(INT, start_type, stmt.line, stmt.column)
                self._ensure_assignable(INT, end_type, stmt.line, stmt.column)
                if stmt.step is not None:
                    step_type = self._analyze_expr(stmt.step)
                    self._ensure_assignable(INT, step_type, stmt.line, stmt.column)
                if stmt.invariants:
                    bindings = self._spec_bindings()
                    bindings[stmt.name] = var_type
                    for invariant in stmt.invariants:
                        self._analyze_spec_predicate(
                            invariant, bindings, invariant.line, invariant.column
                        )
                self.scopes.append({stmt.name: var_type})
                self.loop_depth += 1
                self._analyze_block(stmt.body, expected_return)
                self.loop_depth -= 1
                self.scopes.pop()
            elif isinstance(stmt, ast.RepeatStmt):
                self.loop_depth += 1
                self._analyze_block(stmt.body, expected_return)
                self.loop_depth -= 1
                cond_type = self._analyze_expr(stmt.condition)
                self._ensure_assignable(BOOL, cond_type, stmt.line, stmt.column)
            elif isinstance(stmt, ast.SwitchStmt):
                expr_type = self._analyze_expr(stmt.expr)
                if expr_type.kind in {"Result", "Option"}:
                    self._analyze_switch_pattern(expr_type, stmt, expected_return)
                else:
                    if expr_type not in (INT, FLOAT, BOOL, STRING, CHAR):
                        raise YadroError(
                            Diagnostic(
                                "Switch expression must be int, float, bool, string, or char",
                                stmt.line,
                                stmt.column,
                            )
                        )
                    for case in stmt.cases:
                        if not isinstance(case.value, ast.PatternLiteral):
                            raise YadroError(
                                Diagnostic(
                                    "Pattern not allowed for non Result/Option switch",
                                    case.value.line,
                                    case.value.column,
                                )
                            )
                        case_type = self._analyze_expr(case.value.value)
                        if case_type != expr_type:
                            raise YadroError(
                                Diagnostic(
                                    "Case value type must match switch expression",
                                    case.value.line,
                                    case.value.column,
                                )
                            )
                        self._analyze_block(case.body, expected_return)
                if stmt.default_body:
                    self._analyze_block(stmt.default_body, expected_return)
            elif isinstance(stmt, ast.BreakStmt):
                if self.loop_depth == 0:
                    raise YadroError(
                        Diagnostic("Break used outside of loop", stmt.line, stmt.column)
                    )
            elif isinstance(stmt, ast.ContinueStmt):
                if self.loop_depth == 0:
                    raise YadroError(
                        Diagnostic(
                            "Continue used outside of loop", stmt.line, stmt.column
                        )
                    )
            elif isinstance(stmt, ast.ReturnStmt):
                if stmt.value is None:
                    self._ensure_assignable(
                        expected_return, UNIT, stmt.line, stmt.column
                    )
                else:
                    value_type = self._analyze_expr(
                        stmt.value, expected=expected_return
                    )
                    self._ensure_assignable(
                        expected_return, value_type, stmt.line, stmt.column
                    )
                    if value_type.kind == "ref":
                        ref_source = self.ref_sources.get(id(stmt.value))
                        if ref_source and ref_source not in self.param_names:
                            raise YadroError(
                                Diagnostic(
                                    "Returning reference to local value",
                                    stmt.line,
                                    stmt.column,
                                )
                            )
                has_return = True
            elif isinstance(stmt, ast.DelStmt):
                if isinstance(stmt.target, ast.VarRef):
                    target_type = self._lookup_var(
                        stmt.target.name, stmt.line, stmt.column
                    )
                    self.expr_types[id(stmt.target)] = target_type
                    self._mark_move(
                        stmt.target.name, target_type, stmt.line, stmt.column
                    )
                else:
                    target_type = self._analyze_expr(stmt.target)
                    if target_type.kind == "classref":
                        raise YadroError(
                            Diagnostic("del requires value", stmt.line, stmt.column)
                        )
            elif isinstance(stmt, ast.ExprStmt):
                self._analyze_expr(stmt.expr)
            elif isinstance(stmt, ast.ArenaStmt):
                self._analyze_block(stmt.body, expected_return)
            elif isinstance(stmt, ast.UnsafeBlock):
                previous_effects = self.current_effects
                if self.current_effects is None:
                    self.current_effects = {"unsafe"}
                else:
                    self.current_effects = set(self.current_effects)
                    self.current_effects.add("unsafe")
                self._analyze_block(stmt.body, expected_return)
                self.current_effects = previous_effects
            elif isinstance(stmt, ast.InlineAsm):
                if self.in_spec:
                    raise YadroError(
                        Diagnostic(
                            "inline asm not allowed in spec", stmt.line, stmt.column
                        )
                    )
                self._require_effects({"unsafe"}, stmt.line, stmt.column)
                if len(stmt.outputs) > 1:
                    raise YadroError(
                        Diagnostic(
                            "Inline asm supports at most one output",
                            stmt.line,
                            stmt.column,
                        )
                    )
                for _, expr in stmt.inputs:
                    self._analyze_expr(expr)
                for _, name in stmt.outputs:
                    if self._is_const_var(name):
                        raise YadroError(
                            Diagnostic(
                                f"Cannot assign to const '{name}'",
                                stmt.line,
                                stmt.column,
                            )
                        )
                    self._lookup_var(name, stmt.line, stmt.column)
            else:
                raise YadroError(
                    Diagnostic("Unsupported statement", stmt.line, stmt.column)
                )
        # NLL improvement: when a reference variable goes out of scope, release
        # the borrow it held on its source variable.  This lets the source be
        # borrowed or moved again after the reference is no longer live.
        for ref_var, src_var in scope_ref_sources.items():
            self._release_borrow(src_var)
        # Release borrows held on variables declared in this scope before
        # popping, so the outer scope doesn't see stale entries.
        for borrow_scope in self.borrowed:
            for name in scope_declared:
                borrow_scope.pop(name, None)
        # Also clear moved markers for scope-local variables so the outer
        # scope doesn't misinterpret them as moved.
        for moved_scope in self.moved:
            moved_scope -= scope_declared
        self.scopes.pop()
        self.moved.pop()
        self.borrowed.pop()
        self.const_scopes.pop()
        self.const_values.pop()
        return has_return

    def _current_region(self) -> int:
        return max(len(self.scopes) - 1, 0)

    def _with_region(self, typ: Type, region: int) -> Type:
        if typ.kind == "ref" and typ.region is None:
            return Type("ref", element=typ.element, mutable=typ.mutable, region=region)
        return typ

    def _analyze_expr(
        self, expr: ast.Expr, expected: Optional[Type] = None, mode: str = "value"
    ) -> Type:
        expr_id = id(expr)
        if isinstance(expr, ast.IntLiteral):
            self.expr_types[expr_id] = INT
            return INT
        if isinstance(expr, ast.FloatLiteral):
            self.expr_types[expr_id] = FLOAT
            return FLOAT
        if isinstance(expr, ast.BoolLiteral):
            self.expr_types[expr_id] = BOOL
            return BOOL
        if isinstance(expr, ast.StringLiteral):
            self.expr_types[expr_id] = STRING
            return STRING
        if isinstance(expr, ast.CharLiteral):
            self.expr_types[expr_id] = CHAR
            return CHAR
        if isinstance(expr, ast.VarRef):
            if expr.name in self.classes:
                class_type = self.classes[expr.name].typ
                class_ref = Type("classref", element=class_type)
                self.expr_types[expr_id] = class_ref
                return class_ref
            var_type = self._lookup_var(expr.name, expr.line, expr.column)
            if mode == "borrow":
                self._mark_borrow(
                    expr.name, mutable=False, line=expr.line, column=expr.column
                )
            elif mode == "move":
                self._mark_move(expr.name, var_type, expr.line, expr.column)
            else:
                if not self._is_copy(var_type):
                    self._mark_move(expr.name, var_type, expr.line, expr.column)
            self.expr_types[expr_id] = var_type
            return var_type
        if isinstance(expr, ast.TryExpr):
            inner_type = self._analyze_expr(expr.expr)
            if inner_type.kind not in {"Option", "Result"}:
                raise YadroError(
                    Diagnostic(
                        "Try operator requires Option or Result", expr.line, expr.column
                    )
                )
            if self.current_return_type is None:
                raise YadroError(
                    Diagnostic(
                        "Try operator requires function context", expr.line, expr.column
                    )
                )
            if (
                self.current_return_type.kind != inner_type.kind
                or self.current_return_type.type_args != inner_type.type_args
            ):
                raise YadroError(
                    Diagnostic("Try operator type mismatch", expr.line, expr.column)
                )
            result = inner_type.type_args[0]
            self.expr_types[expr_id] = result
            return result
        if isinstance(expr, ast.UnpackExpr):
            inner_type = self._analyze_expr(expr.expr)
            self.expr_types[expr_id] = inner_type
            return inner_type
        if isinstance(expr, ast.UnaryOp):
            operand_type = self._analyze_expr(
                expr.operand, mode="borrow" if expr.op in {"&", "&mut"} else "value"
            )
            if expr.op == "-":
                if not is_numeric(operand_type):
                    raise YadroError(
                        Diagnostic(
                            "Unary '-' requires numeric type", expr.line, expr.column
                        )
                    )
                result = FLOAT if operand_type == FLOAT else INT
                self.expr_types[expr_id] = result
                return result
            if expr.op == "!":
                self._ensure_assignable(BOOL, operand_type, expr.line, expr.column)
                self.expr_types[expr_id] = BOOL
                return BOOL
            if expr.op == "~":
                if self.in_spec:
                    self.expr_types[expr_id] = operand_type
                    return operand_type
                if operand_type not in (INT, CHAR):
                    raise YadroError(
                        Diagnostic(
                            "Bitwise '~' requires int or char", expr.line, expr.column
                        )
                    )
                self.expr_types[expr_id] = INT
                return INT
            if expr.op in {"&", "&mut"}:
                if isinstance(expr.operand, ast.VarRef):
                    mutable = expr.op == "&mut"
                    self._mark_borrow(
                        expr.operand.name,
                        mutable=mutable,
                        line=expr.line,
                        column=expr.column,
                    )
                    ref_type = Type(
                        "ref",
                        element=operand_type,
                        mutable=mutable,
                        region=self._current_region(),
                    )
                    self.ref_sources[expr_id] = expr.operand.name
                    self.expr_types[expr_id] = ref_type
                    return ref_type
                if isinstance(expr.operand, ast.IndexExpr):
                    element_type = self._analyze_index(expr.operand, borrow_target=True)
                    ref_type = Type(
                        "ref",
                        element=element_type,
                        mutable=expr.op == "&mut",
                        region=self._current_region(),
                    )
                    self.expr_types[expr_id] = ref_type
                    return ref_type
                raise YadroError(
                    Diagnostic(
                        "Address-of requires a variable or index expression",
                        expr.line,
                        expr.column,
                    )
                )
            if expr.op == "*":
                if operand_type.kind != "ref":
                    raise YadroError(
                        Diagnostic(
                            "Dereference requires reference type",
                            expr.line,
                            expr.column,
                        )
                    )
                self.expr_types[expr_id] = operand_type._elem
                return operand_type._elem
            raise YadroError(
                Diagnostic("Unsupported unary operator", expr.line, expr.column)
            )
        if isinstance(expr, ast.BinaryOp):
            left = self._analyze_expr(expr.left)
            right = self._analyze_expr(expr.right)
            if expr.op in {"+", "-", "*", "/", "%"}:
                if is_numeric(left) and is_numeric(right):
                    result = FLOAT if (left == FLOAT or right == FLOAT) else INT
                    self.expr_types[expr_id] = result
                    return result
                raise YadroError(
                    Diagnostic(
                        "Arithmetic operators require numeric operands",
                        expr.line,
                        expr.column,
                    )
                )
            if expr.op in {"==", "!=", "<", "<=", ">", ">="}:
                if left != right and not (is_numeric(left) and is_numeric(right)):
                    raise YadroError(
                        Diagnostic(
                            "Comparison requires matching operand types",
                            expr.line,
                            expr.column,
                        )
                    )
                self.expr_types[expr_id] = BOOL
                return BOOL
            if expr.op in {"and", "or", "xor", "nand"}:
                if expr.op == "or" and left.kind == "Option":
                    inner = left.type_args[0]
                    self._ensure_assignable(inner, right, expr.line, expr.column)
                    self.expr_types[expr_id] = inner
                    return inner
                self._ensure_assignable(BOOL, left, expr.line, expr.column)
                self._ensure_assignable(BOOL, right, expr.line, expr.column)
                self.expr_types[expr_id] = BOOL
                return BOOL
            if expr.op in {"|", "&", "^"}:
                if left not in (INT, CHAR) or right not in (INT, CHAR):
                    raise YadroError(
                        Diagnostic(
                            "Bitwise operators require int or char operands",
                            expr.line,
                            expr.column,
                        )
                    )
                self.expr_types[expr_id] = INT
                return INT
            if expr.op in {"<<", ">>"}:
                if left not in (INT, CHAR) or right != INT:
                    raise YadroError(
                        Diagnostic(
                            "Shift operators require (int|char) << int",
                            expr.line,
                            expr.column,
                        )
                    )
                self.expr_types[expr_id] = INT
                return INT
            raise YadroError(
                Diagnostic("Unsupported binary operator", expr.line, expr.column)
            )
        if isinstance(expr, ast.MemberAccess):
            target_type = self._analyze_expr(expr.target, mode="borrow")
            if target_type.kind == "ref":
                target_type = target_type._elem
            if target_type.kind not in self.classes:
                raise YadroError(
                    Diagnostic(
                        "Member access requires class type", expr.line, expr.column
                    )
                )
            info = self.classes[target_type.kind]
            if expr.name not in info.fields:
                raise YadroError(
                    Diagnostic(f"Unknown field '{expr.name}'", expr.line, expr.column)
                )
            field_type = info.fields[expr.name]
            self.expr_types[expr_id] = field_type
            return field_type
        if isinstance(expr, ast.MethodCall):
            target_type = self._analyze_expr(expr.target, mode="borrow")
            if target_type.kind == "ref":
                target_type = target_type._elem
            if expr.name == "copy" and not expr.args and not expr.type_args:
                if target_type.kind == "classref":
                    raise YadroError(
                        Diagnostic("copy requires value", expr.line, expr.column)
                    )
                if (
                    target_type.kind in self.classes
                    and "linear" in self.classes[target_type.kind].modifiers
                ):
                    raise YadroError(
                        Diagnostic(
                            "copy is not allowed for linear class",
                            expr.line,
                            expr.column,
                        )
                    )
                if (
                    target_type.kind in self.classes
                    and "copy" in self.classes[target_type.kind].methods
                ):
                    pass
                else:
                    self.copy_calls.add(expr_id)
                    self.expr_types[expr_id] = target_type
                    return target_type
            is_classref = target_type.kind == "classref"
            if is_classref:
                class_type = target_type._elem
            else:
                class_type = target_type
            if class_type.kind == "trait":  # type: ignore[union-attr]
                trait = self.traits.get(class_type.var_name or "")
                if trait is None or expr.name not in trait.methods:
                    raise YadroError(
                        Diagnostic(
                            f"Unknown method '{expr.name}'", expr.line, expr.column
                        )
                    )
                sig = trait.methods[expr.name]
                if expr.type_args:
                    if not sig.type_params:
                        raise YadroError(
                            Diagnostic(
                                "Type arguments provided for non-generic trait method",
                                expr.line,
                                expr.column,
                            )
                        )
                    if len(expr.type_args) != len(sig.type_params):
                        raise YadroError(
                            Diagnostic(
                                "Incorrect number of type arguments",
                                expr.line,
                                expr.column,
                            )
                        )
                    concrete_args = [self._resolve_type(arg) for arg in expr.type_args]
                    self._enforce_where_bounds(
                        sig, concrete_args, expr.line, expr.column
                    )
                    bindings = dict(zip(sig.type_params, concrete_args))
                    param_types = [
                        self._apply_type_bindings(t, bindings) for t in sig.param_types
                    ]
                    return_type = self._apply_type_bindings(sig.return_type, bindings)
                else:
                    if sig.type_params:
                        raise YadroError(
                            Diagnostic(
                                "Explicit type arguments required for generic trait method call",
                                expr.line,
                                expr.column,
                            )
                        )
                    param_types = sig.param_types
                    return_type = sig.return_type
                expected_params = (
                    param_types[1:]
                    if trait.method_self.get(expr.name, False)
                    else param_types
                )
                if len(expr.args) != len(expected_params):
                    raise YadroError(
                        Diagnostic("Incorrect argument count", expr.line, expr.column)
                    )
                for arg, expected_type in zip(expr.args, expected_params):
                    arg_type = self._analyze_expr(arg, expected=expected_type)
                    self._ensure_assignable(
                        expected_type, arg_type, expr.line, expr.column
                    )
                self.expr_types[expr_id] = return_type
                return return_type
            if class_type.kind not in self.classes:
                raise YadroError(
                    Diagnostic(
                        "Method call requires class type", expr.line, expr.column
                    )
                )
            info = self.classes[class_type.kind]
            if expr.name not in info.methods:
                trait_match: Optional[tuple[str, FunctionSig, bool]] = None
                for trait_name, impl_types in self.impls.items():
                    if not any(t.kind == class_type.kind for t in impl_types):
                        continue
                    trait = self.traits[trait_name]
                    if expr.name not in trait.methods:
                        continue
                    has_self = trait.method_self.get(expr.name, False)
                    if trait_match is not None:
                        raise YadroError(
                            Diagnostic(
                                f"Ambiguous trait method '{expr.name}'",
                                expr.line,
                                expr.column,
                            )
                        )
                    trait_match = (trait_name, trait.methods[expr.name], has_self)
                if trait_match is None:
                    raise YadroError(
                        Diagnostic(
                            f"Unknown method '{expr.name}'", expr.line, expr.column
                        )
                    )
                trait_name, sig, has_self = trait_match
                if is_classref and has_self:
                    raise YadroError(
                        Diagnostic(
                            "Instance method requires object", expr.line, expr.column
                        )
                    )
                if expr.type_args:
                    if not sig.type_params:
                        raise YadroError(
                            Diagnostic(
                                "Type arguments provided for non-generic method",
                                expr.line,
                                expr.column,
                            )
                        )
                    if len(expr.type_args) != len(sig.type_params):
                        raise YadroError(
                            Diagnostic(
                                "Incorrect number of type arguments",
                                expr.line,
                                expr.column,
                            )
                        )
                    concrete_args = [self._resolve_type(arg) for arg in expr.type_args]
                    self._enforce_where_bounds(
                        sig, concrete_args, expr.line, expr.column
                    )
                    impl_base = self._mangle_trait_impl_name(
                        trait_name, class_type.kind, expr.name
                    )
                    specialized_name = self._mangle_generic_name(
                        impl_base, concrete_args
                    )
                    if specialized_name not in self.functions:
                        impl_def = self.impl_method_defs.get(
                            (trait_name, class_type.kind, expr.name)
                        )
                        if impl_def is None:
                            raise YadroError(
                                Diagnostic(
                                    f"Unknown method '{expr.name}'",
                                    expr.line,
                                    expr.column,
                                )
                            )
                        previous_class = self.current_class
                        self.current_class = self.classes[class_type.kind].typ
                        self._analyze_specialization(
                            impl_def, specialized_name, sig, concrete_args
                        )
                        self.current_class = previous_class
                    sig = self.functions[specialized_name]
                    self.trait_method_calls[expr_id] = (specialized_name, has_self)
                    self._require_effects(
                        self.function_effects.get(specialized_name, set()),
                        expr.line,
                        expr.column,
                    )
                else:
                    if sig.type_params:
                        raise YadroError(
                            Diagnostic(
                                "Explicit type arguments required for generic method call",
                                expr.line,
                                expr.column,
                            )
                        )
                    impl_name = self._mangle_trait_impl_name(
                        trait_name, class_type.kind, expr.name
                    )
                    sig = self.functions[impl_name]
                    self.trait_method_calls[expr_id] = (impl_name, has_self)
                    self._require_effects(
                        self.function_effects.get(impl_name, set()),
                        expr.line,
                        expr.column,
                    )
                expected_params = sig.param_types[1:] if has_self else sig.param_types
                if len(expr.args) != len(expected_params):
                    raise YadroError(
                        Diagnostic("Incorrect argument count", expr.line, expr.column)
                    )
                for arg, expected_type in zip(expr.args, expected_params):
                    arg_type = self._analyze_expr(arg, expected=expected_type)
                    self._ensure_assignable(
                        expected_type, arg_type, expr.line, expr.column
                    )
                self.expr_types[expr_id] = sig.return_type
                return sig.return_type
            method = info.methods[expr.name]
            if is_classref and not method.is_class:
                raise YadroError(
                    Diagnostic(
                        "Instance method requires object", expr.line, expr.column
                    )
                )
            if expr.type_args:
                if not method.sig.type_params:
                    raise YadroError(
                        Diagnostic(
                            "Type arguments provided for non-generic method",
                            expr.line,
                            expr.column,
                        )
                    )
                if len(expr.type_args) != len(method.sig.type_params):
                    raise YadroError(
                        Diagnostic(
                            "Incorrect number of type arguments", expr.line, expr.column
                        )
                    )
                concrete_args = [self._resolve_type(arg) for arg in expr.type_args]
                self._enforce_where_bounds(
                    method.sig, concrete_args, expr.line, expr.column
                )
                specialized_name = self._mangle_generic_name(
                    method.sig.name, concrete_args
                )
                if specialized_name not in self.functions:
                    method_def = self.method_defs.get((class_type.kind, expr.name))
                    if method_def is None:
                        raise YadroError(
                            Diagnostic(
                                f"Unknown method '{expr.name}'", expr.line, expr.column
                            )
                        )
                    previous_class = self.current_class
                    self.current_class = self.classes[class_type.kind].typ
                    self._analyze_specialization(
                        method_def, specialized_name, method.sig, concrete_args
                    )
                    self.current_class = previous_class
                sig = self.functions[specialized_name]
                self.call_specializations[expr_id] = specialized_name
                expected_params = (
                    sig.param_types if method.is_class else sig.param_types[1:]
                )
                return_type = sig.return_type
                self._require_effects(
                    self.function_effects.get(specialized_name, set()),
                    expr.line,
                    expr.column,
                )
            else:
                if method.sig.type_params:
                    raise YadroError(
                        Diagnostic(
                            "Explicit type arguments required for generic method call",
                            expr.line,
                            expr.column,
                        )
                    )
                expected_params = (
                    method.sig.param_types[1:]
                    if not method.is_class
                    else method.sig.param_types
                )
                return_type = method.sig.return_type
                impl_name = self._mangle_method_name(class_type.kind, expr.name)
                self._require_effects(
                    self.function_effects.get(impl_name, set()), expr.line, expr.column
                )
            if len(expr.args) != len(expected_params):
                raise YadroError(
                    Diagnostic("Incorrect argument count", expr.line, expr.column)
                )
            for arg, expected_type in zip(expr.args, expected_params):
                arg_type = self._analyze_expr(arg, expected=expected_type)
                self._ensure_assignable(expected_type, arg_type, expr.line, expr.column)
            self.expr_types[expr_id] = return_type
            return return_type
        if isinstance(expr, ast.NewExpr):
            target_type = self._resolve_type(expr.type_expr)
            if target_type.kind not in self.classes:
                raise YadroError(
                    Diagnostic("new requires class type", expr.line, expr.column)
                )
            info = self.classes[target_type.kind]
            if len(expr.args) > len(info.field_order):
                raise YadroError(
                    Diagnostic(
                        "Constructor argument count must match fields",
                        expr.line,
                        expr.column,
                    )
                )
            for arg, field_name in zip(expr.args, info.field_order):
                field_type = info.fields[field_name]
                arg_type = self._analyze_expr(arg, expected=field_type)
                self._ensure_assignable(field_type, arg_type, expr.line, expr.column)
            self.expr_types[expr_id] = target_type
            return target_type
        if isinstance(expr, ast.Call):
            # YUP 26.1.5 §2.1 – spec old(e): "value of expression at function entry"
            # old() is only meaningful inside spec ensures blocks; it type-checks to
            # the same type as its argument and is erased before codegen (zero-cost).
            if expr.callee == "old":
                if not self.in_spec:
                    raise YadroError(
                        Diagnostic(
                            "'old' is only valid inside spec ensures/invariant blocks",
                            expr.line,
                            expr.column,
                        )
                    )
                if len(expr.args) != 1 or expr.type_args:
                    raise YadroError(
                        Diagnostic(
                            "'old' requires exactly one argument",
                            expr.line,
                            expr.column,
                        )
                    )
                inner_type = self._analyze_expr(expr.args[0])
                self.expr_types[expr_id] = inner_type
                return inner_type
            if expr.callee == "copy":
                if len(expr.type_args) != 0 or len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic("copy requires one argument", expr.line, expr.column)
                    )
                value_type = self._analyze_expr(expr.args[0], mode="borrow")
                if value_type.kind == "ref":
                    value_type = value_type._elem
                if (
                    value_type.kind in self.classes
                    and "linear" in self.classes[value_type.kind].modifiers
                ):
                    raise YadroError(
                        Diagnostic(
                            "copy is not allowed for linear class",
                            expr.line,
                            expr.column,
                        )
                    )
                self.copy_calls.add(expr_id)
                self.expr_types[expr_id] = value_type
                return value_type
            if expr.callee in {"Ok", "Err", "Some", "None"}:
                if expected is None:
                    raise YadroError(
                        Diagnostic(
                            "Expected type required for constructor",
                            expr.line,
                            expr.column,
                        )
                    )
                return self._analyze_constructor(expr, expected)
            if expr.callee == "gc":
                if len(expr.type_args) != 1 or len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic(
                            "gc requires one type argument and one value",
                            expr.line,
                            expr.column,
                        )
                    )
                element = self._resolve_type(expr.type_args[0])
                value_type = self._analyze_expr(expr.args[0], expected=element)
                self._ensure_assignable(element, value_type, expr.line, expr.column)
                gc_type = Type("gc", element=element)
                self.expr_types[expr_id] = gc_type
                return gc_type
            if expr.callee == "gc_weak":
                if len(expr.type_args) != 1 or len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic(
                            "gc_weak requires one type argument and one value",
                            expr.line,
                            expr.column,
                        )
                    )
                element = self._resolve_type(expr.type_args[0])
                expected_gc = Type("gc", element=element)
                value_type = self._analyze_expr(expr.args[0], expected=expected_gc)
                self._ensure_assignable(expected_gc, value_type, expr.line, expr.column)
                weak_type = Type("gc_weak", element=element)
                self.expr_types[expr_id] = weak_type
                return weak_type
            if expr.callee in self.classes:
                class_type = self.classes[expr.callee].typ
                info = self.classes[expr.callee]
                if len(expr.args) > len(info.field_order):
                    raise YadroError(
                        Diagnostic(
                            "Constructor argument count must match fields",
                            expr.line,
                            expr.column,
                        )
                    )
                for arg, field_name in zip(expr.args, info.field_order):
                    field_type = info.fields[field_name]
                    arg_type = self._analyze_expr(arg, expected=field_type)
                    self._ensure_assignable(
                        field_type, arg_type, expr.line, expr.column
                    )
                self.expr_types[expr_id] = class_type
                return class_type
            if expr.callee not in self.functions:
                raise YadroError(
                    Diagnostic(
                        f"Unknown function '{expr.callee}'", expr.line, expr.column
                    )
                )
            sig = self.functions[expr.callee]
            if sig.type_params:
                if not expr.type_args:
                    raise YadroError(
                        Diagnostic(
                            "Explicit type arguments required for generic call",
                            expr.line,
                            expr.column,
                        )
                    )
                if len(expr.type_args) != len(sig.type_params):
                    raise YadroError(
                        Diagnostic(
                            "Incorrect number of type arguments", expr.line, expr.column
                        )
                    )
                concrete_args = [self._resolve_type(arg) for arg in expr.type_args]
                self._enforce_where_bounds(sig, concrete_args, expr.line, expr.column)
                specialized_name = self._mangle_generic_name(expr.callee, concrete_args)
                if specialized_name not in self.functions:
                    func_def = self.function_defs.get(expr.callee)
                    if func_def is None:
                        raise YadroError(
                            Diagnostic(
                                f"Unknown function '{expr.callee}'",
                                expr.line,
                                expr.column,
                            )
                        )
                    self._analyze_specialization(
                        func_def, specialized_name, sig, concrete_args
                    )
                expr.callee = specialized_name
                sig = self.functions[specialized_name]
            self._require_effects(
                self.function_effects.get(expr.callee, set()), expr.line, expr.column
            )
            if len(expr.args) != len(sig.param_types):
                raise YadroError(
                    Diagnostic("Incorrect argument count", expr.line, expr.column)
                )
            for arg, expected_type in zip(expr.args, sig.param_types):
                arg_type = self._analyze_expr(arg, expected=expected_type)
                self._ensure_assignable(expected_type, arg_type, expr.line, expr.column)
            self.expr_types[expr_id] = sig.return_type
            return sig.return_type
        if isinstance(expr, ast.ArrayLiteral):
            if not expr.items:
                raise YadroError(
                    Diagnostic(
                        "Cannot infer type from empty array literal",
                        expr.line,
                        expr.column,
                    )
                )
            if expected is not None and expected.kind == "vector":
                if expected.size is not None and expected.size != len(expr.items):
                    raise YadroError(
                        Diagnostic(
                            "Vector literal size does not match type",
                            expr.line,
                            expr.column,
                        )
                    )
                if expected.element is None:
                    raise YadroError(
                        Diagnostic(
                            "Vector requires element type", expr.line, expr.column
                        )
                    )
                for item in expr.items:
                    item_type = self._analyze_expr(item, expected=expected.element)
                    self._ensure_assignable(
                        expected.element, item_type, expr.line, expr.column
                    )
                vector_type = Type(
                    "vector", element=expected.element, size=len(expr.items)
                )
                self.expr_types[expr_id] = vector_type
                return vector_type
            item_types = [self._analyze_expr(item) for item in expr.items]
            element_type = item_types[0]
            if all(is_numeric(t) for t in item_types):
                element_type = FLOAT if any(t == FLOAT for t in item_types) else INT
            else:
                for t in item_types[1:]:
                    if t != element_type:
                        raise YadroError(
                            Diagnostic(
                                "Array literal elements must have matching types",
                                expr.line,
                                expr.column,
                            )
                        )
            array_type = Type("array", element=element_type, size=len(expr.items))
            self.expr_types[expr_id] = array_type
            return array_type
        if isinstance(expr, ast.DictLiteral):
            key_types = [self._analyze_expr(key) for key, _ in expr.items]
            value_types = [self._analyze_expr(value) for _, value in expr.items]
            key_type = key_types[0]
            value_type = value_types[0]
            if all(is_numeric(t) for t in key_types):
                key_type = FLOAT if any(t == FLOAT for t in key_types) else INT
            else:
                for t in key_types[1:]:
                    if t != key_type:
                        raise YadroError(
                            Diagnostic(
                                "Dict literal keys must have matching types",
                                expr.line,
                                expr.column,
                            )
                        )
            if all(is_numeric(t) for t in value_types):
                value_type = FLOAT if any(t == FLOAT for t in value_types) else INT
            else:
                for t in value_types[1:]:
                    if t != value_type:
                        raise YadroError(
                            Diagnostic(
                                "Dict literal values must have matching types",
                                expr.line,
                                expr.column,
                            )
                        )
            dict_type = Type("dict", type_args=[key_type, value_type])
            self.expr_types[expr_id] = dict_type
            return dict_type
        if isinstance(expr, ast.SetLiteral):
            item_types = [self._analyze_expr(item) for item in expr.items]
            element_type = item_types[0]
            if all(is_numeric(t) for t in item_types):
                element_type = FLOAT if any(t == FLOAT for t in item_types) else INT
            else:
                for t in item_types[1:]:
                    if t != element_type:
                        raise YadroError(
                            Diagnostic(
                                "Set literal items must have matching types",
                                expr.line,
                                expr.column,
                            )
                        )
            set_type = Type("set", type_args=[element_type])
            self.expr_types[expr_id] = set_type
            return set_type
        if isinstance(expr, ast.IndexExpr):
            element_type = self._analyze_index(expr)
            self.expr_types[expr_id] = element_type
            return element_type
        raise YadroError(Diagnostic("Unsupported expression", expr.line, expr.column))

    def _resolve_type(self, type_expr: ast.TypeExpr) -> Type:
        if isinstance(type_expr, ast.TypeName):
            if type_expr.name == "self" and self.current_class is not None:
                return self.current_class
            if type_expr.name == "self" and self.current_trait is not None:
                return Type("var", var_name="Self")
            if type_expr.name in self.type_bindings:
                return self.type_bindings[type_expr.name]
            if type_expr.name in self.spec_types:
                spec = self.spec_types[type_expr.name]
                if spec.type_params:
                    raise YadroError(
                        Diagnostic(
                            f"Spec type '{spec.name}' requires type arguments",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                return self._resolve_type(spec.base_type)
            if type_expr.name in BUILTINS:
                return BUILTINS[type_expr.name]
            if type_expr.name in self.traits:
                info = self.traits[type_expr.name]
                if info.is_protocol:
                    raise YadroError(
                        Diagnostic(
                            f"Protocol '{type_expr.name}' cannot be used as trait object",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                if type_expr.name in self.traits_with_generic_methods:
                    raise YadroError(
                        Diagnostic(
                            f"Trait '{type_expr.name}' with generic methods cannot be used as trait object",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                return Type("trait", var_name=type_expr.name)
            if type_expr.name in self.classes:
                return self.classes[type_expr.name].typ
            if type_expr.name in self.type_params:
                return Type("var", var_name=type_expr.name)
            raise YadroError(
                Diagnostic(
                    f"Unknown type '{type_expr.name}'", type_expr.line, type_expr.column
                )
            )
        if isinstance(type_expr, ast.TypeArray):
            element = self._resolve_type(type_expr.element)
            return Type("array", element=element, size=type_expr.size)
        if isinstance(type_expr, ast.TypeDArray):
            element = self._resolve_type(type_expr.element)
            return Type("darray", element=element)
        if isinstance(type_expr, ast.TypeRef):
            element = self._resolve_type(type_expr.element)
            return Type("ref", element=element, mutable=type_expr.mutable)
        if isinstance(type_expr, ast.TypeGc):
            element = self._resolve_type(type_expr.element)
            return Type("gc", element=element)
        if isinstance(type_expr, ast.TypeGcWeak):
            element = self._resolve_type(type_expr.element)
            return Type("gc_weak", element=element)
        if isinstance(type_expr, ast.TypeConstInt):
            return Type("constint", size=type_expr.value)
        if isinstance(type_expr, ast.TypeApply):
            if type_expr.name in self.spec_types:
                spec = self.spec_types[type_expr.name]
                if len(type_expr.args) != len(spec.type_params):
                    raise YadroError(
                        Diagnostic(
                            f"Spec type '{spec.name}' argument count mismatch",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                args = [self._resolve_type(arg) for arg in type_expr.args]
                bindings = dict(zip(spec.type_params, args))
                previous_bindings = self.type_bindings
                self.type_bindings = {**previous_bindings, **bindings}
                resolved = self._resolve_type(spec.base_type)
                self.type_bindings = previous_bindings
                return resolved
            args = [self._resolve_type(arg) for arg in type_expr.args]
            if type_expr.name in {"Result", "Option"}:
                return Type(type_expr.name, type_args=args)
            if type_expr.name == "vector":
                if len(args) != 2 or args[1].kind != "constint":
                    raise YadroError(
                        Diagnostic(
                            "vector requires element type and size",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                if args[0] not in {INT, FLOAT, CHAR, BOOL}:
                    raise YadroError(
                        Diagnostic(
                            "vector element type must be numeric or bool",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                return Type("vector", element=args[0], size=args[1].size)
            if type_expr.name == "dict":
                if len(args) != 2:
                    raise YadroError(
                        Diagnostic(
                            "dict requires key and value types",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                return Type("dict", type_args=args)
            if type_expr.name == "set":
                if len(args) != 1:
                    raise YadroError(
                        Diagnostic(
                            "set requires element type",
                            type_expr.line,
                            type_expr.column,
                        )
                    )
                return Type("set", type_args=args)
            if type_expr.name in self.classes:
                return Type(type_expr.name, type_args=args)
            return Type(type_expr.name, type_args=args)
        raise YadroError(
            Diagnostic("Unknown type expression", type_expr.line, type_expr.column)
        )

    def _apply_type_bindings(self, typ: Type, bindings: Dict[str, Type]) -> Type:
        if typ.kind == "var":
            return bindings.get(typ.var_name or "", typ)
        if typ.kind == "ref":
            return Type(
                "ref",
                element=self._apply_type_bindings(typ._elem, bindings),
                mutable=typ.mutable,
                region=typ.region,
            )
        if typ.kind == "array":
            return Type(
                "array",
                element=self._apply_type_bindings(typ._elem, bindings),
                size=typ.size,
            )
        if typ.kind == "darray":
            return Type(
                "darray", element=self._apply_type_bindings(typ._elem, bindings)
            )
        if typ.kind == "gc":
            return Type("gc", element=self._apply_type_bindings(typ._elem, bindings))
        if typ.kind == "gc_weak":
            return Type(
                "gc_weak", element=self._apply_type_bindings(typ._elem, bindings)
            )
        if typ.kind == "vector":
            return Type(
                "vector",
                element=self._apply_type_bindings(typ._elem, bindings),
                size=typ.size,
            )
        if typ.type_args:
            args = [self._apply_type_bindings(arg, bindings) for arg in typ.type_args]
            return Type(
                typ.kind,
                element=typ.element,
                size=typ.size,
                mutable=typ.mutable,
                type_args=args,
                var_name=typ.var_name,
            )
        return typ

    def _validate_function_modifiers(
        self,
        modifiers: List[str],
        modifier_args: dict,
        line: int,
        column: int,
        context: str,
    ) -> None:
        allowed = {"async", "thread", "const", "ffi", "class"}
        seen = set()
        for mod in modifiers:
            if mod not in allowed:
                raise YadroError(
                    Diagnostic(f"Unknown function modifier '{mod}'", line, column)
                )
            if mod in seen:
                raise YadroError(
                    Diagnostic(f"Duplicate function modifier '{mod}'", line, column)
                )
            seen.add(mod)
        if "async" in seen and "thread" in seen:
            raise YadroError(
                Diagnostic("Function cannot be both async and thread", line, column)
            )
        if "class" in seen and context != "method":
            raise YadroError(
                Diagnostic("class modifier is only valid on methods", line, column)
            )
        if "ffi" in seen and context != "function":
            raise YadroError(
                Diagnostic("ffi modifier is only valid on functions", line, column)
            )
        if "ffi" in seen and ("async" in seen or "thread" in seen or "const" in seen):
            raise YadroError(
                Diagnostic(
                    "ffi modifier cannot be combined with async/thread/const",
                    line,
                    column,
                )
            )
        if "ffi" in seen:
            args = modifier_args.get("ffi", {})
            positional = args.get("$", [])
            if not positional or not isinstance(positional[0], str):
                raise YadroError(
                    Diagnostic("ffi modifier requires library name", line, column)
                )
            abi = args.get("abi")
            if abi is None and len(positional) > 1 and isinstance(positional[1], str):
                abi = positional[1]
            if abi is not None:
                if not isinstance(abi, str):
                    raise YadroError(
                        Diagnostic("ffi abi must be a string", line, column)
                    )
                if abi not in self.allowed_ffi_abis:
                    raise YadroError(
                        Diagnostic(f"Unknown ffi abi '{abi}'", line, column)
                    )

    def _validate_class_modifiers(
        self, modifiers: List[str], line: int, column: int
    ) -> None:
        allowed = {"linear", "actor"}
        seen = set()
        for mod in modifiers:
            if mod not in allowed:
                raise YadroError(
                    Diagnostic(f"Unknown class modifier '{mod}'", line, column)
                )
            if mod in seen:
                raise YadroError(
                    Diagnostic(f"Duplicate class modifier '{mod}'", line, column)
                )
            seen.add(mod)
        if "linear" in seen and "actor" in seen:
            raise YadroError(
                Diagnostic("Class cannot be both linear and actor", line, column)
            )

    def _validate_class_behavior(self, cls: ast.ClassDef) -> None:
        info = self.classes[cls.name]
        if "linear" in info.modifiers:
            if "copy" in info.methods:
                raise YadroError(
                    Diagnostic(
                        "linear class cannot define copy method", cls.line, cls.column
                    )
                )
        if "drop" in info.methods:
            drop = info.methods["drop"]
            if drop.is_class:
                raise YadroError(
                    Diagnostic("drop must be an instance method", cls.line, cls.column)
                )
            params = drop.sig.param_types
            if len(params) != 1:
                raise YadroError(
                    Diagnostic(
                        "drop must take only self parameter", cls.line, cls.column
                    )
                )
            first = params[0]
            if first.kind != "ref" or not first.mutable or first.element != info.typ:
                raise YadroError(
                    Diagnostic(
                        "drop requires &mut self parameter", cls.line, cls.column
                    )
                )
            if drop.sig.return_type != UNIT:
                raise YadroError(
                    Diagnostic("drop must return Unit", cls.line, cls.column)
                )
        if "actor" in info.modifiers:
            receive = info.methods.get("receive")
            if receive is None or receive.is_class:
                raise YadroError(
                    Diagnostic(
                        "actor class requires instance method 'receive'",
                        cls.line,
                        cls.column,
                    )
                )
            params = receive.sig.param_types
            if not params:
                raise YadroError(
                    Diagnostic(
                        "actor receive method requires self parameter",
                        cls.line,
                        cls.column,
                    )
                )
            first = params[0]
            if first.kind != "ref" or not first.mutable or first.element != info.typ:
                raise YadroError(
                    Diagnostic(
                        "actor receive method requires &mut self parameter",
                        cls.line,
                        cls.column,
                    )
                )

    def _validate_attributes(
        self, attributes: List[ast.Attribute], line: int, column: int
    ) -> None:
        seen = set()
        for attr in attributes:
            if attr.name in seen:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate attribute '{attr.name}'", attr.line, attr.column
                    )
                )
            seen.add(attr.name)
            if attr.name == "effect":
                effects = self._attribute_effects(attr)
                self._validate_effects(effects, attr.line, attr.column)

    def _validate_effects(self, effects: List[str], line: int, column: int) -> None:
        seen = set()
        for effect in effects:
            if effect not in self.allowed_effects:
                raise YadroError(Diagnostic(f"Unknown effect '{effect}'", line, column))
            if effect in seen:
                raise YadroError(
                    Diagnostic(f"Duplicate effect '{effect}'", line, column)
                )
            seen.add(effect)

    def _validate_where_bounds_decl(
        self,
        where_bounds: List[tuple[str, str]],
        type_params: List[str],
        line: int,
        column: int,
    ) -> None:
        for param, trait in where_bounds:
            if param not in type_params:
                raise YadroError(
                    Diagnostic(
                        f"Unknown type parameter '{param}' in where clause",
                        line,
                        column,
                    )
                )
            if trait not in self.traits:
                raise YadroError(
                    Diagnostic(f"Unknown trait '{trait}' in where clause", line, column)
                )

    def _enforce_where_bounds(
        self, sig: FunctionSig, type_args: List[Type], line: int, column: int
    ) -> None:
        if not sig.where_bounds:
            return
        bindings = dict(zip(sig.type_params, type_args))
        for param, trait_name in sig.where_bounds:
            bound_type = bindings.get(param)
            if bound_type is None:
                raise YadroError(
                    Diagnostic(f"Missing type argument for '{param}'", line, column)
                )
            if trait_name not in self.traits:
                raise YadroError(
                    Diagnostic(
                        f"Unknown trait '{trait_name}' in where clause", line, column
                    )
                )
            if not self._satisfies_trait_bound(bound_type, trait_name):
                raise YadroError(
                    Diagnostic(
                        f"Type '{bound_type.name}' does not satisfy trait '{trait_name}'",
                        line,
                        column,
                    )
                )

    def _satisfies_trait_bound(self, typ: Type, trait_name: str) -> bool:
        if typ.kind == "trait":
            return typ.var_name == trait_name
        if typ.kind == "ref":
            return typ._elem.kind in self.classes and self._has_trait_impl(
                trait_name, typ._elem.kind
            )
        if typ.kind in self.classes:
            return self._has_trait_impl(trait_name, typ.kind)
        return False

    def _validate_const_body(self, body: List[ast.Stmt]) -> None:
        for stmt in body:
            if isinstance(stmt, ast.VarDecl):
                self._validate_const_expr(stmt.value)
            elif isinstance(stmt, ast.Assign):
                self._validate_const_expr(stmt.value)
            elif isinstance(stmt, ast.AssignMember):
                self._validate_const_expr(stmt.target)
                self._validate_const_expr(stmt.value)
            elif isinstance(stmt, ast.AssignIndex):
                self._validate_const_expr(stmt.target)
                self._validate_const_expr(stmt.index)
                self._validate_const_expr(stmt.value)
            elif isinstance(stmt, ast.IfStmt):
                self._validate_const_expr(stmt.condition)
                self._validate_const_body(stmt.then_body)
                for cond, block in stmt.elifs:
                    self._validate_const_expr(cond)
                    self._validate_const_body(block)
                self._validate_const_body(stmt.else_body)
            elif isinstance(stmt, ast.WhileStmt):
                self._validate_const_expr(stmt.condition)
                self._validate_const_body(stmt.body)
            elif isinstance(stmt, ast.ForStmt):
                self._validate_const_expr(stmt.start)
                self._validate_const_expr(stmt.end)
                if stmt.step is not None:
                    self._validate_const_expr(stmt.step)
                self._validate_const_body(stmt.body)
            elif isinstance(stmt, ast.RepeatStmt):
                self._validate_const_body(stmt.body)
                self._validate_const_expr(stmt.condition)
            elif isinstance(stmt, ast.SwitchStmt):
                self._validate_const_expr(stmt.expr)
                for case in stmt.cases:
                    self._validate_const_body(case.body)
                self._validate_const_body(stmt.default_body)
            elif isinstance(stmt, ast.ReturnStmt):
                if stmt.value is not None:
                    self._validate_const_expr(stmt.value)
            elif isinstance(stmt, ast.ExprStmt):
                self._validate_const_expr(stmt.expr)
            elif isinstance(stmt, (ast.BreakStmt, ast.ContinueStmt)):
                continue
            elif isinstance(stmt, ast.ArenaStmt):
                raise YadroError(
                    Diagnostic(
                        "arena not allowed in const function", stmt.line, stmt.column
                    )
                )
            elif isinstance(stmt, ast.DelStmt):
                raise YadroError(
                    Diagnostic(
                        "del not allowed in const function", stmt.line, stmt.column
                    )
                )
            elif isinstance(stmt, (ast.UnsafeBlock, ast.InlineAsm)):
                raise YadroError(
                    Diagnostic(
                        "unsafe and asm not allowed in const function",
                        stmt.line,
                        stmt.column,
                    )
                )
            else:
                raise YadroError(
                    Diagnostic(
                        "Unsupported statement in const function",
                        stmt.line,
                        stmt.column,
                    )
                )

    def _validate_const_expr(self, expr: ast.Expr) -> None:
        if isinstance(
            expr,
            (
                ast.IntLiteral,
                ast.FloatLiteral,
                ast.BoolLiteral,
                ast.StringLiteral,
                ast.CharLiteral,
                ast.VarRef,
            ),
        ):
            return
        if isinstance(expr, ast.UnaryOp):
            self._validate_const_expr(expr.operand)
            return
        if isinstance(expr, ast.BinaryOp):
            self._validate_const_expr(expr.left)
            self._validate_const_expr(expr.right)
            return
        if isinstance(expr, ast.ArrayLiteral):
            for item in expr.items:
                self._validate_const_expr(item)
            return
        if isinstance(expr, ast.IndexExpr):
            self._validate_const_expr(expr.target)
            self._validate_const_expr(expr.index)
            return
        if isinstance(expr, ast.MemberAccess):
            self._validate_const_expr(expr.target)
            return
        if isinstance(expr, ast.TryExpr):
            self._validate_const_expr(expr.expr)
            return
        if isinstance(expr, ast.Call):
            if expr.callee in self.const_functions:
                for arg in expr.args:
                    self._validate_const_expr(arg)
                return
            raise YadroError(
                Diagnostic(
                    "Non-const function call in const context", expr.line, expr.column
                )
            )

    def _eval_const_expr(  # noqa: C901
        self, expr: ast.Expr, env: Optional[Dict[str, object]] = None
    ) -> object:
        if isinstance(expr, ast.IntLiteral):
            return expr.value
        if isinstance(expr, ast.FloatLiteral):
            return expr.value
        if isinstance(expr, ast.BoolLiteral):
            return expr.value
        if isinstance(expr, ast.StringLiteral):
            return expr.value
        if isinstance(expr, ast.CharLiteral):
            return expr.value
        if isinstance(expr, ast.VarRef):
            if env is not None and expr.name in env:
                return env[expr.name]
            return self._lookup_const_value(expr.name, expr.line, expr.column)
        if isinstance(expr, ast.UnaryOp):
            value = self._eval_const_expr(expr.operand, env)
            if expr.op == "-":
                return -value  # type: ignore[operator]
            if expr.op == "+":
                return +value  # type: ignore[operator]
            if expr.op == "!":
                return not value
            if expr.op == "~":
                return ~value  # type: ignore[operator]
            raise YadroError(
                Diagnostic("Unsupported const unary operator", expr.line, expr.column)
            )
        if isinstance(expr, ast.BinaryOp):
            left = self._eval_const_expr(expr.left, env)
            right = self._eval_const_expr(expr.right, env)
            op = expr.op
            if op == "+":
                return left + right  # type: ignore[operator]
            if op == "-":
                return left - right  # type: ignore[operator]
            if op == "*":
                return left * right  # type: ignore[operator]
            if op == "/":
                return left / right  # type: ignore[operator]
            if op == "%":
                return left % right  # type: ignore[operator]
            if op == "<<":
                return left << right  # type: ignore[operator]
            if op == ">>":
                return left >> right  # type: ignore[operator]
            if op == "&":
                return left & right  # type: ignore[operator]
            if op == "|":
                return left | right  # type: ignore[operator]
            if op == "^":
                return left ^ right  # type: ignore[operator]
            if op == "==":
                return left == right
            if op == "!=":
                return left != right
            if op == "<":
                return left < right  # type: ignore[operator]
            if op == "<=":
                return left <= right  # type: ignore[operator]
            if op == ">":
                return left > right  # type: ignore[operator]
            if op == ">=":
                return left >= right  # type: ignore[operator]
            if op == "and":
                return left and right
            if op == "or":
                return left or right
            if op == "xor":
                return bool(left) ^ bool(right)
            raise YadroError(
                Diagnostic("Unsupported const binary operator", expr.line, expr.column)
            )
        if isinstance(expr, ast.ArrayLiteral):
            return [self._eval_const_expr(item, env) for item in expr.items]
        if isinstance(expr, ast.IndexExpr):
            target = self._eval_const_expr(expr.target, env)
            index = self._eval_const_expr(expr.index, env)
            return target[index]  # type: ignore[index]
        if isinstance(expr, ast.MemberAccess):
            target = self._eval_const_expr(expr.target, env)
            return target[expr.name]  # type: ignore[index]
        if isinstance(expr, ast.TryExpr):
            return self._eval_const_expr(expr.expr, env)
        if isinstance(expr, ast.Call):
            if expr.callee not in self.const_functions:
                raise YadroError(
                    Diagnostic(
                        "Non-const function call in const context",
                        expr.line,
                        expr.column,
                    )
                )
            func = self.function_defs.get(expr.callee)
            if func is None:
                raise YadroError(
                    Diagnostic(
                        f"Unknown const function '{expr.callee}'",
                        expr.line,
                        expr.column,
                    )
                )
            args = [self._eval_const_expr(arg, env) for arg in expr.args]
            return self._eval_const_function(func, args, expr.line, expr.column)
        raise YadroError(
            Diagnostic("Unsupported const expression", expr.line, expr.column)
        )

    def _eval_const_function(
        self, func: ast.FunctionDef, args: List[object], line: int, column: int
    ) -> object:
        if len(args) != len(func.params):
            raise YadroError(Diagnostic("Const function arity mismatch", line, column))
        env: Dict[str, object] = {}
        for param, value in zip(func.params, args):
            env[param.name] = value
        try:
            self._eval_const_block(func.body, env)
        except _ConstReturn as ret:
            return ret.value
        raise YadroError(Diagnostic("Missing return in const function", line, column))

    def _eval_const_block(self, body: List[ast.Stmt], env: Dict[str, object]) -> None:
        for stmt in body:
            self._eval_const_stmt(stmt, env)

    def _eval_const_stmt(self, stmt: ast.Stmt, env: Dict[str, object]) -> None:
        if isinstance(stmt, ast.VarDecl):
            env[stmt.name] = self._eval_const_expr(stmt.value, env)
            return
        if isinstance(stmt, ast.ConstDecl):
            env[stmt.name] = self._eval_const_expr(stmt.value, env)
            return
        if isinstance(stmt, ast.Assign):
            env[stmt.name] = self._eval_const_expr(stmt.value, env)
            return
        if isinstance(stmt, ast.AssignIndex):
            target = self._eval_const_expr(stmt.target, env)
            index = self._eval_const_expr(stmt.index, env)
            target[index] = self._eval_const_expr(stmt.value, env)  # type: ignore[index]
            return
        if isinstance(stmt, ast.AssignMember):
            target = self._eval_const_expr(stmt.target, env)
            target[stmt.name] = self._eval_const_expr(stmt.value, env)  # type: ignore[index]
            return
        if isinstance(stmt, ast.IfStmt):
            if self._eval_const_expr(stmt.condition, env):
                self._eval_const_block(stmt.then_body, env)
                return
            for cond, block in stmt.elifs:
                if self._eval_const_expr(cond, env):
                    self._eval_const_block(block, env)
                    return
            self._eval_const_block(stmt.else_body, env)
            return
        if isinstance(stmt, ast.WhileStmt):
            iterations = 0
            while self._eval_const_expr(stmt.condition, env):
                self._eval_const_block(stmt.body, env)
                iterations += 1
                if iterations > 10000:
                    raise YadroError(
                        Diagnostic(
                            "Const while loop exceeds iteration limit",
                            stmt.line,
                            stmt.column,
                        )
                    )
            return
        if isinstance(stmt, ast.ForStmt):
            start = self._eval_const_expr(stmt.start, env)
            end = self._eval_const_expr(stmt.end, env)
            step = self._eval_const_expr(stmt.step, env) if stmt.step is not None else 1
            iterations = 0
            value = start
            while (value < end and step > 0) or (value > end and step < 0):  # type: ignore[operator]
                env[stmt.name] = value
                self._eval_const_block(stmt.body, env)
                value += step  # type: ignore[operator]
                iterations += 1
                if iterations > 10000:
                    raise YadroError(
                        Diagnostic(
                            "Const for loop exceeds iteration limit",
                            stmt.line,
                            stmt.column,
                        )
                    )
            return
        if isinstance(stmt, ast.RepeatStmt):
            iterations = 0
            while True:
                self._eval_const_block(stmt.body, env)
                if self._eval_const_expr(stmt.condition, env):
                    break
                iterations += 1
                if iterations > 10000:
                    raise YadroError(
                        Diagnostic(
                            "Const repeat loop exceeds iteration limit",
                            stmt.line,
                            stmt.column,
                        )
                    )
            return
        if isinstance(stmt, ast.SwitchStmt):
            value = self._eval_const_expr(stmt.expr, env)
            matched = False
            for case in stmt.cases:
                if isinstance(case.value, ast.PatternLiteral):
                    if self._eval_const_expr(case.value.value, env) == value:
                        self._eval_const_block(case.body, env)
                        matched = True
                        break
            if not matched:
                self._eval_const_block(stmt.default_body, env)
            return
        if isinstance(stmt, ast.ReturnStmt):
            if stmt.value is None:
                raise _ConstReturn(None)
            raise _ConstReturn(self._eval_const_expr(stmt.value, env))
        if isinstance(stmt, ast.ExprStmt):
            self._eval_const_expr(stmt.expr, env)
            return
        if isinstance(stmt, (ast.BreakStmt, ast.ContinueStmt)):
            return
        raise YadroError(
            Diagnostic(
                "Unsupported statement in const evaluation", stmt.line, stmt.column
            )
        )

    def _lookup_const_value(self, name: str, line: int, column: int) -> object:
        for scope in reversed(self.const_values):
            if name in scope:
                return scope[name]
        raise YadroError(Diagnostic(f"Unknown const '{name}'", line, column))

    def _const_literal_expr(self, value: object, line: int, column: int) -> ast.Expr:
        if isinstance(value, bool):
            return ast.BoolLiteral(value, line, column)
        if isinstance(value, int):
            return ast.IntLiteral(value, line, column)
        if isinstance(value, float):
            return ast.FloatLiteral(value, line, column)
        if isinstance(value, str):
            if len(value) == 1:
                return ast.CharLiteral(value, line, column)
            return ast.StringLiteral(value, line, column)
        if isinstance(value, list):
            items = [self._const_literal_expr(item, line, column) for item in value]
            return ast.ArrayLiteral(items, line, column)
        raise YadroError(Diagnostic("Unsupported const literal type", line, column))

    def _analyze_lvalue(self, expr: ast.Expr, line: int, column: int) -> Type:
        if isinstance(expr, ast.VarRef):
            return self._lookup_var(expr.name, line, column)
        if isinstance(expr, ast.MemberAccess):
            target_type = self._analyze_expr(expr.target, mode="borrow")
            if target_type.kind == "ref":
                target_type = target_type._elem
            if target_type.kind not in self.classes:
                raise YadroError(
                    Diagnostic("Member assignment requires class type", line, column)
                )
            info = self.classes[target_type.kind]
            if expr.name not in info.fields:
                raise YadroError(
                    Diagnostic(f"Unknown field '{expr.name}'", line, column)
                )
            return info.fields[expr.name]
        if isinstance(expr, ast.IndexExpr):
            target_type = self._analyze_expr(expr.target)
            if target_type.kind not in {"array", "darray"}:
                raise YadroError(
                    Diagnostic(
                        "Index assignment requires array or darray", line, column
                    )
                )
            index_type = self._analyze_expr(expr.index)
            self._ensure_assignable(INT, index_type, line, column)
            return target_type._elem
        raise YadroError(Diagnostic("Invalid assignment target", line, column))

    def _compound_result_type(
        self, op: str, left: Type, right: Type, line: int, column: int
    ) -> Type:
        if op in {"+", "-", "*", "/", "%"}:
            if is_numeric(left) and is_numeric(right):
                return FLOAT if (left == FLOAT or right == FLOAT) else INT
            raise YadroError(
                Diagnostic(
                    "Arithmetic operators require numeric operands", line, column
                )
            )
        if op in {"|", "&", "^"}:
            if left in (INT, CHAR) and right in (INT, CHAR):
                return INT
            raise YadroError(
                Diagnostic(
                    "Bitwise operators require int or char operands", line, column
                )
            )
        if op in {"<<", ">>"}:
            if left in (INT, CHAR) and right == INT:
                return INT
            raise YadroError(
                Diagnostic("Shift operators require (int|char) << int", line, column)
            )
        raise YadroError(Diagnostic("Unsupported compound operator", line, column))

    def _mangle_method_name(self, class_name: str, method_name: str) -> str:
        return f"{class_name}.{method_name}"

    def _mangle_trait_impl_name(
        self, trait_name: str, class_name: str, method_name: str
    ) -> str:
        return f"{trait_name}.{class_name}.{method_name}"

    def _mangle_generic_name(self, name: str, args: List[Type]) -> str:
        suffix = "_".join(
            t.name.replace("[", "_")
            .replace("]", "_")
            .replace(",", "_")
            .replace(" ", "_")
            for t in args
        )
        return f"{name}${suffix}"

    def _ensure_assignable(
        self, target: Type, value: Type, line: int, column: int
    ) -> None:
        if target == value:
            return
        if target == FLOAT and value in (INT, CHAR):
            return
        if target == INT and value in (BOOL, CHAR):
            return
        if target == CHAR and value == INT:
            return
        if target == BOOL and value == INT:
            return
        if target.kind == "ThreadId" and value == INT:
            return
        if target.kind == "ref" and value.kind == "ref":
            if (
                target.region is not None
                and value.region is not None
                and value.region > target.region
            ):
                raise YadroError(
                    Diagnostic("Reference escapes its region", line, column)
                )
            if target.element == value.element and (
                target.mutable == value.mutable
                or (not target.mutable and value.mutable)
            ):
                return
            if (
                target._elem.kind in self.classes
                and value._elem.kind in self.classes
                and self._is_subclass(value._elem.kind, target._elem.kind)
                and (
                    target.mutable == value.mutable
                    or (not target.mutable and value.mutable)
                )
            ):
                return
        if (
            target.kind in self.classes
            and value.kind == "ref"
            and value.element == target
        ):
            return
        if (
            target.kind in self.classes
            and value.kind in self.classes
            and self._is_subclass(value.kind, target.kind)
        ):
            return
        if target.kind == "trait":
            trait_name = target.var_name
            if value.kind in self.classes and self._has_trait_impl(
                trait_name, value.kind
            ):
                return
            if (
                value.kind == "ref"
                and value._elem.kind in self.classes
                and self._has_trait_impl(trait_name, value._elem.kind)
            ):
                return
        if (
            target.kind == "gc"
            and value.kind in {"gc", "ref"}
            and target.element == value.element
        ):
            return
        if (
            target.kind == "gc_weak"
            and value.kind in {"gc", "gc_weak"}
            and target.element == value.element
        ):
            return
        if (
            target.kind == "darray"
            and value.kind == "array"
            and target.element == value.element
        ):
            return
        if target.kind == "Option" and value.kind == "Option":
            if target.type_args == value.type_args:
                return
        if target.kind == "Result" and value.kind == "Result":
            if target.type_args == value.type_args:
                return
        if target == UNIT and value == UNIT:
            return
        raise YadroError(
            Diagnostic(
                f"Type mismatch: expected {target.name}, got {value.name}", line, column
            )
        )

    def _analyze_index(self, expr: ast.IndexExpr, borrow_target: bool = False) -> Type:
        target_type = self._analyze_expr(
            expr.target, mode="borrow" if borrow_target else "value"
        )
        index_type = self._analyze_expr(expr.index)
        self._ensure_assignable(INT, index_type, expr.index.line, expr.index.column)
        if target_type.kind in {"array", "darray"}:
            return target_type._elem
        if target_type.kind == "vector":
            if borrow_target:
                raise YadroError(
                    Diagnostic(
                        "Cannot take address of vector element", expr.line, expr.column
                    )
                )
            return target_type._elem
        raise YadroError(
            Diagnostic(
                "Indexing requires array, darray, or vector", expr.line, expr.column
            )
        )

    def _analyze_trait(self, trait: ast.TraitDef) -> None:
        self.current_trait = trait.name
        methods: Dict[str, FunctionSig] = {}
        method_order: List[str] = []
        method_self: Dict[str, bool] = {}
        for method in trait.methods:
            self._validate_attributes(method.attributes, method.line, method.column)
            self._validate_function_modifiers(
                method.modifiers,
                method.modifier_args,
                method.line,
                method.column,
                context="method",
            )
            self._validate_where_bounds_decl(
                method.where_bounds, method.type_params, method.line, method.column
            )
            self.type_params = ["Self"] + trait.type_params + method.type_params
            param_types = [self._resolve_type(p.type_name) for p in method.params]
            return_type = self._resolve_type(method.return_type)
            if "async" in method.modifiers:
                if return_type.kind != "Task" or len(return_type.type_args) != 1:
                    raise YadroError(
                        Diagnostic(
                            "async method must return Task[T]",
                            method.line,
                            method.column,
                        )
                    )
            if "thread" in method.modifiers:
                if return_type.kind != "ThreadId":
                    raise YadroError(
                        Diagnostic(
                            "thread method must return ThreadId",
                            method.line,
                            method.column,
                        )
                    )
            methods[method.name] = FunctionSig(
                method.name,
                param_types,
                return_type,
                method.type_params,
                method.where_bounds,
            )
            method_order.append(method.name)
            method_self[method.name] = bool(
                method.params and method.params[0].name == "self"
            )
        self.traits[trait.name].methods = methods
        self.traits[trait.name].method_order = method_order
        self.traits[trait.name].method_self = method_self
        self.type_params = []
        self.current_trait = None

    def _matches_trait_sig(self, expected: Type, actual: Type, for_type: Type) -> bool:
        if expected == actual:
            return True
        if expected.kind == "var" and expected.var_name == "Self":
            return actual == for_type
        if expected.kind == "ref" and actual.kind == "ref":
            if expected._elem.kind == "var" and expected._elem.var_name == "Self":
                return actual.element == for_type
            return self._matches_trait_sig(expected._elem, actual._elem, for_type)
        if (
            expected.kind in {"array", "darray", "gc", "gc_weak"}
            and actual.kind == expected.kind
        ):
            return self._matches_trait_sig(expected._elem, actual._elem, for_type)
        if expected.kind in {"Option", "Result"} and actual.kind == expected.kind:
            return all(
                self._matches_trait_sig(e, a, for_type)
                for e, a in zip(expected.type_args, actual.type_args)
            )
        return False

    def _analyze_impl(self, impl: ast.ImplDef) -> None:
        if impl.trait_name not in self.traits:
            raise YadroError(
                Diagnostic(f"Unknown trait '{impl.trait_name}'", impl.line, impl.column)
            )
        for_type = self._resolve_type(impl.for_type)
        if for_type.kind == "var":
            raise YadroError(
                Diagnostic(
                    "Impl for type parameter not supported", impl.line, impl.column
                )
            )
        if for_type.kind not in self.classes:
            raise YadroError(
                Diagnostic("Impl requires class type", impl.line, impl.column)
            )
        trait = self.traits[impl.trait_name]
        for method in impl.methods:
            if method.name not in trait.methods:
                raise YadroError(
                    Diagnostic(
                        f"Method '{method.name}' not in trait",
                        method.line,
                        method.column,
                    )
                )
            self.impl_method_defs[(impl.trait_name, for_type.kind, method.name)] = (
                method
            )
            expected = trait.methods[method.name]
            if len(method.type_params) != len(expected.type_params):
                raise YadroError(
                    Diagnostic(
                        f"Method '{method.name}' generic parameter count mismatch",
                        method.line,
                        method.column,
                    )
                )
            if method.where_bounds != expected.where_bounds:
                raise YadroError(
                    Diagnostic(
                        f"Method '{method.name}' where clause mismatch",
                        method.line,
                        method.column,
                    )
                )
            self._validate_where_bounds_decl(
                method.where_bounds, method.type_params, method.line, method.column
            )
            self.type_params = method.type_params
            param_types = [self._resolve_type(p.type_name) for p in method.params]
            return_type = self._resolve_type(method.return_type)
            self.type_params = []
            mangled = self._mangle_trait_impl_name(
                impl.trait_name, for_type.kind, method.name
            )
            sig = FunctionSig(
                mangled,
                param_types,
                return_type,
                method.type_params,
                method.where_bounds,
            )
            if mangled in self.functions:
                raise YadroError(
                    Diagnostic(
                        f"Duplicate function '{mangled}'", method.line, method.column
                    )
                )
            self.functions[mangled] = sig
            self.function_effects[mangled] = self._effective_effects(
                method.effects, method.modifiers, method.attributes
            )
            impl_def = ast.FunctionDef(
                name=mangled,
                type_params=method.type_params,
                params=method.params,
                return_type=method.return_type,
                where_bounds=method.where_bounds,
                body=method.body,
                modifiers=method.modifiers,
                attributes=method.attributes,
                effects=method.effects,
                modifier_args=method.modifier_args,
                line=method.line,
                column=method.column,
            )
            self.current_class = self.classes[for_type.kind].typ
            self._analyze_function(impl_def)
            self.current_class = None
            self.impl_functions.append(impl_def)
            if len(sig.param_types) != len(
                expected.param_types
            ) or not self._matches_trait_sig(
                expected.return_type, sig.return_type, for_type
            ):
                raise YadroError(
                    Diagnostic(
                        f"Method '{method.name}' signature mismatch",
                        method.line,
                        method.column,
                    )
                )
            for exp_type, act_type in zip(expected.param_types, sig.param_types):
                if not self._matches_trait_sig(exp_type, act_type, for_type):
                    raise YadroError(
                        Diagnostic(
                            f"Method '{method.name}' signature mismatch",
                            method.line,
                            method.column,
                        )
                    )
        self.impls.setdefault(impl.trait_name, []).append(for_type)

    def _analyze_switch_pattern(
        self, expr_type: Type, stmt: ast.SwitchStmt, expected_return: Type
    ) -> None:
        for case in stmt.cases:
            self.scopes.append({})
            self.moved.append(set())
            self.borrowed.append({})
            if isinstance(case.value, ast.PatternConstructor):
                if expr_type.kind == "Result":
                    if case.value.name not in {"Ok", "Err"}:
                        raise YadroError(
                            Diagnostic(
                                "Invalid Result pattern",
                                case.value.line,
                                case.value.column,
                            )
                        )
                    if case.value.name == "Ok":
                        if len(case.value.args) != 1:
                            raise YadroError(
                                Diagnostic(
                                    "Ok pattern requires one binding",
                                    case.value.line,
                                    case.value.column,
                                )
                            )
                        self.scopes[-1][case.value.args[0]] = expr_type.type_args[0]
                    else:
                        if len(case.value.args) != 1:
                            raise YadroError(
                                Diagnostic(
                                    "Err pattern requires one binding",
                                    case.value.line,
                                    case.value.column,
                                )
                            )
                        self.scopes[-1][case.value.args[0]] = expr_type.type_args[1]
                if expr_type.kind == "Option":
                    if case.value.name not in {"Some", "None"}:
                        raise YadroError(
                            Diagnostic(
                                "Invalid Option pattern",
                                case.value.line,
                                case.value.column,
                            )
                        )
                    if case.value.name == "Some":
                        if len(case.value.args) != 1:
                            raise YadroError(
                                Diagnostic(
                                    "Some pattern requires one binding",
                                    case.value.line,
                                    case.value.column,
                                )
                            )
                        self.scopes[-1][case.value.args[0]] = expr_type.type_args[0]
                    if case.value.name == "None" and case.value.args:
                        raise YadroError(
                            Diagnostic(
                                "None pattern takes no bindings",
                                case.value.line,
                                case.value.column,
                            )
                        )
            elif isinstance(case.value, ast.PatternWildcard):
                pass
            else:
                raise YadroError(
                    Diagnostic(
                        "Invalid pattern for Result/Option",
                        case.value.line,
                        case.value.column,
                    )
                )
            self._analyze_block(case.body, expected_return)
            self.scopes.pop()
            self.moved.pop()
            self.borrowed.pop()

    def _analyze_constructor(self, expr: ast.Call, expected: Type) -> Type:
        if expected.kind == "Result":
            if expr.callee == "Ok":
                if len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic("Ok requires one argument", expr.line, expr.column)
                    )
                value_type = self._analyze_expr(
                    expr.args[0], expected=expected.type_args[0]
                )
                self._ensure_assignable(
                    expected.type_args[0], value_type, expr.line, expr.column
                )
                self.expr_types[id(expr)] = expected
                return expected
            if expr.callee == "Err":
                if len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic("Err requires one argument", expr.line, expr.column)
                    )
                value_type = self._analyze_expr(
                    expr.args[0], expected=expected.type_args[1]
                )
                self._ensure_assignable(
                    expected.type_args[1], value_type, expr.line, expr.column
                )
                self.expr_types[id(expr)] = expected
                return expected
        if expected.kind == "Option":
            if expr.callee == "Some":
                if len(expr.args) != 1:
                    raise YadroError(
                        Diagnostic("Some requires one argument", expr.line, expr.column)
                    )
                value_type = self._analyze_expr(
                    expr.args[0], expected=expected.type_args[0]
                )
                self._ensure_assignable(
                    expected.type_args[0], value_type, expr.line, expr.column
                )
                self.expr_types[id(expr)] = expected
                return expected
            if expr.callee == "None":
                if expr.args:
                    raise YadroError(
                        Diagnostic("None takes no arguments", expr.line, expr.column)
                    )
                self.expr_types[id(expr)] = expected
                return expected
        raise YadroError(
            Diagnostic(
                "Constructor does not match expected type", expr.line, expr.column
            )
        )

    def _analyze_specialization(
        self, func: ast.FunctionDef, name: str, sig: FunctionSig, type_args: List[Type]
    ) -> None:
        self._enforce_where_bounds(sig, type_args, func.line, func.column)
        bindings = dict(zip(sig.type_params, type_args))
        previous_bindings = self.type_bindings
        self.type_bindings = bindings
        param_types = [self._resolve_type(p.type_name) for p in func.params]
        return_type = self._resolve_type(func.return_type)
        specialized_sig = FunctionSig(name, param_types, return_type, [], [])
        self.functions[name] = specialized_sig
        self.function_effects[name] = self._effective_effects(
            func.effects, func.modifiers, func.attributes
        )
        specialized = ast.FunctionDef(
            name=name,
            type_params=[],
            params=func.params,
            return_type=func.return_type,
            where_bounds=[],
            body=func.body,
            modifiers=func.modifiers,
            attributes=func.attributes,
            effects=func.effects,
            modifier_args=func.modifier_args,
            line=func.line,
            column=func.column,
        )
        self._analyze_function(specialized)
        self.specialized_functions.append(specialized)
        self.type_bindings = previous_bindings

    def _mark_move(self, name: str, typ: Type, line: int, column: int) -> None:
        if self._is_copy(typ):
            return
        for scope in self.moved:
            if name in scope:
                raise YadroError(Diagnostic(f"Use after move '{name}'", line, column))
        for borrow_scope in self.borrowed:
            if name in borrow_scope:
                raise YadroError(
                    Diagnostic(
                        f"Move conflicts with active borrow of '{name}'", line, column
                    )
                )
        scope_index = self._find_scope_index(name)
        if scope_index is None:
            raise YadroError(Diagnostic(f"Undefined variable '{name}'", line, column))
        self.moved[scope_index].add(name)

    def _mark_borrow(self, name: str, mutable: bool, line: int, column: int) -> None:
        # NLL improvement: collect ALL active borrow states across all scopes.
        existing_states: list[str] = []
        for borrow_scope in self.borrowed:
            if name in borrow_scope:
                existing_states.append(borrow_scope[name])

        if mutable:
            # A mutable borrow requires exclusive access — no other borrows
            # (mutable or immutable) may be active at the same time.
            if existing_states:
                existing = existing_states[0]
                kind = "mutable" if existing == "mut" else "immutable"
                raise YadroError(
                    Diagnostic(
                        f"Cannot borrow '{name}' as mutable: already borrowed as {kind}",
                        line,
                        column,
                    )
                )
            # Also check for active immutable borrows in all scopes
            self.borrowed[-1][name] = "mut"
        else:
            # An immutable borrow conflicts only with an active mutable borrow.
            if "mut" in existing_states:
                raise YadroError(
                    Diagnostic(
                        f"Cannot borrow '{name}' as immutable: already borrowed as mutable",
                        line,
                        column,
                    )
                )
            # Multiple immutable borrows are allowed simultaneously.
            self.borrowed[-1][name] = "imm"

    def _release_borrow(self, name: str) -> None:
        """
        Explicitly release all active borrows of *name* across all scopes.

        Called when a reference variable goes out of scope or is reassigned,
        allowing the original variable to be borrowed or moved again.
        This is the key NLL (Non-Lexical Lifetimes) mechanism: borrows end
        when the last use of the reference is reached, not at the syntactic
        end of the enclosing block.
        """
        for borrow_scope in self.borrowed:
            borrow_scope.pop(name, None)

    def _is_copy(self, typ: Type) -> bool:
        if typ in (INT, FLOAT, BOOL, CHAR, STRING, THREAD_ID):
            return True
        if typ.kind in {"gc_weak", "ref", "classref"}:
            return True
        if typ.kind in {"array", "darray"} and typ.element is not None:
            return self._is_copy(typ.element)
        if typ.kind in {"Option", "Result"}:
            return all(self._is_copy(arg) for arg in typ.type_args)
        return False

    def _is_subclass(self, child: str, parent: str) -> bool:
        if child == parent:
            return True
        current = self.classes.get(child)
        while current and current.base:
            if current.base == parent:
                return True
            current = self.classes.get(current.base)
        return False

    def _has_trait_impl(self, trait_name: Optional[str], class_name: str) -> bool:
        if trait_name is None:
            return False
        return any(impl.kind == class_name for impl in self.impls.get(trait_name, []))

    def _lookup_var(self, name: str, line: int, column: int) -> Type:
        for scope in reversed(self.scopes):
            if name in scope:
                for move_scope in self.moved:
                    if name in move_scope:
                        raise YadroError(
                            Diagnostic(f"Use after move '{name}'", line, column)
                        )
                return scope[name]
        raise YadroError(Diagnostic(f"Undefined variable '{name}'", line, column))

    def _is_const_var(self, name: str) -> bool:
        for scope in reversed(self.const_scopes):
            if name in scope:
                return True
        return False

    def _collect_directives(self, directives: List[ast.Directive]) -> None:
        self.required_libs = set()
        self.plugins = set()
        for directive in directives:
            if directive.kind == "requires":
                if not isinstance(directive.payload, list):
                    continue
                for lib in directive.payload:
                    if not isinstance(lib, str):
                        raise YadroError(Diagnostic("Invalid #requires entry", 1, 1))
                    if lib in self.required_libs:
                        raise YadroError(
                            Diagnostic(f"Duplicate #requires entry '{lib}'", 1, 1)
                        )
                    self.required_libs.add(lib)
            if directive.kind == "plugin":
                if not isinstance(directive.payload, list):
                    continue
                for plugin in directive.payload:
                    if not isinstance(plugin, str):
                        raise YadroError(Diagnostic("Invalid #plugin entry", 1, 1))
                    if plugin in self.plugins:
                        raise YadroError(
                            Diagnostic(f"Duplicate #plugin entry '{plugin}'", 1, 1)
                        )
                    self.plugins.add(plugin)

    # ------------------------------------------------------------------
    # YUP 26.1.5 – Spec / Verification warning pass
    # ------------------------------------------------------------------

    def _collect_spec_warnings(
        self, program: ast.Program, result: SemanticResult
    ) -> None:
        """
        Walk all spec blocks in the program and emit warnings for obligations
        that cannot be statically discharged.

        Per YUP 26.1.5 §5, the default verification level is "check":
          - Spec annotations are parsed and type-checked (already done above).
          - Trivially-true predicates are silently accepted.
          - Remaining obligations produce a warning so that engineers know
            what still requires an external prover (Why3/Coq/F*).

        With verify_level == "none" this method is a no-op.
        """
        if getattr(self, "_verify_level", "check") == "none":
            return

        severity = (
            "error"
            if getattr(self, "_verify_level", "check") == "require"
            else "warning"
        )

        def _warn(line: int, col: int, kind: str, ctx: str) -> None:
            result.verification_warnings.append(
                f"{line}:{col}: {severity}: UNPROVEN {kind} in '{ctx}' "
                f"— no external prover available; obligation remains open "
                f"(YUP 26.1.5 §5 verify=check)"
            )

        def _trivially_true(expr: ast.Expr) -> bool:
            """Return True for obviously-true constant predicates."""
            if isinstance(expr, ast.BoolLiteral):
                return expr.value
            if isinstance(expr, ast.BinaryOp) and expr.op == "and":
                return _trivially_true(expr.left) and _trivially_true(expr.right)
            if isinstance(expr, ast.BinaryOp) and expr.op == "or":
                return _trivially_true(expr.left) or _trivially_true(expr.right)
            if isinstance(expr, ast.BinaryOp) and expr.op in {
                "==",
                "!=",
                "<",
                "<=",
                ">",
                ">=",
            }:
                if isinstance(expr.left, ast.IntLiteral) and isinstance(
                    expr.right, ast.IntLiteral
                ):
                    a, b = expr.left.value, expr.right.value
                    return {
                        "==": a == b,
                        "!=": a != b,
                        "<": a < b,
                        "<=": a <= b,
                        ">": a > b,
                        ">=": a >= b,
                    }[expr.op]
                # x == x, x <= x, x >= x are trivially true
                if expr.op in {"==", "<=", ">="}:
                    if (
                        isinstance(expr.left, ast.VarRef)
                        and isinstance(expr.right, ast.VarRef)
                        and expr.left.name == expr.right.name
                    ):
                        return True
            return False

        def _check_spec(spec: ast.SpecBlock, fname: str) -> None:
            for pred in spec.requires:
                if not _trivially_true(pred):
                    _warn(pred.line, pred.column, "requires", fname)
            for pred in spec.ensures:
                if not _trivially_true(pred):
                    _warn(pred.line, pred.column, "ensures", fname)
            for inv in spec.invariants:
                if not _trivially_true(inv):
                    _warn(inv.line, inv.column, "spec invariant", fname)

        def _check_loop_invariants(stmts: List[ast.Stmt], fname: str) -> None:
            for stmt in stmts:
                if isinstance(stmt, ast.WhileStmt):
                    for inv in stmt.invariants:
                        if not _trivially_true(inv):
                            _warn(inv.line, inv.column, "loop invariant", fname)
                    _check_loop_invariants(stmt.body, fname)
                elif isinstance(stmt, ast.ForStmt):
                    for inv in stmt.invariants:
                        if not _trivially_true(inv):
                            _warn(inv.line, inv.column, "loop invariant", fname)
                    _check_loop_invariants(stmt.body, fname)
                elif isinstance(stmt, ast.RepeatStmt):
                    for inv in stmt.invariants:
                        if not _trivially_true(inv):
                            _warn(inv.line, inv.column, "loop invariant", fname)
                    _check_loop_invariants(stmt.body, fname)
                elif isinstance(stmt, ast.IfStmt):
                    _check_loop_invariants(stmt.then_body, fname)
                    for _, body in stmt.elifs:
                        _check_loop_invariants(body, fname)
                    if stmt.else_body:
                        _check_loop_invariants(stmt.else_body, fname)
                elif isinstance(stmt, (ast.UnsafeBlock, ast.ArenaStmt)):
                    _check_loop_invariants(stmt.body, fname)

        # Top-level spec types
        for spec_type in program.spec_types:
            if not _trivially_true(spec_type.predicate):
                result.verification_warnings.append(
                    f"{spec_type.line}:{spec_type.column}: {severity}: "
                    f"UNPROVEN spec type predicate for '{spec_type.name}' "
                    f"(YUP 26.1.5 §5)"
                )

        # Functions
        for func in program.functions:
            if func.spec is not None:
                _check_spec(func.spec, func.name)
            _check_loop_invariants(func.body, func.name)
            # Refined parameters
            for param in func.params:
                if param.refined and param.predicate is not None:
                    if not _trivially_true(param.predicate):
                        result.verification_warnings.append(
                            f"{param.line}:{param.column}: {severity}: "
                            f"UNPROVEN refined parameter predicate for "
                            f"'{param.name}' in '{func.name}' "
                            f"(YUP 26.1.5 §5)"
                        )

        # Class invariants and method specs
        for cls in program.classes:
            for inv in cls.invariants:
                if not _trivially_true(inv):
                    result.verification_warnings.append(
                        f"{inv.line}:{inv.column}: {severity}: "
                        f"UNPROVEN class invariant in '{cls.name}' "
                        f"(YUP 26.1.5 §5)"
                    )
            for method in cls.methods:
                qname = f"{cls.name}.{method.name}"
                if method.spec is not None:
                    _check_spec(method.spec, qname)
                _check_loop_invariants(method.body, qname)

        # Main block loop invariants
        _check_loop_invariants(program.main_block, "<main>")

    # ------------------------------------------------------------------
    # YUP 26.1.3 – Constitutional enforcement pass
    # ------------------------------------------------------------------

    def _check_article_iv1(self, program: ast.Program, result: SemanticResult) -> None:
        """
        YUP 26.1.3 Article IV.1 — Against Global Entropy.

        Checks:
        1. Any VarDecl (mutable) in the main_block that is passed as &mut to a
           function call is flagged as potential unmanaged global mutable state.
        2. Functions with no declared effects that call functions with known
           effects without propagating them are flagged.
        """
        notes = result.constitution_notes

        # --- Check 1: mutable main_block variables passed as &mut ---------------
        main_mutable_vars: set[str] = set()
        for stmt in program.main_block:
            if isinstance(stmt, ast.VarDecl) and not getattr(stmt, "ghost", False):
                main_mutable_vars.add(stmt.name)

        def _scan_for_mut_ref_of_main_var(
            expr: ast.Expr,
        ) -> List[tuple[str, int, int]]:
            """Return (var_name, line, col) for every &mut <main_var> found."""
            found: List[tuple[str, int, int]] = []
            if isinstance(expr, ast.UnaryOp) and expr.op == "&mut":
                if isinstance(expr.operand, ast.VarRef):
                    if expr.operand.name in main_mutable_vars:
                        found.append((expr.operand.name, expr.line, expr.column))
            if isinstance(expr, ast.BinaryOp):
                found.extend(_scan_for_mut_ref_of_main_var(expr.left))
                found.extend(_scan_for_mut_ref_of_main_var(expr.right))
            if isinstance(expr, ast.Call):
                for arg in expr.args:
                    found.extend(_scan_for_mut_ref_of_main_var(arg))
            if isinstance(expr, ast.MethodCall):
                found.extend(_scan_for_mut_ref_of_main_var(expr.target))
                for arg in expr.args:
                    found.extend(_scan_for_mut_ref_of_main_var(arg))
            if isinstance(expr, ast.UnaryOp):
                found.extend(_scan_for_mut_ref_of_main_var(expr.operand))
            return found

        mut_ref_counts: Dict[str, int] = {}
        for stmt in program.main_block:
            if isinstance(stmt, ast.ExprStmt):
                for varname, line, col in _scan_for_mut_ref_of_main_var(stmt.expr):
                    mut_ref_counts[varname] = mut_ref_counts.get(varname, 0) + 1
                    if mut_ref_counts[varname] == 1:
                        notes.append(
                            f"{line}:{col}: note: "
                            f"[Article IV.1] variable '{varname}' from main block is "
                            f"passed as &mut to a function; this is module-level "
                            f"mutable state accessible across calls (YUP 26.1.3)"
                        )

        # --- Check 2: undeclared effect propagation ----------------------------
        for func in program.functions:
            if "ffi" in func.modifiers or "async" in func.modifiers:
                continue
            declared_effects = set(func.effects) | {
                e for attr in func.attributes for e in self._attribute_effects(attr)
            }
            if declared_effects:
                # Already has effects declared — propagation is explicit
                continue
            # Scan body for calls to functions with known effects
            for called_name, called_effects in self.function_effects.items():
                if not called_effects:
                    continue
                if called_name == func.name:
                    continue
                if self._body_calls(func.body, called_name):
                    missing = called_effects - {"unsafe"}
                    if missing:
                        notes.append(
                            f"{func.line}:{func.column}: note: "
                            f"[Article IV.1] function '{func.name}' calls "
                            f"'{called_name}' which has effects "
                            f"{sorted(missing)} but declares no effects itself; "
                            f"side-effects must be propagated explicitly (YUP 26.1.3)"
                        )

    def _body_calls(self, stmts: List[ast.Stmt], name: str) -> bool:
        """Return True if any statement in *stmts* (recursively) calls *name*."""
        for stmt in stmts:
            if isinstance(stmt, ast.ExprStmt):
                if self._expr_calls(stmt.expr, name):
                    return True
            elif isinstance(stmt, ast.VarDecl):
                if self._expr_calls(stmt.value, name):
                    return True
            elif isinstance(stmt, ast.Assign):
                if self._expr_calls(stmt.value, name):
                    return True
            elif hasattr(stmt, "body") and isinstance(stmt.body, list):
                if self._body_calls(stmt.body, name):
                    return True
        return False

    def _expr_calls(self, expr: ast.Expr, name: str) -> bool:
        if isinstance(expr, ast.Call) and expr.callee == name:
            return True
        if isinstance(expr, ast.Call):
            return any(self._expr_calls(a, name) for a in expr.args)
        if isinstance(expr, ast.MethodCall):
            return self._expr_calls(expr.target, name) or any(
                self._expr_calls(a, name) for a in expr.args
            )
        if isinstance(expr, ast.BinaryOp):
            return self._expr_calls(expr.left, name) or self._expr_calls(
                expr.right, name
            )
        if isinstance(expr, ast.UnaryOp):
            return self._expr_calls(expr.operand, name)
        return False

    def _check_constitution_rules(
        self, program: ast.Program, result: SemanticResult
    ) -> None:
        """
        Lightweight static checks for constitutional compliance per YUP 26.1.3.

        Produces informational notes (not errors) for patterns that approach
        a constitutional boundary.  Full constitutional enforcement requires
        the YadroConstitutionPass (YUP 26.1.4 §3.2) which runs at LLVM IR level.

        Checks implemented
        ------------------
        Article I.1  (Proof Assistant):
          - [const] functions with non-trivial bodies but no spec block are
            noted — they are candidates for formal verification.

        Article II.3 (Cost Must Be Apparent):
          - [thread] functions that return a type other than ThreadId / void
            are flagged; the spawning cost must be visible in the signature.

        Article IV.1 (Against Global Entropy):
          - Functions with [async] modifier that also declare [thread] are
            flagged (already rejected by _validate_function_modifiers, but
            we add a constitutional context note here for diagnostics).

        Article V.Pillar1 (Ownership):
          - linear classes whose methods take self by value (not &mut self)
            are noted; linear types must use unique-ownership discipline.
        """
        notes = result.constitution_notes

        for func in program.functions:
            # Article I.1: const function without spec
            if "const" in func.modifiers and func.spec is None and len(func.body) > 2:
                notes.append(
                    f"{func.line}:{func.column}: note: "
                    f"[Article I.1] const function '{func.name}' has no spec block; "
                    f"consider adding spec: requires/ensures to strengthen "
                    f"compile-time proof guarantees (YUP 26.1.3)"
                )

            # Article II.3: thread function return type visibility
            if "thread" in func.modifiers:
                ret = self._resolve_type(func.return_type) if func.return_type else UNIT
                if ret not in (UNIT,) and ret.kind not in {"ThreadId"}:
                    notes.append(
                        f"{func.line}:{func.column}: note: "
                        f"[Article II.3] thread function '{func.name}' returns "
                        f"'{ret.name}'; ThreadId is the conventional return type "
                        f"to make spawning cost apparent (YUP 26.1.3)"
                    )

        # Article V.Pillar1: linear class ownership discipline
        for cls in program.classes:
            if "linear" not in cls.modifiers:
                continue
            info = self.classes.get(cls.name)
            if info is None:
                continue
            for method_name, method_info in info.methods.items():
                if method_info.is_class:
                    continue
                params = method_info.sig.param_types
                if not params:
                    continue
                first = params[0]
                # A linear class instance method should take &mut self
                if first.kind != "ref" or not first.mutable:
                    notes.append(
                        f"{cls.line}:{cls.column}: note: "
                        f"[Article V.Pillar1] linear class '{cls.name}' method "
                        f"'{method_name}' takes self by non-mutable-reference; "
                        f"linear types should use &mut self to enforce unique "
                        f"ownership discipline (YUP 26.1.3)"
                    )

    def _validate_ffi_requires(self, func: ast.FunctionDef) -> None:
        if "ffi" not in func.modifiers:
            return
        args = func.modifier_args.get("ffi", {})
        positional = args.get("$", [])
        if not positional or not isinstance(positional[0], str):
            return
        lib = positional[0]
        if self.required_libs and lib not in self.required_libs:
            raise YadroError(
                Diagnostic(
                    f"Library '{lib}' not declared in #requires", func.line, func.column
                )
            )
        plugin = args.get("plugin")
        if plugin is None and len(positional) > 1 and isinstance(positional[1], str):
            plugin = positional[1]
        if plugin and self.plugins and plugin not in self.plugins:
            raise YadroError(
                Diagnostic(
                    f"Plugin '{plugin}' not declared in #plugin", func.line, func.column
                )
            )

    def _spec_bindings(self) -> Dict[str, Type]:
        bindings: Dict[str, Type] = {}
        for scope in self.scopes:
            bindings.update(scope)
        return bindings

    def _analyze_spec_predicate(
        self, expr: ast.Expr, bindings: Dict[str, Type], line: int, column: int
    ) -> None:
        prev_in_spec = self.in_spec
        self.in_spec = True
        self.scopes.append(dict(bindings))
        self.moved.append(set())
        self.borrowed.append({})
        self.const_scopes.append(set())
        try:
            pred_type = self._analyze_expr(expr)
        finally:
            self.scopes.pop()
            self.moved.pop()
            self.borrowed.pop()
            self.const_scopes.pop()
            self.in_spec = prev_in_spec
        self._ensure_assignable(BOOL, pred_type, line, column)

    def _validate_refined_params(self, params: List[ast.Param]) -> None:
        if not params:
            return
        bindings = self._spec_bindings()
        for param in params:
            if param.predicate is None:
                continue
            param_type = self._resolve_type(param.type_name)
            param_bindings = dict(bindings)
            param_bindings["value"] = param_type
            param_bindings[param.name] = param_type
            self._analyze_spec_predicate(
                param.predicate, param_bindings, param.line, param.column
            )

    def _validate_spec_block(self, spec: ast.SpecBlock, return_type: Type) -> None:
        bindings = self._spec_bindings()
        bindings["result"] = return_type
        for predicate in spec.requires:
            self._analyze_spec_predicate(
                predicate, bindings, predicate.line, predicate.column
            )
        for predicate in spec.ensures:
            self._analyze_spec_predicate(
                predicate, bindings, predicate.line, predicate.column
            )
        for predicate in spec.invariants:
            self._analyze_spec_predicate(
                predicate, bindings, predicate.line, predicate.column
            )

    def _validate_spec_types(self, spec_types: List[ast.SpecTypeDef]) -> None:
        for spec in spec_types:
            previous_params = self.type_params
            self.type_params = spec.type_params
            try:
                base_type = self._resolve_type(spec.base_type)
                bindings = {"value": base_type}
                self._analyze_spec_predicate(
                    spec.predicate, bindings, spec.line, spec.column
                )
            finally:
                self.type_params = previous_params

    def _effective_effects(
        self, effects: List[str], modifiers: List[str], attributes: List[ast.Attribute]
    ) -> set[str]:
        result = set(effects)
        if "ffi" in modifiers:
            result.add("unsafe")
        if any(attr.name == "unsafe" for attr in attributes):
            result.add("unsafe")
        for attr in attributes:
            for effect in self._attribute_effects(attr):
                result.add(effect)
        return result

    def _attribute_effects(self, attr: ast.Attribute) -> List[str]:
        if attr.name != "effect":
            return []
        args = attr.args or {}
        effects: List[str] = []
        positional = args.get("$", [])
        if positional:
            for value in positional:
                if not isinstance(value, str):
                    raise YadroError(
                        Diagnostic(
                            "effect attribute requires effect name",
                            attr.line,
                            attr.column,
                        )
                    )
                effects.append(value)
        elif isinstance(args.get("name"), str):
            effects.append(args["name"])
        else:
            raise YadroError(
                Diagnostic(
                    "effect attribute requires effect name", attr.line, attr.column
                )
            )
        return effects

    def _require_effects(self, required: set[str], line: int, column: int) -> None:
        if not required:
            return
        if self.current_effects is None:
            return
        missing = required - self.current_effects
        if missing:
            missing_list = ", ".join(sorted(missing))
            raise YadroError(
                Diagnostic(f"Missing required effects: {missing_list}", line, column)
            )

    def _find_scope_index(self, name: str) -> Optional[int]:
        for idx in range(len(self.scopes) - 1, -1, -1):
            if name in self.scopes[idx]:
                return idx
        return None
