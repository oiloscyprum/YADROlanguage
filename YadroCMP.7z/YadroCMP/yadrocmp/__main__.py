import argparse
import sys

from .driver import compile_file
from .errors import YadroError


def main() -> int:
    parser = argparse.ArgumentParser(prog="yadrocmp")
    sub = parser.add_subparsers(dest="command")
    compile_parser = sub.add_parser("compile")
    compile_parser.add_argument("source")
    compile_parser.add_argument("-o", "--output", required=True)
    compile_parser.add_argument("--emit", choices=["llvm", "obj"], default="llvm")
    args = parser.parse_args()
    if args.command != "compile":
        parser.print_help()
        return 1
    try:
        compile_file(args.source, args.output, emit=args.emit)
    except YadroError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
