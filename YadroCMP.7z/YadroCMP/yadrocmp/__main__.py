import argparse
import shutil
import subprocess
import sys

from .driver import compile_file
from .errors import YadroError


def main() -> int:
    parser = argparse.ArgumentParser(prog="yadrocmp")
    sub = parser.add_subparsers(dest="command")
    compile_parser = sub.add_parser("compile")
    compile_parser.add_argument("source")
    compile_parser.add_argument("-o", "--output", required=True)
    compile_parser.add_argument("--emit", choices=["llvm", "obj", "bin"], default="llvm")
    lint_parser = sub.add_parser("lint")
    lint_parser.add_argument("paths", nargs="*", default=["yadrocmp"])
    args = parser.parse_args()
    if args.command == "lint":
        if shutil.which("ruff") is None:
            sys.stderr.write("ruff is not installed. Run: pip install -r requirements.txt\n")
            return 1
        result = subprocess.run(["ruff", "check", *args.paths])
        return result.returncode
    if args.command != "compile":
        parser.print_help()
        return 1
    try:
        compile_file(args.source, args.output, emit=args.emit)
    except YadroError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
