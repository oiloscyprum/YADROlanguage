import argparse
import shutil
import subprocess
import sys

from .driver import compile_file
from .errors import YadroError


def main() -> int:
    parser = argparse.ArgumentParser(prog="yadrocmp")
    sub = parser.add_subparsers(dest="command")

    # ── compile ─────────────────────────────────────────────────────────────
    compile_parser = sub.add_parser(
        "compile",
        help="Compile a .yad source file to LLVM IR, object code, or a binary.",
    )
    compile_parser.add_argument("source", help="Path to the .yad source file.")
    compile_parser.add_argument(
        "-o", "--output", required=True, help="Output file path."
    )
    compile_parser.add_argument(
        "--emit",
        choices=["llvm", "obj", "bin"],
        default="llvm",
        help="Output format (default: llvm).",
    )
    compile_parser.add_argument(
        "--verify",
        choices=["none", "check", "require", "certify"],
        default="check",
        metavar="LEVEL",
        help=(
            "Verification level for spec / proof obligations (YUP 26.1.5).\n"
            "  none     – skip all spec processing\n"
            "  check    – warn for unproven obligations (default)\n"
            "  require  – error for unproven obligations\n"
            "  certify  – error + dump proof-certificate stubs"
        ),
    )
    compile_parser.add_argument(
        "--dump-obligations",
        action="store_true",
        default=False,
        help=(
            "Print all collected proof obligations (proved and unproven) "
            "to stdout before emitting code (YUP 26.1.5 §4.2)."
        ),
    )

    # ── verify ──────────────────────────────────────────────────────────────
    verify_parser = sub.add_parser(
        "verify",
        help=(
            "Run only the VIR proof-obligation pass on a .yad file "
            "without emitting code (YUP 26.1.5)."
        ),
    )
    verify_parser.add_argument("source", help="Path to the .yad source file.")
    verify_parser.add_argument(
        "--level",
        choices=["none", "check", "require", "certify"],
        default="check",
        metavar="LEVEL",
        help="Verification level (default: check).",
    )
    verify_parser.add_argument(
        "--dump-obligations",
        action="store_true",
        default=False,
        help="Print the full obligation table to stdout.",
    )

    # ── lint ────────────────────────────────────────────────────────────────
    lint_parser = sub.add_parser(
        "lint",
        help="Run ruff linter on the compiler source.",
    )
    lint_parser.add_argument(
        "paths",
        nargs="*",
        default=["yadrocmp"],
        help="Paths to lint (default: yadrocmp/).",
    )

    args = parser.parse_args()

    # ── dispatch ─────────────────────────────────────────────────────────────
    if args.command == "lint":
        if shutil.which("ruff") is None:
            sys.stderr.write(
                "ruff is not installed. Run: pip install -r requirements.txt\n"
            )
            return 1
        result = subprocess.run(["ruff", "check", *args.paths])
        return result.returncode

    if args.command == "compile":
        try:
            compile_file(
                args.source,
                args.output,
                emit=args.emit,
                verify_level=args.verify,
                dump_obligations_flag=args.dump_obligations,
            )
        except YadroError as exc:
            sys.stderr.write(str(exc) + "\n")
            return 1
        return 0

    if args.command == "verify":
        # Import here so that llvmlite is not required just to run verification
        from pathlib import Path

        from .driver import _merge_with_imports, _parse_program, parse_directives
        from .sema import SemanticAnalyzer
        from .vir import collect_obligations, dump_obligations, format_diagnostics

        source_path = Path(args.source)
        if not source_path.exists():
            sys.stderr.write(f"error: file not found: '{args.source}'\n")
            return 1

        try:
            source = source_path.read_text(encoding="utf-8")
            directives, code = parse_directives(source)
            program = _parse_program(code, directives)
            program = _merge_with_imports(program, source_path.parent, {}, set())
            semantic = SemanticAnalyzer().analyze(program, verify_level=args.level)

            # Constitutional notes from semantic analysis
            # (verification_warnings are intentionally skipped here —
            #  VIR is now the canonical source of spec/obligation diagnostics
            #  and would produce duplicates for the same obligations.)
            for note in semantic.constitution_notes:
                sys.stderr.write(note + "\n")

            vir = collect_obligations(program, verify_level=args.level)

            if args.dump_obligations:
                sys.stdout.write(dump_obligations(vir) + "\n")

            diags = format_diagnostics(vir, verify_level=args.level)
            for diag in diags:
                sys.stderr.write(diag + "\n")

            if args.level in {"require", "certify"} and vir.unproven_count > 0:
                sys.stderr.write(
                    f"error: {vir.unproven_count} unproven proof obligation(s) "
                    f"(--level={args.level})\n"
                )
                return 1

            # Summary line
            total = len(vir.obligations)
            proved = vir.proved_count
            unproven = vir.unproven_count
            sys.stdout.write(
                f"Verification complete: {total} obligation(s), "
                f"{proved} proved, {unproven} unproven.\n"
            )
        except YadroError as exc:
            sys.stderr.write(str(exc) + "\n")
            return 1
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
