"""
Verification Intermediate Representation (VIR)

Implements YUP 26.1.5: Formal Verification Integration Standard.

The VIR sits between the typed AST (MIR) and LLVM IR generation. Its duties are:

  1. Collect all proof obligations from spec blocks (requires, ensures,
     loop invariants, class invariants, refined parameter predicates).
  2. Attempt lightweight static discharge via constant-folding and trivial
     predicate evaluation.
  3. Report unproven obligations at the configured verification level
     (none / check / require / certify) as defined in YUP 26.1.5 §5.

Full proof-checking against an external prover (Why3, Coq, F*) is a planned
extension (YUP 26.1.5 §4). The current pass fulfils the "check" level:
  - Spec annotations are parsed and type-checked (done in sema.py).
  - Trivially-true predicates are statically discharged.
  - All remaining obligations emit diagnostics so that engineers know what
     still needs a proof.

Constitutional alignment (YUP 26.1.3):
  - Article I.1  (Proof Assistant):    obligations are made visible to the user.
  - Article II.1 (No Magic):           every obligation includes its source location.
  - Article II.3 (Cost Must Be Apparent): zero runtime overhead; ghost variables
                                         erased before code generation.
  - Article IV.2 (Modular Reasoning):  obligations compose across functions and
                                       classes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Optional

from . import ast

# ---------------------------------------------------------------------------
# Public type definitions
# ---------------------------------------------------------------------------


class ObligationKind(Enum):
    """Classification of a proof obligation per YUP 26.1.5 §3.2."""

    REQUIRES = auto()  # Pre-condition  (spec.requires)
    ENSURES = auto()  # Post-condition (spec.ensures)
    INVARIANT = auto()  # Loop invariant (spec invariant …)
    CLASS_INVARIANT = auto()  # Data structure invariant (spec invariant: in class)
    REFINED_PARAM = auto()  # Predicate on a refined parameter (~T : pred)
    SPEC_TYPE = auto()  # Top-level spec type predicate (spec S = T where pred)


class VerificationStatus(Enum):
    """Discharge status of a single proof obligation."""

    PROVED = auto()  # Statically discharged (trivially true / constant-folded)
    UNPROVEN = auto()  # Cannot be determined without an external prover
    VACUOUS = auto()  # No specification present (not an error)
    SKIPPED = auto()  # Skipped due to verify_level == "none"


@dataclass
class ProofObligation:
    """
    A single proof obligation collected from a spec annotation.

    Per YUP 26.1.5 §3.2 (VIR Core Constructs) each obligation carries:
      - Its kind (requires / ensures / invariant / …)
      - The source function (or None for class invariants)
      - The predicate AST node
      - Source location for diagnostic reporting
      - The current discharge status
      - A human-readable note
    """

    kind: ObligationKind
    function: Optional[str]  # None for class-level invariants
    predicate: ast.Expr
    line: int
    column: int
    status: VerificationStatus = VerificationStatus.UNPROVEN
    note: str = ""

    def format_diagnostic(self, level: str = "check") -> str:
        severity = "error" if level == "require" else "warning"
        kind_label = self.kind.name.replace("_", " ").lower()
        loc = f"{self.line}:{self.column}"
        ctx = f" in '{self.function}'" if self.function else ""
        return f"{loc}: {severity}: UNPROVEN {kind_label}{ctx} — {self.note}"


@dataclass
class VirModule:
    """
    The Verification Intermediate Representation of a compiled YADRO program.

    Contains all collected proof obligations and the discharge results
    produced by the static analysis pass.
    """

    # Back-reference to the source AST (used for ghost-variable erasure, §3.2)
    program: ast.Program

    # All collected proof obligations
    obligations: List[ProofObligation] = field(default_factory=list)

    # Summary counters (populated by collect_obligations)
    proved_count: int = 0
    unproven_count: int = 0

    def proved(self) -> List[ProofObligation]:
        return [o for o in self.obligations if o.status == VerificationStatus.PROVED]

    def unproven(self) -> List[ProofObligation]:
        return [o for o in self.obligations if o.status == VerificationStatus.UNPROVEN]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def collect_obligations(
    program: ast.Program,
    verify_level: str = "check",
) -> VirModule:
    """
    Collect all proof obligations from a parsed, semantically-checked program.

    This is the main entry-point for the VIR pass.  It is called by the
    driver after semantic analysis but before LLVM IR generation
    (YUP 26.1.5 §3.1 Architecture).

    Parameters
    ----------
    program:
        The AST produced by the parser and validated by the semantic analyser.
    verify_level:
        One of "none" | "check" | "require" | "certify" (YUP 26.1.5 §5).
        "none"    – skip collection entirely.
        "check"   – collect and discharge; warn for unproven (default).
        "require" – collect and discharge; error for unproven.
        "certify" – like "require" but also dumps proof-certificate stubs.

    Returns
    -------
    VirModule
        The populated VIR with obligation statuses filled in.
    """
    vir = VirModule(program=program)

    if verify_level == "none":
        # Per YUP 26.1.5 §5: skip all spec processing (prototyping mode)
        for ob in vir.obligations:
            ob.status = VerificationStatus.SKIPPED
        return vir

    # --- 1. Collect top-level spec type obligations --------------------------
    for spec in program.spec_types:
        _collect_spec_type(vir, spec)

    # --- 2. Collect function-level obligations --------------------------------
    for func in program.functions:
        _collect_function(vir, func)

    # --- 3. Collect class-level obligations -----------------------------------
    for cls in program.classes:
        _collect_class(vir, cls)

    # --- 4. Collect obligations from the main block --------------------------
    _collect_stmts(vir, "<main>", program.main_block)

    # --- 5. Lightweight static discharge -------------------------------------
    _static_discharge(vir)

    # --- 6. Update summary counters ------------------------------------------
    vir.proved_count = sum(
        1 for o in vir.obligations if o.status == VerificationStatus.PROVED
    )
    vir.unproven_count = sum(
        1 for o in vir.obligations if o.status == VerificationStatus.UNPROVEN
    )

    return vir


def format_diagnostics(vir: VirModule, verify_level: str = "check") -> List[str]:
    """
    Produce a list of diagnostic strings for all unproven obligations.

    Proved obligations are silently dropped.  The format matches the YADRO
    compiler's standard diagnostic format:  ``<line>:<col>: <sev>: <msg>``

    Per YUP 26.1.5 §5, the severity is:
      "check"   → "warning"
      "require" → "error"
      "certify" → "error" (additionally produces certificate stubs)
    """
    if verify_level == "none":
        return []

    lines: List[str] = []

    for ob in vir.obligations:
        if ob.status != VerificationStatus.UNPROVEN:
            continue
        lines.append(ob.format_diagnostic(verify_level))

    if verify_level == "certify" and lines:
        lines.append(
            "note: --verify=certify: generate proof-certificate stubs with "
            "'yadro verify --dump-obligations'"
        )

    return lines


def dump_obligations(vir: VirModule) -> str:
    """
    Return a human-readable dump of all proof obligations (proved and unproven).

    Equivalent to ``yadro verify --dump-obligations`` (YUP 26.1.5 §4.2).
    """
    rows: List[str] = ["# YADRO Proof Obligations (YUP 26.1.5)", ""]
    for i, ob in enumerate(vir.obligations, 1):
        status_str = ob.status.name
        kind_str = ob.kind.name
        func_str = ob.function or "<class>"
        rows.append(
            f"[{i:03d}] {status_str:<10} {kind_str:<18} {func_str}  "
            f"({ob.line}:{ob.column})  {ob.note}"
        )
    rows.append("")
    rows.append(
        f"Total: {len(vir.obligations)}  "
        f"Proved: {vir.proved_count}  "
        f"Unproven: {vir.unproven_count}"
    )
    return "\n".join(rows)


# ---------------------------------------------------------------------------
# Collection helpers
# ---------------------------------------------------------------------------


def _add(
    vir: VirModule,
    kind: ObligationKind,
    function: Optional[str],
    pred: ast.Expr,
    note: str = "",
) -> None:
    ob = ProofObligation(
        kind=kind,
        function=function,
        predicate=pred,
        line=pred.line,
        column=pred.column,
        note=note,
    )
    vir.obligations.append(ob)


def _collect_spec_type(vir: VirModule, spec: ast.SpecTypeDef) -> None:
    """Collect the predicate from a top-level ``spec S = T where pred`` declaration."""
    _add(
        vir,
        ObligationKind.SPEC_TYPE,
        function=None,
        pred=spec.predicate,
        note=f"spec type '{spec.name}' predicate is well-formed",
    )


def _collect_function(vir: VirModule, func: ast.FunctionDef) -> None:
    """Collect obligations from a top-level function definition."""
    fname = func.name

    # Refined parameter predicates (e.g. ~int x : ~value > 0)
    for param in func.params:
        if param.refined and param.predicate is not None:
            _add(
                vir,
                ObligationKind.REFINED_PARAM,
                function=fname,
                pred=param.predicate,
                note=(
                    f"caller must satisfy predicate for parameter '{param.name}'"
                    f" of '{fname}'"
                ),
            )

    # Function spec block (requires / ensures / invariants)
    if func.spec is not None:
        _collect_spec_block(vir, fname, func.spec)

    # Nested loop / control-flow invariants in the body
    _collect_stmts(vir, fname, func.body)


def _collect_class(vir: VirModule, cls: ast.ClassDef) -> None:
    """Collect class invariants and method obligations."""

    # Class-level spec invariants
    for inv in cls.invariants:
        _add(
            vir,
            ObligationKind.CLASS_INVARIANT,
            function=None,
            pred=inv,
            note=f"class '{cls.name}' structural invariant must hold",
        )

    # Per-method obligations
    for method in cls.methods:
        qname = f"{cls.name}.{method.name}"

        for param in method.params:
            if param.refined and param.predicate is not None:
                _add(
                    vir,
                    ObligationKind.REFINED_PARAM,
                    function=qname,
                    pred=param.predicate,
                    note=(
                        f"caller must satisfy predicate for parameter "
                        f"'{param.name}' of '{qname}'"
                    ),
                )

        if method.spec is not None:
            _collect_spec_block(vir, qname, method.spec)

        _collect_stmts(vir, qname, method.body)


def _collect_spec_block(
    vir: VirModule,
    func_name: str,
    spec: ast.SpecBlock,
) -> None:
    """Extract requires / ensures / invariants from a SpecBlock."""
    for pred in spec.requires:
        _add(
            vir,
            ObligationKind.REQUIRES,
            function=func_name,
            pred=pred,
            note=f"pre-condition of '{func_name}'",
        )

    for pred in spec.ensures:
        _add(
            vir,
            ObligationKind.ENSURES,
            function=func_name,
            pred=pred,
            note=f"post-condition of '{func_name}'",
        )

    for inv in spec.invariants:
        _add(
            vir,
            ObligationKind.INVARIANT,
            function=func_name,
            pred=inv,
            note=f"spec invariant in '{func_name}'",
        )


def _collect_stmts(
    vir: VirModule,
    func_name: str,
    stmts: List[ast.Stmt],
) -> None:
    """Recursively collect invariants from control-flow statements."""
    for stmt in stmts:
        if isinstance(stmt, ast.WhileStmt):
            for inv in stmt.invariants:
                _add(
                    vir,
                    ObligationKind.INVARIANT,
                    function=func_name,
                    pred=inv,
                    note=f"while-loop invariant in '{func_name}' must hold on every iteration",
                )
            _collect_stmts(vir, func_name, stmt.body)

        elif isinstance(stmt, ast.ForStmt):
            for inv in stmt.invariants:
                _add(
                    vir,
                    ObligationKind.INVARIANT,
                    function=func_name,
                    pred=inv,
                    note=(
                        f"for-loop invariant in '{func_name}' must hold on every"
                        f" iteration (loop variable: '{stmt.name}')"
                    ),
                )
            _collect_stmts(vir, func_name, stmt.body)

        elif isinstance(stmt, ast.RepeatStmt):
            for inv in stmt.invariants:
                _add(
                    vir,
                    ObligationKind.INVARIANT,
                    function=func_name,
                    pred=inv,
                    note=f"repeat-loop invariant in '{func_name}' must hold on every iteration",
                )
            _collect_stmts(vir, func_name, stmt.body)

        elif isinstance(stmt, ast.IfStmt):
            _collect_stmts(vir, func_name, stmt.then_body)
            for _, body in stmt.elifs:
                _collect_stmts(vir, func_name, body)
            if stmt.else_body:
                _collect_stmts(vir, func_name, stmt.else_body)

        elif isinstance(stmt, ast.SwitchStmt):
            for case in stmt.cases:
                _collect_stmts(vir, func_name, case.body)
            if stmt.default_body:
                _collect_stmts(vir, func_name, stmt.default_body)

        elif isinstance(stmt, (ast.UnsafeBlock, ast.ArenaStmt)):
            _collect_stmts(vir, func_name, stmt.body)


# ---------------------------------------------------------------------------
# Lightweight static discharge
# ---------------------------------------------------------------------------


def _static_discharge(vir: VirModule) -> None:
    """
    Attempt to statically discharge trivially-true proof obligations.

    Handles:
      - Boolean literal ``true``
      - Literal-vs-literal comparisons (constant folding)
      - Conjunctions (``and``) where both sides are trivially true
      - Negations of trivially-false literals

    Per YUP 26.1.5 §5: the default verify level is "check", which means
    warnings are emitted for UNPROVEN obligations.  PROVED obligations are
    silently accepted.  This pass discharges the easy ones so that the user
    only sees diagnostics for genuinely hard obligations.
    """
    for ob in vir.obligations:
        if ob.status != VerificationStatus.UNPROVEN:
            continue
        if _is_trivially_true(ob.predicate):
            ob.status = VerificationStatus.PROVED


def _is_trivially_true(expr: ast.Expr) -> bool:
    """
    Return True if *expr* can be statically evaluated to ``true``.

    This is a best-effort constant-folder; it does not attempt full symbolic
    execution.  Unknown expressions are conservatively treated as unproven.
    """

    # ---- Literals ----
    if isinstance(expr, ast.BoolLiteral):
        return expr.value

    # ---- Integer / float literal comparisons ----
    if isinstance(expr, ast.BinaryOp):
        op = expr.op

        if op in {"==", "!=", "<", "<=", ">", ">="}:
            if isinstance(expr.left, ast.IntLiteral) and isinstance(
                expr.right, ast.IntLiteral
            ):
                a, b = expr.left.value, expr.right.value
                return _cmp(op, a, b)
            if isinstance(expr.left, ast.FloatLiteral) and isinstance(
                expr.right, ast.FloatLiteral
            ):
                a, b = expr.left.value, expr.right.value
                return _cmp(op, a, b)
            # Same variable compared with itself: x == x, x <= x, x >= x
            if op in {"==", "<=", ">="} and _same_var(expr.left, expr.right):
                return True
            if op in {"<", ">"} and _same_var(expr.left, expr.right):
                return False  # x < x is always false; mark unproven → False means we don't discharge

        # ---- Logical conjunction: both sides must be trivially true ----
        if op == "and":
            return _is_trivially_true(expr.left) and _is_trivially_true(expr.right)

        # ---- Logical disjunction: at least one side trivially true ----
        if op == "or":
            return _is_trivially_true(expr.left) or _is_trivially_true(expr.right)

    # ---- Logical negation ----
    if isinstance(expr, ast.UnaryOp) and expr.op == "!":
        # !(false) == true
        if isinstance(expr.operand, ast.BoolLiteral):
            return not expr.operand.value
        # !(x != x) == true  (but we'd need equality; skip)

    return False


def _cmp(op: str, a: object, b: object) -> bool:
    """Apply a comparison operator to two comparable Python values."""
    if op == "==":
        return a == b  # type: ignore[operator]
    if op == "!=":
        return a != b  # type: ignore[operator]
    if op == "<":
        return a < b  # type: ignore[operator]
    if op == "<=":
        return a <= b  # type: ignore[operator]
    if op == ">":
        return a > b  # type: ignore[operator]
    if op == ">=":
        return a >= b  # type: ignore[operator]
    return False


def _same_var(left: ast.Expr, right: ast.Expr) -> bool:
    """Return True if both expressions refer to the same named variable."""
    return (
        isinstance(left, ast.VarRef)
        and isinstance(right, ast.VarRef)
        and left.name == right.name
    )


# ---------------------------------------------------------------------------
# Constitutional verification helpers  (YUP 26.1.3 Article I/II/IV)
# ---------------------------------------------------------------------------


@dataclass
class ConstitutionalViolation:
    """
    A constitutional violation detected during static analysis.

    Per YUP 26.1.4 §3.2 (Constitutional Verification Pass) and
    YUP 26.1.3, violations halt compilation with a diagnostic of the form:
      ``CONSTITUTIONAL_VIOLATION: [Article X.Y]: <message>``
    """

    article: str  # e.g. "II.1", "IV.1"
    message: str
    line: int
    column: int

    def format(self) -> str:
        return (
            f"{self.line}:{self.column}: error: "
            f"CONSTITUTIONAL_VIOLATION: [Article {self.article}]: {self.message}"
        )


def check_constitution(program: ast.Program) -> List[ConstitutionalViolation]:
    """
    Perform a lightweight constitutional audit of the program.

    Checks currently implemented:

    Article I.1 – Compiler as Proof Assistant:
      - Warn (via VIR) when spec blocks have no requires/ensures (vacuous contracts).
        (Full proof assistant enforcement requires an external prover.)

    Article II.1 – No Magic / No Hidden Control Flow:
      - Unsafe blocks must be wrapped in #[unsafe] or an unsafe function.
        (Already enforced in sema.py; repeated here for belt-and-suspenders.)

    Article II.3 – Cost Must Be Apparent:
      - Functions annotated [thread] that return non-ThreadId are flagged.

    Article IV.1 – Against Global Entropy:
      - Global mutable state is always forbidden.  The program block is
        allowed to hold initialised bindings, but re-assignment of those
        bindings is tracked by the semantic analyser.

    Returns a list of ConstitutionalViolation records (may be empty).
    """
    violations: List[ConstitutionalViolation] = []

    for func in program.functions:
        # Article II.3: thread functions must return ThreadId
        if "thread" in func.modifiers:
            ret_name = _type_expr_name(func.return_type)
            if ret_name not in {"ThreadId", "void", "Unit"}:
                violations.append(
                    ConstitutionalViolation(
                        article="II.3",
                        message=(
                            f"thread function '{func.name}' return type should be ThreadId"
                            f" (cost must be apparent — got '{ret_name}')"
                        ),
                        line=func.line,
                        column=func.column,
                    )
                )

        # Article I.1: const functions with non-trivial bodies should have specs
        if "const" in func.modifiers and func.spec is None and len(func.body) > 2:
            violations.append(
                ConstitutionalViolation(
                    article="I.1",
                    message=(
                        f"const function '{func.name}' has no spec block; "
                        f"consider adding spec: requires/ensures to enable proof assistant"
                    ),
                    line=func.line,
                    column=func.column,
                )
            )

    return violations


def _type_expr_name(te: ast.TypeExpr) -> str:
    """Best-effort extraction of a simple type name from a TypeExpr node."""
    if isinstance(te, ast.TypeName):
        return te.name
    if isinstance(te, ast.TypeApply):
        return te.name
    return ""
