from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass(frozen=True)
class Directive:
    kind: str
    payload: object


class TypeExpr:
    line: int
    column: int


@dataclass(frozen=True)
class TypeName(TypeExpr):
    name: str
    line: int
    column: int


@dataclass(frozen=True)
class TypeArray(TypeExpr):
    element: TypeExpr
    size: int
    line: int
    column: int


@dataclass(frozen=True)
class TypeDArray(TypeExpr):
    element: TypeExpr
    line: int
    column: int


@dataclass(frozen=True)
class TypeRef(TypeExpr):
    element: TypeExpr
    mutable: bool
    line: int
    column: int


@dataclass(frozen=True)
class TypeGc(TypeExpr):
    element: TypeExpr
    line: int
    column: int


@dataclass(frozen=True)
class TypeApply(TypeExpr):
    name: str
    args: List[TypeExpr]
    line: int
    column: int


@dataclass
class Program:
    directives: List[Directive]
    classes: List["ClassDef"]
    traits: List["TraitDef"]
    impls: List["ImplDef"]
    functions: List["FunctionDef"]
    main_block: List["Stmt"]


@dataclass
class FunctionDef:
    name: str
    type_params: List[str]
    params: List["Param"]
    return_type: TypeExpr
    where_bounds: List[Tuple[str, str]]
    body: List["Stmt"]
    modifiers: List[str]
    line: int
    column: int


@dataclass
class FieldDef:
    type_name: TypeExpr
    name: str
    line: int
    column: int


@dataclass
class ClassDef:
    name: str
    base: Optional[str]
    modifiers: List[str]
    fields: List[FieldDef]
    methods: List[FunctionDef]
    line: int
    column: int


@dataclass
class TraitMethodSig:
    name: str
    type_params: List[str]
    params: List["Param"]
    return_type: TypeExpr
    where_bounds: List[Tuple[str, str]]
    modifiers: List[str]
    line: int
    column: int


@dataclass
class TraitDef:
    name: str
    type_params: List[str]
    methods: List[TraitMethodSig]
    line: int
    column: int


@dataclass
class ImplDef:
    trait_name: str
    for_type: TypeExpr
    methods: List[FunctionDef]
    line: int
    column: int


@dataclass
class Param:
    type_name: TypeExpr
    name: str
    default: Optional["Expr"]
    line: int
    column: int


class Stmt:
    line: int
    column: int


@dataclass
class VarDecl(Stmt):
    type_name: TypeExpr
    name: str
    value: "Expr"
    line: int
    column: int


@dataclass
class Assign(Stmt):
    name: str
    value: "Expr"
    line: int
    column: int


@dataclass
class AssignMember(Stmt):
    target: "Expr"
    name: str
    value: "Expr"
    line: int
    column: int


@dataclass
class AssignIndex(Stmt):
    target: "Expr"
    index: "Expr"
    value: "Expr"
    line: int
    column: int


@dataclass
class IfStmt(Stmt):
    condition: "Expr"
    then_body: List["Stmt"]
    elifs: List[Tuple["Expr", List["Stmt"]]]
    else_body: List["Stmt"]
    line: int
    column: int


@dataclass
class WhileStmt(Stmt):
    condition: "Expr"
    body: List["Stmt"]
    line: int
    column: int


@dataclass
class ForStmt(Stmt):
    var_type: TypeExpr
    name: str
    start: "Expr"
    end: "Expr"
    step: Optional["Expr"]
    body: List["Stmt"]
    line: int
    column: int


@dataclass
class RepeatStmt(Stmt):
    body: List["Stmt"]
    condition: "Expr"
    line: int
    column: int


@dataclass
class SwitchCase:
    value: "Pattern"
    body: List["Stmt"]


@dataclass
class SwitchStmt(Stmt):
    expr: "Expr"
    cases: List[SwitchCase]
    default_body: List["Stmt"]
    line: int
    column: int


@dataclass
class BreakStmt(Stmt):
    line: int
    column: int


@dataclass
class ContinueStmt(Stmt):
    line: int
    column: int


@dataclass
class ReturnStmt(Stmt):
    value: Optional["Expr"]
    line: int
    column: int


@dataclass
class DelStmt(Stmt):
    target: "Expr"
    line: int
    column: int


@dataclass
class ExprStmt(Stmt):
    expr: "Expr"
    line: int
    column: int


class Expr:
    line: int
    column: int


@dataclass
class IntLiteral(Expr):
    value: int
    line: int
    column: int


@dataclass
class FloatLiteral(Expr):
    value: float
    line: int
    column: int


@dataclass
class BoolLiteral(Expr):
    value: bool
    line: int
    column: int


@dataclass
class StringLiteral(Expr):
    value: str
    line: int
    column: int


@dataclass
class CharLiteral(Expr):
    value: str
    line: int
    column: int


@dataclass
class VarRef(Expr):
    name: str
    line: int
    column: int


@dataclass
class UnaryOp(Expr):
    op: str
    operand: Expr
    line: int
    column: int


@dataclass
class BinaryOp(Expr):
    op: str
    left: Expr
    right: Expr
    line: int
    column: int


@dataclass
class Call(Expr):
    callee: str
    args: List[Expr]
    type_args: List[TypeExpr]
    line: int
    column: int


@dataclass
class ArrayLiteral(Expr):
    items: List[Expr]
    line: int
    column: int


@dataclass
class IndexExpr(Expr):
    target: Expr
    index: Expr
    line: int
    column: int


@dataclass
class MemberAccess(Expr):
    target: Expr
    name: str
    line: int
    column: int


@dataclass
class MethodCall(Expr):
    target: Expr
    name: str
    type_args: List[TypeExpr]
    args: List[Expr]
    line: int
    column: int


@dataclass
class NewExpr(Expr):
    type_expr: TypeExpr
    args: List[Expr]
    line: int
    column: int


class Pattern:
    line: int
    column: int


@dataclass
class PatternLiteral(Pattern):
    value: Expr
    line: int
    column: int


@dataclass
class PatternConstructor(Pattern):
    name: str
    args: List[str]
    line: int
    column: int


@dataclass
class PatternWildcard(Pattern):
    line: int
    column: int
