from dataclasses import dataclass
from typing import List

from .errors import Diagnostic, YadroError
from .token import Token


KEYWORDS = {
    "fun",
    "if",
    "elsif",
    "else",
    "while",
    "for",
    "in",
    "range",
    "switch",
    "case",
    "default",
    "repeat",
    "until",
    "arena",
    "class",
    "trait",
    "protocol",
    "impl",
    "for",
    "where",
    "temp",
    "new",
    "del",
    "break",
    "continue",
    "return",
    "const",
    "async",
    "thread",
    "mut",
    "true",
    "false",
    "and",
    "or",
    "xor",
    "nand",
    "spec",
    "requires",
    "ensures",
    "invariant",
    "asm",
}

TYPES = {"int", "float", "bool", "string", "char", "Unit", "void", "ThreadId"}


@dataclass(frozen=True)
class LexedLine:
    line_no: int
    indent: int
    content: str


class Lexer:
    def __init__(self, source: str):
        self.source = self._strip_block_comments(source)

    def tokenize(self) -> List[Token]:
        tokens: List[Token] = []
        lines = self._prepare_lines(self.source)
        indent_stack = [0]
        for line in lines:
            if not line.content.strip():
                continue
            if line.content.lstrip().startswith("//"):
                continue
            indent = line.indent
            if indent % 4 != 0:
                raise YadroError(Diagnostic("Indentation must be multiple of 4 spaces", line.line_no, 1))
            if indent > indent_stack[-1]:
                indent_stack.append(indent)
                tokens.append(Token("INDENT", "", line.line_no, 1))
            while indent < indent_stack[-1]:
                indent_stack.pop()
                tokens.append(Token("DEDENT", "", line.line_no, 1))
            stripped = line.content.strip()
            if stripped == "#start":
                tokens.append(Token("START", "", line.line_no, 1))
                tokens.append(Token("NEWLINE", "", line.line_no, len(line.content)))
                continue
            if stripped == "#end":
                tokens.append(Token("END", "", line.line_no, 1))
                tokens.append(Token("NEWLINE", "", line.line_no, len(line.content)))
                continue
            tokens.extend(self._tokenize_line(line))
            tokens.append(Token("NEWLINE", "", line.line_no, len(line.content)))
        while len(indent_stack) > 1:
            indent_stack.pop()
            tokens.append(Token("DEDENT", "", lines[-1].line_no if lines else 1, 1))
        tokens.append(Token("EOF", "", lines[-1].line_no if lines else 1, 1))
        return tokens

    def _prepare_lines(self, source: str) -> List[LexedLine]:
        result = []
        for line_no, raw in enumerate(source.splitlines(), start=1):
            expanded = raw.replace("\t", "    ")
            indent = len(expanded) - len(expanded.lstrip(" "))
            content = expanded.rstrip("\n")
            result.append(LexedLine(line_no, indent, content))
        return result

    def _strip_block_comments(self, source: str) -> str:
        result = []
        i = 0
        while i < len(source):
            if source[i] == "/" and i + 1 < len(source) and source[i + 1] == "*":
                i += 2
                while i < len(source):
                    if source[i] == "*" and i + 1 < len(source) and source[i + 1] == "/":
                        i += 2
                        break
                    if source[i] == "\n":
                        result.append("\n")
                    else:
                        result.append(" ")
                    i += 1
                else:
                    raise YadroError(Diagnostic("Unterminated block comment", 1, 1))
                continue
            result.append(source[i])
            i += 1
        return "".join(result)

    def _tokenize_line(self, line: LexedLine) -> List[Token]:
        tokens: List[Token] = []
        content = line.content
        pos = line.indent
        while pos < len(content):
            ch = content[pos]
            if ch.isspace():
                pos += 1
                continue
            if ch == "/" and pos + 1 < len(content) and content[pos + 1] == "/":
                break
            if ch.isdigit():
                start = pos
                if ch == "0" and pos + 1 < len(content) and content[pos + 1] in {"x", "X"}:
                    pos += 2
                    while pos < len(content) and content[pos].isalnum():
                        pos += 1
                    tokens.append(Token("INT", content[start:pos], line.line_no, start + 1))
                else:
                    pos += 1
                    while pos < len(content) and content[pos].isdigit():
                        pos += 1
                    if pos < len(content) and content[pos] == ".":
                        pos += 1
                        while pos < len(content) and content[pos].isdigit():
                            pos += 1
                        tokens.append(Token("FLOAT", content[start:pos], line.line_no, start + 1))
                    else:
                        tokens.append(Token("INT", content[start:pos], line.line_no, start + 1))
                continue
            if ch.isalpha() or ch == "_":
                start = pos
                pos += 1
                while pos < len(content) and (content[pos].isalnum() or content[pos] == "_"):
                    pos += 1
                text = content[start:pos]
                if text in KEYWORDS:
                    tokens.append(Token(text.upper(), text, line.line_no, start + 1))
                elif text in TYPES:
                    tokens.append(Token("TYPE", text, line.line_no, start + 1))
                else:
                    tokens.append(Token("IDENT", text, line.line_no, start + 1))
                continue
            if ch == "\"":
                start = pos
                pos += 1
                escaped = False
                value = ""
                while pos < len(content):
                    c = content[pos]
                    if escaped:
                        if c == "n":
                            value += "\n"
                        elif c == "t":
                            value += "\t"
                        else:
                            value += c
                        escaped = False
                        pos += 1
                        continue
                    if c == "\\":
                        escaped = True
                        pos += 1
                        continue
                    if c == "\"":
                        pos += 1
                        tokens.append(Token("STRING", value, line.line_no, start + 1))
                        break
                    value += c
                    pos += 1
                else:
                    raise YadroError(Diagnostic("Unterminated string literal", line.line_no, start + 1))
                continue
            if ch == "#" and pos + 1 < len(content) and content[pos + 1] == "[":
                tokens.append(Token("ATTR", "#[", line.line_no, pos + 1))
                pos += 2
                continue
            if ch == "'":
                start = pos
                pos += 1
                escaped = False
                value = ""
                while pos < len(content):
                    c = content[pos]
                    if escaped:
                        if c == "n":
                            value = "\n"
                        elif c == "t":
                            value = "\t"
                        elif c == "'":
                            value = "'"
                        elif c == "\\":
                            value = "\\"
                        else:
                            value = c
                        escaped = False
                        pos += 1
                        continue
                    if c == "\\":
                        escaped = True
                        pos += 1
                        continue
                    if c == "'":
                        pos += 1
                        if len(value) != 1:
                            raise YadroError(Diagnostic("Char literal must be a single character", line.line_no, start + 1))
                        tokens.append(Token("CHAR", value, line.line_no, start + 1))
                        break
                    value += c
                    pos += 1
                else:
                    raise YadroError(Diagnostic("Unterminated char literal", line.line_no, start + 1))
                continue
            three = content[pos : pos + 3]
            if three in {">>>", "<<<"}:
                tokens.append(Token(three, three, line.line_no, pos + 1))
                pos += 3
                continue
            two = content[pos : pos + 2]
            if two in {"->", "==", "!=", "<=", ">=", "+=", "-=", "*=", "/=", "%=", "<<", ">>", "<<=", ">>=", "&=", "|=", "^=", "@=", "$="}:
                tokens.append(Token(two, two, line.line_no, pos + 1))
                pos += 2
                continue
            if ch in "()[]{};,.:+-*/%<>!=&?|^~":
                tokens.append(Token(ch, ch, line.line_no, pos + 1))
                pos += 1
                continue
            raise YadroError(Diagnostic(f"Unexpected character '{ch}'", line.line_no, pos + 1))
        return tokens
