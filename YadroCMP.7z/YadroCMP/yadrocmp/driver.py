import copy
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from . import ast
from .codegen import emit_llvm_ir, emit_object
from .errors import Diagnostic, YadroError
from .lexer import Lexer
from .mir import lower_to_mir
from .parser import Parser
from .sema import SemanticAnalyzer


def parse_directives(source: str) -> Tuple[List[ast.Directive], str]:
    lines = source.splitlines()
    directives: List[ast.Directive] = []
    remaining: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped in {"#start", "#end"}:
            remaining.append(line)
            i += 1
            continue
        if stripped.startswith("#target"):
            i += 1
            payload = {}
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                if "=" in s:
                    key, value = s.split("=", 1)
                    payload[key.strip()] = _strip_quotes(value.strip())
                i += 1
            directives.append(ast.Directive("target", payload))
            continue
        if stripped.startswith("#import"):
            i += 1
            modules = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                if " as " in s:
                    mod, alias = s.split(" as ", 1)
                    modules.append((mod.strip(), alias.strip()))
                else:
                    modules.append((s, None))
                i += 1
            directives.append(ast.Directive("import", modules))
            continue
        if stripped.startswith("#requires"):
            i += 1
            libs = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                libs.append(_strip_quotes(s))
                i += 1
            directives.append(ast.Directive("requires", libs))
            continue
        if stripped.startswith("#plugin"):
            i += 1
            plugins = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                plugins.append(s)
                i += 1
            directives.append(ast.Directive("plugin", plugins))
            continue
        remaining.append(line)
        i += 1
    return directives, "\n".join(remaining)


def compile_source(source: str, emit: str = "llvm", base_dir: Path | None = None) -> bytes | str:
    if base_dir is None:
        base_dir = Path.cwd()
    module_cache: Dict[Path, ast.Program] = {}
    directives, code = parse_directives(source)
    program = _parse_program(code, directives)
    program = _merge_with_imports(program, base_dir, module_cache, set())
    semantic = SemanticAnalyzer().analyze(program)
    mir = lower_to_mir(semantic)
    if emit == "llvm":
        return emit_llvm_ir(mir)
    if emit == "obj":
        return emit_object(mir)
    raise YadroError(Diagnostic(f"Unknown emit mode '{emit}'", 1, 1))


def compile_file(path: str, output: str, emit: str = "llvm") -> None:
    source = Path(path).read_text(encoding="utf-8")
    result = compile_source(source, emit=emit, base_dir=Path(path).parent)
    out_path = Path(output)
    if emit == "obj":
        out_path.write_bytes(result if isinstance(result, bytes) else result.encode("utf-8"))
    else:
        out_path.write_text(result if isinstance(result, str) else result.decode("utf-8"), encoding="utf-8")


def _strip_quotes(value: str) -> str:
    if value.startswith("\"") and value.endswith("\"") and len(value) >= 2:
        return value[1:-1]
    return value


def _parse_program(code: str, directives: List[ast.Directive]) -> ast.Program:
    tokens = Lexer(code).tokenize()
    return Parser(tokens).parse(directives)


def _merge_with_imports(
    program: ast.Program,
    base_dir: Path,
    cache: Dict[Path, ast.Program],
    visiting: Set[Path],
) -> ast.Program:
    imported_programs: List[ast.Program] = []
    for directive in program.directives:
        if directive.kind != "import":
            continue
        modules = directive.payload
        if not isinstance(modules, list):
            continue
        for module, alias in modules:
            module_path = _resolve_module_path(module, base_dir)
            imported = _load_module(module_path, base_dir, cache, visiting)
            namespace = _module_alias(module, alias)
            if namespace:
                imported = _namespace_program(imported, f"{namespace}.")
            imported_programs.append(imported)
    if not imported_programs:
        return program
    merged = ast.Program(
        directives=program.directives,
        classes=[],
        traits=[],
        impls=[],
        functions=[],
        main_block=program.main_block,
    )
    for imported in imported_programs:
        if imported.main_block:
            raise YadroError(Diagnostic("Imported module must not contain #start/#end block", 1, 1))
        merged.classes.extend(imported.classes)
        merged.traits.extend(imported.traits)
        merged.impls.extend(imported.impls)
        merged.functions.extend(imported.functions)
    merged.classes.extend(program.classes)
    merged.traits.extend(program.traits)
    merged.impls.extend(program.impls)
    merged.functions.extend(program.functions)
    return merged


def _load_module(
    path: Path,
    base_dir: Path,
    cache: Dict[Path, ast.Program],
    visiting: Set[Path],
) -> ast.Program:
    resolved = path.resolve()
    if resolved in cache:
        return cache[resolved]
    if resolved in visiting:
        raise YadroError(Diagnostic(f"Cyclic import detected for '{resolved}'", 1, 1))
    if not resolved.exists():
        raise YadroError(Diagnostic(f"Import not found: '{resolved}'", 1, 1))
    visiting.add(resolved)
    source = resolved.read_text(encoding="utf-8")
    directives, code = parse_directives(source)
    program = _parse_program(code, directives)
    program = _merge_with_imports(program, resolved.parent, cache, visiting)
    cache[resolved] = program
    visiting.remove(resolved)
    return program


def _resolve_module_path(module: str, base_dir: Path) -> Path:
    module_path = Path(module)
    if module_path.suffix == ".yad":
        return base_dir / module_path
    if "." in module:
        parts = module.split(".")
        module_path = Path(*parts)
    return (base_dir / module_path).with_suffix(".yad")


def _module_alias(module: str, alias: Optional[str]) -> str:
    if alias:
        return alias
    normalized = module.replace("\\", "/")
    last = normalized.split("/")[-1]
    if last.endswith(".yad"):
        last = Path(last).stem
    if "." in last:
        last = last.split(".")[-1]
    return last


def _namespace_program(program: ast.Program, prefix: str) -> ast.Program:
    namespaced = copy.deepcopy(program)
    local_classes = {cls.name for cls in namespaced.classes}
    local_traits = {tr.name for tr in namespaced.traits}
    local_functions = {fn.name for fn in namespaced.functions}
    class_map = {name: f"{prefix}{name}" for name in local_classes}
    trait_map = {name: f"{prefix}{name}" for name in local_traits}
    func_map = {name: f"{prefix}{name}" for name in local_functions}
    local_types = local_classes | local_traits

    def rewrite_type(type_expr: ast.TypeExpr) -> ast.TypeExpr:
        if isinstance(type_expr, ast.TypeName):
            name = class_map.get(type_expr.name) or trait_map.get(type_expr.name)
            if name:
                return ast.TypeName(name, type_expr.line, type_expr.column)
            return type_expr
        if isinstance(type_expr, ast.TypeArray):
            element = rewrite_type(type_expr.element)
            return ast.TypeArray(element, type_expr.size, type_expr.line, type_expr.column)
        if isinstance(type_expr, ast.TypeDArray):
            element = rewrite_type(type_expr.element)
            return ast.TypeDArray(element, type_expr.line, type_expr.column)
        if isinstance(type_expr, ast.TypeRef):
            element = rewrite_type(type_expr.element)
            return ast.TypeRef(element, type_expr.mutable, type_expr.line, type_expr.column)
        if isinstance(type_expr, ast.TypeGc):
            element = rewrite_type(type_expr.element)
            return ast.TypeGc(element, type_expr.line, type_expr.column)
        if isinstance(type_expr, ast.TypeGcWeak):
            element = rewrite_type(type_expr.element)
            return ast.TypeGcWeak(element, type_expr.line, type_expr.column)
        if isinstance(type_expr, ast.TypeApply):
            name = class_map.get(type_expr.name) or trait_map.get(type_expr.name) or type_expr.name
            args = [rewrite_type(arg) for arg in type_expr.args]
            return ast.TypeApply(name, args, type_expr.line, type_expr.column)
        return type_expr

    def rewrite_where_bounds(bounds: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        rewritten: List[Tuple[str, str]] = []
        for name, trait in bounds:
            rewritten.append((name, trait_map.get(trait, trait)))
        return rewritten

    def rewrite_expr(expr: ast.Expr) -> ast.Expr:
        if isinstance(expr, ast.VarRef):
            name = class_map.get(expr.name)
            if name:
                return ast.VarRef(name, expr.line, expr.column)
            return expr
        if isinstance(expr, ast.UnaryOp):
            return ast.UnaryOp(expr.op, rewrite_expr(expr.operand), expr.line, expr.column)
        if isinstance(expr, ast.BinaryOp):
            return ast.BinaryOp(expr.op, rewrite_expr(expr.left), rewrite_expr(expr.right), expr.line, expr.column)
        if isinstance(expr, ast.Call):
            callee = func_map.get(expr.callee) or class_map.get(expr.callee) or expr.callee
            args = [rewrite_expr(arg) for arg in expr.args]
            type_args = [rewrite_type(arg) for arg in expr.type_args]
            return ast.Call(callee, args, type_args, expr.line, expr.column)
        if isinstance(expr, ast.TryExpr):
            return ast.TryExpr(rewrite_expr(expr.expr), expr.line, expr.column)
        if isinstance(expr, ast.ArrayLiteral):
            return ast.ArrayLiteral([rewrite_expr(item) for item in expr.items], expr.line, expr.column)
        if isinstance(expr, ast.IndexExpr):
            return ast.IndexExpr(rewrite_expr(expr.target), rewrite_expr(expr.index), expr.line, expr.column)
        if isinstance(expr, ast.MemberAccess):
            return ast.MemberAccess(rewrite_expr(expr.target), expr.name, expr.line, expr.column)
        if isinstance(expr, ast.MethodCall):
            type_args = [rewrite_type(arg) for arg in expr.type_args]
            args = [rewrite_expr(arg) for arg in expr.args]
            return ast.MethodCall(rewrite_expr(expr.target), expr.name, type_args, args, expr.line, expr.column)
        if isinstance(expr, ast.NewExpr):
            return ast.NewExpr(rewrite_type(expr.type_expr), [rewrite_expr(arg) for arg in expr.args], expr.line, expr.column)
        return expr

    def rewrite_stmt(stmt: ast.Stmt) -> ast.Stmt:
        if isinstance(stmt, ast.VarDecl):
            return ast.VarDecl(rewrite_type(stmt.type_name), stmt.name, rewrite_expr(stmt.value), stmt.line, stmt.column)
        if isinstance(stmt, ast.Assign):
            return ast.Assign(stmt.name, rewrite_expr(stmt.value), stmt.line, stmt.column)
        if isinstance(stmt, ast.AssignMember):
            return ast.AssignMember(rewrite_expr(stmt.target), stmt.name, rewrite_expr(stmt.value), stmt.line, stmt.column)
        if isinstance(stmt, ast.AssignIndex):
            return ast.AssignIndex(rewrite_expr(stmt.target), rewrite_expr(stmt.index), rewrite_expr(stmt.value), stmt.line, stmt.column)
        if isinstance(stmt, ast.IfStmt):
            then_body = [rewrite_stmt(s) for s in stmt.then_body]
            elifs = [(rewrite_expr(cond), [rewrite_stmt(s) for s in body]) for cond, body in stmt.elifs]
            else_body = [rewrite_stmt(s) for s in stmt.else_body]
            return ast.IfStmt(rewrite_expr(stmt.condition), then_body, elifs, else_body, stmt.line, stmt.column)
        if isinstance(stmt, ast.WhileStmt):
            return ast.WhileStmt(rewrite_expr(stmt.condition), [rewrite_stmt(s) for s in stmt.body], stmt.line, stmt.column)
        if isinstance(stmt, ast.ForStmt):
            return ast.ForStmt(
                rewrite_type(stmt.var_type),
                stmt.name,
                rewrite_expr(stmt.start),
                rewrite_expr(stmt.end),
                rewrite_expr(stmt.step) if stmt.step is not None else None,
                [rewrite_stmt(s) for s in stmt.body],
                stmt.line,
                stmt.column,
            )
        if isinstance(stmt, ast.RepeatStmt):
            return ast.RepeatStmt([rewrite_stmt(s) for s in stmt.body], rewrite_expr(stmt.condition), stmt.line, stmt.column)
        if isinstance(stmt, ast.ArenaStmt):
            return ast.ArenaStmt([rewrite_stmt(s) for s in stmt.body], stmt.line, stmt.column)
        if isinstance(stmt, ast.SwitchStmt):
            cases: List[ast.SwitchCase] = []
            for case in stmt.cases:
                if isinstance(case.value, ast.PatternLiteral):
                    value = ast.PatternLiteral(rewrite_expr(case.value.value), case.value.line, case.value.column)
                elif isinstance(case.value, ast.PatternConstructor):
                    name = class_map.get(case.value.name) or case.value.name
                    value = ast.PatternConstructor(name, case.value.args, case.value.line, case.value.column)
                else:
                    value = case.value
                cases.append(ast.SwitchCase(value, [rewrite_stmt(s) for s in case.body]))
            return ast.SwitchStmt(
                rewrite_expr(stmt.expr),
                cases,
                [rewrite_stmt(s) for s in stmt.default_body],
                stmt.line,
                stmt.column,
            )
        if isinstance(stmt, ast.ReturnStmt):
            return ast.ReturnStmt(rewrite_expr(stmt.value) if stmt.value is not None else None, stmt.line, stmt.column)
        if isinstance(stmt, ast.DelStmt):
            return ast.DelStmt(rewrite_expr(stmt.target), stmt.line, stmt.column)
        if isinstance(stmt, ast.ExprStmt):
            return ast.ExprStmt(rewrite_expr(stmt.expr), stmt.line, stmt.column)
        return stmt

    for cls in namespaced.classes:
        cls.name = class_map.get(cls.name, cls.name)
        if cls.base in class_map:
            cls.base = class_map[cls.base]
        cls.fields = [ast.FieldDef(rewrite_type(f.type_name), f.name, f.line, f.column) for f in cls.fields]
        rewritten_methods: List[ast.FunctionDef] = []
        for method in cls.methods:
            params = [ast.Param(rewrite_type(p.type_name), p.name, rewrite_expr(p.default) if p.default else None, p.line, p.column) for p in method.params]
            method = ast.FunctionDef(
                name=method.name,
                type_params=method.type_params,
                params=params,
                return_type=rewrite_type(method.return_type),
                where_bounds=rewrite_where_bounds(method.where_bounds),
                body=[rewrite_stmt(s) for s in method.body],
                modifiers=method.modifiers,
                line=method.line,
                column=method.column,
                attributes=method.attributes,
                effects=method.effects,
                modifier_args=method.modifier_args,
            )
            rewritten_methods.append(method)
        cls.methods = rewritten_methods

    for trait in namespaced.traits:
        trait.name = trait_map.get(trait.name, trait.name)
        rewritten_methods: List[ast.TraitMethodSig] = []
        for method in trait.methods:
            params = [ast.Param(rewrite_type(p.type_name), p.name, rewrite_expr(p.default) if p.default else None, p.line, p.column) for p in method.params]
            rewritten_methods.append(
                ast.TraitMethodSig(
                    name=method.name,
                    type_params=method.type_params,
                    params=params,
                    return_type=rewrite_type(method.return_type),
                    where_bounds=rewrite_where_bounds(method.where_bounds),
                    modifiers=method.modifiers,
                    line=method.line,
                    column=method.column,
                    attributes=method.attributes,
                    modifier_args=method.modifier_args,
                )
            )
        trait.methods = rewritten_methods

    rewritten_impls: List[ast.ImplDef] = []
    for impl in namespaced.impls:
        trait_name = trait_map.get(impl.trait_name, impl.trait_name)
        methods: List[ast.FunctionDef] = []
        for method in impl.methods:
            params = [ast.Param(rewrite_type(p.type_name), p.name, rewrite_expr(p.default) if p.default else None, p.line, p.column) for p in method.params]
            methods.append(
                ast.FunctionDef(
                    name=method.name,
                    type_params=method.type_params,
                    params=params,
                    return_type=rewrite_type(method.return_type),
                    where_bounds=rewrite_where_bounds(method.where_bounds),
                    body=[rewrite_stmt(s) for s in method.body],
                    modifiers=method.modifiers,
                    line=method.line,
                    column=method.column,
                    attributes=method.attributes,
                    effects=method.effects,
                    modifier_args=method.modifier_args,
                )
            )
        rewritten_impls.append(
            ast.ImplDef(
                trait_name=trait_name,
                for_type=rewrite_type(impl.for_type),
                methods=methods,
                line=impl.line,
                column=impl.column,
                attributes=impl.attributes,
            )
        )
    namespaced.impls = rewritten_impls

    namespaced.functions = [
        ast.FunctionDef(
            name=func_map.get(fn.name, fn.name),
            type_params=fn.type_params,
            params=[ast.Param(rewrite_type(p.type_name), p.name, rewrite_expr(p.default) if p.default else None, p.line, p.column) for p in fn.params],
            return_type=rewrite_type(fn.return_type),
            where_bounds=rewrite_where_bounds(fn.where_bounds),
            body=[rewrite_stmt(s) for s in fn.body],
            modifiers=fn.modifiers,
            line=fn.line,
            column=fn.column,
            attributes=fn.attributes,
            effects=fn.effects,
            modifier_args=fn.modifier_args,
        )
        for fn in namespaced.functions
    ]
    namespaced.main_block = [rewrite_stmt(s) for s in namespaced.main_block]
    return namespaced
