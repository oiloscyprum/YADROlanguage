from pathlib import Path
from typing import List, Tuple

from . import ast
from .codegen import emit_llvm_ir, emit_object
from .errors import Diagnostic, YadroError
from .lexer import Lexer
from .mir import lower_to_mir
from .parser import Parser
from .sema import SemanticAnalyzer


def parse_directives(source: str) -> Tuple[List[ast.Directive], str]:
    lines = source.splitlines()
    directives: List[ast.Directive] = []
    remaining: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped in {"#start", "#end"}:
            remaining.append(line)
            i += 1
            continue
        if stripped.startswith("#target"):
            i += 1
            payload = {}
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                if "=" in s:
                    key, value = s.split("=", 1)
                    payload[key.strip()] = _strip_quotes(value.strip())
                i += 1
            directives.append(ast.Directive("target", payload))
            continue
        if stripped.startswith("#import"):
            i += 1
            modules = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                if " as " in s:
                    mod, alias = s.split(" as ", 1)
                    modules.append((mod.strip(), alias.strip()))
                else:
                    modules.append((s, None))
                i += 1
            directives.append(ast.Directive("import", modules))
            continue
        if stripped.startswith("#requires"):
            i += 1
            libs = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                libs.append(_strip_quotes(s))
                i += 1
            directives.append(ast.Directive("requires", libs))
            continue
        if stripped.startswith("#plugin"):
            i += 1
            plugins = []
            while i < len(lines):
                s = lines[i].strip()
                if not s:
                    i += 1
                    break
                if s.startswith("#"):
                    break
                plugins.append(s)
                i += 1
            directives.append(ast.Directive("plugin", plugins))
            continue
        remaining.append(line)
        i += 1
    return directives, "\n".join(remaining)


def compile_source(source: str, emit: str = "llvm") -> bytes | str:
    directives, code = parse_directives(source)
    tokens = Lexer(code).tokenize()
    program = Parser(tokens).parse(directives)
    semantic = SemanticAnalyzer().analyze(program)
    mir = lower_to_mir(semantic)
    if emit == "llvm":
        return emit_llvm_ir(mir)
    if emit == "obj":
        return emit_object(mir)
    raise YadroError(Diagnostic(f"Unknown emit mode '{emit}'", 1, 1))


def compile_file(path: str, output: str, emit: str = "llvm") -> None:
    source = Path(path).read_text(encoding="utf-8")
    result = compile_source(source, emit=emit)
    out_path = Path(output)
    if emit == "obj":
        out_path.write_bytes(result if isinstance(result, bytes) else result.encode("utf-8"))
    else:
        out_path.write_text(result if isinstance(result, str) else result.decode("utf-8"), encoding="utf-8")


def _strip_quotes(value: str) -> str:
    if value.startswith("\"") and value.endswith("\"") and len(value) >= 2:
        return value[1:-1]
    return value
