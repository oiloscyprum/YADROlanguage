# YadroCMP — Отчёт: Не реализовано и частично реализовано (YUP 26.1.x)

> Этот документ является дополнением к `yadro_spec_report.implemented.md`.
> Здесь перечислено только то, что **отсутствует или реализовано с существенными пробелами**.
> Полный список реализованного — в основном отчёте.

---

## Легенда

| Статус | Описание |
|--------|----------|
| ⚠️ Частично | Есть реализация, но с существенными пробелами |
| ❌ Не реализовано | В коде полностью отсутствует |

---

## YUP 26.1.1 — Ядро языка

### Частично реализованное

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| `class[linear]` поведение | ⚠️ | Валидация: запрет `copy`, проверка `drop`, note для `&mut self` | Полноценная линейная семантика (no-escape во всех путях кода) |
| `class[actor]` поведение | ⚠️ | Валидация: требует `receive(&mut self, msg)` | Реальный actor runtime, message queue, изоляция состояния |
| GC (`gc<T>` / `gc[T]`) | ⚠️ | Inline RC-GC (alloc/inc/dec/weak_*), magic sentinel | Нет трейсинга циклических ссылок; `gc_weak` не может upgrade-аться обратно в `gc` |
| `fun[async]` | ⚠️ | `Task[T]` как LLVM-структура, флаг готовности | Нет event loop / executor; нет `await` оператора; async не приостанавливает выполнение |
| `fun[thread]` | ⚠️ | Регистрирует `ThreadId`, emits функцию в LLVM IR | Нет реального spawning через `pthread_create` или аналог; тело исполняется в том же потоке |
| Move/Borrow checker | ⚠️ | Базовая проверка moved/borrowed переменных в lexical scopes | Нет NLL (non-lexical lifetimes), нет полного lifetime анализа через CFG, нет двухфазного borrow |

### Не реализованное

| Требование | Статус | Примечание |
|---|---|---|
| Стандартная библиотека (`std.*`) | ❌ | В репозитории нет ни одного модуля `std.core`, `std.alloc`, `std.collections`, `std.os`, `std.async`, `std.math`, `std.crypto` и т.д. |
| `fun[async]` — реальный await | ❌ | `await` как оператор не парсится и не генерируется |
| Channels для inter-thread / actor коммуникации | ❌ | Нет типов `Channel[T]`, `Sender[T]`, `Receiver[T]` |
| Полноценный `copy()` метод для non-Copy типов | ❌ | `copy()` не генерируется автоматически; нет `#Copy` intrinsic |
| `gc<darray[T]>` с arena интеграцией | ❌ | Arena не интегрирована с GC heap |

---

## YUP 26.1.2 — YUPPI (пакетная система)

**Покрытие: 0%** — в репозитории нет ни одного компонента менеджера пакетов.

| Требование | Статус |
|---|---|
| Структура пакета `package-name.ymd/` | ❌ |
| Манифест `main.toml` (парсинг, валидация, секции `[package]`, `[dependencies]`, `[features]`, `[build]`, `[requires]`, `[exports]`, `[compatibility]`, `[security]`) | ❌ |
| Build-скрипт `setup.yad` | ❌ |
| `checksum.sha256` — верификация целостности файлов | ❌ |
| Алгоритм разрешения зависимостей (топологическая сортировка, semver constraints) | ❌ |
| `yadro yuppi install <pkg>[@<version>]` | ❌ |
| `yadro yuppi uninstall / update / update --all` | ❌ |
| `yadro yuppi add [-D] / remove` | ❌ |
| `yadro yuppi list / tree` | ❌ |
| `yadro yuppi init / build / test / publish / audit` | ❌ |
| `yadro yuppi search / info / versions / outdated` | ❌ |
| `yadro yuppi repo add/list/remove/update` | ❌ |
| Install с `--features`, `--repo`, `--force-reinstall`, `--dry-run` | ❌ |
| Install из локального пути и Git репозитория | ❌ |
| Repository server API (`GET /index.json`, `/packages/<name>/...`) | ❌ |
| Repository index JSON format | ❌ |
| Build cache (source cache / build cache / metadata cache) | ❌ |
| Build sandboxing (ограничение filesystem/network/syscalls во время сборки) | ❌ |
| SHA256 + PGP/GPG подписи пакетов и верификация | ❌ |
| Certificate pinning для repository connections | ❌ |
| Security audit trail (installation log с package hashes) | ❌ |
| Vulnerability database integration | ❌ |
| `yadro build` автоматически вызывает YUPPI resolver | ❌ |
| Компоненты: `yuppi-core`, `yuppi-client`, `yuppi-server`, `yuppi-registry` | ❌ |

---

## YUP 26.1.3 — Конституция

### Частично реализованное

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| Полный `YadroConstitutionPass` (YUP 26.1.4 §3.2) | ⚠️ | Articles I.1, II.1, II.3, V.Pillar1 | Articles IV.1 (global mutable state), IV.3 (side-effects в типе), II.2 (declarative config enforcement) |
| `--constitution=strict/balanced/permissive` | ⚠️ | Частично покрыто `--verify=require/check/none` | Нет явного `--constitution` флага; `permissive` не отключает safety |

### Не реализованное

| Требование | Статус |
|---|---|
| Article IV.1: статический запрет глобального изменяемого состояния | ❌ |
| Article IV.3: side-effects как часть типа функции | ❌ |
| `yadro constitution --explain <Article>` | ❌ |
| `yadro constitution --audit <package>` | ❌ |
| Machine-readable constitution JSON (`share/constitution/yup-26.1.3.json`) | ❌ |
| `CONSTITUTIONAL_VIOLATION` диагностики на уровне LLVM IR pass | ❌ |
| Governance enforcement: supermajority check для breaking changes | ❌ |

---

## YUP 26.1.4 — Стандарт компилятора

### Частично реализованное

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| MIR с Verified MIR фазой | ⚠️ | MIR с opt hints + VIR constitutional checks | Нет отдельной "Verified MIR" фазы как независимого прохода; нет расширенного alias analysis |
| LLVM optimization pipeline | ⚠️ | PassManagerBuilder (FPM + MPM, opt_level 0-3) | Конфигурация best-effort (try/except), нет target-специфичных passes, нет конституционально-опасных pass blacklist |
| `yadro compile --constitution-check-only` | ⚠️ | `yadro verify` закрывает часть этого | Нет точного флага `--constitution-check-only` без codegen |

### Не реализованное

| Требование | Статус |
|---|---|
| `yadro-check` — отдельный статический анализатор | ❌ |
| `yadro-doc` — генератор документации из исходников | ❌ |
| `yadro-lsp` — Language Server Protocol (real-time diagnostics, hover, borrow visualization) | ❌ |
| `yadro constitution --explain/--audit` | ❌ |
| Cranelift backend (альтернатива LLVM) | ❌ |
| `yadro yuppi build / test --constitution` интеграция | ❌ |
| Распределение компилятора как `yadro-cmp.ymd` | ❌ |
| `NOTICE` файл с LLVM attributions в дистрибутиве | ❌ |
| Reproducible builds (`reprotest` framework) | ❌ |
| LSP: real-time constitutional violation diagnostics | ❌ |
| LSP: borrow checker visualization | ❌ |
| LSP: effect system annotations в tooltips | ❌ |
| LSP: zero-cost abstraction cost analysis | ❌ |
| Formal methods верификация самого компилятора (CompCert-style, YUP 27.x) | ❌ |
| `yadro compile --target <triple>` cross-compilation для всех target triple | ⚠️ Частично — wasm32/gpu triple не поддерживаются кодогеном |

---

## YUP 26.1.5 — Формальная верификация

### Частично реализованное

| Требование | Статус | Что сделано | Что отсутствует |
|---|---|---|---|
| Статическая разрядка предикатов | ⚠️ | Bool literals, integer comparisons, and/or, same-var identity | Symbolic execution, algebraic simplification, внешние SMT-solvers (z3/CVC5) |
| Ghost переменные `#[ghost]` | ⚠️ | `#[ghost]` парсится как атрибут | Нет erase-before-codegen: ghost переменные попадают в LLVM IR (нарушение zero-cost guarantee) |
| `spec old(e)` | ⚠️ | `old` резолвится как обычный вызов функции | Нет специальной семантики "значение на входе функции" для frame conditions |
| `--verify=certify` | ⚠️ | Уровень принимается CLI, блокирует компиляцию при unproven | Proof certificate файлы (`.proof`) не генерируются |

### Не реализованное

| Требование | Статус |
|---|---|
| Интеграция с Why3 (bundled primary prover) | ❌ |
| Интеграция с Coq | ❌ |
| Интеграция с F* | ❌ |
| Интеграция с Crucible (symbolic execution над LLVM IR) | ❌ |
| `yadro verify --prover=why3/coq/fstar` | ❌ |
| `yadro verify --dump-obligations` — экспорт в Why3 / `.v` / F* формат | ❌ (только human-readable текст) |
| `spec_axiom` / `#[unsafe(axiom)]` с `justification:` | ❌ |
| Proof obligation generation rules (Obligation 1-4 per §3.3) через SMT | ❌ |
| Loop termination / decreasing measure | ❌ |
| Ghost variable erasure перед LLVM IR генерацией | ❌ |
| `.proof` artifact файлы рядом с `.o` | ❌ |
| Proof cache (keyed by source hash + prover version) | ❌ |
| `yadro verify --reproducible` | ❌ |
| DWARF debug info с embedded verification metadata | ❌ |
| `yadro yuppi verify --all-tests` | ❌ (YUPPI не реализован) |
| `verified = true` в `main.toml` + transitive proof chain | ❌ |
| YUPPI: verified packages могут зависеть только от verified packages | ❌ |
| Certification tiers: Bronze / Silver / Gold / Platinum | ❌ |
| Архитектура VIR §3.1: `yadro verify --dump-obligations > obligations.v` (machine-readable) | ❌ |

---

## YUP 26.1.7 — GPU Target Specialization

**Покрытие: 0%** — нет ни одной GPU-специфичной конструкции в компиляторе.

| Требование | Статус |
|---|---|
| `#target` расширения: `backend = "cuda"/"vulkan"/"metal"/"spirv"` | ❌ |
| GPU memory space типы (`@shared T`, `@global T`, `@local T`, `@constant T`) | ❌ |
| `fun[kernel]` объявления с параметрами `<<<grid, block, smem>>>` | ❌ |
| Kernel launch синтаксис | ❌ |
| Host/Device type boundary enforcement (нельзя передать `@shared` на host) | ❌ |
| GPU barrier primitives (`syncthreads`, `threadfence`, `memfence`) | ❌ |
| GPU-специфичные типы (warp-level primitives, built-in indices) | ❌ |
| SPIR-V backend | ❌ |
| NVPTX backend | ❌ |
| Constitutional Verification Pass для GPU кода | ❌ |
| GPU Safety Tiers (Basic / Cooperative / Full) | ❌ |
| `main.toml` GPU-специфичные метаданные (`[gpu]`, `compute_capability`) | ❌ |
| GPU binary distribution format (`.ptx`, `.spv`) | ❌ |
| Host/Device memory transfer API | ❌ |

---

## YUP 26.1.9 — WebAssembly GC Integration

**Покрытие: 0%** — нет WASM GC backend.

| Требование | Статус |
|---|---|
| `#target` расширения: `backend = "wasm-gc"` | ❌ |
| WASM GC heap types (`wasm_struct[T]`, `wasm_array[T]`, `wasm_funcref`, `wasm_anyref`) | ❌ |
| Dual-heap memory model (linear ownership + WASM GC collector heap) | ❌ |
| Явное повышение linear → WASM GC (`T.promote_to_gc()`) | ❌ |
| Явное понижение WASM GC → linear (`T.demote_from_gc()`) | ❌ |
| JavaScript FFI с constitutional safety (capability model) | ❌ |
| `js_capability` тип и explicit capability objects | ❌ |
| `#[js_export]` / `#[js_import]` атрибуты | ❌ |
| Type-safe JS interop без `unsafe` для базовых типов | ❌ |
| WASM GC compilation pipeline в codegen | ❌ |
| Non-determinism acknowledgment (Article IV.1) для JS GC timing | ❌ |
| WASM GC Safety Tiers (Isolated / Managed / Interop) | ❌ |
| `main.toml` WASM-специфичные метаданные (`[wasm]`, `wasi = true`) | ❌ |
| `.wasm` / `.wat` binary distribution | ❌ |
| `yadro yuppi install ... --target wasm-gc` | ❌ |

---

## Сводная таблица приоритетов реализации

### Высокий приоритет (блокирует корректность языка)

| # | Задача | Спецификация | Обоснование |
|---|---|---|---|
| 1 | Ghost variable erasure перед codegen | YUP 26.1.5 §3.2 | Нарушение zero-cost guarantee и Article II.3 Constitution |
| 2 | `spec old(e)` семантика | YUP 26.1.5 §2.1 | Без него post-conditions не могут описывать изменения состояния |
| 3 | Полный borrow checker / NLL | YUP 26.1.1 | Текущая проверка move/borrow не покрывает все случаи; язык unsafe без него |
| 4 | Article IV.1 enforcement (запрет global mutable state) | YUP 26.1.3 | Конституционное требование; сейчас не проверяется |
| 5 | `fun[thread]` — реальный OS thread spawning | YUP 26.1.1 | Текущий thread не создаёт реальный поток — поведение противоречит спецификации |

### Средний приоритет (экосистема и инструментарий)

| # | Задача | Спецификация | Обоснование |
|---|---|---|---|
| 6 | YUPPI минимальная реализация (`init/build/install`, `main.toml`) | YUP 26.1.2 | Без пакетной системы невозможно строить реальные проекты |
| 7 | Why3 интеграция (минимальный prover) | YUP 26.1.5 §4.1 | Нужен для discharge non-trivial proof obligations |
| 8 | `fun[async]` с реальным executor / `await` | YUP 26.1.1 | Async без executor не имеет практического смысла |
| 9 | Стандартная библиотека (`std.core`, `std.alloc`, `std.os`) | YUP 26.1.1 | Нет std.core = нет реальных программ |
| 10 | `yadro-lsp` Language Server Protocol | YUP 26.1.4 §6.3 | Без LSP IDE-интеграция невозможна |

### Низкий приоритет (специализированные targets / долгосрочные цели)

| # | Задача | Спецификация |
|---|---|---|
| 11 | GPU backend (SPIR-V / NVPTX) | YUP 26.1.7 |
| 12 | WASM GC backend | YUP 26.1.9 |
| 13 | Cranelift backend | YUP 26.1.4 |
| 14 | Proof certificates / Certify tier с реальными `.proof` файлами | YUP 26.1.5 |
| 15 | Формальная верификация самого компилятора (CompCert-style) | YUP 26.1.4 §10 |