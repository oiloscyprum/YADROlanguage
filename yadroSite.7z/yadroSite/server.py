import http.server
import socketserver
import sqlite3
import json
import os
import sys

PORT = 8000
DB_NAME = "yadro.db"

GUIDE_TITLES = {
    "01_intro": "Getting Started",
    "02_basics": "Language Basics",
    "03_memory": "Memory Model",
    "04_stdlib": "Standard Library",
    "tutorial_web": "Tutorial: Web App",
    "05_concurrency": "Concurrency",
    "06_ffi": "Foreign Function Interface",
    "07_testing": "Testing & Benchmarking",
    "08_macros": "Metaprogramming & Macros"
}

GUIDE_ORDER = ["01_intro", "02_basics", "03_memory", "05_concurrency", "06_ffi", "07_testing", "08_macros", "04_stdlib", "tutorial_web"]

class YadroHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/content':
            self.handle_api_content()
            return
            
        if self.path == '/':
            self.path = '/docs.html'
            
        if '..' in self.path:
            self.send_error(403, "Forbidden")
            return
            
        return super().do_GET()

    def handle_api_content(self):
        try:
            conn = sqlite3.connect(DB_NAME)
            cursor = conn.cursor()
            
            cursor.execute("SELECT doc_type, lang, slug, content FROM documents")
            rows = cursor.fetchall()
            conn.close()
            
            specs = {}
            guides = {}
            languages = set()
            
            for doc_type, lang, slug, content in rows:
                languages.add(lang)
                
                if doc_type == 'spec':
                    if lang not in specs: specs[lang] = {}
                    specs[lang][slug] = content
                elif doc_type == 'guide':
                    if lang not in guides: guides[lang] = {}
                    guides[lang][slug] = content
            
            guide_meta = []
            en_guides = guides.get('en', {})
            for key in GUIDE_ORDER:
                if key in en_guides:
                    guide_meta.append({
                        "id": key,
                        "title": GUIDE_TITLES.get(key, key)
                    })
            
            response_data = {
                "specs": specs,
                "guides": guides,
                "guideMeta": guide_meta,
                "availableLanguages": list(languages)
            }
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode('utf-8'))
            
        except Exception as e:
            self.send_error(500, f"Internal Server Error: {str(e)}")

def run_server():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    with http.server.ThreadingHTTPServer(("", PORT), YadroHandler) as httpd:
        print(f"Serving YADRO Docs at http://localhost:{PORT}")
        print(f"API available at http://localhost:{PORT}/api/content")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")
            httpd.shutdown()

if __name__ == "__main__":
    run_server()
