import os
import shutil

def replace_syntax(directory, extension):
    count = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(extension):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                new_content = content.replace("::", ".")
                
                if new_content != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                    count += 1
                    print(f"Updated {file}")
    return count

def setup_i18n():
    guides_dir = "guides"
    en_dir = os.path.join(guides_dir, "en")
    
    if not os.path.exists(en_dir):
        os.makedirs(en_dir)
        print(f"Created {en_dir}")
        
    # Move existing .md files to en/
    moved = 0
    for file in os.listdir(guides_dir):
        if file.endswith(".md"):
            src = os.path.join(guides_dir, file)
            dst = os.path.join(en_dir, file)
            shutil.move(src, dst)
            moved += 1
            print(f"Moved {file} to en/")
    return moved

if __name__ == "__main__":
    # 1. Refactor Code
    print("Refactoring .yad files...")
    yad_count = replace_syntax("stdlib", ".yad")
    print(f"Updated {yad_count} .yad files.")

    # 2. Refactor Guides (Syntax)
    print("Refactoring .md files...")
    md_count = replace_syntax("guides", ".md")
    print(f"Updated {md_count} .md files.")

    # 3. Setup i18n
    print("Setting up i18n structure...")
    moved_count = setup_i18n()
    print(f"Moved {moved_count} guides to en/ folder.")
