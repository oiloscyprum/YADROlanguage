# Concurrency in YADRO

YADRO provides powerful concurrency primitives inspired by Go and Rust, allowing you to write safe and efficient parallel code.

## 1. Tasks and Spawning
The `spawn` keyword creates a lightweight thread (task) managed by the runtime.

```yadro
#import std.async

fun main():
    // Spawn a background task
    spawn worker(1)
    spawn worker(2)

    // Main thread work
    cli.println("Main thread working...")
    
    // Wait for tasks (simple sleep for demo)
    async.sleep(1000)

fun worker(id: int):
    cli.println("Worker ${id} started")
    async.sleep(500)
    cli.println("Worker ${id} finished")
```

## 2. Channels
Channels are typed conduits for sending data between tasks.

```yadro
fun channels_demo():
    // Create a channel for strings
    let ch = Channel<string>::new()

    spawn fun():
        ch.send("Message from task")

    let msg = ch.recv()
    cli.println("Received: ${msg}")
```

## 3. Async/Await
For I/O bound operations, use `async` functions and `await`.

```yadro
async fun fetch_data(url: string) -> string:
    let resp = await http.get(url)
    return resp.text()

fun main():
    // Run async code from sync context
    let result = async.block_on(fetch_data("https://yadro.dev"))
    cli.println(result)
```

## 4. Structured Concurrency
YADRO enforces structured concurrency to prevent leaked tasks.

```yadro
fun structured_demo():
    async.scope(|s| {
        s.spawn(fun() { ... })
        s.spawn(fun() { ... })
        // Scope waits for all tasks to complete here
    })
```
