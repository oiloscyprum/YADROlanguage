# Foreign Function Interface (FFI)

YADRO can interact seamlessly with C libraries using the `#requires` directive and `extern` blocks.

## 1. Calling C Functions
Use `#requires` to link against shared libraries.

```yadro
#requires "m" // Link against libm

extern "C":
    fun cos(x: f64) -> f64
    fun sin(x: f64) -> f64

fun main():
    let x = 3.14159
    let y = unsafe { cos(x) }
    cli.println("Cos(PI) = ${y}")
```

## 2. Passing Structs
You can define structs that match C memory layout.

```yadro
#[repr(C)]
struct Point:
    i32 x
    i32 y

extern "C":
    fun transform_point(p: Point) -> Point

fun use_struct():
    let p = Point{x: 10, y: 20}
    let p2 = unsafe { transform_point(p) }
```

## 3. Callbacks
Passing YADRO functions to C.

```yadro
extern "C":
    fun register_callback(cb: fun(i32))

fun my_callback(val: i32):
    cli.println("Callback called with ${val}")

fun main():
    unsafe {
        register_callback(my_callback)
    }
```

## 4. Safety
All FFI calls are inherently `unsafe` and must be wrapped in an `unsafe` block. YADRO cannot verify the memory safety of external code.
