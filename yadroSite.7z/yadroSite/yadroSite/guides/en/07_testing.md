# Testing in YADRO

YADRO includes a first-class test runner. Tests are defined alongside your code or in a separate `tests/` directory.

## 1. Writing Unit Tests
Mark functions with `#[test]` to register them with the test runner.

```yadro
fun add(a: int, b: int) -> int:
    return a + b

#[test]
fun test_add():
    assert(add(2, 2) == 4)
    assert(add(-1, 1) == 0)
```

## 2. Test Organization
Tests can be grouped in a `tests` module within the same file.

```yadro
// src/lib.yad

fun compute() -> int:
    return 42

#[cfg(test)]
module tests:
    #import super.compute

    #[test]
    fun test_compute():
        assert(compute() == 42)
```

## 3. Running Tests
Use the YADRO CLI to run tests.

```bash
# Run all tests
yadro test

# Run specific test
yadro test test_add

# Run with output captured
yadro test --nocapture
```

## 4. Integration Tests
Create a `tests/` directory at the project root. Files here are compiled as separate crates.

```yadro
// tests/integration_test.yad
#import my_project

#[test]
fun test_public_api():
    let client = my_project.Client::new()
    assert(client.connect())
```

## 5. Benchmarks
Use `#[bench]` to define benchmarks (requires nightly/unstable).

```yadro
#import std.test.Bencher

#[bench]
fun bench_add(b: mut Bencher):
    b.iter(|| add(2, 2))
```
