# Language Basics

## Variables & Mutability
By default, variables are **immutable**. Use `mut` to make them mutable.

```yadro
fun basics():
    int x = 42          // Immutable
    // x = 43           // Error!
    
    mut int y = 10      // Mutable
    y += 5              // OK
```

## Basic Types
YADRO provides standard primitive types and high-level collections.

| Type | Description |
|------|-------------|
| `int`, `u32`, `i64` | Integers (platform-dependent or fixed width) |
| `float`, `f64` | Floating point numbers |
| `bool` | `true` or `false` |
| `string` | UTF-8 encoded text string |
| `array[T, N]` | Fixed-size array (stack allocated) |
| `darray[T]` | Dynamic array (heap allocated) |

```yadro
string name = "YADRO"
bool is_fast = true
darray[int] numbers = [1, 2, 3, 4]
```

## Functions
Functions are declared with `fun`. Return types follow the `->` arrow.

```yadro
fun add(int a, int b) -> int:
    return a + b

// Function with named parameters
fun greet(string name, string greeting = "Hello"):
    cli.println("${greeting}, ${name}!")
```

## Control Flow
Standard `if`, `for`, and `while` constructs, plus `switch` pattern matching.

```yadro
// Pattern Matching
switch value:
    case 1:
        cli.print("One")
    case 2..10:
        cli.print("Between 2 and 10")
    default:
        cli.print("Other")

// Loops
for i in range(0, 10):
    cli.print(i)
```
