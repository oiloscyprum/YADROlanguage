# Metaprogramming & Macros

YADRO provides a powerful macro system that operates on the Abstract Syntax Tree (AST) at compile time.

## 1. Macro Rules
Declarative macros using pattern matching, similar to Rust's `macro_rules!`.

```yadro
macro say_hello {
    () => {
        cli.println("Hello!")
    };
    ($name:expr) => {
        cli.println("Hello, " + $name)
    };
}

fun main():
    say_hello!()
    say_hello!("World")
```

## 2. Procedural Macros
Procedural macros define custom syntax extensions. They are written in YADRO and compiled by the compiler during the build process.

```yadro
// In a separate crate marked as #plugin
#import std.compiler.ast

#[proc_macro]
fun make_answer(input: TokenStream) -> TokenStream:
    return quote! {
        fun answer() -> int { 42 }
    }
```

## 3. Attribute Macros
Custom attributes for structs and functions.

```yadro
#[route(GET, "/")]
fun index():
    return "Home"
```

## 4. Derive Macros
Auto-generate trait implementations.

```yadro
#[derive(Json, Debug)]
struct User:
    string name
    int age
```

## 5. Hygiene
YADRO macros are hygienic by default, meaning variables defined inside a macro don't leak into the outer scope unless explicitly captured.
