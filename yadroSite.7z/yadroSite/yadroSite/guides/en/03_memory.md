# Memory Model

YADRO uses a **Dual-Heap Model** to balance performance and convenience.

## 1. Static Ownership (Linear Memory)
The default model is **linear ownership**, similar to Rust.
- **Zero Cost**: No garbage collection.
- **Deterministic**: Destructors run immediately when variables go out of scope.
- **Safety**: Compile-time checks prevent use-after-free and data races.

```yadro
fun linear_example():
    darray[int] v = [1, 2, 3]  // Owned by v
    take_ownership(v)          // Moved to function
    // print(v)                // Error: 'v' moved
```

## 2. Managed Heap (`gc<T>`)
For complex graphs or shared data, use the **Managed Heap**.
- **Reference Counted**: Automatic cleanup when count reaches zero.
- **Explicit**: Must opt-in via `gc<T>`.

```yadro
fun shared_example():
    gc[string] s = gc("Shared Data")
    gc[string] s2 = s.clone()  // Increments ref count
    
    // s and s2 point to same data
```

## 3. WebAssembly GC
When targeting WASM, YADRO can use the host's GC (e.g., browser GC).
See [YUP 26.1.9](/#/yup/yup26.1.9) for details.

```yadro
#target wasm=gc-2.0

fun web_example():
    wasm_gc[DomNode] node = dom.create_element("div")
```
