# Начало работы с YADRO

## Установка
YADRO управляется через инструментарий **YUPPI**. Для установки:

```bash
# Установка YUPPI через curl (Linux/macOS)
curl --proto '=https' --tlsv1.2 -sSf https://yadro.dev/install.sh | sh

# Windows (PowerShell)
iwr https://yadro.dev/install.ps1 -useb | iex
```

## Ваша первая программа
Создайте новый проект с помощью YUPPI:

```bash
yadro yuppi init hello-world
cd hello-world
```

Отредактируйте `src/main.yad`:

```yadro
#import
std.core.cli

#start
fun main():
    cli.println("Hello, YADRO Universe!")
#end
```

Запустите:
```bash
yadro run
```

## Структура проекта
Стандартный проект YADRO выглядит так:

```text
my-project/
├── main.toml        # Манифест проекта
├── src/
│   └── main.yad     # Точка входа
└── README.md
```
