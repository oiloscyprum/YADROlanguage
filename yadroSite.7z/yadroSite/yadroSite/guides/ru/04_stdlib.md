# Справочник Стандартной Библиотеки YADRO

Стандартная библиотека YADRO (`std`) предоставляет основные строительные блоки для создания надежных и эффективных приложений. Она спроектирована быть модульной, безопасной и производительной.

## Обзор Модулей

| Модуль | Описание |
| :--- | :--- |
| `std.core` | Базовые примитивные типы, макросы (`print`, `panic`) и типы `Option`/`Result`. |
| `std.io` | Операции ввода/вывода для файлов и стандартных потоков (`stdin`, `stdout`). |
| `std.fs` | Работа с файловой системой (Пути, Директории, Метаданные). |
| `std.collections` | Общие структуры данных, такие как `Vector`, `HashMap` и `HashSet`. |
| `std.math` | Математические функции (`sin`, `sqrt`) и константы (`PI`). |
| `std.net` | Сетевые примитивы для TCP и UDP коммуникации. |
| `std.http` | Высокоуровневый HTTP клиент (`Client`, `Request`, `Response`). |
| `std.async` | Помощники асинхронного времени выполнения, `Task`, `Future` и `spawn`. |
| `std.thread` | Нативные системные потоки и локальное хранилище потоков (TLS). |
| `std.sync` | Примитивы синхронизации (`Mutex`, `RwLock`, `Arc`, `Barrier`). |
| `std.crypto` | Криптографические примитивы (Хеширование, RNG, Шифрование). |
| `std.regex` | Компиляция и сопоставление регулярных выражений. |
| `std.time` | Измерение времени и манипуляции с ним (`Duration`, `Instant`). |
| `std.os` | Взаимодействие с ОС (Переменные окружения, Управление процессами). |
| `std.ffi` | Интерфейс внешних функций (Foreign Function Interface) для взаимодействия с C. |
| `std.log` | Средства логирования (`error`, `warn`, `info`, `debug`, `trace`). |
| `std.cli` | Парсер аргументов командной строки. |
| `std.json` | Сериализация и десериализация JSON. |

## Модуль Core (`std.core`)
Модуль `std.core` автоматически импортируется в каждую программу YADRO (если не используется `#no_std`).

### Базовый Вывод
```yadro
println("Hello, {}", "World");
panic("Critical error occurred");
```

### Option и Result
Безопасная обработка пустых значений и ошибок.
```yadro
let x: Option<int> = Some(42);
let y: Result<File, string> = File.open("data.txt");
```

## Коллекции (`std.collections`)

### Vector
Динамический, расширяемый массив.
```yadro
import std.collections

let mut v = Vector.new();
v.push(10);
v.push(20);
```

### HashMap
Хранилище ключ-значение.
```yadro
let mut map = HashMap.new();
map.insert("key", "value");
```

## Ввод/Вывод и Файловая Система (`std.io`, `std.fs`)
Доступ к файловой системе и манипуляция потоками.

```yadro
import std.io
import std.fs

let path = Path.new("config.toml");
if path.exists() {
    let file = File.open(path)?;
    let content = file.read_to_string()?;
    println("Config: {}", content);
}

// Список файлов в директории
for entry in fs.read_dir(".")? {
    println!("{}", entry.path);
}
```

## Конкурентность (`std.thread`, `std.sync`)
Параллельное выполнение с потоками и разделяемым состоянием.

```yadro
import std.thread
import std.sync

let counter = Arc.new(Mutex.new(0));
let mut handles = Vector.new();

for _ in 0..10 {
    let c = counter.clone();
    handles.push(thread.spawn(move || {
        let mut num = c.lock().unwrap();
        *num += 1;
    }));
}

for h in handles { h.join()?; }
```

## Сеть (`std.net`, `std.http`)
Создание сетевых приложений и веб-клиентов.

```yadro
import std.net
import std.http

// TCP Сервер
let listener = TcpListener.bind(SocketAddr.new("127.0.0.1", 8080))?;
let (stream, addr) = listener.accept()?;

// HTTP Клиент
let response = http.get("https://api.yadro.dev/v1/status")?;
println("Status: {}", response.status);
let json: HashMap<string, string> = response.json()?;
```

## CLI и Логирование (`std.cli`, `std.log`)
Создание инструментов командной строки.

```yadro
import std.cli
import std.log

fun main() {
    let app = App.new("myapp")
        .version("1.0")
        .arg(Arg.with_name("input").required(true));
        
    let matches = app.get_matches();
    
    if let Some(input) = matches.value_of("input") {
        log.info("Processing input: {}", input);
    }
}
```

## FFI (`std.ffi`)
Взаимодействие с библиотеками C.

```yadro
import std.ffi

let lib = Library.load("libm.so")?;
let cos: fun(f64) -> f64 = lib.get("cos")?;
println("Cos(0) = {}", cos(0.0));
```

## Async (`std.async`)
Асинхронные задачи.

```yadro
import std.async

async fun fetch_data() -> string {
    // ...
}

fun main() {
    let task = spawn(fetch_data());
    let result = task.await();
}
```

## Криптография (`std.crypto`)
Безопасное хеширование и шифрование.

```yadro
import std.crypto

let sha256 = Sha256.new();
let hash = sha256.hash("password".as_bytes());

let rng = Rng.os_rng();
let random_num = rng.next_u64();
```

## Регулярные Выражения (`std.regex`)
Сопоставление с образцом.

```yadro
import std.regex

let re = Regex.new(r"^\d{4}-\d{2}-\d{2}$")?;
if re.is_match("2026-02-10") {
    println("Valid date format");
}
```

## Время (`std.time`)
Измерение времени и длительность.

```yadro
import std.time

let start = Instant.now();
// ... операция ...
let duration = start.elapsed();
println("Took {} ms", duration.as_millis());
```

## ОС (`std.os`)
Взаимодействие с операционной системой.

```yadro
import std.os

let args = os.args();
let path = os.var("PATH")?;

let output = Command.new("ls").arg("-la").output()?;
```

## JSON (`std.json`)
Сериализация данных.

```yadro
import std.json

let data = json!({ "name": "YADRO", "ver": 0.2 });
let json_str = json.to_string(&data)?;
```

## Тестирование (`std.test`)
Фреймворк для юнит-тестирования.

```yadro
import std.test

test.run("addition", || {
    test.assert_eq(2 + 2, 4);
});
```

## Кодирование (`std.encoding`)
Поддержка Base64, Hex и CSV.

```yadro
import std.encoding

let b64 = encoding.base64.encode("hello".bytes());
let csv_reader = encoding.csv.Reader.new();
```

## Сжатие (`std.compress`)
Поддержка Gzip и Zlib.

```yadro
import std.compress

let compressed = compress.gzip.Encoder.new(9).compress(data)?;
```

## XML (`std.xml`)
Парсинг и генерация XML.

```yadro
import std.xml

let root = xml.parse("<root><child>text</child></root>")?;
```

## Итераторы (`std.iter`)
Компонуемые примитивы итерации.

```yadro
import std.iter

let r = iter.range(0, 10);
while let Some(i) = r.next() {
    println("{}", i);
}
```

## Случайные Числа (`std.random`)
Генерация псевдослучайных чисел (не криптографическая).

```yadro
import std.random

let mut rng = random.Pcg32.seed_from_time();
let n = rng.range(1, 100);
```

## URL (`std.url`)
Парсинг и манипуляция URL.

```yadro
import std.url

let url = url.Url.parse("https://yadro.dev")?;
println("Host: {}", url.host);
```

## Prelude (`std.prelude`)
Общие импорты.

```yadro
import std.prelude

// Теперь вы можете использовать Vector, HashMap, Result без полных путей
let v: Vector<int> = Vector.new();
```

## Каналы (`std.channels`)
Каналы MPSC (Multi-Producer, Single-Consumer).

```yadro
import std.channels
import std.thread

let (tx, rx) = channels.channel();

thread.spawn(move || {
    tx.send("Hello from thread").unwrap();
});

println("Received: {}", rx.recv().unwrap());
```

## Дата и Время (`std.date`)
Календарные даты и форматирование.

```yadro
import std.date

let now = date.DateTime.now();
println("Current time: {}", now.to_string());
```

## UUID (`std.uuid`)
Универсальные уникальные идентификаторы (v4).

```yadro
import std.uuid

let id = uuid.Uuid.new_v4();
println("New ID: {}", id.to_string());
```

## Форматирование (`std.fmt`)
Трейты Display и Debug.

```yadro
import std.fmt

struct Point { x: i32, y: i32 }

impl fmt.Display for Point {
    fun fmt(self, f: &mut fmt.Formatter) -> Result<Unit, string> {
        f.write_str("Point");
        return Result.Ok(Unit);
    }
}
```

## Структура Проекта
Стандартная библиотека организована следующим образом в дереве исходных кодов YADRO:

```
stdlib/
├── core.yad        # Основные определения
├── io.yad          # Операции ввода/вывода
├── fs.yad          # Файловая система
├── collections.yad # Структуры данных
├── math.yad        # Математические функции
├── net.yad         # Сеть
├── http.yad        # HTTP Клиент
├── async.yad       # Асинхронная среда выполнения
├── thread.yad      # Потоки
├── sync.yad        # Синхронизация
├── crypto.yad      # Криптография
├── regex.yad       # Регулярные выражения
├── time.yad        # Время и Длительность
├── os.yad          # Взаимодействие с системой
├── ffi.yad         # C Interop
├── log.yad         # Логирование
├── cli.yad         # CLI Парсер
├── json.yad        # Поддержка JSON
├── test.yad        # Юнит-тестирование
├── encoding.yad    # Кодирование данных
├── compress.yad    # Сжатие
├── xml.yad         # XML парсер
├── iter.yad        # Итераторы
├── random.yad      # Случайные числа
├── url.yad         # URL парсер
├── channels.yad    # Каналы MPSC
├── prelude.yad     # Стандартный prelude
├── date.yad        # Дата и Календарь
├── uuid.yad        # Генератор UUID
└── fmt.yad         # Трейты форматирования
```
