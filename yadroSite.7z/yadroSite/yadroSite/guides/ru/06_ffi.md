# Интерфейс внешних функций (FFI)

YADRO может бесшовно взаимодействовать с библиотеками C, используя директиву `#requires` и блоки `extern`.

## 1. Вызов функций C
Используйте `#requires` для линковки с разделяемыми библиотеками.

```yadro
#requires "m" // Линковка с libm

extern "C":
    fun cos(x: f64) -> f64
    fun sin(x: f64) -> f64

fun main():
    let x = 3.14159
    let y = unsafe { cos(x) }
    cli.println("Cos(PI) = ${y}")
```

## 2. Передача структур
Вы можете определять структуры, которые соответствуют расположению в памяти C.

```yadro
#[repr(C)]
struct Point:
    i32 x
    i32 y

extern "C":
    fun transform_point(p: Point) -> Point

fun use_struct():
    let p = Point{x: 10, y: 20}
    let p2 = unsafe { transform_point(p) }
```

## 3. Callbacks (Обратные вызовы)
Передача функций YADRO в C.

```yadro
extern "C":
    fun register_callback(cb: fun(i32))

fun my_callback(val: i32):
    cli.println("Callback вызван с ${val}")

fun main():
    unsafe {
        register_callback(my_callback)
    }
```

## 4. Безопасность
Все вызовы FFI по своей природе являются `unsafe` (небезопасными) и должны быть обернуты в блок `unsafe`. YADRO не может проверить безопасность памяти внешнего кода.
