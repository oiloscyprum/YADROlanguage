# Урок: Продвинутое WebAssembly приложение

Этот урок показывает создание полнофункционального списка задач (Todo app), работающего в браузере с использованием поддержки WASM GC в YADRO. Мы рассмотрим манипуляцию DOM, обработку событий и взаимодействие с JavaScript.

## Предварительные требования
- Компилятор YADRO v0.2.0+
- Установленный `wasm-tools`

## 1. Настройка
Создайте `main.toml`:

```toml
[package]
name = "todo-app"
version = "0.1.0"

[build]
targets = ["wasm32-browser+gc-2.0"]

[wasm.js_ffi]
allowed = ["dom", "console", "fetch"]
```

## 2. Код (`src/main.yad`)

Этот пример демонстрирует:
- **Структуры WASM GC**: Определение типов данных, управляемых сборщиком мусора браузера.
- **DOM API**: Создание элементов, обработка событий.
- **JS Interop**: Вывод логов в консоль.

```yadro
#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true

#import
std.wasm_gc.dom
std.wasm_gc.console
std.wasm_gc.events

// Определение задачи в куче WASM GC
wasm_struct Todo:
    string text
    mut bool done

// Контейнер состояния
wasm_struct AppState:
    mut wasm_array[wasm_gc[Todo]] todos
    wasm_gc[Element] root_el

fun main():
    console.log("Запуск YADRO Todo App...")

    // Получаем корневой элемент
    wasm_gc[Element] app_el = dom.get_element_by_id("app")
    
    // Инициализируем состояние
    wasm_gc[AppState] state = wasm_gc.new(AppState{
        todos: wasm_gc.array_new(0),
        root_el: app_el
    })
    
    // Добавляем начальные задачи
    add_todo(state, "Изучить YADRO")
    add_todo(state, "Создать продвинутое WASM приложение")
    
    // Первоначальная отрисовка
    render(state)

    // Настройка обработки ввода
    setup_input(state)

fun add_todo(mut wasm_gc[AppState] state, string text):
    wasm_gc[Todo] item = wasm_gc.new(Todo{text, false})
    state.todos.push(item)
    console.log("Добавлена задача: " + text)

fun toggle_todo(mut wasm_gc[AppState] state, u32 index):
    if index < state.todos.len():
        let item = state.todos[index]
        item.done = !item.done
        render(state)

fun render(wasm_gc[AppState] state):
    state.root_el.set_inner_html("") // Очистить текущий вид
    
    wasm_gc[Element] list = dom.create_element("ul")
    list.set_attribute("class", "todo-list")
    
    u32 i = 0
    for item in state.todos:
        wasm_gc[Element] li = dom.create_element("li")
        
        // Стиль в зависимости от состояния
        if item.done:
            li.set_attribute("class", "completed")
        
        li.set_text(item.text)
        
        // Добавить слушатель клика для переключения
        // Захват 'state' и 'i' через замыкание
        let idx = i
        li.add_event_listener("click", fun(wasm_gc[Event] e):
            toggle_todo(state, idx)
        )
        
        list.append_child(li)
        i += 1
        
    state.root_el.append_child(list)

fun setup_input(wasm_gc[AppState] state):
    wasm_gc[Element] input = dom.get_element_by_id("new-todo")
    wasm_gc[Element] btn = dom.get_element_by_id("add-btn")
    
    btn.add_event_listener("click", fun(wasm_gc[Event] e):
        string text = input.get_value()
        if text.len() > 0:
            add_todo(state, text)
            input.set_value("") // Очистить ввод
            render(state)
    )
```

## 3. HTML Структура (`index.html`)

Вам понадобится базовый HTML файл для запуска вашего WASM приложения:

```html
<!DOCTYPE html>
<html>
<head>
    <title>YADRO Todo</title>
    <style>
        .completed { text-decoration: line-through; color: #888; }
        .todo-list { list-style: none; padding: 0; }
        li { cursor: pointer; padding: 5px; border-bottom: 1px solid #eee; }
        li:hover { background-color: #f5f5f5; }
    </style>
</head>
<body>
    <h1>Задачи YADRO</h1>
    <div>
        <input type="text" id="new-todo" placeholder="Что нужно сделать?">
        <button id="add-btn">Добавить</button>
    </div>
    <div id="app"></div>
    
    <!-- Загрузка WASM -->
    <script type="module">
        import init from './pkg/todo_app.js';
        init();
    </script>
</body>
</html>
```

## 4. Сборка и Запуск
```bash
yadro build --release
python -m http.server
```

Откройте `http://localhost:8000`, чтобы увидеть ваше интерактивное приложение!
