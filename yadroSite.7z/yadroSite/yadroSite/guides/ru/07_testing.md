# Тестирование в YADRO

YADRO включает в себя первоклассный инструмент для запуска тестов. Тесты определяются рядом с вашим кодом или в отдельной директории `tests/`.

## 1. Написание модульных тестов
Помечайте функции атрибутом `#[test]`, чтобы зарегистрировать их в системе тестирования.

```yadro
fun add(a: int, b: int) -> int:
    return a + b

#[test]
fun test_add():
    assert(add(2, 2) == 4)
    assert(add(-1, 1) == 0)
```

## 2. Организация тестов
Тесты можно группировать в модуле `tests` в том же файле.

```yadro
// src/lib.yad

fun compute() -> int:
    return 42

#[cfg(test)]
module tests:
    #import super.compute

    #[test]
    fun test_compute():
        assert(compute() == 42)
```

## 3. Запуск тестов
Используйте YADRO CLI для запуска тестов.

```bash
# Запустить все тесты
yadro test

# Запустить конкретный тест
yadro test test_add

# Запустить с выводом в консоль
yadro test --nocapture
```

## 4. Интеграционные тесты
Создайте директорию `tests/` в корне проекта. Файлы здесь компилируются как отдельные крейты.

```yadro
// tests/integration_test.yad
#import my_project

#[test]
fun test_public_api():
    let client = my_project.Client::new()
    assert(client.connect())
```

## 5. Бенчмарки
Используйте `#[bench]` для определения бенчмарков (требует nightly/unstable).

```yadro
#import std.test.Bencher

#[bench]
fun bench_add(b: mut Bencher):
    b.iter(|| add(2, 2))
```
