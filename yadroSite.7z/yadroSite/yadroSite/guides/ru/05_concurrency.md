# Конкурентность в YADRO

YADRO предоставляет мощные примитивы конкурентности, вдохновленные Go и Rust, позволяющие писать безопасный и эффективный параллельный код.

## 1. Задачи и Spawning
Ключевое слово `spawn` создает легковесный поток (задачу), управляемый средой выполнения.

```yadro
#import std.async

fun main():
    // Запуск фоновой задачи
    spawn worker(1)
    spawn worker(2)

    // Работа в основном потоке
    cli.println("Основной поток работает...")
    
    // Ожидание задач (простой sleep для демонстрации)
    async.sleep(1000)

fun worker(id: int):
    cli.println("Воркер ${id} запущен")
    async.sleep(500)
    cli.println("Воркер ${id} завершил работу")
```

## 2. Каналы (Channels)
Каналы — это типизированные каналы связи для отправки данных между задачами.

```yadro
fun channels_demo():
    // Создание канала для строк
    let ch = Channel<string>::new()

    spawn fun():
        ch.send("Сообщение от задачи")

    let msg = ch.recv()
    cli.println("Получено: ${msg}")
```

## 3. Async/Await
Для операций, связанных с вводом-выводом, используйте `async` функции и `await`.

```yadro
async fun fetch_data(url: string) -> string:
    let resp = await http.get(url)
    return resp.text()

fun main():
    // Запуск асинхронного кода из синхронного контекста
    let result = async.block_on(fetch_data("https://yadro.dev"))
    cli.println(result)
```

## 4. Структурная Конкурентность
YADRO обеспечивает структурную конкурентность для предотвращения утечек задач.

```yadro
fun structured_demo():
    async.scope(|s| {
        s.spawn(fun() { ... })
        s.spawn(fun() { ... })
        // Scope ожидает завершения всех задач здесь
    })
```
