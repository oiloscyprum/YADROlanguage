import os
import json

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    guides_dir = os.path.join(base_dir, "guides")
    
    # 1. Load YUP Specs (Multi-language)
    specs_dir = os.path.join(base_dir, "specs")
    specs = {}
    
    # Define spec files we expect (or just read all .md files)
    # We can just read all .md files in the language folders
    
    if os.path.exists(specs_dir):
        for item in os.listdir(specs_dir):
            item_path = os.path.join(specs_dir, item)
            
            # Case 1: Subdirectory (e.g., 'en', 'ru')
            if os.path.isdir(item_path):
                lang = item
                if lang not in specs:
                    specs[lang] = {}
                for filename in os.listdir(item_path):
                    if filename.endswith(".md"):
                        with open(os.path.join(item_path, filename), 'r', encoding='utf-8') as f:
                            key = filename.replace('.md', '')
                            specs[lang][key] = f.read()
                            
    # Ensure 'en' exists
    if 'en' not in specs:
        specs['en'] = {}
        
    # Legacy fallback: check root for yup*.md if not found in specs/en
    yup_files = [
        "yup26.1.1.md", "yup26.1.2.md", "yup26.1.3.md", 
        "yup26.1.4.md", "yup26.1.5.md", "yup26.1.7.md", "yup26.1.9.md"
    ]
    for filename in yup_files:
        filepath = os.path.join(base_dir, filename)
        if os.path.exists(filepath):
            key = filename.replace('.md', '')
            if key not in specs['en']:
                with open(filepath, 'r', encoding='utf-8') as f:
                    specs['en'][key] = f.read()

    
    # 2. Load Guides (Multi-language)
    guides = {}
    guide_titles = {
        "01_intro": "Getting Started",
        "02_basics": "Language Basics",
        "03_memory": "Memory Model",
        "04_stdlib": "Standard Library",
        "tutorial_web": "Tutorial: Web App",
        "05_concurrency": "Concurrency",
        "06_ffi": "Foreign Function Interface",
        "07_testing": "Testing & Benchmarking",
        "08_macros": "Metaprogramming & Macros"
    }
    
    guide_order = ["01_intro", "02_basics", "03_memory", "05_concurrency", "06_ffi", "07_testing", "08_macros", "04_stdlib", "tutorial_web"]
    
    # Check if guides_dir has language subfolders
    if os.path.exists(guides_dir):
        # Walk through subdirectories
        for item in os.listdir(guides_dir):
            item_path = os.path.join(guides_dir, item)
            
            # Case 1: Subdirectory (e.g., 'en', 'ru')
            if os.path.isdir(item_path):
                lang = item
                guides[lang] = {}
                for filename in os.listdir(item_path):
                    if filename.endswith(".md"):
                        with open(os.path.join(item_path, filename), 'r', encoding='utf-8') as f:
                            key = filename.replace('.md', '')
                            guides[lang][key] = f.read()
            
            # Case 2: Direct file (legacy support or default 'en')
            elif item.endswith(".md"):
                if 'en' not in guides:
                    guides['en'] = {}
                with open(item_path, 'r', encoding='utf-8') as f:
                    key = item.replace('.md', '')
                    guides['en'][key] = f.read()

    # Ensure 'en' exists
    if 'en' not in guides:
        guides['en'] = {}

    # 3. Generate JS content
    content_obj = {
        "specs": specs,
        "guides": guides,
        "guideMeta": [
            {"id": key, "title": guide_titles.get(key, key)}
            for key in guide_order 
            # Check if key exists in 'en' at least
            if key in guides.get('en', {})
        ],
        "availableLanguages": list(guides.keys())
    }
    
    js_content = f"window.SITE_CONTENT = {json.dumps(content_obj, indent=2)};"
    
    with open(os.path.join(base_dir, "content.js"), 'w', encoding='utf-8') as f:
        f.write(js_content)
        
    print(f"Generated content.js with {len(specs)} specs and guides in {list(guides.keys())}")

if __name__ == "__main__":
    main()
