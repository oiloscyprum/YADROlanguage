# YUP 26.1.7: Стандарт Специализации GPU Целей

**Метаданные**  
YUP ID: 26.1.7  
Название: Стандарт Специализации GPU Целей  
Автор: CyrOil   
Статус: Предложен  
Создан: 2026-02-02  
Регулирует: Спецификацию Языка YADRO v0.2.0+  
Заменяет: Н/Д  
Конституционное соответствие: YUP 26.1.3 (Статьи II.2, III.3, IV.1, IV.3)  

---

## Аннотация

Этот стандарт определяет архитектуру программирования GPU в экосистеме YADRO, обеспечивая бесшовное выполнение ядер на гетерогенном оборудовании (NVIDIA CUDA, AMD ROCm, Vulkan/SPIR-V) при сохранении конституционных гарантий статической верификации, явного намерения и абстракции с нулевой стоимостью. YUP 26.1.7 вводит декларативные спецификации целей, унифицированную модель памяти, охватывающую границы хоста/устройства, и принудительное соблюдение ограничений безопасности GPU во время компиляции — все это без ущерба для основополагающей семантики владения YADRO или введения скрытых накладных расходов во время выполнения.

---

## 1. Конституционный Фундамент

Программирование GPU представляет уникальные вызовы для конституционных принципов YADRO. Этот стандарт разрешает эти противоречия через явное моделирование:

| Конституционный Принцип | Стратегия Реализации GPU |
|--------------------------|-----------------------------|
| **Статья II.2 (Декларативная Конфигурация)** | Все цели GPU явно декларируются через `#target gpu=...`; никакой неявной выгрузки (offloading) |
| **Статья III.3 (Право Спускаться)** | Полный доступ к аппаратным интринсикам (`#[intrinsic("nvvm")]`, `#[intrinsic("spirv")]`) с явным обозначением unsafe |
| **Статья I.3 (Типы Описывают Поведение)** | Пространства памяти закодированы в типах (`global[T]`, `shared[T]`, `local[T]`); требования синхронизации в сигнатурах функций |
| **Статья IV.3 (Побочные Эффекты в Типе)** | Эффекты запуска ядра моделируются через возвращаемый тип `Task[Unit]`; передача данных явная в местах вызова |
| **Статья IV.1 (Детерминизм)** | Недетерминизм GPU (расхождение варпов, гонки атомиков) статически отвергается, если не подтвержден явно через `#[relaxed]` |

---

## 2. Расширения Синтаксиса Декларации Целей

### 2.1 Спецификация Цели GPU (расширение `#target`)

```yadro
// Гетерогенная цель Хост + GPU
#target
os = "linux"
arch = "x86-64"
gpu = "cuda-12.4"          // NVIDIA CUDA
gpu_arch = "sm_90"         // Архитектура Hopper

// Альтернатива: цель Vulkan/SPIR-V
#target
os = "windows"
arch = "x86-64"
gpu = "spirv-1.6"
gpu_arch = "vulkan-1.3"

// Конфигурация Multi-GPU
#target
os = "linux"
arch = "aarch64"
gpu = ["cuda-12.4", "rocm-6.0"]  // Компиляция для обоих бэкендов
```

### 2.2 Ограничения Целей в Манифестах Пакетов (`main.toml`)

```toml
[package]
name = "raytracer-gpu"
version = "1.0.0"

[build]
targets = [
  "x86_64-linux+cuda-12.4",
  "aarch64-linux+rocm-6.0",
  "x86_64-windows+spirv-1.6"
]

[gpu.features]
cuda = ["tensor-cores", "ray-tracing"]
rocm = ["matrix-core", "wavefront-64"]
spirv = ["subgroup-operations", "shader-clock"]
```

---

## 3. Модель Памяти GPU и Расширения Системы Типов

### 3.1 Типы Пространств Памяти (Обеспечение Статьи I.3 Конституции)

```yadro
// Глобальная память устройства (выделяется на GPU, доступна всем потокам)
global[T]               // Аналог CUDA __global__

// Разделяемая память (на блок, быстрая SRAM)
shared[T]               // Аналог CUDA __shared__

// Локальная память (на поток, приватные регистры/стек)
local[T]                // Аналог CUDA __local__

// Константная память (только для чтения, широковещательная)
constant[T]             // Аналог CUDA __constant__

// Унифицированная память (доступна хосту/устройству, управляемая миграция)
unified[T]              // Zero-copy через CUDA UVM/ROCm HMM
```

**Конституционная Гарантия**: Переходы между пространствами памяти требуют явных операций — никакого неявного копирования. Компилятор отвергает код, нарушающий границы пространств памяти, во время компиляции.

### 3.2 Владение через Границу Хост/Устройство

```yadro
// Передача владения от хоста к устройству
fun transfer_to_device(darray[float] host_data) -> global[darray[float]]:
    // Владение перемещается: host_data недействительна после передачи
    return #gpu_transfer(host_data)

// Передача обратно на хост (возврат владения)
fun transfer_to_host(global[darray[float]] device_data) -> darray[float]:
    // Владение перемещается обратно в контекст хоста
    return #gpu_transfer(device_data)

// Паттерн заимствования (zero-copy через унифицированную память)
fun process_in_place(mut unified[darray[float]] data):
    // Изменяемое заимствование унифицированной памяти для выполнения ядра
    launch_kernel(kernel_process, data)
    // data остается валидной на хосте после завершения ядра
```

**Конституционное Обеспечение** (Статья I.1):
- Компилятор статически верифицирует отсутствие использования после передачи (use-after-transfer) на стороне хоста
- Заимствования на стороне устройства проверяются на валидность времени жизни относительно области выполнения ядра
- Доступ к унифицированной памяти отслеживается на предмет гонок данных между потоками хоста/устройства

---

## 4. Декларация Ядра и Семантика Запуска

### 4.1 Синтаксис Функции Ядра

```yadro
// Декларация ядра GPU
fun[gpu(kernel)] raytrace_kernel(
    global[Scene] scene,
    global[Image] output,
    shared[Ray] ray_cache,
    u32 thread_idx,
    u32 block_idx
) -> Unit:
    // Тело ядра выполняется на GPU
    Ray ray = compute_ray(thread_idx, block_idx)
    Color color = trace_ray(scene, ray)
    output.store(thread_idx, color)

// Ядро с явными требованиями синхронизации
fun[gpu(kernel)]
requires_sync = "block"    // Требуется барьер уровня блока
shared_mem = 4096          // 4КБ разделяемой памяти на блок
fun[gpu] reduction_kernel(
    global[darray[float]] input,
    global[float] output,
    shared[float] scratch
):
    u32 tid = #gpu_thread_id()
    u32 local_sum = 0
    
    // Явный барьер (требуется сигнатурой функции)
    #gpu_sync_block()
    
    // Паттерн редукции с конституционной безопасностью:
    // - Границы разделяемой памяти проверяются при компиляции
    // - Нет гонок данных на scratch[tid] (единственный писатель)
    if tid == 0:
        output.store(0, scratch[0])
```

### 4.2 Синтаксис Запуска Ядра (Явное Намерение - Статья II.1)

```yadro
// Явный запуск ядра с конфигурацией
launch raytrace_kernel(
    scene_data,
    image_buffer,
    shared_ray_cache
)
config:
    grid_dim = (1024, 1024)    // 1M блоков
    block_dim = (256,)         // 256 потоков на блок
    shared_mem = 4096          // Выделение 4КБ разделяемой памяти
    stream = compute_stream    // Явное назначение потока (stream)

// Запуск возвращает Task[Unit] для синхронизации
Task[Unit] kernel_task = launch raytrace_kernel(...) config: {...}

// Явная точка синхронизации (никакой скрытой блокировки)
await kernel_task

// Альтернатива: fire-and-forget с явной аннотацией эффекта
#[fire_and_forget]
launch raytrace_kernel(...) config: {...}
// Компилятор требует #[fire_and_forget] для подтверждения несинхронизированного выполнения
```

**Конституционная Гарантия**: Все запуски ядер производят значения `Task[Unit]`, представляющие асинхронное вычисление. Игнорирование этого значения требует явной аннотации `#[fire_and_forget]` — никакой скрытой синхронизации (Статья II.1 "Никакой Магии").

---

## 5. Специфичные для GPU Примитивы Синхронизации

### 5.1 Типы Упорядочивания Памяти (Статья IV.3 Конституции)

```yadro
// Ограничения упорядочивания памяти как явные типы
enum GpuMemoryOrder:
    Relaxed          // Нет гарантий упорядочивания
    Acquire          // Synchronizes-with для предшествующих сохранений
    Release          // Synchronizes-with для последующих загрузок
    AcqRel           // И acquire, и release
    SequentiallyConsistent  // Полная последовательная согласованность

// Атомарные операции с явным упорядочиванием
fun[gpu] atomic_add(
    mut global[int] target, 
    int value,
    GpuMemoryOrder order = Acquire
) -> int:
    return #gpu_atomic("add", target, value, order)
```

### 5.2 Примитивы Барьеров (Верификация по Статье I.1)

```yadro
// Синхронизация уровня блока (все потоки в блоке)
#gpu_sync_block()

// Синхронизация уровня сетки (требует compute capability 9.0+)
#gpu_sync_grid()

// Примитивы уровня варпа (явная обработка расхождения варпов)
#gpu_sync_warp()
bool lane_active = #gpu_any_sync(mask, predicate)  // Конституционная проверка: валидность маски проверяется при компиляции
```

**Конституционное Обеспечение**: Компилятор статически верифицирует:
- Отсутствие расхождения барьеров (все потоки в варпе/блоке должны достичь одного барьера)
- Атомарные операции используются только на правильно выровненной памяти
- Ограничения упорядочивания памяти совместимы с целевой архитектурой

---

## 6. Интеграция с YadroCMP (YUP 26.1.4)

### 6.1 Конвейер Компиляции для Целей GPU

```
Исходный код YADRO (.yad)
       ↓
[Фронтенд: Парсинг аннотаций GPU]
       ↓
Типизированное AST + Метаданные GPU
       ↓
[Конституционный Проход Верификации GPU]
       ├── Проверка границ пространств памяти
       ├── Проверка свободы от расхождения барьеров
       ├── Валидация выравнивания атомиков
       └── Обеспечение явной синхронизации
       ↓
GPU-Aware MIR
       ↓
┌──────────────┬──────────────┬──────────────┐
│ NVVM IR      │ AMDGCN IR    │ SPIR-V       │
│ (CUDA)       │ (ROCm)       │ (Vulkan)     │
└──────────────┴──────────────┴──────────────┘
       ↓              ↓              ↓
   PTX Assembly   ISA Assembly   SPIR-V Binary
       ↓              ↓              ↓
   cubin/elf      .co/.o         .spv
       ↓
[Линковка с Кодом Хоста через YadroCMP]
       ↓
Унифицированный Исполняемый Файл (Код CPU + GPU)
```

### 6.2 Конституционный Проход Верификации для Кода GPU

`YadroGpuConstitutionPass` обеспечивает:

| Проверка | Конституционное Основание | Диагностика Ошибки |
|-------|----------------------|-------------------|
| Нарушение пространства памяти | Статья I.3 | `GPU_MEMORY_VIOLATION: accessing global memory as shared` |
| Расхождение барьера | Статья I.1 | `BARRIER_DIVERGENCE: conditional barrier in warp` |
| Неявная синхронизация | Статья II.1 | `HIDDEN_SYNC: kernel launch result ignored without #[fire_and_forget]` |
| Невыравнивание атомика | Статья I.1 | `ATOMIC_ALIGNMENT: 64-bit atomic on 4-byte boundary` |
| Недетерминированная гонка | Статья IV.1 | `DATA_RACE: unsynchronized write to global memory` |

---

## 7. Интеграция YUPPI для Пакетов GPU (Соответствие YUP 26.1.2)

### 7.1 Специфичные Метаданные Пакета GPU

```toml
[package]
name = "gpu-primitives"
version = "2.1.0"

[gpu.targets]
cuda = { min_version = "11.0", architectures = ["sm_70", "sm_80", "sm_90"] }
rocm = { min_version = "5.0", architectures = ["gfx908", "gfx1100"] }
spirv = { version = "1.6", extensions = ["SPV_KHR_shader_clock"] }

[gpu.dependencies]
"cuda-runtime" = ">=12.0.0"
"vulkan-loader" = ">=1.3.0"

[exports.gpu_kernels]
raytrace = "src/kernels/raytrace.yad::raytrace_kernel"
reduction = "src/kernels/reduce.yad::reduction_kernel"
```

### 7.2 Формат Дистрибуции Бинарных Файлов GPU

Пакеты GPU, распространяемые через YUPPI, включают прекомпилированные ядра:

```
gpu-package.ymd/
├── main.toml
├── src/
│   └── kernels/
│       ├── raytrace.yad
│       └── reduce.yad
├── gpu_bin/
│   ├── cuda-sm_90/
│   │   ├── raytrace.cubin
│   │   └── reduce.cubin
│   ├── rocm-gfx1100/
│   │   ├── raytrace.co
│   │   └── reduce.co
│   └── spirv-1.6/
│       ├── raytrace.spv
│       └── reduce.spv
└── checksum.sha256
```

YadroCMP выбирает соответствующий бинарный файл на основе декларации `#target gpu=...`, возвращаясь к компиляции из исходного кода, если подходящий бинарный файл отсутствует.

---

## 8. Гарантии Безопасности и Конституционные Границы

### 8.1 Уровни Безопасности GPU

| Уровень | Аннотация | Гарантии | Конституционное Основание |
|------|------------|------------|----------------------|
| **Safe GPU** | (по умолчанию) | Нет гонок данных, свобода от расхождения барьеров, безопасность памяти | Статья I.1 + I.3 |
| **Relaxed GPU** | `#[relaxed]` | Допускает "доброкачественные" гонки (напр., атомарные счетчики), явное расхождение | Статья III.3 (Право Спускаться) |
| **Unsafe GPU** | `#[unsafe(gpu)]` | Сырые указатели, inline PTX/ISA, обход проверок безопасности | Статья III.3 + явное обозначение |

```yadro
// Безопасное ядро GPU (по умолчанию)
fun[gpu(kernel)] safe_kernel(global[darray[int]] data):
    // Компилятор верифицирует отсутствие гонок, отсутствие расхождения

// Relaxed ядро для критичных к производительности счетчиков
#[relaxed(reason = "benign race on histogram counter")]
fun[gpu(kernel)] histogram_kernel(
    global[darray[int]] values,
    global[darray[u32]] histogram
):
    u32 bin = compute_bin(values[#gpu_thread_id()])
    #gpu_atomic_add(histogram[bin], 1, Relaxed)  // Явное relaxed упорядочивание

// Unsafe ядро с inline PTX
#[unsafe(gpu)]
fun[gpu(kernel)] custom_asm_kernel(global[float] data):
    asm("mma.sync.aligned.m16n8k16.f32.f16.f16.f32 ..."):
        // Интринсик тензорного ядра с явной границей unsafe
```

### 8.2 Обеспечение Границы Хост/Устройство

Компилятор обеспечивает строгое разделение:

```yadro
// INVALID: Нельзя вызвать функцию хоста из контекста устройства
fun[gpu(kernel)] bad_kernel():
    cli.print("Debug")  // REJECTED: cli.print только для хоста

// VALID: Явный callback хоста через утвержденный механизм
fun[gpu(kernel)] debug_kernel():
    #gpu_host_callback(debug_handler, thread_id)  // Конституционно: явный эффект

// INVALID: Нельзя захватить стековые переменные хоста в ядре
fun process():
    int host_var = 42
    launch kernel():
        use(host_var)  // REJECTED: стек хоста недоступен на устройстве

// VALID: Явная передача данных
fun process():
    int host_var = 42
    global[int] device_var = transfer_to_device(host_var)
    launch kernel(device_var)  // Конституционно: явная передача
```

---

## 9. Пример: Конституционно Верифицированное Приложение GPU

```yadro
#import
std::core::math
std::gpu::kernel   // Примитивы ядер GPU
std::gpu::memory   // Типы пространств памяти

#target
os = "linux"
arch = "x86-64"
gpu = "cuda-12.4"
gpu_arch = "sm_90"

// Описание сцены (память хоста)
class Scene:
    darray[Sphere] spheres
    Light light

// Структура ввода ядра (память устройства)
class[linear] GpuScene:
    global[darray[Sphere]] spheres
    Light light

// Конституционно безопасное ядро
fun[gpu(kernel)]
requires_sync = "block"
shared_mem = 4096
fun[gpu] path_trace_kernel(
    global[GpuScene] scene,
    global[Image] output,
    shared[Ray] ray_pool,
    u32 thread_idx,
    u32 block_idx
) -> Unit:
    // Расчет индекса потока с конституционной проверкой границ
    u32 global_idx = block_idx * 256 + thread_idx
    if global_idx >= output.width * output.height:
        return  // Ранний выход - компилятор верифицирует отсутствие расхождения барьеров
    
    // Генерация лучей с оптимизацией разделяемой памяти
    Ray ray = generate_ray(global_idx, output)
    ray_pool.store(thread_idx, ray)
    #gpu_sync_block()  // Требуется сигнатурой функции
    
    // Трассировка пути с явными переходами пространств памяти
    Color color = trace_path(scene, ray_pool.load(thread_idx))
    output.store(global_idx, color)

// Оркестрация на стороне хоста с явной передачей данных
fun render_scene(Scene host_scene, Image host_output) -> Result[Unit, GpuError]:
    // Передача сцены на устройство (владение перемещается)
    global[darray[Sphere]] device_spheres = 
        transfer_to_device(host_scene.spheres)?
    
    global[GpuScene] device_scene = 
        GpuScene.new(device_spheres, host_scene.light)
    
    // Запуск ядра с явной конфигурацией
    Task[Unit] render_task = launch path_trace_kernel(
        device_scene,
        host_output.as_device_image(),  // Явная передача
        shared[Ray].alloc(256)
    ) config:
        grid_dim = (ceil_div(host_output.pixels(), 256), 1)
        block_dim = (256,)
        shared_mem = 4096
    
    // Явная точка синхронизации
    await render_task?
    
    // Передача результата обратно на хост (владение возвращается)
    host_output.copy_from_device()?
    
    // Память устройства автоматически освобождается через семантику владения
    return Ok(())

// Конституционная гарантия: Никаких гонок данных, никакой скрытой синхронизации,
// явная модель стоимости и полная статическая верификация свойств безопасности GPU
```

---

## 10. Управление и Эволюция

### 10.1 Процесс Утверждения Целей GPU

Новые цели GPU требуют обзора Архитектурного Совета для обеспечения:
1. Конституционного соответствия (Статьи I, II, IV)
2. Совместимости модели памяти с семантикой владения YADRO
3. Возможности верификации свойств безопасности
4. Обратной совместимости с существующим кодом GPU

### 10.2 Политика Депрекации

Интринсики GPU или цели, нарушающие конституционные принципы, следуют:
- 6-месячному периоду предупреждения с путем миграции
- 3-месячному переходному периоду с opt-in включением
- Удаление требует супербольшинства голосов согласно Статье VI.2

### 10.3 Соображения Безопасности

- Ядра GPU подлежат той же песочнице, что и скрипты сборки YUPPI (YUP 26.1.2 §7.2)
- Бинарные файлы ядер криптографически подписаны в пакетах YUPPI
- Валидация подписей ядер во время выполнения перед исполнением на устройстве
- Защита от атак по сторонним каналам через явные аннотации тайминга

---

## 11. Ссылки

1. YUP 26.1.3: *Конституция YADRO*  
2. YUP 26.1.4: *Стандарт Реализации Компилятора YadroCMP*  
3. YUP 26.1.2: *Спецификация Индекса Пакетов Пользовательских Проектов Yadro (YUPPI)*  
4. NVIDIA CUDA Documentation: https://docs.nvidia.com/cuda/  
5. Khronos SPIR-V Specification: https://www.khronos.org/registry/SPIR-V/  
6. AMD ROCm Documentation: https://rocm.docs.amd.com/  

---

*Этот стандарт выполняет "Право Спускаться" Статьи III.3, предоставляя конституционно безопасный доступ к оборудованию GPU, сохраняя мандат Статьи II.2 на явную конфигурацию и требование Статьи I.1 о статической верификации. Программирование GPU в YADRO остается прозрачным, безопасным и с нулевой стоимостью — никогда не жертвуя конституционными принципами ради производительности.*
