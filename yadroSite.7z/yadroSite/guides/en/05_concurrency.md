# Concurrency in YADRO

YADRO supports both **Async Tasks** (lightweight, green threads) and **OS Threads** (heavyweight).

## 1. Async Tasks (`std.async`)

Use `fun[async]` to define asynchronous functions. These return a `Task[T]` and must be awaited.

```yadro
#import std.async

// Define an async function
fun[async] fetch_data(url: string) -> string:
    // 'await' yields control until the future completes
    let resp = await http.get(url)
    return resp.text()

fun main():
    // Run the async runtime
    async.block_on(async_main())

fun[async] async_main():
    // Spawn a concurrent task
    let task_handle = async.spawn(fetch_data("https://example.com"))
    
    // Do other work...
    
    // Await the result
    let result = await task_handle
    cli.println(result)
```

## 2. Channels

Channels allow safe communication between tasks.

```yadro
import std.async.channel

fun[async] channel_demo():
    let (tx, rx) = channel.unbounded<string>()

    async.spawn(fun[async]():
        tx.send("Hello from task").await
    )

    let msg = rx.recv().await
    cli.println("Received: {}", msg)
```

## 3. OS Threads (`std.thread`)

For CPU-bound tasks, use native OS threads to utilize multiple cores.

```yadro
import std.thread

fun parallel_compute():
    let handle = thread.spawn(|| {
        // Heavy computation
        let mut sum = 0
        for i in 0..1000000: sum += i
        return sum
    })

    // Wait for thread to finish
    let result = handle.join().unwrap()
    cli.println("Result: {}", result)
```

## 4. Shared State (`std.sync`)

When sharing data between threads, use synchronization primitives.

*   `Mutex<T>`: Mutual exclusion.
*   `RwLock<T>`: Read-Write lock.
*   `Arc<T>`: Atomic Reference Counting (for sharing ownership).

```yadro
import std.sync
import std.thread

fun shared_counter():
    let counter = Arc.new(Mutex.new(0))
    let mut handles = Vector.new()

    for _ in 0..10:
        let c = counter.clone()
        handles.push(thread.spawn(move || {
            let mut num = c.lock().unwrap()
            *num += 1
        }))

    for h in handles: h.join()

    print("Count: {}", *counter.lock().unwrap())
```

## 5. Structured Concurrency

Prevent resource leaks by scoping concurrency.

```yadro
fun[async] structured_demo():
    // All tasks spawned in 'scope' must finish before it returns
    async.scope(|s| {
        s.spawn(fetch_data("https://a.com"))
        s.spawn(fetch_data("https://b.com"))
    }).await
```
