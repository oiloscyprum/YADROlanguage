# Tutorial: WebAssembly with GC

This tutorial builds a fully functional **Todo App** running in the browser using YADRO's **WASM GC (Garbage Collection)** support. Unlike traditional WASM (linear memory), WASM GC allows YADRO objects to live directly in the JavaScript heap, enabling seamless interoperability and automatic memory management by the browser.

## Prerequisites

*   YADRO Compiler v0.2.0+
*   A modern browser with WASM GC support (Chrome 119+, Firefox 120+, Safari 17.4+)
*   A static file server (e.g., `python3 -m http.server`)

## 1. Project Setup

Initialize a new project and configure it for the browser target.

### `main.toml`

```toml
[package]
name = "todo-app"
version = "0.1.0"
description = "YADRO Todo App using WASM GC"

[build]
# Target the browser with Garbage Collection enabled
targets = ["wasm32-browser+gc-2.0"]

[wasm.js_ffi]
# Allow access to browser APIs
allowed = ["dom", "console", "events"]
```

### `index.html`

Create an `index.html` file in the project root to host your app.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>YADRO Todo App</title>
    <style>
        body { font-family: sans-serif; max-width: 500px; margin: 2rem auto; }
        .completed { text-decoration: line-through; color: #888; }
        ul { list-style: none; padding: 0; }
        li { padding: 0.5rem; border-bottom: 1px solid #eee; cursor: pointer; }
        input { width: 100%; padding: 0.5rem; box-sizing: border-box; }
    </style>
</head>
<body>
    <h1>YADRO Todos</h1>
    <input type="text" id="new-todo" placeholder="What needs to be done?">
    <div id="app"></div>

    <!-- Load the YADRO WASM module -->
    <script type="module">
        import init from './bin/todo-app.js';
        init();
    </script>
</body>
</html>
```

## 2. The Application Code (`src/main.yad`)

This code demonstrates how to define managed structs, manipulate the DOM, and handle events.

```yadro
#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true

#import
std.wasm_gc.dom
std.wasm_gc.console
std.wasm_gc.events

// 'wasm_struct' defines an object that lives in the JS Heap.
// It is garbage collected by the browser.
wasm_struct Todo {
    string text
    mut bool done
}

// Application State
wasm_struct AppState {
    // 'wasm_array' is a growable array backed by JS Array
    mut wasm_array[wasm_gc[Todo]] todos
    wasm_gc[Element] root_el
}

// Entry point
fun main():
    console.log("Starting YADRO Todo App...")

    // Get reference to DOM elements
    let app_el = dom.get_element_by_id("app")
    let input_el = dom.get_element_by_id("new-todo")

    // Initialize state
    // 'wasm_gc.new' allocates on the managed heap
    let state = wasm_gc.new(AppState {
        todos: wasm_gc.array_new(0),
        root_el: app_el
    })
    
    // Add some default items
    add_todo(state, "Learn YADRO WASM")
    add_todo(state, "Build something cool")
    
    // Render initial state
    render(state)

    // Attach event listener to input
    // We pass a closure that captures 'state'
    input_el.add_event_listener("keypress", move |event| {
        if event.key == "Enter":
            let text = input_el.value
            if text.len() > 0:
                add_todo(state, text)
                input_el.value = "" // Clear input
                render(state)
    })

fun add_todo(mut state: wasm_gc[AppState], text: string):
    let item = wasm_gc.new(Todo { text: text, done: false })
    state.todos.push(item)
    console.log("Added todo: {}", text)

fun toggle_todo(mut state: wasm_gc[AppState], index: u32):
    if index < state.todos.len():
        let item = state.todos.get(index)
        item.done = !item.done
        render(state)

fun render(state: wasm_gc[AppState]):
    // Clear current list
    state.root_el.set_inner_html("")
    
    let ul = dom.create_element("ul")
    ul.set_attribute("class", "todo-list")
    
    // Iterate over todos
    for i in 0..state.todos.len():
        let item = state.todos.get(i)
        let li = dom.create_element("li")
        
        li.set_text(item.text)
        
        if item.done:
            li.set_attribute("class", "completed")
            
        // Add click handler to toggle
        li.add_event_listener("click", move |_| {
            toggle_todo(state, i)
        })
        
        ul.append_child(li)
        
    state.root_el.append_child(ul)
```

## 3. Building and Running

1.  **Build the project**:
    ```bash
    yadro build --release
    ```
    This generates `bin/todo-app.wasm` and `bin/todo-app.js`.

2.  **Serve the directory**:
    ```bash
    python3 -m http.server 8000
    ```

3.  **Open in Browser**:
    Go to `http://localhost:8000`. You should see your Todo app!

## Key Concepts

### `wasm_struct` vs `struct`
*   `struct`: Allocated in linear memory (WASM memory). Manual management or stack allocation.
*   `wasm_struct`: Allocated in the host (browser) heap. Managed by the host's Garbage Collector.

### `wasm_gc[...]`
A reference to a managed object. It acts like a smart pointer but is handled natively by the engine.

### JS Interop
The `std.wasm_gc` modules provide zero-overhead bindings to browser APIs. Because we use WASM GC, we can pass objects directly to JS functions without serialization overhead.
