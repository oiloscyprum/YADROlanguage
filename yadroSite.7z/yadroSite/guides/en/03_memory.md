# Memory Model

YADRO employs a **Dual-Heap Model** that allows you to choose between zero-cost abstractions (like Rust) and easy-to-use garbage collection (like Java/Go), all within the same language.

## 1. Linear Ownership (Default)

The default memory model is **linear ownership**. This means every value has a single owner. When the owner goes out of scope, the value is dropped.

### Rules of Ownership
1.  **Each value has a variable that's called its owner.**
2.  **There can only be one owner at a time.**
3.  **When the owner goes out of scope, the value will be dropped.**

### Move Semantics
Assigning a value to another variable or passing it to a function **moves** the ownership. The previous variable becomes invalid.

```yadro
fun ownership_demo():
    darray[int] v = [1, 2, 3]
    
    // Ownership moved to 'v2'
    darray[int] v2 = v
    
    // println(v) // Compile Error: Use of moved value 'v'
    
    // 'v2' is dropped here
```

### Borrowing
Instead of moving ownership, you can **borrow** references.
*   `&T`: Shared, immutable reference. Multiple allowed.
*   `&mut T`: Exclusive, mutable reference. Only one allowed at a time.

```yadro
fun calculate_length(v: &darray[int]) -> int:
    return v.len() // 'v' is borrowed, not moved

fun add_element(v: &mut darray[int], val: int):
    v.push(val)
```

## 2. Managed Heap (`gc<T>`)

For complex data structures (like graphs) or shared state where ownership is unclear, use the **Managed Heap**.

*   **Reference Counted**: Automatic cleanup when the last reference is dropped.
*   **Explicit**: You must opt-in using `gc<T>`.

```yadro
fun shared_state():
    // Create a reference-counted integer
    gc[int] shared = gc(10)
    
    // Clone increments the reference count (cheap)
    gc[int] ref1 = shared.clone()
    gc[int] ref2 = shared.clone()
    
    print(*ref1) // Access value
```

### Cycle Breaking (`gc_weak<T>`)
Reference counting cannot handle cycles (e.g., A -> B -> A). Use `gc_weak<T>` to break cycles. Weak references do not prevent the value from being dropped.

```yadro
struct Node {
    parent: Option<gc_weak<Node>>,
    children: Vector<gc<Node>>
}
```

## 3. Explicit Destruction (`del`)

You can force immediate destruction of a value using the `del` keyword. This is valid for both linear and managed types (decrements ref count).

```yadro
darray[int] huge_data = [...]
// ... use data ...
del huge_data // Free memory immediately
```

## 4. The `#Copy` Trait

Types that implement `#Copy` are duplicated on assignment instead of moved. This applies to simple primitive types:
*   Integers (`int`, `u8`, etc.)
*   Floats (`f32`, `f64`)
*   `bool`
*   `char`

```yadro
int a = 5
int b = a // 'a' is copied, not moved. Both are valid.
```
