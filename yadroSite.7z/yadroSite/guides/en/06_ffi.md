# Foreign Function Interface (FFI)

YADRO allows seamless interaction with C libraries using the `#requires` directive and `fun[ffi]` function declarations.

## 1. Linking Libraries

Use the `#requires` directive to specify which shared libraries to link against.

```yadro
#requires
"m"             // libm (Math)
"libc.so.6"     // libc (Linux)
// "kernel32.dll" // Windows
```

## 2. Declaring External Functions

Foreign functions are declared using the `fun[ffi(...)]` syntax.

```yadro
// Declare cos function from standard math lib
fun[ffi(lib="m", name="cos")] cos(x: f64) -> f64

fun main():
    let x = 3.14159
    // FFI calls are unsafe
    let y = unsafe { cos(x) }
    cli.println("Cos(PI) = {}", y)
```

## 3. C-Compatible Structs

To pass data structures to C, they must be layout-compatible. Use `#[repr(C)]`.

```yadro
#[repr(C)]
struct Point {
    x: i32,
    y: i32
}

fun[ffi(lib="mylib")] transform_point(p: Point) -> Point

fun use_struct():
    let p = Point { x: 10, y: 20 }
    let p2 = unsafe { transform_point(p) }
```

## 4. Pointers and Memory

C uses raw pointers. In YADRO, these are mapped to `&void`, `&u8`, etc., often wrapped in `unsafe`.

```yadro
fun[ffi(lib="c")] malloc(size: u64) -> &mut void
fun[ffi(lib="c")] free(ptr: &mut void)

fun manual_memory():
    unsafe {
        let ptr = malloc(1024)
        // ... use memory ...
        free(ptr)
    }
```

## 5. Callbacks

You can pass YADRO functions to C, provided they match the ABI.

```yadro
// C signature: void register_callback(void (*cb)(int));
fun[ffi(lib="mylib")] register_callback(cb: fun(i32))

fun my_callback(val: i32):
    cli.println("Callback called with {}", val)

fun main():
    unsafe {
        register_callback(my_callback)
    }
```
