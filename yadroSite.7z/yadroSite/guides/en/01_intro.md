# Getting Started with YADRO

## Installation

YADRO is managed via the **YUPPI** (Yadro User Project Package Index) toolchain. To install:

```bash
# Install YUPPI via curl (Linux/macOS)
curl --proto '=https' --tlsv1.2 -sSf https://yadro.dev/install.sh | sh

# Windows (PowerShell)
iwr https://yadro.dev/install.ps1 -useb | iex
```

After installation, ensure `yadro` is in your PATH.

## Your First Program

Create a new project using YUPPI:

```bash
yadro yuppi init hello-world
cd hello-world
```

This command creates a directory `hello-world` with the necessary files.

Edit `src/main.yad`:

```yadro
#import
std.core.cli

#start
fun main():
    cli.println("Hello, YADRO Universe!")
#end
```

Run it:
```bash
yadro run
```

## Project Structure

A standard YADRO project follows a strict directory layout defined by YUPPI:

```text
my-project/
├── main.toml                 # REQUIRED: Package manifest
├── setup.yad                 # REQUIRED: Build/install script
├── checksum.sha256           # REQUIRED: Package integrity
├── LICENSE                   # OPTIONAL: License file
├── README.md                 # OPTIONAL: Documentation
├── src/                      # Source code root
│   ├── main.yad              # Main module entry point
│   └── utils.yad             # Additional modules
├── include/                  # OPTIONAL: C/C++ headers (for FFI)
├── bin/                      # OPTIONAL: Pre-compiled binaries
└── docs/                     # OPTIONAL: Documentation
```

## Package Manifest (`main.toml`)

The `main.toml` file is the heart of your project. It defines metadata, dependencies, and configuration.

```toml
[package]
name = "hello-world"
version = "0.1.0"
description = "My first YADRO application"
authors = ["Your Name <you@example.com>"]
license = "MIT"

[dependencies]
# Add external packages here
# serde = "1.0"
```

## Toolchain Commands

*   `yadro run`: Compile and run the current project.
*   `yadro build`: Compile the project to a binary.
*   `yadro test`: Run unit tests.
*   `yadro fmt`: Format source code.
*   `yadro check`: Check for errors without generating code.
