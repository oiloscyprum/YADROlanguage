# Getting Started with YADRO

## Installation
YADRO is managed via the **YUPPI** toolchain. To install:

```bash
# Install YUPPI via curl (Linux/macOS)
curl --proto '=https' --tlsv1.2 -sSf https://yadro.dev/install.sh | sh

# Windows (PowerShell)
iwr https://yadro.dev/install.ps1 -useb | iex
```

## Your First Program
Create a new project using YUPPI:

```bash
yadro yuppi init hello-world
cd hello-world
```

Edit `src/main.yad`:

```yadro
#import
std.core.cli

#start
fun main():
    cli.println("Hello, YADRO Universe!")
#end
```

Run it:
```bash
yadro run
```

## Project Structure
A standard YADRO project looks like this:

```text
my-project/
├── main.toml        # Project manifest
├── src/
│   └── main.yad     # Entry point
└── README.md
```
