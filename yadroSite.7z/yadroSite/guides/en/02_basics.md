# Language Basics

## Variables & Mutability

By default, variables are **immutable**. This encourages safety and concurrency. Use `mut` to make them mutable.

```yadro
fun basics():
    // Immutable binding
    int x = 42
    // x = 43           // Compile Error!
    
    // Mutable binding
    mut int y = 10
    y += 5              // OK
    
    // Shadowing is allowed
    int x = x + 1       // New 'x' shadows the old one
```

## Basic Types

YADRO provides a rich set of primitive types.

| Category | Type | Description | Size (bytes) |
|---|---|---|---|
| **Integers** | `i8`, `i16`, `i32`, `i64`, `i128` | Signed integers | 1, 2, 4, 8, 16 |
| | `u8`, `u16`, `u32`, `u64`, `u128` | Unsigned integers | 1, 2, 4, 8, 16 |
| | `int`, `uint` | Machine-dependent (pointer size) | 4 or 8 |
| **Floats** | `f32`, `f64` | IEEE 754 Floating point | 4, 8 |
| **Boolean** | `bool` | `true` or `false` | 1 |
| **Character** | `char` | Unicode Scalar Value (32-bit) | 4 |
| **Void** | `void` | Empty type (size 0) | 0 |

### Literals

```yadro
let decimal = 98_222        // Underscores for readability
let hex = 0xff              // Hexadecimal
let octal = 0o77            // Octal
let binary = 0b1111_0000    // Binary
let byte = b'A'             // u8 literal
let float_val = 2.0         // f64 by default
let float_f32 = 3.14f32     // Explicit type
```

## Complex Types

| Type | Description | Memory Location |
|---|---|---|
| `string` | UTF-8 encoded text string | Heap (Managed or Owned) |
| `array[T, N]` | Fixed-size array | Stack |
| `darray[T]` | Dynamic array (Vector) | Heap |
| `&T`, `&mut T` | References | Stack/Register |
| `Option[T]` | Nullable value wrapper | Stack |

```yadro
// Arrays
array[int, 3] stack_arr = [1, 2, 3]

// Dynamic Arrays
darray[int] heap_arr = [1, 2, 3, 4]
heap_arr.push(5)
```

## Functions

Functions are declared with `fun`.

```yadro
// Standard function
fun add(int a, int b) -> int:
    return a + b

// Named parameters and default values
fun greet(string name, string greeting = "Hello"):
    cli.println("${greeting}, ${name}!")

// Call with named args
greet(name="Alice", greeting="Hi")

// Generic functions
temp<T> fun identity(T val) -> T:
    return val

// Async functions (returns Task[T])
fun[async] fetch_data(string url) -> string:
    // ...
    return "data"
```

## Control Flow

YADRO supports `if`, `switch`, `for`, `while`, and `repeat`.

### Branching

```yadro
if x > 5:
    print("Big")
elsif x < 0:
    print("Negative")
else:
    print("Small")

// Pattern Matching
switch value:
    case 1:
        print("One")
    case 2..10:
        print("Between 2 and 10")
    case x if x % 2 == 0:
        print("Even")
    default:
        print("Other")
```

### Loops

```yadro
// For loop (ranges)
for i in range(0, 10):
    if i == 5: continue
    print(i)

// While loop
while x > 0:
    x -= 1
    if x == 5: break

// Repeat-Until
repeat:
    x += 1
until x >= 10
```

### Labels

Loops can be labeled to break out of nested structures.

```yadro
'outer: for i in range(0, 5):
    for j in range(0, 5):
        if i * j > 10:
            break 'outer
```
