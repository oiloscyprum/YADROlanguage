# Testing in YADRO

YADRO has a built-in test runner. Tests are defined alongside your code.

## 1. Writing Tests

Mark functions with the `#[test]` attribute.

```yadro
// src/math.yad

fun add(a: int, b: int) -> int:
    return a + b

#[test]
fun test_add():
    assert(add(2, 2) == 4, "2+2 should be 4")
    assert(add(-1, 1) == 0, "-1+1 should be 0")
```

## 2. Running Tests

Run all tests in the project using the CLI:

```bash
yadro test
```

Output:
```text
Running tests for package 'my-project'...
[PASS] test_add
[PASS] test_subtract
...
Ok. 2 passed.
```

## 3. Test Configuration

You can conditionally compile code for testing using the `test` config.

```yadro
#[cfg(test)]
fun helper_for_tests_only():
    // ...
```

## 4. Integration Tests

Place integration tests in a `tests/` directory at the project root.

```text
my-project/
├── src/
├── tests/
│   └── integration_test.yad
```

```yadro
// tests/integration_test.yad
#import my_project

#[test]
fun test_public_api():
    // Test the public interface of your package
    ...
```

## 5. Benchmarking

Use `#[bench]` to define benchmarks.

```yadro
#[bench]
fun bench_add(b: &mut Bencher):
    b.iter(|| {
        add(2, 2)
    })
```

Run with `yadro bench`.
