# YADRO Standard Library Reference

The YADRO Standard Library (`std`) provides the essential building blocks for building robust and efficient applications. It is designed to be modular, safe, and performant.

## Modules Overview

| Module | Description |
| :--- | :--- |
| `std.core` | Core primitive types, macros (`print`, `panic`), and `Option`/`Result` types. |
| `std.io` | Input/output operations for files and standard streams (`stdin`, `stdout`). |
| `std.fs` | Filesystem manipulation (Paths, Directories, Metadata). |
| `std.collections` | Common data structures like `Vector`, `HashMap`, and `HashSet`. |
| `std.math` | Mathematical functions (`sin`, `sqrt`) and constants (`PI`). |
| `std.net` | Networking primitives for TCP and UDP communication. |
| `std.http` | High-level HTTP client (`Client`, `Request`, `Response`). |
| `std.async` | Asynchronous runtime helpers, `Task`, `Future`, and `spawn`. |
| `std.thread` | Native system threads and thread-local storage. |
| `std.sync` | Synchronization primitives (`Mutex`, `RwLock`, `Arc`, `Barrier`). |
| `std.crypto` | Cryptographic primitives (Hashing, RNG, Encryption). |
| `std.regex` | Regular expression compilation and matching. |
| `std.time` | Time measurement and manipulation (`Duration`, `Instant`). |
| `std.os` | OS interactions (Environment variables, Process management). |
| `std.ffi` | Foreign Function Interface for C interoperability. |
| `std.log` | Logging facilities (`error`, `warn`, `info`, `debug`, `trace`). |
| `std.cli` | Command Line Argument Parser. |
| `std.json` | JSON serialization and deserialization. |

## Core Module (`std.core`)
The `std.core` module is automatically imported in every YADRO program (unless `#no_std` is used).

### Basic Output
```yadro
println("Hello, {}", "World");
panic("Critical error occurred");
```

### Option & Result
Handle nullable values and errors safely.
```yadro
let x: Option<int> = Some(42);
let y: Result<File, string> = File.open("data.txt");
```

## Collections (`std.collections`)

### Vector
A dynamic, growable array.
```yadro
import std.collections

let mut v = Vector.new();
v.push(10);
v.push(20);
```

### HashMap
Key-value storage.
```yadro
let mut map = HashMap.new();
map.insert("key", "value");
```

## IO & Filesystem (`std.io`, `std.fs`)
File system access and stream manipulation.

```yadro
import std.io
import std.fs

let path = Path.new("config.toml");
if path.exists() {
    let file = File.open(path)?;
    let content = file.read_to_string()?;
    println("Config: {}", content);
}

// Directory listing
for entry in fs.read_dir(".")? {
    println!("{}", entry.path);
}
```

## Concurrency (`std.thread`, `std.sync`)
Parallel execution with threads and shared state.

```yadro
import std.thread
import std.sync

let counter = Arc.new(Mutex.new(0));
let mut handles = Vector.new();

for _ in 0..10 {
    let c = counter.clone();
    handles.push(thread.spawn(move || {
        let mut num = c.lock().unwrap();
        *num += 1;
    }));
}

for h in handles { h.join()?; }
```

## Networking (`std.net`, `std.http`)
Building networked applications and web clients.

```yadro
import std.net
import std.http

// TCP Server
let listener = TcpListener.bind(SocketAddr.new("127.0.0.1", 8080))?;
let (stream, addr) = listener.accept()?;

// HTTP Client
let response = http.get("https://api.yadro.dev/v1/status")?;
println("Status: {}", response.status);
let json: HashMap<string, string> = response.json()?;
```

## CLI & Logging (`std.cli`, `std.log`)
Building command-line tools.

```yadro
import std.cli
import std.log

fun main() {
    let app = App.new("myapp")
        .version("1.0")
        .arg(Arg.with_name("input").required(true));
        
    let matches = app.get_matches();
    
    if let Some(input) = matches.value_of("input") {
        log.info("Processing input: {}", input);
    }
}
```

## FFI (`std.ffi`)
Interfacing with C libraries.

```yadro
import std.ffi

let lib = Library.load("libm.so")?;
let cos: fun(f64) -> f64 = lib.get("cos")?;
println("Cos(0) = {}", cos(0.0));
```

## Async (`std.async`)
Asynchronous tasks.

```yadro
import std.async

async fun fetch_data() -> string {
    // ...
}

fun main() {
    let task = spawn(fetch_data());
    let result = task.await();
}
```

## Crypto (`std.crypto`)
Secure hashing and encryption.

```yadro
import std.crypto

let sha256 = Sha256.new();
let hash = sha256.hash("password".as_bytes());

let rng = Rng.os_rng();
let random_num = rng.next_u64();
```

## Regex (`std.regex`)
Pattern matching.

```yadro
import std.regex

let re = Regex.new(r"^\d{4}-\d{2}-\d{2}$")?;
if re.is_match("2026-02-10") {
    println("Valid date format");
}
```

## Time (`std.time`)
Timing and duration.

```yadro
import std.time

let start = Instant.now();
// ... operation ...
let duration = start.elapsed();
println("Took {} ms", duration.as_millis());
```

## OS (`std.os`)
Operating system interaction.

```yadro
import std.os

let args = os.args();
let path = os.var("PATH")?;

let output = Command.new("ls").arg("-la").output()?;
```

## JSON (`std.json`)
Data serialization.

```yadro
import std.json

let data = json!({ "name": "YADRO", "ver": 0.2 });
let json_str = json.to_string(&data)?;
```

## Testing (`std.test`)
Unit testing framework.

```yadro
import std.test

test.run("addition", || {
    test.assert_eq(2 + 2, 4);
});
```

## Encoding (`std.encoding`)
Support for Base64, Hex, and CSV.

```yadro
import std.encoding

let b64 = encoding.base64.encode("hello".bytes());
let csv_reader = encoding.csv.Reader.new();
```

## Compression (`std.compress`)
Gzip and Zlib support.

```yadro
import std.compress

let compressed = compress.gzip.Encoder.new(9).compress(data)?;
```

## XML (`std.xml`)
XML parsing and generation.

```yadro
import std.xml

let root = xml.parse("<root><child>text</child></root>")?;
```

## Iterators (`std.iter`)
Composable iteration primitives.

```yadro
import std.iter

let r = iter.range(0, 10);
while let Some(i) = r.next() {
    println("{}", i);
}
```

## Random (`std.random`)
Non-cryptographic random number generation.

```yadro
import std.random

let mut rng = random.Pcg32.seed_from_time();
let n = rng.range(1, 100);
```

## URL (`std.url`)
URL parsing and manipulation.

```yadro
import std.url

let url = url.Url.parse("https://yadro.dev")?;
println("Host: {}", url.host);
```

## Prelude (`std.prelude`)
Common imports.

```yadro
import std.prelude

// Now you can use Vector, HashMap, Result without full paths
let v: Vector<int> = Vector.new();
```

## Channels (`std.channels`)
MPSC (Multi-Producer, Single-Consumer) channels.

```yadro
import std.channels
import std.thread

let (tx, rx) = channels.channel();

thread.spawn(move || {
    tx.send("Hello from thread").unwrap();
});

println("Received: {}", rx.recv().unwrap());
```

## Date & Time (`std.date`)
Calendar dates and formatting.

```yadro
import std.date

let now = date.DateTime.now();
println("Current time: {}", now.to_string());
```

## UUID (`std.uuid`)
Universally Unique Identifiers (v4).

```yadro
import std.uuid

let id = uuid.Uuid.new_v4();
println("New ID: {}", id.to_string());
```

## Formatting (`std.fmt`)
Display and Debug traits.

```yadro
import std.fmt

struct Point { x: i32, y: i32 }

impl fmt.Display for Point {
    fun fmt(self, f: &mut fmt.Formatter) -> Result<Unit, string> {
        f.write_str("Point");
        return Result.Ok(Unit);
    }
}
```

## Project Structure
The standard library is organized as follows in the YADRO source tree:

```
stdlib/
├── core.yad        # Core definitions
├── io.yad          # I/O operations
├── fs.yad          # Filesystem
├── collections.yad # Data structures
├── math.yad        # Math functions
├── net.yad         # Networking
├── http.yad        # HTTP Client
├── async.yad       # Async runtime
├── thread.yad      # Threads
├── sync.yad        # Synchronization
├── crypto.yad      # Cryptography
├── regex.yad       # Regular Expressions
├── time.yad        # Time & Duration
├── os.yad          # System interaction
├── ffi.yad         # C Interop
├── log.yad         # Logging
├── cli.yad         # CLI Parser
├── json.yad        # JSON support
├── test.yad        # Unit testing
├── encoding.yad    # Data encoding
├── compress.yad    # Compression
├── xml.yad         # XML parser
├── iter.yad        # Iterators
├── random.yad      # Random numbers
├── url.yad         # URL parser
├── channels.yad    # MPSC Channels
├── prelude.yad     # Standard prelude
├── date.yad        # Date & Calendar
├── uuid.yad        # UUID generator
└── fmt.yad         # Formatting traits
```
