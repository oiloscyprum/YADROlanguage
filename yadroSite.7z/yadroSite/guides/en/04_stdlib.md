# YADRO Standard Library Reference

The YADRO Standard Library (`std`) provides the essential building blocks for building robust and efficient applications.

## Core Module (`std.core`)

Imported automatically. Provides fundamental types and macros.

### Option & Result

Error handling in YADRO uses `Option` for nullable values and `Result` for recoverable errors.

```yadro
pub enum Option<T> { None, Some(T) }
pub enum Result<T, E> { Ok(T), Err(E) }
```

**Common Methods:**
*   `unwrap()`: Returns value or panics.
*   `expect(msg)`: Returns value or panics with message.
*   `is_some()`, `is_none()`, `is_ok()`, `is_err()`: Status checks.

### Macros
*   `print(fmt, ...)`: Print to stdout.
*   `println(fmt, ...)`: Print line to stdout.
*   `panic(msg)`: Abort execution.
*   `assert(cond, msg)`: Verify condition.

## Collections (`std.collections`)

### Vector (`darray`)
A dynamic, growable array.

```yadro
import std.collections

let mut v = Vector.new()
v.push(10)
v.push(20)
let item = v.pop() // Option<int>
let len = v.len()
```

### HashMap
Key-value storage. Keys must implement `Hash` + `Eq`.

```yadro
let mut map = HashMap.new()
map.insert("key", "value")
if map.contains_key("key"):
    print(map.get("key"))
```

## IO & Filesystem (`std.io`, `std.fs`)

### File Operations
```yadro
import std.fs

// Open for reading
let file = File.open("data.txt")?
let content = file.read_to_string()?

// Create/Write
let mut out = File.create("log.txt")?
out.write(b"Log entry")?
```

### Buffering
Wrap readers/writers for performance.
```yadro
let reader = BufReader.new(file)
let line = reader.read_line()?
```

## Concurrency (`std.thread`, `std.sync`)

### Threads
```yadro
import std.thread

let handle = thread.spawn(|| {
    // Run in new thread
    return 42
})
let result = handle.join()
```

### Synchronization
Shared state requires locking.
```yadro
import std.sync

let mutex = Mutex.new(0)
{
    let mut num = mutex.lock().unwrap()
    *num += 1
} // Lock released here
```

## Networking (`std.net`, `std.http`)

### HTTP Client
```yadro
import std.http

let client = http.Client.new()
let resp = client.get("https://yadro.dev")?
println(resp.text()?)
```

### TCP Server
```yadro
import std.net

let listener = TcpListener.bind("127.0.0.1:8080")?
for stream in listener.incoming():
    handle_connection(stream?)
```
