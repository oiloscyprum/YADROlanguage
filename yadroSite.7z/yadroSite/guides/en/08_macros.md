# Macros in YADRO

Macros allow you to write code that writes code. YADRO supports **Declarative Macros** (pattern matching) and **Procedural Macros** (AST manipulation).

## 1. Declarative Macros (`macro`)

Declarative macros use pattern matching to replace syntax.

```yadro
macro say_hello {
    () => {
        cli.println("Hello!")
    };
    ($name:expr) => {
        cli.println("Hello, {}!", $name)
    };
}

fun main():
    say_hello!()
    say_hello!("Alice")
```

## 2. Metaprogramming

Macros operate on the Abstract Syntax Tree (AST) at compile time.

### Hygiene
Macros are **hygienic** by default. Variables defined inside a macro do not leak into the outer scope unless explicitly intended.

## 3. Common Built-in Macros

*   `print!`, `println!`: Formatting output.
*   `panic!`: Crash the program.
*   `assert!`: Runtime check.
*   `vec!`: Create a vector.

```yadro
let v = vec![1, 2, 3]
```

## 4. Conditional Compilation

Use `#[cfg(...)]` to include code based on build flags.

```yadro
#[cfg(target_os = "linux")]
fun linux_only():
    println("I am on Linux")

#[cfg(not(debug_assertions))]
fun production_mode():
    // ...
```
