# Справочник стандартной библиотеки YADRO

Стандартная библиотека YADRO (`std`) предоставляет основные строительные блоки для создания надежных и эффективных приложений.

## Основной модуль (`std.core`)

Импортируется автоматически. Предоставляет фундаментальные типы и макросы.

### Option и Result

Обработка ошибок в YADRO использует `Option` для nullable значений и `Result` для восстановимых ошибок.

```yadro
pub enum Option<T> { None, Some(T) }
pub enum Result<T, E> { Ok(T), Err(E) }
```

**Общие методы:**
*   `unwrap()`: Возвращает значение или паникует.
*   `expect(msg)`: Возвращает значение или паникует с сообщением.
*   `is_some()`, `is_none()`, `is_ok()`, `is_err()`: Проверки статуса.

### Макросы
*   `print(fmt, ...)`: Печать в stdout.
*   `println(fmt, ...)`: Печать строки в stdout.
*   `panic(msg)`: Аварийное завершение выполнения.
*   `assert(cond, msg)`: Проверка условия.

## Коллекции (`std.collections`)

### Vector (`darray`)
Динамический, расширяемый массив.

```yadro
import std.collections

let mut v = Vector.new()
v.push(10)
v.push(20)
let item = v.pop() // Option<int>
let len = v.len()
```

### HashMap
Хранилище ключ-значение. Ключи должны реализовывать `Hash` + `Eq`.

```yadro
let mut map = HashMap.new()
map.insert("key", "value")
if map.contains_key("key"):
    print(map.get("key"))
```

## Ввод/Вывод и Файловая система (`std.io`, `std.fs`)

### Операции с файлами
```yadro
import std.fs

// Открытие для чтения
let file = File.open("data.txt")?
let content = file.read_to_string()?

// Создание/Запись
let mut out = File.create("log.txt")?
out.write(b"Log entry")?
```

### Буферизация
Оберните читатели/писатели для производительности.
```yadro
let reader = BufReader.new(file)
let line = reader.read_line()?
```

## Конкурентность (`std.thread`, `std.sync`)

### Потоки (Threads)
```yadro
import std.thread

let handle = thread.spawn(|| {
    // Запуск в новом потоке
    return 42
})
let result = handle.join()
```

### Синхронизация
Общее состояние требует блокировки.
```yadro
import std.sync

let mutex = Mutex.new(0)
{
    let mut num = mutex.lock().unwrap()
    *num += 1
} // Блокировка снимается здесь
```

## Сеть (`std.net`, `std.http`)

### HTTP Клиент
```yadro
import std.http

let client = http.Client.new()
let resp = client.get("https://yadro.dev")?
println(resp.text()?)
```

### TCP Сервер
```yadro
import std.net

let listener = TcpListener.bind("127.0.0.1:8080")?
for stream in listener.incoming():
    handle_connection(stream?)
```
