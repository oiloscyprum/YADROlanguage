# Интерфейс внешних функций (FFI)

YADRO позволяет беспрепятственно взаимодействовать с библиотеками C, используя директиву `#requires` и объявления функций `fun[ffi]`.

## 1. Компоновка библиотек

Используйте директиву `#requires`, чтобы указать, с какими разделяемыми библиотеками производить линковку.

```yadro
#requires
"m"             // libm (Математика)
"libc.so.6"     // libc (Linux)
// "kernel32.dll" // Windows
```

## 2. Объявление внешних функций

Внешние функции объявляются с использованием синтаксиса `fun[ffi(...)]`.

```yadro
// Объявляем функцию cos из стандартной математической библиотеки
fun[ffi(lib="m", name="cos")] cos(x: f64) -> f64

fun main():
    let x = 3.14159
    // Вызовы FFI небезопасны (unsafe)
    let y = unsafe { cos(x) }
    cli.println("Cos(PI) = {}", y)
```

## 3. C-совместимые структуры

Чтобы передавать структуры данных в C, они должны быть совместимы по расположению в памяти (layout). Используйте `#[repr(C)]`.

```yadro
#[repr(C)]
struct Point {
    x: i32,
    y: i32
}

fun[ffi(lib="mylib")] transform_point(p: Point) -> Point

fun use_struct():
    let p = Point { x: 10, y: 20 }
    let p2 = unsafe { transform_point(p) }
```

## 4. Указатели и память

C использует сырые указатели. В YADRO они отображаются на `&void`, `&u8` и т.д., часто обернутые в `unsafe`.

```yadro
fun[ffi(lib="c")] malloc(size: u64) -> &mut void
fun[ffi(lib="c")] free(ptr: &mut void)

fun manual_memory():
    unsafe {
        let ptr = malloc(1024)
        // ... использование памяти ...
        free(ptr)
    }
```

## 5. Обратные вызовы (Callbacks)

Вы можете передавать функции YADRO в C, при условии, что они соответствуют ABI.

```yadro
// Сигнатура C: void register_callback(void (*cb)(int));
fun[ffi(lib="mylib")] register_callback(cb: fun(i32))

fun my_callback(val: i32):
    cli.println("Обратный вызов с {}", val)

fun main():
    unsafe {
        register_callback(my_callback)
    }
```
