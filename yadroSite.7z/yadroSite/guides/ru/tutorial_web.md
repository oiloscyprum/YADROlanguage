# Урок: WebAssembly с GC

В этом уроке мы создадим полнофункциональное **приложение Todo**, работающее в браузере с использованием поддержки **WASM GC (сборщик мусора)** в YADRO. В отличие от традиционного WASM (линейная память), WASM GC позволяет объектам YADRO жить непосредственно в куче JavaScript, обеспечивая бесшовную совместимость и автоматическое управление памятью браузером.

## Предварительные требования

*   Компилятор YADRO v0.2.0+
*   Современный браузер с поддержкой WASM GC (Chrome 119+, Firefox 120+, Safari 17.4+)
*   Статический файловый сервер (например, `python3 -m http.server`)

## 1. Настройка проекта

Инициализируйте новый проект и настройте его для целевой платформы браузера.

### `main.toml`

```toml
[package]
name = "todo-app"
version = "0.1.0"
description = "YADRO Todo App с использованием WASM GC"

[build]
# Цель сборки - браузер с включенным сборщиком мусора
targets = ["wasm32-browser+gc-2.0"]

[wasm.js_ffi]
# Разрешить доступ к API браузера
allowed = ["dom", "console", "events"]
```

### `index.html`

Создайте файл `index.html` в корне проекта для размещения вашего приложения.

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>YADRO Todo App</title>
    <style>
        body { font-family: sans-serif; max-width: 500px; margin: 2rem auto; }
        .completed { text-decoration: line-through; color: #888; }
        ul { list-style: none; padding: 0; }
        li { padding: 0.5rem; border-bottom: 1px solid #eee; cursor: pointer; }
        input { width: 100%; padding: 0.5rem; box-sizing: border-box; }
    </style>
</head>
<body>
    <h1>YADRO Задачи</h1>
    <input type="text" id="new-todo" placeholder="Что нужно сделать?">
    <div id="app"></div>

    <!-- Загрузка модуля YADRO WASM -->
    <script type="module">
        import init from './bin/todo-app.js';
        init();
    </script>
</body>
</html>
```

## 2. Код приложения (`src/main.yad`)

Этот код демонстрирует, как определять управляемые структуры, манипулировать DOM и обрабатывать события.

```yadro
#target
arch = "wasm32"
wasm = "gc-2.0"
js_ffi = true

#import
std.wasm_gc.dom
std.wasm_gc.console
std.wasm_gc.events

// 'wasm_struct' определяет объект, который живет в куче JS.
// Он управляется сборщиком мусора браузера.
wasm_struct Todo {
    string text
    mut bool done
}

// Состояние приложения
wasm_struct AppState {
    // 'wasm_array' - расширяемый массив, поддерживаемый массивом JS
    mut wasm_array[wasm_gc[Todo]] todos
    wasm_gc[Element] root_el
}

// Точка входа
fun main():
    console.log("Запуск YADRO Todo App...")

    // Получаем ссылки на элементы DOM
    let app_el = dom.get_element_by_id("app")
    let input_el = dom.get_element_by_id("new-todo")

    // Инициализируем состояние
    // 'wasm_gc.new' выделяет память в управляемой куче
    let state = wasm_gc.new(AppState {
        todos: wasm_gc.array_new(0),
        root_el: app_el
    })
    
    // Добавляем несколько задач по умолчанию
    add_todo(state, "Изучить YADRO WASM")
    add_todo(state, "Создать что-то крутое")
    
    // Отрисовываем начальное состояние
    render(state)

    // Прикрепляем слушатель событий к вводу
    // Мы передаем замыкание, которое захватывает 'state'
    input_el.add_event_listener("keypress", move |event| {
        if event.key == "Enter":
            let text = input_el.value
            if text.len() > 0:
                add_todo(state, text)
                input_el.value = "" // Очистить ввод
                render(state)
    })

fun add_todo(mut state: wasm_gc[AppState], text: string):
    let item = wasm_gc.new(Todo { text: text, done: false })
    state.todos.push(item)
    console.log("Добавлена задача: {}", text)

fun toggle_todo(mut state: wasm_gc[AppState], index: u32):
    if index < state.todos.len():
        let item = state.todos.get(index)
        item.done = !item.done
        render(state)

fun render(state: wasm_gc[AppState]):
    // Очистить текущий список
    state.root_el.set_inner_html("")
    
    let ul = dom.create_element("ul")
    ul.set_attribute("class", "todo-list")
    
    // Итерация по задачам
    for i in 0..state.todos.len():
        let item = state.todos.get(i)
        let li = dom.create_element("li")
        
        li.set_text(item.text)
        
        if item.done:
            li.set_attribute("class", "completed")
            
        // Добавляем обработчик клика для переключения
        li.add_event_listener("click", move |_| {
            toggle_todo(state, i)
        })
        
        ul.append_child(li)
        
    state.root_el.append_child(ul)
```

## 3. Сборка и запуск

1.  **Соберите проект**:
    ```bash
    yadro build --release
    ```
    Это создаст `bin/todo-app.wasm` и `bin/todo-app.js`.

2.  **Запустите сервер**:
    ```bash
    python3 -m http.server 8000
    ```

3.  **Откройте в браузере**:
    Перейдите по адресу `http://localhost:8000`. Вы должны увидеть ваше приложение Todo!

## Ключевые концепции

### `wasm_struct` против `struct`
*   `struct`: Выделяется в линейной памяти (память WASM). Ручное управление или размещение в стеке.
*   `wasm_struct`: Выделяется в куче хоста (браузера). Управляется сборщиком мусора хоста.

### `wasm_gc[...]`
Ссылка на управляемый объект. Действует как умный указатель, но обрабатывается нативно движком.

### Взаимодействие с JS (JS Interop)
Модули `std.wasm_gc` предоставляют привязки к API браузера с нулевыми накладными расходами. Поскольку мы используем WASM GC, мы можем передавать объекты непосредственно в функции JS без накладных расходов на сериализацию.
