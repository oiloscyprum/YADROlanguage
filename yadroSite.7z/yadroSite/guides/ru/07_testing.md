# Тестирование в YADRO

YADRO имеет встроенный инструмент для запуска тестов. Тесты определяются рядом с вашим кодом.

## 1. Написание тестов

Помечайте функции атрибутом `#[test]`.

```yadro
// src/math.yad

fun add(a: int, b: int) -> int:
    return a + b

#[test]
fun test_add():
    assert(add(2, 2) == 4, "2+2 должно быть 4")
    assert(add(-1, 1) == 0, "-1+1 должно быть 0")
```

## 2. Запуск тестов

Запустите все тесты в проекте, используя CLI:

```bash
yadro test
```

Вывод:
```text
Running tests for package 'my-project'...
[PASS] test_add
[PASS] test_subtract
...
Ok. 2 passed.
```

## 3. Конфигурация тестов

Вы можете условно компилировать код для тестирования, используя конфигурацию `test`.

```yadro
#[cfg(test)]
fun helper_for_tests_only():
    // ...
```

## 4. Интеграционные тесты

Размещайте интеграционные тесты в директории `tests/` в корне проекта.

```text
my-project/
├── src/
├── tests/
│   └── integration_test.yad
```

```yadro
// tests/integration_test.yad
#import my_project

#[test]
fun test_public_api():
    // Тестирование публичного интерфейса вашего пакета
    ...
```

## 5. Бенчмаркинг

Используйте `#[bench]` для определения бенчмарков.

```yadro
#[bench]
fun bench_add(b: &mut Bencher):
    b.iter(|| {
        add(2, 2)
    })
```

Запуск с помощью `yadro bench`.
