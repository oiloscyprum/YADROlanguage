# Основы языка

## Переменные и Мутабельность

По умолчанию переменные **неизменяемы (immutable)**. Это способствует безопасности и конкурентности. Используйте `mut`, чтобы сделать их изменяемыми.

```yadro
fun basics():
    // Неизменяемая привязка
    int x = 42
    // x = 43           // Ошибка компиляции!
    
    // Изменяемая привязка
    mut int y = 10
    y += 5              // OK
    
    // Затенение (Shadowing) разрешено
    int x = x + 1       // Новая 'x' затеняет старую
```

## Базовые типы

YADRO предоставляет богатый набор примитивных типов.

| Категория | Тип | Описание | Размер (байт) |
|---|---|---|---|
| **Целые числа** | `i8`, `i16`, `i32`, `i64`, `i128` | Знаковые целые | 1, 2, 4, 8, 16 |
| | `u8`, `u16`, `u32`, `u64`, `u128` | Беззнаковые целые | 1, 2, 4, 8, 16 |
| | `int`, `uint` | Машинно-зависимые (размер указателя) | 4 или 8 |
| **С плавающей точкой** | `f32`, `f64` | IEEE 754 | 4, 8 |
| **Логический** | `bool` | `true` или `false` | 1 |
| **Символ** | `char` | Скалярное значение Unicode (32-бит) | 4 |
| **Пустой** | `void` | Пустой тип (размер 0) | 0 |

### Литералы

```yadro
let decimal = 98_222        // Подчеркивания для читаемости
let hex = 0xff              // Шестнадцатеричный
let octal = 0o77            // Восьмеричный
let binary = 0b1111_0000    // Двоичный
let byte = b'A'             // u8 литерал
let float_val = 2.0         // f64 по умолчанию
let float_f32 = 3.14f32     // Явный тип
```

## Сложные типы

| Тип | Описание | Расположение в памяти |
|---|---|---|
| `string` | UTF-8 строка текста | Куча (Managed или Owned) |
| `array[T, N]` | Массив фиксированного размера | Стек |
| `darray[T]` | Динамический массив (Vector) | Куча |
| `&T`, `&mut T` | Ссылки | Стек/Регистр |
| `Option[T]` | Обертка для nullable значений | Стек |

```yadro
// Массивы
array[int, 3] stack_arr = [1, 2, 3]

// Динамические массивы
darray[int] heap_arr = [1, 2, 3, 4]
heap_arr.push(5)
```

## Функции

Функции объявляются с помощью `fun`.

```yadro
// Стандартная функция
fun add(int a, int b) -> int:
    return a + b

// Именованные параметры и значения по умолчанию
fun greet(string name, string greeting = "Hello"):
    cli.println("${greeting}, ${name}!")

// Вызов с именованными аргументами
greet(name="Alice", greeting="Hi")

// Обобщенные функции (Generics)
temp<T> fun identity(T val) -> T:
    return val

// Асинхронные функции (возвращают Task[T])
fun[async] fetch_data(string url) -> string:
    // ...
    return "data"
```

## Управление потоком

YADRO поддерживает `if`, `switch`, `for`, `while` и `repeat`.

### Ветвление

```yadro
if x > 5:
    print("Big")
elsif x < 0:
    print("Negative")
else:
    print("Small")

// Сопоставление с образцом (Pattern Matching)
switch value:
    case 1:
        print("One")
    case 2..10:
        print("Between 2 and 10")
    case x if x % 2 == 0:
        print("Even")
    default:
        print("Other")
```

### Циклы

```yadro
// Цикл for (диапазоны)
for i in range(0, 10):
    if i == 5: continue
    print(i)

// Цикл while
while x > 0:
    x -= 1
    if x == 5: break

// Repeat-Until
repeat:
    x += 1
until x >= 10
```

### Метки

Циклы могут быть помечены для выхода из вложенных структур.

```yadro
'outer: for i in range(0, 5):
    for j in range(0, 5):
        if i * j > 10:
            break 'outer
```
