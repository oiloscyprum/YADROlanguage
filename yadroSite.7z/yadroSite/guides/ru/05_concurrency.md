# Конкурентность в YADRO

YADRO поддерживает как **Асинхронные задачи (Async Tasks)** (легковесные, зеленые потоки), так и **Потоки ОС (OS Threads)** (тяжеловесные).

## 1. Асинхронные задачи (`std.async`)

Используйте `fun[async]` для определения асинхронных функций. Они возвращают `Task[T]` и должны ожидать завершения с помощью `await`.

```yadro
#import std.async

// Определение асинхронной функции
fun[async] fetch_data(url: string) -> string:
    // 'await' передает управление, пока future не завершится
    let resp = await http.get(url)
    return resp.text()

fun main():
    // Запуск асинхронной среды выполнения
    async.block_on(async_main())

fun[async] async_main():
    // Запуск конкурентной задачи
    let task_handle = async.spawn(fetch_data("https://example.com"))
    
    // Делаем другую работу...
    
    // Ожидание результата
    let result = await task_handle
    cli.println(result)
```

## 2. Каналы (Channels)

Каналы позволяют безопасно обмениваться данными между задачами.

```yadro
import std.async.channel

fun[async] channel_demo():
    let (tx, rx) = channel.unbounded<string>()

    async.spawn(fun[async]():
        tx.send("Привет из задачи").await
    )

    let msg = rx.recv().await
    cli.println("Получено: {}", msg)
```

## 3. Потоки ОС (`std.thread`)

Для задач, интенсивно использующих процессор, используйте нативные потоки ОС для утилизации нескольких ядер.

```yadro
import std.thread

fun parallel_compute():
    let handle = thread.spawn(|| {
        // Тяжелые вычисления
        let mut sum = 0
        for i in 0..1000000: sum += i
        return sum
    })

    // Ожидание завершения потока
    let result = handle.join().unwrap()
    cli.println("Результат: {}", result)
```

## 4. Общее состояние (`std.sync`)

При совместном использовании данных между потоками используйте примитивы синхронизации.

*   `Mutex<T>`: Взаимное исключение (Мьютекс).
*   `RwLock<T>`: Блокировка чтения-записи.
*   `Arc<T>`: Атомарный подсчет ссылок (для совместного владения).

```yadro
import std.sync
import std.thread

fun shared_counter():
    let counter = Arc.new(Mutex.new(0))
    let mut handles = Vector.new()

    for _ in 0..10:
        let c = counter.clone()
        handles.push(thread.spawn(move || {
            let mut num = c.lock().unwrap()
            *num += 1
        }))

    for h in handles: h.join()

    print("Счетчик: {}", *counter.lock().unwrap())
```

## 5. Структурированная конкурентность

Предотвращайте утечки ресурсов, ограничивая область видимости конкурентности.

```yadro
fun[async] structured_demo():
    // Все задачи, запущенные в 'scope', должны завершиться до выхода из него
    async.scope(|s| {
        s.spawn(fetch_data("https://a.com"))
        s.spawn(fetch_data("https://b.com"))
    }).await
```
