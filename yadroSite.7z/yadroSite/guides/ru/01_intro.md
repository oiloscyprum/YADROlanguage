# Начало работы с YADRO

## Установка

YADRO управляется через инструментарий **YUPPI** (Yadro User Project Package Index). Для установки:

```bash
# Установка YUPPI через curl (Linux/macOS)
curl --proto '=https' --tlsv1.2 -sSf https://yadro.dev/install.sh | sh

# Windows (PowerShell)
iwr https://yadro.dev/install.ps1 -useb | iex
```

После установки убедитесь, что `yadro` находится в вашем PATH.

## Ваша первая программа

Создайте новый проект с помощью YUPPI:

```bash
yadro yuppi init hello-world
cd hello-world
```

Эта команда создает директорию `hello-world` с необходимыми файлами.

Откройте `src/main.yad`:

```yadro
#import
std.core.cli

#start
fun main():
    cli.println("Привет, Вселенная YADRO!")
#end
```

Запустите программу:
```bash
yadro run
```

## Структура проекта

Стандартный проект YADRO имеет строгую структуру, определенную YUPPI:

```text
my-project/
├── main.toml                 # ОБЯЗАТЕЛЬНО: Манифест пакета
├── setup.yad                 # ОБЯЗАТЕЛЬНО: Скрипт сборки/установки
├── checksum.sha256           # ОБЯЗАТЕЛЬНО: Целостность пакета
├── LICENSE                   # ОПЦИОНАЛЬНО: Файл лицензии
├── README.md                 # ОПЦИОНАЛЬНО: Документация
├── src/                      # Исходный код
│   ├── main.yad              # Точка входа основного модуля
│   └── utils.yad             # Дополнительные модули
├── include/                  # ОПЦИОНАЛЬНО: C/C++ заголовки (для FFI)
├── bin/                      # ОПЦИОНАЛЬНО: Скомпилированные бинарники
└── docs/                     # ОПЦИОНАЛЬНО: Документация
```

## Манифест пакета (`main.toml`)

Файл `main.toml` — это сердце вашего проекта. Он определяет метаданные, зависимости и конфигурацию.

```toml
[package]
name = "hello-world"
version = "0.1.0"
description = "Мое первое приложение на YADRO"
authors = ["Ваше Имя <you@example.com>"]
license = "MIT"

[dependencies]
# Добавьте внешние пакеты здесь
# serde = "1.0"
```

## Команды инструментария

*   `yadro run`: Компиляция и запуск текущего проекта.
*   `yadro build`: Компиляция проекта в бинарный файл.
*   `yadro test`: Запуск модульных тестов.
*   `yadro fmt`: Форматирование исходного кода.
*   `yadro check`: Проверка на ошибки без генерации кода.
