import os

def main():
    file_path = r"c:\Users\Admin\Downloads\yadroSite\docs.html"
    
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Find the line with <div id="app"> and the closing </div>
    # Actually, we know the structure. We want to keep everything up to the last <script> block which contains the Vue app.
    # The read output showed the main script starts at line 537.
    # Let's verify by content.
    
    cut_index = -1
    for i, line in enumerate(lines):
        if line.strip() == '<script>' and i > 500: # It's near the end
            cut_index = i
            break
            
    if cut_index == -1:
        print("Could not find the script tag.")
        return

    # Keep lines before the script
    new_content_lines = lines[:cut_index]
    
    # Append the new script
    new_script = r"""    <script>
        const { createApp, ref, computed, watch } = Vue;
        const { createRouter, createWebHashHistory } = VueRouter;

        // --- Data: Load from external bundle ---
        const contentData = window.SITE_CONTENT || { specs: {}, guides: {}, guideMeta: [] };

        // --- I18n ---
        const messages = {
            en: {
                nav: { home: 'Home', constitution: 'Constitution', yuppi: 'YUPPI', docs: 'Docs' },
                hero: { title: 'YADRO', subtitle: "Your Architecture's Definitive Runtime Optimizer", cta: 'Get Started' },
                features: { 
                    safety: 'Static Verification', safety_desc: 'Correctness and safety proven at compile time.',
                    perf: 'Zero-Cost', perf_desc: 'High-level constructs, assembly-level performance.',
                    eco: 'YUPPI Ecosystem', eco_desc: 'Secure package management built-in.'
                },
                docs_list: 'Documentation Hub'
            },
            ru: {
                nav: { home: 'Главная', constitution: 'Конституция', yuppi: 'YUPPI', docs: 'Документация' },
                hero: { title: 'YADRO', subtitle: "Определяющий оптимизатор времени выполнения вашей архитектуры", cta: 'Начать' },
                features: { 
                    safety: 'Статическая верификация', safety_desc: 'Корректность и безопасность доказаны при компиляции.',
                    perf: 'Нулевая стоимость', perf_desc: 'Высокоуровневые конструкции, производительность ассемблера.',
                    eco: 'Экосистема YUPPI', eco_desc: 'Встроенное безопасное управление пакетами.'
                },
                docs_list: 'Центр документации'
            }
        };

        // --- Components ---

        // Home Component
        const Home = {
            template: `
                <div class="hero">
                    <div class="container">
                        <h1>{{ t('hero.title') }}</h1>
                        <p>{{ t('hero.subtitle') }}</p>
                        <router-link to="/guides/01_intro" class="btn-cta">{{ t('hero.cta') }}</router-link>
                    </div>
                </div>
                <div class="container">
                    <div class="grid">
                        <div class="card">
                            <div class="card-icon">🔒</div>
                            <h3>{{ t('features.safety') }}</h3>
                            <p>{{ t('features.safety_desc') }}</p>
                        </div>
                        <div class="card">
                            <div class="card-icon">⚡</div>
                            <h3>{{ t('features.perf') }}</h3>
                            <p>{{ t('features.perf_desc') }}</p>
                        </div>
                        <div class="card">
                            <div class="card-icon">📦</div>
                            <h3>{{ t('features.eco') }}</h3>
                            <p>{{ t('features.eco_desc') }}</p>
                        </div>
                    </div>
                </div>
            `,
            setup() {
                const { t } = useI18n();
                return { t };
            }
        };

        // Layout for Documentation (Sidebar + Content)
        const DocLayout = {
            template: `
                <div class="doc-layout">
                    <aside class="sidebar">
                        <h3>Guides</h3>
                        <router-link v-for="guide in guideMeta" 
                            :key="guide.id" 
                            :to="'/docs/guides/' + guide.id" 
                            class="sidebar-link">
                            {{ guide.title }}
                        </router-link>
                        
                        <h3>Specifications</h3>
                        <router-link v-for="(title, id) in specsList" 
                            :key="id" 
                            :to="'/docs/specs/' + id" 
                            class="sidebar-link">
                            {{ id.toUpperCase() }}
                        </router-link>
                    </aside>
                    <main class="doc-content">
                         <router-view></router-view>
                    </main>
                </div>
            `,
            setup() {
                const guideMeta = contentData.guideMeta;
                const specsList = {
                    "yup26.1.1": "Language Spec",
                    "yup26.1.2": "YUPPI Spec",
                    "yup26.1.3": "Constitution",
                    "yup26.1.4": "Compiler Implementation",
                    "yup26.1.5": "Formal Verification",
                    "yup26.1.7": "GPU Specialization",
                    "yup26.1.9": "WASM GC Integration"
                };
                return { guideMeta, specsList };
            }
        };

        // Markdown Viewer Component
        const DocViewer = {
            props: ['type', 'id'],
            template: `
                <div class="markdown-body">
                    <div v-if="content" v-html="renderedContent"></div>
                    <div v-else class="container" style="text-align:center; padding: 4rem;">
                        <h2>Document not found</h2>
                        <p>Type: {{ type }}, ID: {{ id }}</p>
                    </div>
                </div>
            `,
            setup(props) {
                const content = computed(() => {
                    if (props.type === 'guides') return contentData.guides[props.id];
                    if (props.type === 'specs') return contentData.specs[props.id];
                    return null;
                });

                const renderedContent = computed(() => {
                    if (!content.value) return '';
                    
                    // Configure Marked to use Highlight.js
                    if (typeof marked !== 'undefined') {
                        if (typeof marked.setOptions === 'function') {
                             marked.setOptions({
                                highlight: function(code, lang) {
                                    if (lang && hljs.getLanguage(lang)) {
                                        return hljs.highlight(code, { language: lang }).value;
                                    }
                                    return hljs.highlightAuto(code).value;
                                }
                            });
                        }
                    }
                    
                    let html = '';
                    if (typeof marked?.parse === 'function') html = marked.parse(content.value);
                    else if (typeof marked === 'function') html = marked(content.value);
                    else html = content.value;
                    
                    return html;
                });
                return { content, renderedContent };
            }
        };

        // Docs Landing Component
        const DocsLanding = {
            template: `
                <div class="container">
                    <h2>{{ t('docs_list') }}</h2>
                    <p>Select a guide or specification from the sidebar to start reading.</p>
                </div>
            `,
            setup() {
                const { t } = useI18n();
                return { t };
            }
        };

        // --- App Setup ---
        
        // Simple I18n Composable
        let currentLang = ref('en');
        const useI18n = () => {
            const t = (key) => {
                const keys = key.split('.');
                let val = messages[currentLang.value];
                for (const k of keys) {
                    val = val ? val[k] : null;
                }
                return val || key;
            };
            return { t, lang: currentLang };
        };

        const routes = [
            { path: '/', component: Home },
            { 
                path: '/docs', 
                component: DocLayout,
                children: [
                    { path: '', component: DocsLanding },
                    { path: 'guides/:id', component: DocViewer, props: route => ({ type: 'guides', id: route.params.id }) },
                    { path: 'specs/:id', component: DocViewer, props: route => ({ type: 'specs', id: route.params.id }) }
                ]
            },
            // Legacy/Direct shortcuts
            { path: '/constitution', redirect: '/docs/specs/yup26.1.3' },
            { path: '/yuppi', redirect: '/docs/specs/yup26.1.2' },
            { path: '/yup/:id', redirect: to => '/docs/specs/' + to.params.id }
        ];

        const router = createRouter({
            history: createWebHashHistory(),
            routes,
            scrollBehavior(to, from, savedPosition) {
                return { top: 0 };
            }
        });

        const app = createApp({
            setup() {
                const theme = ref('dark');
                const { t, lang } = useI18n();

                const toggleTheme = () => {
                    theme.value = theme.value === 'dark' ? 'light' : 'dark';
                    document.documentElement.setAttribute('data-theme', theme.value);
                };

                const toggleLang = () => {
                    lang.value = lang.value === 'en' ? 'ru' : 'en';
                };

                return { theme, toggleTheme, lang, toggleLang, t };
            }
        });

        app.use(router);
        app.mount('#app');
    </script>
</body>
</html>
"""
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.writelines(new_content_lines)
        f.write(new_script)
        
    print("Successfully updated docs.html")

if __name__ == "__main__":
    main()
